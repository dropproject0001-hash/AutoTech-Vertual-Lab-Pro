# Autoelectric Lab

An automotive ECU diagnostics workbench with PCB inspection, pinout and wiring references, and virtual circuit tools.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/autoelectric-lab run dev` — run the Autoelectric Lab web app
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Optional env: `GEMINI_API_KEY` enables live Gemini chat and image analysis; without it, the app stays in offline mode.
- The diagnostic workspace uses included sample data and browser-local project storage; it does not require sign-in or a database.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/autoelectric-lab/` — technician workbench web app
- `artifacts/api-server/src/routes/autoelectric.ts` — health, engineering-assistant, and schematic-analysis endpoints
- `lib/api-spec/openapi.yaml` — source of truth for generated API types and validation schemas
- `artifacts/autoelectric-lab/src/data/` — bundled vehicle, wiring, and sample PCB reference data

## Product

- Supports ECU pinout exploration, wiring diagrams, virtual bench readings, DTC troubleshooting, PCB annotation, and test reports.
- Live AI is optional. Without `GEMINI_API_KEY`, chat returns offline safety guidance and image analysis returns no unverified detections.

## Architecture decisions

- Uploaded PCB images and annotations remain in browser-local storage; no user login or project database is configured.
- The API accepts base64 image JSON up to 32 MB to support the app's 20 MB upload limit.
- Live Gemini access is optional and uses the `GEMINI_API_KEY` secret; no key is included in the project.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
