import React, { useEffect, useState } from 'react';
import { BookOpen, ExternalLink, ShieldAlert } from 'lucide-react';
import type { SavedReference } from '../services/referenceLibrary';

interface ReferencePinoutProps {
  reference: SavedReference | null;
  onOpenLibrary: () => void;
}

export const ReferencePinout: React.FC<ReferencePinoutProps> = ({ reference, onOpenLibrary }) => {
  const [connectorId, setConnectorId] = useState<string | null>(null);
  const [pinNumber, setPinNumber] = useState<number | null>(null);
  const refId = reference?.profile.id;

  useEffect(() => { setConnectorId(null); setPinNumber(null); }, [reference]);

  if (!reference) {
    return (
      <section role="status" className="m-4 flex min-h-[280px] flex-col items-center justify-center rounded-2xl border border-amber-500/20 bg-workstation-panel/70 p-8 text-center">
        <ShieldAlert className="mb-4 h-9 w-9 text-amber-400" />
        <h2 className="text-lg font-semibold text-white">No transcript selected</h2>
        <p className="mt-2 max-w-xl text-sm text-slate-400">Pins appear only from a reviewed transcript you saved. Nothing is assumed.</p>
        <button type="button" data-testid="button-open-library" onClick={onOpenLibrary} className="mt-5 inline-flex items-center gap-2 rounded-lg border border-cyan-500/30 bg-cyan-950/40 px-4 py-2 text-sm text-cyan-200 hover:bg-cyan-900/50">
          <BookOpen className="h-4 w-4" /> Open reference library
        </button>
      </section>
    );
  }

  const p = reference.profile;
  const connector = p.connectors.find((c) => c.id === connectorId) ?? p.connectors[0];
  const pins = [...connector.pins].sort((a, b) => a.number - b.number);
  const pin = pins.find((x) => x.number === pinNumber) ?? null;
  const meta: [string, string][] = [
    ['Make', p.make], ['Model', p.model], ['Years', p.productionYears], ['Chassis', p.chassisCode], ['Engine', p.engineCode],
    ['Transmission', p.transmission], ['Market', p.market], ['ECU part no.', p.ecuPartNumber], ['Hardware no.', p.hardwareNumber],
  ];

  return (
    <div className="space-y-5 p-4 md:p-6">
      <div role="note" className="flex gap-3 rounded-xl border border-amber-500/30 bg-amber-950/30 p-4 text-sm text-amber-100">
        <ShieldAlert className="h-5 w-5 shrink-0 text-amber-400" />
        <p>USER TRANSCRIPT, reviewed by {reference.reviewedBy} on {new Date(reference.reviewedAt).toLocaleString()}. Not independently OEM verified. Confirm against the cited source before probing.</p>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_1.4fr]">
        <section className="space-y-4 rounded-2xl border border-white/5 bg-workstation-panel/70 p-4">
          <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            {meta.map(([k, v]) => (<div key={k}><dt className="text-[11px] uppercase tracking-wider text-slate-500">{k}</dt><dd className="font-mono text-slate-100" data-testid={`text-meta-${k}`}>{v}</dd></div>))}
          </dl>
          <div className="border-t border-white/5 pt-3 text-sm">
            <p className="text-[11px] uppercase tracking-wider text-slate-500">Cited source</p>
            <a href={p.source.url} target="_blank" rel="noopener noreferrer" data-testid="link-reference-source" className="inline-flex items-center gap-1 text-cyan-200 hover:underline">{p.source.title} <ExternalLink className="h-3 w-3" /></a>
            <p className="text-xs text-slate-400">{p.source.publisher}, rev. {p.source.revision}. Locator: {p.source.locator}</p>
            <p className="text-xs text-slate-400">Applicability: {p.source.marketApplicability}</p>
            <p className="text-xs text-slate-400">Reuse: {p.source.reusePermission}</p>
          </div>
        </section>

        <section className="space-y-4 rounded-2xl border border-white/5 bg-workstation-panel/70 p-4">
          <div className="flex flex-wrap gap-2" role="tablist" aria-label="Connectors">
            {p.connectors.map((c) => (
              <button key={c.id} type="button" role="tab" aria-selected={c.id === connector.id} data-testid={`button-connector-${c.id}`}
                onClick={() => { setConnectorId(c.id); setPinNumber(null); }}
                className={`rounded-lg px-3 py-1.5 text-sm ${c.id === connector.id ? 'bg-workstation-accent text-slate-950' : 'border border-white/10 text-slate-300 hover:bg-white/5'}`}>
                {c.id} / {c.name}
              </button>
            ))}
          </div>
          <div className="text-sm">
            <p className="text-slate-300">Orientation as transcribed: <span className="font-mono text-slate-100">{connector.orientation}</span></p>
            <p data-testid="text-coverage" className="mt-1 font-mono text-xs text-slate-400">
              {connector.pins.length} of {connector.cavityCount} cavities transcribed; {connector.cavityCount - connector.pins.length} unknown (not documented, not assumed NC).
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-[11px] uppercase tracking-wider text-slate-500"><tr><th className="py-1 pr-3">Pin</th><th className="pr-3">Label</th><th className="pr-3">Function</th><th>Source locator</th></tr></thead>
              <tbody>
                {pins.map((x) => (
                  <tr key={x.number} data-testid={`row-pin-${connector.id}-${x.number}`} onClick={() => setPinNumber(x.number)} tabIndex={0}
                    onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') setPinNumber(x.number); }}
                    className={`cursor-pointer border-t border-white/5 ${pin?.number === x.number ? 'bg-cyan-950/50' : 'hover:bg-white/5'}`}>
                    <td className="py-1.5 pr-3 font-mono text-workstation-accent">{x.number}</td><td className="pr-3 text-slate-100">{x.label}</td>
                    <td className="pr-3 text-slate-300">{x.function}</td><td className="font-mono text-xs text-slate-500">{x.sourceLocator}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {pin && (
            <div data-testid="panel-selected-pin" className="rounded-lg border border-cyan-500/30 bg-cyan-950/30 p-3 text-sm">
              <p className="font-mono text-cyan-100">{connector.id}:{pin.number} / {pin.label}</p>
              <p className="text-slate-300">{pin.function}</p>
              <p className="text-xs text-slate-500">Cited at: {pin.sourceLocator}. No voltage, wire colour, or threshold is recorded in this transcript.</p>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

export default ReferencePinout;
