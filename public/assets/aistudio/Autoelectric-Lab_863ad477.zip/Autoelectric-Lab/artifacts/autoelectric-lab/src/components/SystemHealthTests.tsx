import React, { useState } from 'react';
import { solveResistor } from '../services/circuitMath';
import { SOURCE_DIRECTORY } from '../data/sourceDirectory';
import { VEHICLE_DATABASE, DTC_DATABASE } from '../data/automotiveDatabase';

export function SystemHealthTests({onClose}: {onClose:()=>void}) {
  const [results,setResults] = useState<{name:string;passed:boolean}[]>([]);
  const run = () => {
    const r = solveResistor(12,120);
    let rejectsZero = false; try {solveResistor(12,0);} catch {rejectsZero=true;}
    const tests = [
      {name:'Ideal resistor: 12 V / 120 ohm = 0.1 A and 1.2 W',passed:Math.abs(r.currentAmps-0.1)<1e-12 && Math.abs(r.powerWatts-1.2)<1e-12},
      {name:'Zero resistance is rejected by this finite-resistor model',passed:rejectsZero},
      {name:'Source directory uses HTTPS links and unique identifiers',passed:SOURCE_DIRECTORY.every(s=>s.url.startsWith('https://')) && new Set(SOURCE_DIRECTORY.map(s=>s.id)).size===SOURCE_DIRECTORY.length},
      {name:'Unsupported bundled vehicle and DTC records are absent',passed:VEHICLE_DATABASE.length===0 && DTC_DATABASE.length===0},
    ]; setResults(tests);
  };
  return <div role="dialog" aria-modal="true" aria-label="Software checks" className="fixed inset-0 z-50 bg-black/80 p-4 flex items-center justify-center text-slate-100">
    <section className="bg-slate-900 border border-slate-700 rounded-xl p-5 max-w-xl w-full space-y-4">
      <header className="flex justify-between"><h2 className="font-bold text-lg">Software sanity checks</h2><button aria-label="Close software checks" onClick={onClose}>Close</button></header>
      <p className="text-amber-200 text-sm">These checks validate a few software invariants only. Passing them does not verify pinout accuracy, ECU operation, source authenticity, calibration, or the full application.</p>
      <button onClick={run} className="px-4 py-2 bg-cyan-400 text-slate-950 rounded font-bold">Run software checks</button>
      <ul className="space-y-3">{results.map(r=><li key={r.name} className="text-sm">{r.passed?'PASS':'FAIL'} — {r.name}</li>)}</ul>
    </section>
  </div>;
}
