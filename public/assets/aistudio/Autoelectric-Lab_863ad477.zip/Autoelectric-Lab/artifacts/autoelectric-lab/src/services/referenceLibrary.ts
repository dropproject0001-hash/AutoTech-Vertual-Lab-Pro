import { z } from 'zod';
import type { VehicleProfile } from '../types/automotive';

const text = z.string().trim().min(1).max(2000);
const sourceSchema = z.object({
  title: text,
  publisher: text,
  url: z.string().url().refine((url) => url.startsWith('https://'), 'Use an HTTPS source URL'),
  revision: text,
  locator: text,
  marketApplicability: text,
  reusePermission: text,
});
const pinSchema = z.object({
  number: z.number().int().positive().max(500),
  label: text,
  function: text,
  sourceLocator: text,
});
const connectorSchema = z.object({
  id: text,
  name: text,
  cavityCount: z.number().int().positive().max(500),
  orientation: text,
  pins: z.array(pinSchema).min(1).max(500),
});
export const profileSchema = z.object({
  id: z.string().regex(/^[a-z0-9-]{3,100}$/),
  make: text,
  model: text,
  productionYears: text,
  chassisCode: text,
  engineCode: text,
  transmission: text,
  market: text,
  ecuPartNumber: text,
  hardwareNumber: text,
  source: sourceSchema,
  connectors: z.array(connectorSchema).min(1).max(10),
}).superRefine((profile, ctx) => {
  const connectors = new Set<string>();
  for (const c of profile.connectors) {
    if (connectors.has(c.id)) ctx.addIssue({ code: 'custom', message: `Duplicate connector ${c.id}` });
    connectors.add(c.id);
    const pins = new Set<number>();
    for (const p of c.pins) {
      if (pins.has(p.number) || p.number > c.cavityCount) {
        ctx.addIssue({ code: 'custom', message: `Duplicate or out-of-bounds pin ${c.id}:${p.number}` });
      }
      pins.add(p.number);
    }
  }
});
export type ReferenceProfile = z.infer<typeof profileSchema>;
export interface SavedReference {
  profile: ReferenceProfile;
  reviewedBy: string;
  reviewedAt: string;
  status: 'USER_TRANSCRIPT';
}
const savedSchema = z.object({
  profile: profileSchema,
  reviewedBy: text,
  reviewedAt: z.string().datetime(),
  status: z.literal('USER_TRANSCRIPT'),
});
const KEY = 'autoelectric_user_references_v1';
export function parseReference(raw: string): ReferenceProfile {
  if (raw.length > 256_000) throw new Error('Reference JSON exceeds 256 KB.');
  return profileSchema.parse(JSON.parse(raw));
}
export function loadReferences(): SavedReference[] {
  const raw = localStorage.getItem(KEY);
  return raw ? z.array(savedSchema).parse(JSON.parse(raw)) : [];
}
export function saveReferences(references: SavedReference[]) {
  localStorage.setItem(KEY, JSON.stringify(z.array(savedSchema).parse(references)));
}
export function toVehicleProfile(reference: SavedReference): VehicleProfile {
  const p = reference.profile;
  const identity = JSON.stringify([p.id,p.ecuPartNumber,p.hardwareNumber,p.engineCode,p.chassisCode,p.productionYears,p.transmission,p.market]);
  let hash = 2166136261;
  for(const character of identity)hash=Math.imul(hash ^ character.charCodeAt(0),16777619);
  return {
    id: `user-${p.id}-${(hash>>>0).toString(16)}`, make: p.make, model: p.model, productionYears: p.productionYears,
    chassisCode: p.chassisCode, engineCode: p.engineCode, engineDisp: 'Not recorded',
    fuelType: 'UNKNOWN', market: p.market, ecuManufacturer: 'UNKNOWN', ecuModel: 'User-transcribed reference',
    ecuPartNumber: p.ecuPartNumber, hardwareNumber: p.hardwareNumber, socketCount: p.connectors.length,
    // This adapter supplies identity only. Numerical simulation never consumes user transcripts.
    connectors: [],
    description: `User transcript; reviewed by ${reference.reviewedBy}. Not independently OEM-verified.`,
    verifiedStatus: 'UNVERIFIED', pinoutSource: `${p.source.title}, ${p.source.locator}. ${p.source.url}`,
    completenessReports: [],
  };
}
