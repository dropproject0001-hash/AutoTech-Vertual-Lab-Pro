import React, { useState, useRef, useEffect } from 'react';
import type { BenchReading } from './types/automotive';
import { UNSPECIFIED_VEHICLE_PROFILE } from './data/unspecifiedVehicle';
import { AppShell } from './components/AppShell';
import { Overview } from './components/Overview';
import { ComponentReadingsLab } from './components/ComponentReadingsLab';
import { AiEngineeringAssistant } from './components/AiEngineeringAssistant';
import { SchematicPcbScanner } from './components/SchematicPcbScanner';
import { TestReportModal } from './components/TestReportModal';
import { SystemHealthTests } from './components/SystemHealthTests';
import { SourceRequiredState } from './components/SourceRequiredState';
import { ReferenceLibrary } from './components/ReferenceLibrary';
import { VehicleCoverageCatalogue } from './components/VehicleCoverageCatalogue';
import { ReferencePinout } from './components/ReferencePinout';
import { downloadBrowserRecovery } from './services/browserRecovery';
import { GenericCircuitLab } from './components/GenericCircuitLab';
import { loadReadings, persistReadings, readingSchema } from './services/readingRecords';
import { toVehicleProfile, type SavedReference } from './services/referenceLibrary';

export default function App() {
  const [activeTab, setActiveTab] = useState(() =>
    new URLSearchParams(window.location.search).get('tab') === 'vehicle-catalogue'
      ? 'vehicle-catalogue'
      : 'overview',
  );
  const [reference, setReference] = useState<SavedReference | null>(null);
  const selectedVehicle = reference ? toVehicleProfile(reference) : UNSPECIFIED_VEHICLE_PROFILE;
  const [showReport, setShowReport] = useState(false);
  const [showTests, setShowTests] = useState(false);
  const [initial] = useState(() => {
    try { return { records: loadReadings(), error: '' }; }
    catch { return { records: [] as BenchReading[], error: 'Saved readings could not be read. Existing browser data has not been replaced; new records will be session-only.' }; }
  });
  const [allReadings, setAllReadings] = useState(initial.records);
  const recordsRef=useRef(initial.records);
  const [storageStatus, setStorageStatus] = useState(initial.error);
  const [focusedReading, setFocusedReading] = useState<BenchReading | null>(null);
  const readings = allReadings.filter(r => r.vehicleId === selectedVehicle.id);
  useEffect(()=>{
    const refresh=(e:StorageEvent)=>{
      if(e.key!=='autoelectric_readings_v1')return;
      try {const records=loadReadings();recordsRef.current=records;setAllReadings(records);setStorageStatus('Readings refreshed from another browser tab.');}
      catch {setStorageStatus('Another tab changed saved readings, but the data could not be read. Current records have been kept.');}
    };
    window.addEventListener('storage',refresh);return ()=>window.removeEventListener('storage',refresh);
  },[]);
  const updateReadings = (transform: (previous: BenchReading[]) => BenchReading[]) => {
      const next = transform(recordsRef.current);
      try {
        if (initial.error) throw new Error(initial.error);
        persistReadings(next);
        setStorageStatus('Saved in this browser only. Export a report before clearing site data or changing devices.');
      } catch {
        setStorageStatus('NOT SAVED: this change exists in this tab only. Export a report before closing. Existing saved data was not replaced.');
      }
      recordsRef.current=next;setAllReadings(next);
  };
  const addReading = (r: BenchReading) => {
    try {
      const validated = readingSchema.parse({ ...r, vehicleId: selectedVehicle.id,
        vehicleDescription:`${selectedVehicle.make} ${selectedVehicle.model} / ECU ${selectedVehicle.ecuPartNumber} / ${selectedVehicle.engineCode} / ${selectedVehicle.productionYears}` });
      updateReadings(previous => [validated, ...previous.filter(item => item.id !== validated.id)]);
    } catch {
      setStorageStatus('The record was rejected because it contains invalid or missing values.');
    }
  };
  const openLibrary = () => setActiveTab('database');
  const logProps = {
    vehicle: selectedVehicle, readings, historyReadings:allReadings, onAddReading: addReading,
    onDeleteReading: (id: string) => updateReadings(previous => previous.filter(r => r.id !== id)),
    onExportPdf: () => setShowReport(true), onSelectPinForBench: () => setActiveTab('pinouts'),
  };
  return <AppShell activeTab={activeTab} setActiveTab={setActiveTab} selectedVehicle={selectedVehicle}
    onOpenVehicleModal={openLibrary} onOpenReportModal={() => setShowReport(true)} onOpenTestsModal={() => setShowTests(true)}>
    <div className="h-full flex flex-col">
      <div className="shrink-0 border-b border-amber-500/20 bg-amber-950/20 px-4 py-2 text-xs text-amber-200">
        No independently verified Philippine ECU pinouts are bundled. User transcripts are not OEM certification. No hardware is connected.
        <button className="ml-3 underline" onClick={()=>{try{downloadBrowserRecovery();setStorageStatus('Raw browser recovery snapshot downloaded. It may contain private notes/images; it is not an importable project backup.');}catch{setStorageStatus('Browser storage could not be read; no recovery file was created.');}}}>Download raw recovery snapshot</button>
      </div>
      {storageStatus && <p role="status" className="shrink-0 px-4 py-2 text-xs text-cyan-200 bg-slate-900">{storageStatus}</p>}
      <div className="min-h-0 flex-1">
        {activeTab === 'overview' && <Overview vehicle={selectedVehicle} readings={readings} onNavigate={setActiveTab} />}
        {activeTab === 'database' && <div className="h-full overflow-y-auto"><ReferenceLibrary onSelect={ref => { setReference(ref); setFocusedReading(null); setActiveTab('pinouts'); }} onReferencesChanged={refs=>{if(reference)setReference(refs.find(r=>r.profile.id===reference.profile.id) ?? null);}} /></div>}
        {activeTab === 'vehicle-catalogue' && <div className="h-full overflow-y-auto"><VehicleCoverageCatalogue /></div>}
        {activeTab === 'pinouts' && <div className="h-full overflow-y-auto"><ReferencePinout reference={reference} onOpenLibrary={openLibrary} /></div>}
        {activeTab === 'workbench' && <div className="h-full overflow-y-auto"><GenericCircuitLab vehicle={selectedVehicle} onLogReading={addReading} /></div>}
        {activeTab === 'scanner' && <SchematicPcbScanner vehicle={selectedVehicle} onSendPinToBench={() => setActiveTab('pinouts')} />}
        {activeTab === 'wiring' && <SourceRequiredState title="Philippine wiring coverage is not verified yet"
          detail="No market-correct wiring document has passed the source checks. A bench-programming connection guide is not a full vehicle harness diagram. You can inspect your own document and record observed paths in Manual PCB Review."
          onOpenDocuments={() => setActiveTab('scanner')} />}
        {activeTab === 'dtc' && <SourceRequiredState title="No verified vehicle-specific DTC procedures are loaded"
          detail="The previous unsupported code definitions and diagnostic steps have been removed. Exact model, year, ECU and matching OEM diagnostic documentation are required. Do not infer a failed component from a code alone."
          onOpenDocuments={openLibrary} />}
        {(activeTab === 'readings' || activeTab === 'reports') && <ComponentReadingsLab {...logProps} />}
        {activeTab === 'ai-assistant' && <AiEngineeringAssistant vehicle={selectedVehicle} selectedPin={null} readings={readings}
          activeFault={{id:'none',name:'None',description:'No hardware or ECU simulation connected',faultType:'NONE',affectedCircuits:[]}}
          reference={reference} focusedReading={focusedReading} onOpenLibrary={openLibrary} />}
      </div>
    </div>
    {showReport && <TestReportModal vehicle={selectedVehicle} readings={readings} onClose={() => setShowReport(false)} />}
    {showTests && <SystemHealthTests onClose={() => setShowTests(false)} />}
  </AppShell>;
}
