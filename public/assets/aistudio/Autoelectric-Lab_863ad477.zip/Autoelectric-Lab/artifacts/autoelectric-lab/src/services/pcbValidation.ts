import { z } from 'zod';
const text = z.string();
const coord = z.number().finite().min(0).max(1000);
const bbox = z.object({ xmin: coord, ymin: coord, xmax: coord, ymax: coord })
  .refine(b => b.xmin < b.xmax && b.ymin < b.ymax, 'Bounding box must have positive size');
const verification = z.enum(['VERIFIED', 'CROSS_REFERENCED', 'UNVERIFIED', 'UNKNOWN']);
const document = z.object({
  id: text.min(1), name: text, documentType: z.enum(['ELECTRICAL_SCHEMATIC','PCB_LAYOUT','PHYSICAL_PCB_PHOTO','CONNECTOR_PINOUT','TECHNICAL_DOC','UNKNOWN']),
  imageUrl: text, originalFileName: text, fileSizeMb: z.number().nonnegative(),
  uploadTimestamp: text, widthPx: z.number().positive(), heightPx: z.number().positive(), description: text,
}).passthrough();
const component = z.object({
  id: text.min(1), refDes: text.min(1), category: z.enum(['RESISTOR','CAPACITOR','ELECTROLYTIC_CAP','CERAMIC_CAP','DIODE','ZENER_DIODE','TVS_DIODE','TRANSISTOR','MOSFET','IGBT','VOLTAGE_REGULATOR','DCDC_CONVERTER','OP_AMP','COMPARATOR','MICROCONTROLLER','EEPROM','CAN_TRANSCEIVER','LIN_TRANSCEIVER','INJECTOR_DRIVER_IC','IGNITION_DRIVER_IC','RELAY_DRIVER','POWER_MANAGEMENT_IC','CURRENT_SENSE_RESISTOR','INDUCTOR','TRANSFORMER','CRYSTAL','FUSE','CONNECTOR','TEST_POINT','UNKNOWN']),
  marking: text, decodedValue: text, packageType: text, bbox, confidenceScore: z.number().min(0).max(1),
  verificationStatus: verification, circuitFunction: text, connectedNetIds: z.array(text), sourceImageId: text,
}).passthrough();
const net = z.object({
  id: text.min(1), name: text, signalType: z.enum(['UNKNOWN','POWER_BATT','POWER_IGN','GROUND_POWER','GROUND_LOGIC','SENSOR_5V_REF','SENSOR_GROUND','SENSOR_ANALOG_IN','SENSOR_DIGITAL_IN','SENSOR_VR_IN','ACTUATOR_LOW_SIDE','ACTUATOR_HIGH_SIDE','CAN_HIGH','CAN_LOW','LIN_BUS','K_LINE','RESERVED_NC']),
  connectedComponentIds: z.array(text), connectedTerminalIds: z.array(text), tracePoints: z.array(z.object({x:coord,y:coord})),
  verificationStatus: verification, isComplete: z.boolean(),
}).passthrough();
const annotation = z.object({
  id: text.min(1), x: coord, y: coord, text, category: z.enum(['NOTE','CORROSION','BURNT_COMPONENT','TEST_POINT_PIN','BROKEN_TRACE']), author: text, timestamp: text,
}).passthrough();
const audit = z.object({
  id:text, timestamp:text, technicianId:text, componentId:text, action:z.enum(['CREATE','UPDATE','DELETE','VERIFY']),
  fieldChanged:text, previousValue:text, newValue:text, rationale:text,
});
export const pcbProjectSchema = z.object({
  id: text.min(1), name:text, vehicleModel:text, ecuModel:text, ecuPartNumber:text,
  documents: z.array(document), activeDocumentId:text, components:z.array(component), nets:z.array(net),
  annotations:z.array(annotation).optional(), auditHistory:z.array(audit), createdAt:text,updatedAt:text,notes:text,
}).passthrough();
export const pcbProjectsSchema = z.array(pcbProjectSchema);
