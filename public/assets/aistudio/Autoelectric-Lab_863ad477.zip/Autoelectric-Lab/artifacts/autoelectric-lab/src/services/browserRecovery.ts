/** Raw user-data export for manual recovery, not an executable or trusted profile. */
export function captureBrowserData(storage:Storage){
  const entries:Record<string,string>={};
  for(let i=0;i<storage.length;i++){
    const key=storage.key(i);
    if(key?.startsWith('autoelectric_')){
      const raw=storage.getItem(key);
      if(raw!==null)entries[key]=raw;
    }
  }
  return {format:'autoelectric-raw-recovery-v1',exportedAt:new Date().toISOString(),
    notice:'Raw browser-local data. May include private notes/images. Not an importable project backup. Preserve before manual repair.',entries};
}
export function downloadBrowserRecovery(){
  const payload=captureBrowserData(localStorage);
  const url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));
  const a=document.createElement('a');a.href=url;a.download='autoelectric-raw-recovery.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
