import React, { useState } from 'react';
import { jsPDF } from 'jspdf';
import type { VehicleProfile, BenchReading } from '../types/automotive';
import { summarizeReadings } from '../services/readingRecords';

export function TestReportModal({ vehicle, readings, onClose }: { vehicle: VehicleProfile; readings: BenchReading[]; onClose: () => void }) {
  const [technician, setTechnician] = useState('');
  const [order, setOrder] = useState('');
  const [identifier, setIdentifier] = useState('');
  const [conclusion, setConclusion] = useState('');
  const [error, setError] = useState('');
  const summary = summarizeReadings(readings);
  const exportPdf = () => {
    try {
      const pdf = new jsPDF(); let y = 20;
      const write = (text: string, size = 10) => {
        pdf.setFontSize(size);
        // The built-in PDF font is not a Unicode font.
        const safe = text.replaceAll('Ω', 'ohm').replaceAll('—', '-').replaceAll('–', '-').replaceAll('·', '/').replace(/[^\x20-\x7E\n]/g, '?');
        const lines = pdf.splitTextToSize(safe, 180) as string[];
        for (const line of lines) { if (y > 275) { pdf.addPage(); y = 20; } pdf.text(line, 15, y); y += size * 0.48; } y += 3;
      };
      write('AUTOELECTRIC LAB - OBSERVATION RECORD', 15);
      write('Not a calibration certificate, signed approval, or hardware diagnosis.');
      write(`Generated: ${new Date().toISOString()}`);
      write(`Recorded by: ${technician.trim() || 'Not provided'} | Order: ${order.trim() || 'Not provided'}`);
      write(`Vehicle identifier: ${identifier.trim() || 'Not provided'}`);
      write(`${vehicle.make} ${vehicle.model} / ${vehicle.productionYears} / ${vehicle.engineCode}`);
      write(`ECU part: ${vehicle.ecuPartNumber} / Hardware: ${vehicle.hardwareNumber}`);
      write(`Profile source: ${vehicle.pinoutSource || 'No source-backed profile loaded'}`);
      write(`${summary.total} records; ${summary.pass} within comparison range; ${summary.faults} flagged; ${summary.unassessed} unassessed; ${summary.simulated} simulated.`);
      write('A range comparison does not prove serviceability. Simulations are not physical measurements. User-entered information has not been independently verified.');
      for (const [index, r] of readings.entries()) {
        write(`${index + 1}. ${r.pinLabel} / ${r.connectorId ?? 'Unmapped connector'} / Pin ${r.pinNumber ?? 'not recorded'}`, 11);
        write(`Context: ${r.vehicleDescription ?? r.vehicleId ?? 'Not recorded'}`);
        write(`Origin: ${r.source ?? 'Not recorded'} | ${r.timestamp} | By: ${r.technicianName || 'Not provided'}`);
        write(`Mode: ${r.measurementType} | Value: ${r.measuredValue} ${r.unit} | Comparison status: ${r.status}`);
        write(r.expectedMin == null || r.expectedMax == null ? 'No comparison range supplied.' : `Entered comparison range: ${r.expectedMin} to ${r.expectedMax} ${r.unit}`);
        write(`Range source / conditions: ${r.comparisonSource || 'None provided'}`);
        write(`Notes: ${r.notes || 'None provided'}`);
      }
      if (!readings.length) write('No observations recorded. No diagnostic verdict can be made.');
      write(`User conclusion: ${conclusion.trim() || 'No conclusion provided.'}`);
      pdf.save(`Autoelectric_Observation_${order.replace(/[^a-z0-9_-]/gi, '').slice(0,60) || 'record'}.pdf`);
    } catch (err) { setError(err instanceof Error ? err.message : 'PDF could not be generated.'); }
  };
  return <div role="dialog" aria-modal="true" aria-label="Observation report" className="fixed inset-0 z-50 bg-black/80 p-4 flex items-center justify-center">
    <section className="bg-slate-900 text-slate-100 rounded-xl p-5 max-w-2xl w-full max-h-[90vh] overflow-auto border border-slate-700 space-y-4">
      <header className="flex justify-between gap-3"><h2 className="text-lg font-bold">Export observation report</h2><button aria-label="Close report" onClick={onClose}>Close</button></header>
      <p className="text-amber-200 text-sm">An unsigned observation record, not an official calibration certificate or proof of ECU serviceability. All {summary.simulated} simulated records are identified as simulated.</p>
      <p className="text-xs text-slate-400">The PDF uses a basic Latin font. Unsupported characters in free text are replaced with “?”. Export JSON from the records page to preserve exact text.</p>
      {[['Technician (optional)', technician, setTechnician], ['Order number (optional)', order, setOrder], ['Vehicle identifier (optional)', identifier, setIdentifier]] .map(([label,value,setter]) => <label className="block text-sm" key={String(label)}>{String(label)}<input aria-label={String(label)} className="block mt-1 bg-slate-950 border border-slate-700 rounded p-2 w-full" value={value as string} maxLength={200} onChange={e => (setter as React.Dispatch<React.SetStateAction<string>>)(e.target.value)} /></label>)}
      <p className="text-sm">{summary.total} records · {summary.pass} within range · {summary.faults} flagged · {summary.unassessed} unassessed</p>
      <label className="block text-sm">Your conclusion (optional)<textarea aria-label="Your conclusion" className="block mt-1 bg-slate-950 border border-slate-700 rounded p-2 w-full" rows={4} maxLength={10000} value={conclusion} onChange={e => setConclusion(e.target.value)} /></label>
      {error && <p role="alert" className="text-rose-300">{error}</p>}
      <button onClick={exportPdf} className="px-4 py-2 bg-cyan-400 text-slate-950 font-bold rounded">Download PDF record</button>
    </section>
  </div>;
}
