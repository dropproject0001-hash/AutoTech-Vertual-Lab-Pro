import React, { useState, useEffect, useRef } from 'react';
import { VehicleProfile } from '../types/automotive';
import type { DocumentType, ElectricalNet } from '../types/pcbScanner';
import { 
  PCBProject, 
  DetectedComponent, 
  UploadedDocument, 
  TechnicianAnnotation 
} from '../types/pcbScanner';
import { PcbStorageEngine } from '../services/pcbStorageEngine';
import { removeComponentObservation, removeObservedPath, removeDocumentNote } from '../services/manualProjectRecords';
import { LayerManager } from '../services/pcbLayerManagerService';
import { usePcbLayerManager } from '../hooks/usePcbLayerManager';
import { PcbCanvasOverlay } from './PcbCanvasOverlay';
import { FloatingComponentHud } from './FloatingComponentHud';
import { BoardComparisonView } from './BoardComparisonView';
import { NetTracingDrawer } from './NetTracingDrawer';
import { PcbManualCorrectionModal } from './PcbManualCorrectionModal';
import { PcbReportExportModal } from './PcbReportExportModal';
import { PcbAnnotationModal } from './PcbAnnotationModal';
import { SourceRequiredState } from './SourceRequiredState';
import { ManualObservationEditor } from './ManualObservationEditor';
import { parseProjectBackup, downloadProjectBackup } from '../services/projectBackup';
import { 
  FileText, 
  Upload, 
  Layers, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Columns, 
  Activity, 
  Edit3, 
  Download, 
  Cpu,
  Eye,
  EyeOff,
  PlusCircle,
  Sparkles,
  SlidersHorizontal,
  Sun,
  Maximize2
} from 'lucide-react';

const createBlankProject = (
  id = 'manual-review-workspace',
  name = 'Manual document review',
): PCBProject => {
  const now = new Date().toISOString();
  return {
    id,
    name,
    vehicleModel: 'Not specified',
    ecuModel: 'Not specified',
    ecuPartNumber: 'Not specified',
    documents: [],
    activeDocumentId: '',
    components: [],
    nets: [],
    annotations: [],
    auditHistory: [],
    createdAt: now,
    updatedAt: now,
    notes: 'No component, net, pinout, or specification claims are inferred.',
  };
};

interface SchematicPcbScannerProps {
  vehicle: VehicleProfile;
  onSendPinToBench: (pinNumber: number) => void;
}

export const SchematicPcbScanner: React.FC<SchematicPcbScannerProps> = ({
  vehicle,
  onSendPinToBench,
}) => {
  const [initial] = useState(() => {
    try {
      const saved = PcbStorageEngine.loadProjects();
      return { projects: saved.length ? saved : [createBlankProject()], error: null as string | null };
    } catch (err) {
      return { projects: [createBlankProject()], error: err instanceof Error ? err.message : 'Saved projects could not be loaded.' };
    }
  });
  const [projects, setProjects] = useState<PCBProject[]>(initial.projects);
  const projectsRef=useRef(projects);
  projectsRef.current=projects;

  const [activeProjectId, setActiveProjectId] = useState<string>(projects[0]?.id ?? 'manual-review-workspace');
  const activeProject = projects.find((p) => p.id === activeProjectId) || projects[0]!;
  const activeDoc = activeProject?.documents.find((d) => d.id === activeProject.activeDocumentId) || activeProject?.documents[0];

  // State-Based Layer Manager Hook (Persists visibility, opacity, high-contrast, zoom & pan offsets)
  const {
    layers,
    zoomLevel,
    panOffset,
    toggleLayer,
    setLayerProperty,
    applyPreset,
    handleZoom,
    resetZoomAndPan,
    updatePan,
    storageWarning,
  } = usePcbLayerManager(activeProjectId);

  // Selection state
  const [selectedComponentId, setSelectedComponentId] = useState<string | null>(
    activeProject?.components[0]?.id || null
  );
  const [selectedNetId, setSelectedNetId] = useState<string | null>(null);
  const [selectedAnnotationId, setSelectedAnnotationId] = useState<string | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(true);

  // Technician Annotation Mode & Coordinates
  const [isAddingAnnotation, setIsAddingAnnotation] = useState<boolean>(false);
  const [newAnnotationCoords, setNewAnnotationCoords] = useState<{ x: number; y: number } | null>(null);

  // Modals & Drawers
  const [showComparison, setShowComparison] = useState<boolean>(false);
  const [showNetTracer, setShowNetTracer] = useState<boolean>(false);
  const [showCorrectionModal, setShowCorrectionModal] = useState<boolean>(false);
  const [showComponentDetails,setShowComponentDetails]=useState(true);
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisError, setAnalysisError] = useState<string | null>(initial.error);
  const [analysisSuccess, setAnalysisSuccess] = useState<string | null>(null);
  const [uploadDocumentType, setUploadDocumentType] = useState<DocumentType>('UNKNOWN');
  const [editorKind, setEditorKind] = useState<'component' | 'net' | null>(null);
  const [editingNet, setEditingNet] = useState<ElectricalNet | undefined>();
  const [editingAnnotation, setEditingAnnotation] = useState<TechnicianAnnotation | undefined>();
  useEffect(()=>{
    const refresh=(e:StorageEvent)=>{
      if(e.key!=='autoelectric_pcb_projects')return;
      try {
        const saved=PcbStorageEngine.loadProjects();const next=saved.length?saved:[createBlankProject()];
        setProjects(next);if(!next.some(p=>p.id===activeProjectId))setActiveProjectId(next[0].id);
        setSelectedComponentId(null);setSelectedNetId(null);
        setAnalysisSuccess('Projects refreshed from another browser tab.');
      }catch(err){setAnalysisError(err instanceof Error?err.message:'Could not refresh projects; current view was kept.');}
    };
    window.addEventListener('storage',refresh);return ()=>window.removeEventListener('storage',refresh);
  },[activeProjectId]);

  // Virtual Probes
  const [probeRedCompId, setProbeRedCompId] = useState<string | null>(null);
  const [probeBlackCompId, setProbeBlackCompId] = useState<string | null>(null);

  const documentComponents = activeProject.components.filter(c => c.sourceImageId === activeDoc?.id);
  const documentNets = activeProject.nets.filter(n => n.sourceImageId === activeDoc?.id);
  const documentAnnotations = (activeProject.annotations ?? []).filter(a => a.sourceImageId === activeDoc?.id);
  const selectedComp = documentComponents.find((c) => c.id === selectedComponentId) || null;

  // Sync active project to persistent storage
  const updateActiveProject = (updatedProj: PCBProject) => {
    setProjects((prev) => prev.map((p) => (p.id === updatedProj.id ? updatedProj : p)));
    const saved = PcbStorageEngine.saveProject(updatedProj);
    if (!saved) {
      setAnalysisError('The update is available in this tab but could not be saved to browser storage. Export a report before closing.');
    }
    return saved;
  };

  const handleNewProject = () => {
    const id = `manual-review-${crypto.randomUUID()}`;
    const project = createBlankProject(id, `Manual review ${projects.length + 1}`);
    setProjects((previous) => [project, ...previous]);
    setActiveProjectId(id);
    setSelectedComponentId(null);
    const saved = PcbStorageEngine.saveProject(project);
    setAnalysisError(saved ? null : 'New project is session-only. Browser storage failed; export a backup before closing.');
    setAnalysisSuccess(saved ? 'New empty review project saved in this browser.' : null);
  };

  const saveComponent = (component: DetectedComponent) => {
    updateActiveProject({ ...activeProject, components: [...activeProject.components, component] });
    setShowComponentDetails(true);setSelectedComponentId(component.id); setEditorKind(null);
  };
  const saveNet = (net: ElectricalNet) => {
    const nets = [...activeProject.nets.filter(n => n.id !== net.id),net];
    const components = activeProject.components.map(c => ({
      ...c, connectedNetIds: [...c.connectedNetIds.filter(id => id !== net.id), ...(net.connectedComponentIds.includes(c.id) ? [net.id] : [])],
    }));
    updateActiveProject({ ...activeProject,nets,components });
    setSelectedNetId(net.id); setEditorKind(null); setEditingNet(undefined);
  };
  const deleteComponent = (id: string) => {
    if (!confirm('Delete this component observation and remove its recorded net connections? This does not remove the image.')) return;
    updateActiveProject(removeComponentObservation(activeProject,id));
    setSelectedComponentId(null);
  };
  const deleteNet = (id: string) => {
    if (!confirm('Delete this recorded path from the project?')) return;
    updateActiveProject(removeObservedPath(activeProject,id));
    setSelectedNetId(null);
  };
  const deleteProject = () => {
    if (!confirm('Delete this project, its images, and its observations from this browser? Export a JSON backup first if needed.')) return;
    if (!PcbStorageEngine.deleteProject(activeProject.id)) {setAnalysisError('Project could not be deleted from storage. Nothing was removed from this view.');return;}
    const remaining = projects.filter(p => p.id !== activeProject.id);
    const next = remaining.length ? remaining : [createBlankProject()];
    setProjects(next); setActiveProjectId(next[0].id);setSelectedComponentId(null);setSelectedNetId(null);
  };

  // Canvas Click Handler (for dropping pin annotations)
  const handleCanvasClick = (coords: { x: number; y: number }) => {
    if (isAddingAnnotation) {
      setNewAnnotationCoords(coords);
    }
  };

  // Save technician annotation
  const handleSaveAnnotation = (annotationData: Omit<TechnicianAnnotation, 'id' | 'timestamp'>) => {
    const newAnn: TechnicianAnnotation = {
      ...annotationData,
      id: editingAnnotation?.id ?? crypto.randomUUID(),
      sourceImageId: activeDoc?.id,
      timestamp: new Date().toISOString(),
    };

    const updatedAnnotations = [...(activeProject.annotations || []).filter(a=>a.id!==newAnn.id), newAnn];
    const updatedProj: PCBProject = {
      ...activeProject,
      annotations: updatedAnnotations,
    };

    updateActiveProject(updatedProj);
    setNewAnnotationCoords(null);
    setIsAddingAnnotation(false);
    setEditingAnnotation(undefined);
  };

  // Delete annotation
  const handleDeleteAnnotation = (annId: string) => {
    if (!confirm('Delete this annotation from the project?')) return;
    updateActiveProject(removeDocumentNote(activeProject,annId));
    if (selectedAnnotationId === annId) setSelectedAnnotationId(null);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;

    const supportedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!supportedTypes.includes(file.type)) {
      setAnalysisError('Choose a PNG, JPEG, or WebP image. PDFs and other formats are not supported.');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setAnalysisError('Image is larger than 2 MB. Browser-local storage is limited; choose a smaller image.');
      return;
    }

    setIsAnalyzing(true);
    setAnalysisError(null);
    setAnalysisSuccess(null);

    const reader = new FileReader();
    reader.onerror = () => {
      setAnalysisError('The image could not be read from this device.');
      setIsAnalyzing(false);
    };
    reader.onload = () => {
      const imageUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!imageUrl) {
        setAnalysisError('The image could not be read from this device.');
        setIsAnalyzing(false);
        return;
      }

      const image = new Image();
      image.onerror = () => {
        setAnalysisError('The selected file is not a readable image.');
        setIsAnalyzing(false);
      };
      image.onload = () => {
        if(image.naturalWidth*image.naturalHeight>40_000_000 || image.naturalWidth>12000 || image.naturalHeight>12000){
          setAnalysisError('Image dimensions exceed the manual-review limit (40 megapixels, maximum 12,000 pixels per edge).');setIsAnalyzing(false);return;
        }
        const targetProject=projectsRef.current.find(p=>p.id===activeProject.id);
        if(!targetProject){setAnalysisError('The target project was removed before the image finished loading.');setIsAnalyzing(false);return;}
        const now = new Date().toISOString();
        const newDoc: UploadedDocument = {
          id: `doc-${crypto.randomUUID()}`,
          name: file.name,
          documentType: uploadDocumentType,
          imageUrl,
          originalFileName: file.name,
          fileSizeMb: Number((file.size / (1024 * 1024)).toFixed(2)),
          uploadTimestamp: now,
          widthPx: image.naturalWidth,
          heightPx: image.naturalHeight,
          description: 'Uploaded for manual review. No automated image interpretation was performed.',
        };
        const updatedProj: PCBProject = {
          ...targetProject,
          name: targetProject.id === 'manual-review-workspace' ? `Manual review: ${file.name}` : targetProject.name,
          documents: [...targetProject.documents, newDoc],
          activeDocumentId: newDoc.id,
          updatedAt: now,
        };

        const saved = updateActiveProject(updatedProj);
        setActiveProjectId(updatedProj.id);
        setSelectedComponentId(null);
        setAnalysisSuccess(
          saved
            ? 'Image saved for manual review. No components, nets, or electrical values were inferred.'
            : 'Image is available for this session only. No components, nets, or electrical values were inferred.',
        );
        setIsAnalyzing(false);
      };
      image.src = imageUrl;
    };
    reader.readAsDataURL(file);
  };

  // Manual correction save handler
  const handleSaveCorrection = (updatedComp: DetectedComponent, rationale: string, technician: string) => {
    if (documentComponents.some(c => c.id !== updatedComp.id && c.refDes.toLowerCase() === updatedComp.refDes.trim().toLowerCase())) {
      setAnalysisError('This reference designator already exists on this document.'); return;
    }
    const prevComp = activeProject.components.find((c) => c.id === updatedComp.id);
    const updatedComponents = activeProject.components.map((c) => (c.id === updatedComp.id ? updatedComp : c));

    const updatedProj: PCBProject = {
      ...activeProject,
      components: updatedComponents,
      auditHistory: [{
        id:crypto.randomUUID(),timestamp:new Date().toISOString(),technicianId:technician,
        componentId:updatedComp.id,action:'UPDATE',fieldChanged:'manual observation',
        previousValue:prevComp ? `${prevComp.refDes} (${prevComp.decodedValue})` : 'Not recorded',
        newValue:`${updatedComp.refDes} (${updatedComp.decodedValue})`,rationale,
      },...activeProject.auditHistory],
    };
    updateActiveProject(updatedProj);
    setShowCorrectionModal(false);
  };

  return (
    <div className="flex flex-col h-full bg-workstation-bg text-slate-100 overflow-hidden font-sans">
      {/* Top Engineering Module Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 sm:p-4 border-b border-white/5 bg-workstation-panel/60 shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-workstation-accent/10 border border-workstation-accent/40 text-workstation-accent font-bold shrink-0">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-workstation-accent uppercase tracking-wider">
                SCHEMATIC & PCB MANUAL REVIEW
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-xs font-mono text-emerald-400">AUTOMATED INTERPRETATION OFF</span>
            </div>
            <h2 className="text-base sm:text-lg font-bold text-white tracking-tight mt-0.5">
              {activeProject?.name} ({activeProject?.ecuModel})
            </h2>
          </div>
        </div>

        {/* Action Controls Header Toolbar */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <button onClick={handleNewProject} className="px-3 py-2 rounded border border-cyan-500/40 text-xs text-cyan-200">New review project</button>
          <button onClick={()=>downloadProjectBackup(activeProject)} className="px-3 py-2 rounded border border-slate-600 text-xs">Export JSON backup</button>
          <label className="px-3 py-2 rounded border border-slate-600 text-xs cursor-pointer">Restore JSON backup
            <input type="file" accept=".json,application/json" aria-label="Restore review backup" className="hidden" onChange={async e=>{
              const file=e.target.files?.[0];e.target.value='';if(!file)return;
              try {
                if(file.size>12_000_000)throw new Error('Backup exceeds 12 MB.');
                const project=parseProjectBackup(await file.text());
                await Promise.all(project.documents.map(document=>new Promise<void>((resolve,reject)=>{
                  const image=new Image();
                  image.onerror=()=>reject(new Error(`Backup image ${document.name} cannot be decoded.`));
                  image.onload=()=>{
                    if(image.naturalWidth*image.naturalHeight>40_000_000||image.naturalWidth>12000||image.naturalHeight>12000){reject(new Error('A backup image exceeds the dimension limit.'));return;}
                    document.widthPx=image.naturalWidth;document.heightPx=image.naturalHeight;resolve();
                  };
                  image.src=document.imageUrl;
                })));
                if(projects.some(p=>p.id===project.id) && !confirm('Replace the existing review project with this backup? Export the current version first if needed.'))return;
                const saved=PcbStorageEngine.saveProject(project);
                setProjects(previous=>[project,...previous.filter(p=>p.id!==project.id)]);setActiveProjectId(project.id);
                setSelectedComponentId(null);setSelectedNetId(null);
                setAnalysisError(saved?null:'Restored in this session only. Browser storage failed; keep the backup file.');
                setAnalysisSuccess(saved?'Review backup restored. All records remain user observations, not OEM-verified data.':null);
              }catch(err){setAnalysisError(err instanceof Error?err.message:'Backup could not be restored.');}
            }} />
          </label>
          <button disabled={!activeDoc} onClick={() => setEditorKind('component')} className="px-3 py-2 rounded border border-slate-600 text-xs disabled:opacity-40">Add component observation</button>
          <button disabled={!activeDoc} onClick={() => {setEditingNet(undefined);setEditorKind('net');}} className="px-3 py-2 rounded border border-slate-600 text-xs disabled:opacity-40">Add observed path</button>
          {/* Zoom controls */}
          <div className="flex items-center gap-1 bg-workstation-bg p-1 rounded-lg border border-white/5">
            <button onClick={() => handleZoom(-0.2)} className="p-1 text-slate-400 hover:text-white rounded" title="Zoom Out">
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono text-slate-300 px-1.5">{Math.round(zoomLevel * 100)}%</span>
            <button onClick={() => handleZoom(0.2)} className="p-1 text-slate-400 hover:text-white rounded" title="Zoom In">
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button onClick={resetZoomAndPan} className="p-1 text-slate-400 hover:text-workstation-accent rounded" title="Reset Zoom & Pan">
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Add Pin Annotation Tool Button */}
          <button
            onClick={() => {setEditingAnnotation(undefined);setIsAddingAnnotation(!isAddingAnnotation);}}
            disabled={!activeDoc}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-lg border transition-all whitespace-nowrap ${
              isAddingAnnotation
                ? 'bg-purple-900/70 border-purple-400 text-purple-200 animate-pulse font-bold shadow'
                : 'bg-workstation-bg hover:bg-white/5 border-white/5 text-slate-300'
            } disabled:cursor-not-allowed disabled:opacity-40`}
            title={activeDoc ? 'Add a note to the active document' : 'Upload an image before adding annotations'}
          >
            <PlusCircle className="w-3.5 h-3.5 text-purple-400" />
            <span>{isAddingAnnotation ? 'Click PCB to Drop Pin...' : 'Add Pin Annotation'}</span>
          </button>

          {/* Board Comparison button */}
          <button
            onClick={() => setShowComparison(true)}
            disabled={projects.filter((project) => project.documents.length > 0).length < 2}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-lg bg-workstation-bg hover:bg-white/5 border border-white/5 text-slate-200 transition-colors whitespace-nowrap"
            title="Compare two uploaded review projects"
          >
            <Columns className="w-3.5 h-3.5 text-workstation-accent" />
            <span>Compare Revisions</span>
          </button>

          {/* Circuit Net Tracer button */}
          <button
            onClick={() => setShowNetTracer(!showNetTracer)}
            disabled={documentNets.length === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-lg bg-workstation-bg hover:bg-white/5 border border-white/5 text-slate-200 transition-colors whitespace-nowrap"
            title={activeProject.nets.length ? 'Open the selected net trace' : 'No manually recorded net paths are available'}
          >
            <Activity className="w-3.5 h-3.5 text-workstation-accent" />
            <span>Net Tracer</span>
          </button>

          {/* Manual Correction button */}
          {selectedComp && (
            <button
              onClick={() => setShowCorrectionModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-lg bg-status-warning/10 hover:bg-status-warning/20 border border-status-warning/40 text-status-warning transition-colors whitespace-nowrap"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit {selectedComp.refDes}</span>
            </button>
          )}

          {/* Export Report button */}
          <button
            onClick={() => setShowExportModal(true)}
            disabled={!activeDoc}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-workstation-accent text-workstation-bg hover:bg-workstation-accent-light transition-colors shadow-sm whitespace-nowrap"
            title={activeDoc ? 'Export the current manual review record' : 'Upload an image before exporting a review'}
          >
            <Download className="w-3.5 h-3.5 shrink-0" />
            <span>PDF Technical Report</span>
          </button>
        </div>
      </div>

      {storageWarning && <p role="status" className="p-2 text-xs text-amber-200">{storageWarning}</p>}
      {/* State-Based Layer View Manager Control Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-2 border-b border-white/5 bg-workstation-panel/90 font-mono text-xs">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-workstation-accent shrink-0" />
          <span className="text-slate-400 font-bold uppercase tracking-wider text-[11px]">State Layer Manager:</span>
        </div>

        {/* Preset Selector Buttons */}
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => applyPreset('ALL')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold border transition-all ${
              layers.showPhotoBase && layers.showComponents && layers.showTraces && layers.showAnnotations
                ? 'bg-workstation-accent/10 text-workstation-accent border-workstation-accent/50'
                : 'bg-workstation-bg text-slate-400 border-white/5 hover:text-slate-200'
            }`}
          >
            All Layers On
          </button>
          <button
            onClick={() => applyPreset('COMPONENTS')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold border transition-all ${
              layers.showComponents && !layers.showTraces && !layers.showAnnotations
                ? 'bg-workstation-accent/10 text-workstation-accent border-workstation-accent/50'
                : 'bg-workstation-bg text-slate-400 border-white/5 hover:text-slate-200'
            }`}
          >
            Components Only
          </button>
          <button
            onClick={() => applyPreset('TRACES')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold border transition-all ${
              !layers.showComponents && layers.showTraces && !layers.showAnnotations
                ? 'bg-workstation-accent/10 text-workstation-accent border-workstation-accent/50'
                : 'bg-workstation-bg text-slate-400 border-white/5 hover:text-slate-200'
            }`}
          >
            Traces & Nets
          </button>
          <button
            onClick={() => applyPreset('ANNOTATIONS')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold border transition-all ${
              !layers.showComponents && !layers.showTraces && layers.showAnnotations
                ? 'bg-workstation-accent/10 text-workstation-accent border-workstation-accent/50'
                : 'bg-workstation-bg text-slate-400 border-white/5 hover:text-slate-200'
            }`}
          >
            Annotations Only
          </button>
          <button
            onClick={() => applyPreset('PHOTO_ONLY')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold border transition-all ${
              layers.showPhotoBase && !layers.showComponents && !layers.showTraces && !layers.showAnnotations
                ? 'bg-workstation-accent/10 text-workstation-accent border-workstation-accent/50'
                : 'bg-workstation-bg text-slate-400 border-white/5 hover:text-slate-200'
            }`}
          >
            Bare Hardware Photo
          </button>
          <button
            onClick={() => applyPreset('HIGH_CONTRAST')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-semibold border transition-all ${
              layers.photoHighContrast
                ? 'bg-status-warning/10 text-status-warning border-status-warning/50 font-bold shadow'
                : 'bg-workstation-bg text-slate-400 border-white/5 hover:text-slate-200'
            }`}
          >
            <Sun className="w-3 h-3 text-amber-400 shrink-0" />
            <span>High Contrast PCB</span>
          </button>
        </div>

        {/* Individual Layer Toggle Switches */}
        <div className="flex items-center gap-3 border-l border-white/5 pl-3">
          <button
            onClick={() => toggleLayer('showPhotoBase')}
            className={`flex items-center gap-1 text-[11px] transition-colors ${
              layers.showPhotoBase ? 'text-slate-200 font-bold' : 'text-slate-500 line-through'
            }`}
          >
            {layers.showPhotoBase ? <Eye className="w-3.5 h-3.5 text-workstation-accent" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>Base Image</span>
          </button>

          <button
            onClick={() => toggleLayer('showComponents')}
            className={`flex items-center gap-1 text-[11px] transition-colors ${
              layers.showComponents ? 'text-slate-200 font-bold' : 'text-slate-500 line-through'
            }`}
          >
            {layers.showComponents ? <Eye className="w-3.5 h-3.5 text-status-success" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>Components ({activeProject?.components.length || 0})</span>
          </button>

          <button
            onClick={() => toggleLayer('showTraces')}
            className={`flex items-center gap-1 text-[11px] transition-colors ${
              layers.showTraces ? 'text-slate-200 font-bold' : 'text-slate-500 line-through'
            }`}
          >
            {layers.showTraces ? <Eye className="w-3.5 h-3.5 text-workstation-secondary" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>Nets ({activeProject?.nets.length || 0})</span>
          </button>

          <button
            onClick={() => toggleLayer('showAnnotations')}
            className={`flex items-center gap-1 text-[11px] transition-colors ${
              layers.showAnnotations ? 'text-slate-200 font-bold' : 'text-slate-500 line-through'
            }`}
          >
            {layers.showAnnotations ? <Eye className="w-3.5 h-3.5 text-purple-400" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>Annotations ({activeProject?.annotations?.length || 0})</span>
          </button>
        </div>
      </div>

      {/* Main Workspace Body */}
      <div className="flex flex-col md:flex-row flex-1 overflow-auto md:overflow-hidden relative min-h-0">
        {/* Left Floating Document & Layer Drawer */}
        {isDrawerOpen && (
          <div className="w-full md:w-72 max-h-[40vh] md:max-h-none border-r border-slate-800 bg-slate-900/95 backdrop-blur-md flex flex-col p-4 overflow-y-auto shrink-0 space-y-5">
            {/* Upload New Document Button */}
            <div>
              <p className="text-[11px] text-amber-200 mb-3">Browser-local image review only. PNG/JPEG/WebP up to 2 MB. No PDFs or automated interpretation. Export JSON backups; clearing site data removes saved projects.</p>
              <label className="block text-xs text-slate-300 mb-2">Document type
                <select aria-label="Upload document type" value={uploadDocumentType} onChange={e => setUploadDocumentType(e.target.value as DocumentType)} className="block w-full p-2 mt-1 bg-slate-950 border border-slate-700 rounded">
                  {['UNKNOWN','ELECTRICAL_SCHEMATIC','PCB_LAYOUT','PHYSICAL_PCB_PHOTO','CONNECTOR_PINOUT','TECHNICAL_DOC'].map(t => <option key={t}>{t}</option>)}
                </select>
              </label>
              <label className="flex items-center justify-center gap-2 w-full px-4 py-2.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-xl cursor-pointer transition-colors shadow-md font-mono">
                <Upload className="w-4 h-4" />
                <span>Upload Schematic / PCB</span>
                <input aria-label="Upload review image" type="file" disabled={isAnalyzing} accept="image/png,image/jpeg,image/webp" onChange={handleFileUpload} className="hidden" />
              </label>
              {isAnalyzing && (
                <div className="mt-2 text-[11px] font-mono text-cyan-400 flex items-center justify-center gap-2 p-2 bg-cyan-950/40 rounded border border-cyan-500/30 animate-pulse">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Reading local image…</span>
                </div>
              )}
              {analysisError && <p role="alert" className="mt-2 rounded border border-rose-500/30 bg-rose-950/30 p-2 text-[11px] text-rose-300">{analysisError}</p>}
              {analysisSuccess && <p role="status" className="mt-2 rounded border border-emerald-500/30 bg-emerald-950/30 p-2 text-[11px] text-emerald-300">{analysisSuccess}</p>}
            </div>
            <details key={activeProject.id} className="text-xs text-slate-300">
              <summary className="cursor-pointer">Project metadata (user-entered)</summary>
              <form className="space-y-2 mt-2" onSubmit={e => {
                e.preventDefault();const data=new FormData(e.currentTarget);
                updateActiveProject({...activeProject,name:String(data.get('name') ?? '').trim() || 'Untitled review',vehicleModel:String(data.get('vehicle') ?? ''),ecuModel:String(data.get('ecu') ?? ''),ecuPartNumber:String(data.get('part') ?? '')});
              }}>
                {[['name','Project name',activeProject.name],['vehicle','Vehicle',activeProject.vehicleModel],['ecu','ECU model',activeProject.ecuModel],['part','ECU part number',activeProject.ecuPartNumber]].map(([name,label,value]) =>
                  <label key={name} className="block">{label}<input aria-label={label} name={name} defaultValue={value} className="w-full bg-slate-950 p-2 border border-slate-700 rounded" /></label>)}
                <button className="text-cyan-300">Save metadata</button>
              </form>
            </details>
            <button onClick={deleteProject} className="text-rose-300 text-xs text-left">Delete current project</button>

            {/* Document Library Project Switcher */}
            <div className="space-y-2">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block font-bold">
                ECU PCB Projects Database:
              </span>
              {projects.map((proj) => (
                <button
                  key={proj.id}
                  onClick={() => {
                    setActiveProjectId(proj.id);
                    setSelectedComponentId(null);
                    setSelectedNetId(null);setSelectedAnnotationId(null);setIsAddingAnnotation(false);
                  }}
                  className={`w-full text-left p-2.5 rounded-xl border transition-all text-xs font-mono ${
                    activeProjectId === proj.id
                      ? 'bg-cyan-950/50 text-white border-cyan-500/50 shadow'
                      : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="font-bold text-slate-200 truncate">{proj.name}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5 truncate">{proj.ecuModel}</div>
                  <div className="text-[9px] text-cyan-400 mt-1">{proj.components.length} mapped components</div>
                </button>
              ))}
            </div>

            {/* Document Pages inside Active Project */}
            <div className="space-y-2">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block font-bold">
                Project Document Layers:
              </span>
              {activeProject?.documents.map((doc) => (
                <div key={doc.id} className="space-y-1"><button
                  key={doc.id}
                  onClick={() => {
                    const updatedProj = { ...activeProject, activeDocumentId: doc.id };
                    updateActiveProject(updatedProj);
                    setSelectedComponentId(null);setSelectedNetId(null);setSelectedAnnotationId(null);
                  }}
                  className={`w-full text-left p-2 rounded-lg border text-xs font-mono transition-all flex items-center gap-2 ${
                    activeProject.activeDocumentId === doc.id
                      ? 'bg-slate-800 text-cyan-300 border-cyan-500/40 font-bold'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5 shrink-0 text-cyan-400" />
                  <span className="truncate">{doc.name}</span>
                </button><p className="text-[10px] text-slate-400">{doc.widthPx} × {doc.heightPx} px · {doc.documentType}</p>
                <button className="text-[10px] text-rose-300" onClick={() => {
                  if (!confirm('Delete this image and all observations attached to it?')) return;
                  const docs=activeProject.documents.filter(d=>d.id!==doc.id);
                  const removedIds=new Set(activeProject.components.filter(c=>c.sourceImageId===doc.id).map(c=>c.id));
                  updateActiveProject({...activeProject,documents:docs,activeDocumentId:activeProject.activeDocumentId===doc.id ? (docs[0]?.id ?? '') : activeProject.activeDocumentId,
                    components:activeProject.components.filter(c=>!removedIds.has(c.id)),nets:activeProject.nets.filter(n=>n.sourceImageId!==doc.id),
                    annotations:(activeProject.annotations ?? []).filter(a=>a.sourceImageId!==doc.id)});
                  setSelectedComponentId(null);setSelectedNetId(null);
                }}>Delete image</button></div>
              ))}
            </div>

            {/* Component List Navigation */}
            <div className="space-y-2 flex-1 overflow-y-auto">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block font-bold">
                Document observations ({documentComponents.length}):
              </span>
              <div className="space-y-1.5 max-h-[220px] overflow-y-auto">
                {documentComponents.map((comp) => (
                  <div
                    key={comp.id}
                    onClick={() => {setShowComponentDetails(true);setSelectedComponentId(comp.id);}}
                    className={`p-2 rounded-lg border cursor-pointer text-xs font-mono transition-colors flex items-center justify-between ${
                      selectedComponentId === comp.id
                        ? 'bg-cyan-950/60 text-white border-cyan-500/50 font-bold'
                        : 'bg-slate-950 text-slate-400 border-slate-800/80 hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="text-cyan-400 font-bold">{comp.refDes}</span>
                      <span className="text-slate-300 truncate">{comp.decodedValue}</span>
                    </div>
                    <span
                      title={`User-declared classification: ${comp.verificationStatus}. Not independently OEM verified.`}
                      className="px-1.5 py-0.5 rounded text-[9px] font-bold text-amber-400 bg-amber-950"
                    >
                      USER
                    </span>
                  </div>
                ))}
              </div>
              {selectedComp && <button className="text-xs text-rose-300" onClick={()=>deleteComponent(selectedComp.id)}>Delete {selectedComp.refDes}</button>}
              <p className="text-xs text-slate-300 pt-3">Observed paths ({documentNets.length})</p>
              {documentNets.map(n => <div key={n.id} className="text-xs space-x-3">
                <button onClick={()=>{setSelectedNetId(n.id);setShowNetTracer(true);}} className="text-cyan-300">{n.name}</button>
                <button onClick={()=>{setEditingNet(n);setEditorKind('net');}}>Edit path</button>
                <button className="text-rose-300" onClick={()=>deleteNet(n.id)}>Delete path</button>
              </div>)}
              <p className="text-xs text-slate-300 pt-3">Document notes ({documentAnnotations.length})</p>
              {documentAnnotations.map(a=><div key={a.id} className="text-xs border-t border-slate-700 pt-2 space-y-1">
                <p className="break-words">{a.text}</p><p className="text-slate-400">{a.author}</p>
                <div className="flex gap-3"><button className="text-cyan-300" onClick={()=>{setEditingAnnotation(a);setNewAnnotationCoords({x:a.x,y:a.y});}}>Edit note</button>
                  <button className="text-rose-300" onClick={()=>handleDeleteAnnotation(a.id)}>Delete note</button></div>
              </div>)}
            </div>
          </div>
        )}

        {/* Central High-Resolution Interactive Canvas with State-Based Layer Manager */}
        {!activeDoc && <SourceRequiredState title="Upload an image for manual review" detail="Use the document drawer to add a PNG, JPEG or WebP image. Components, paths and notes are entered by you; the app does not infer electrical facts from an image." />}
        {activeDoc && (
          <PcbCanvasOverlay
            imageUrl={activeDoc.imageUrl}
            documentType={activeDoc.documentType}
            components={documentComponents}
            nets={documentNets}
            annotations={documentAnnotations}
            layerConfig={layers}
            selectedComponentId={selectedComponentId}
            selectedNetId={selectedNetId}
            selectedAnnotationId={selectedAnnotationId}
            onSelectComponent={(compId) => {setShowComponentDetails(true);setSelectedComponentId(compId);}}
            onSelectAnnotation={(annId) => setSelectedAnnotationId(annId)}
            onDeleteAnnotation={handleDeleteAnnotation}
            onCanvasClick={handleCanvasClick}
            isAddingAnnotation={isAddingAnnotation}
            probeRedComponentId={probeRedCompId}
            probeBlackComponentId={probeBlackCompId}
            zoomLevel={zoomLevel}
            panOffset={panOffset}
            onZoomChange={handleZoom}
            onPanChange={updatePan}
            onResetZoomPan={resetZoomAndPan}
          />
        )}

        {/* Floating Component Inspection HUD */}
        <FloatingComponentHud
          component={showComponentDetails?selectedComp:null}
          onClose={() => setShowComponentDetails(false)}
          onEdit={()=>setShowCorrectionModal(true)}
          simulatedVoltage={null}
        />
      </div>

      {/* Modals */}
      {showComparison && (
        <BoardComparisonView
          currentProject={activeProject}
          allProjects={projects.filter(p => p.documents.length > 0)}
          onClose={() => setShowComparison(false)}
        />
      )}

      {showNetTracer && activeProject && (
        <NetTracingDrawer
          nets={documentNets}
          components={documentComponents}
          selectedNetId={selectedNetId}
          onSelectNet={(netId) => setSelectedNetId(netId)}
          onClose={() => setShowNetTracer(false)}
        />
      )}

      {showCorrectionModal && selectedComp && (
        <PcbManualCorrectionModal
          component={selectedComp}
          onSaveCorrection={handleSaveCorrection}
          onClose={() => setShowCorrectionModal(false)}
        />
      )}

      {showExportModal && activeProject && (
        <PcbReportExportModal
          project={activeProject}
          onClose={() => setShowExportModal(false)}
        />
      )}

      {newAnnotationCoords && (
        <PcbAnnotationModal
          key={editingAnnotation?.id ?? 'new-note'}
          initial={editingAnnotation}
          coords={newAnnotationCoords}
          onSave={handleSaveAnnotation}
          onClose={() => {setNewAnnotationCoords(null);setEditingAnnotation(undefined);}}
        />
      )}
      {editorKind && activeDoc && <ManualObservationEditor key={editingNet?.id ?? editorKind} kind={editorKind} net={editingNet}
        documentId={activeDoc.id} components={documentComponents} onSaveComponent={saveComponent} onSaveNet={saveNet}
        onClose={()=>{setEditorKind(null);setEditingNet(undefined);}} />}
    </div>
  );
};
