import React, { useMemo, useRef, useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle2, Download, ExternalLink, FileJson, Search, ShieldAlert, Trash2, Upload } from 'lucide-react';
import { ZodError } from 'zod';
import { PH_RESEARCH_BRANDS, SOURCE_DIRECTORY } from '../data/sourceDirectory';
import { loadReferences, parseReference, profileSchema, saveReferences, type ReferenceProfile, type SavedReference } from '../services/referenceLibrary';

interface ReferenceLibraryProps {
  onSelect: (reference: SavedReference) => void;
  onReferencesChanged?: (references: SavedReference[]) => void;
}

const EMPTY_TEMPLATE = {
  id: '',
  make: '', model: '', productionYears: '', chassisCode: '', engineCode: '', transmission: '', market: '',
  ecuPartNumber: '', hardwareNumber: '',
  source: { title: '', publisher: '', url: 'https://', revision: '', locator: '', marketApplicability: '', reusePermission: '' },
  connectors: [{ id: '', name: '', cavityCount: 0, orientation: '', pins: [{ number: 0, label: '', function: '', sourceLocator: '' }] }],
};

function describeError(err: unknown): string[] {
  if (err instanceof ZodError) return err.issues.map((i) => `${i.path.join('.') || 'profile'}: ${i.message}`);
  if (err instanceof SyntaxError) return [`Invalid JSON: ${err.message}`];
  return [err instanceof Error ? err.message : 'Unknown error'];
}

function download(name: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const initialLoad = (): { refs: SavedReference[]; error: string | null } => {
  try { return { refs: loadReferences(), error: null }; }
  catch (e) { return { refs: [], error: `Stored references could not be read: ${describeError(e).join('; ')}` }; }
};

export const ReferenceLibrary: React.FC<ReferenceLibraryProps> = ({ onSelect, onReferencesChanged }) => {
  const [init] = useState(initialLoad);
  const [saved, setSaved] = useState<SavedReference[]>(init.refs);
  const [storageError, setStorageError] = useState<string | null>(init.error);
  const [query, setQuery] = useState('');
  const [brand, setBrand] = useState<string>('ALL');
  const [raw, setRaw] = useState('');
  const [parsed, setParsed] = useState<ReferenceProfile | null>(null);
  const [errors, setErrors] = useState<string[]>([]);
  const [reviewer, setReviewer] = useState('');
  const [checked, setChecked] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  useEffect(()=>{
    const refresh=(e:StorageEvent)=>{
      if(e.key!=='autoelectric_user_references_v1')return;
      try {const refs=loadReferences();setSaved(refs);onReferencesChanged?.(refs);setNotice('References refreshed from another browser tab.');}
      catch(err){setStorageError(`Another tab changed stored references, but they could not be read: ${describeError(err).join('; ')}`);}
    };
    window.addEventListener('storage',refresh);return ()=>window.removeEventListener('storage',refresh);
  },[onReferencesChanged]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return SOURCE_DIRECTORY.filter((s) =>
      (brand === 'ALL' || s.brands.includes(brand) || s.brands.includes('Multiple')) &&
      (!q || [s.title, s.note, s.region, s.kind, ...s.brands].join(' ').toLowerCase().includes(q)));
  }, [query, brand]);

  const validate = (text: string) => {
    setNotice(null);
    setChecked(false);
    try {
      const p = parseReference(text);
      // Double-check against the exported schema contract.
      profileSchema.parse(p);
      setParsed(p); setErrors([]);
    } catch (e) { setParsed(null); setErrors(describeError(e)); }
  };

  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    if (f.size > 256_000) { setErrors(['File exceeds 256 KB.']); setParsed(null); return; }
    try { const t = await f.text(); setRaw(t); validate(t); }
    catch { setErrors(['File could not be read.']); }
  };

  const persist = (next: SavedReference[], msg: string) => {
    try {
      if(init.error)throw new Error('Existing saved references are unreadable and will not be overwritten. Back up browser data before repair.');
      saveReferences(next); setSaved(next); onReferencesChanged?.(next); setStorageError(null); setNotice(msg); return true;
    }
    catch (e) { setStorageError(`Save failed, nothing changed: ${describeError(e).join('; ')}`); return false; }
  };

  const canSave = !!parsed && reviewer.trim().length > 0 && checked;
  const handleSave = () => {
    if (!parsed || !canSave) return;
    const exists = saved.some((r) => r.profile.id === parsed.id);
    if (exists && !window.confirm(`A transcript with id "${parsed.id}" exists. Replace it?`)) return;
    const entry: SavedReference = { profile: parsed, reviewedBy: reviewer.trim(), reviewedAt: new Date().toISOString(), status: 'USER_TRANSCRIPT' };
    if (persist([entry, ...saved.filter((r) => r.profile.id !== parsed.id)], `Saved "${parsed.id}" as USER_TRANSCRIPT (not OEM verified).`)) {
      setRaw(''); setParsed(null); setChecked(false);
    }
  };

  const handleDelete = (id: string) => {
    if (persist(saved.filter((r) => r.profile.id !== id), `Deleted "${id}".`)) setConfirmDelete(null);
  };

  return (
    <div className="space-y-5 p-4 md:p-6">
      <header className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-workstation-accent">Reference Library</p>
          <h1 className="text-xl font-semibold text-white">Sources, leads, and your reviewed transcripts</h1>
        </div>
        <button type="button" data-testid="button-download-template" onClick={() => download('autoelectric-reference-template.json', EMPTY_TEMPLATE)}
          className="inline-flex items-center gap-2 self-start rounded-lg border border-cyan-500/30 bg-cyan-950/40 px-3 py-2 text-sm text-cyan-200 hover:bg-cyan-900/50">
          <Download className="h-4 w-4" /> Empty JSON template
        </button>
      </header>

      <div role="note" className="flex gap-3 rounded-xl border border-amber-500/30 bg-amber-950/30 p-4 text-sm text-amber-100">
        <ShieldAlert className="h-5 w-5 shrink-0 text-amber-400" />
        <p><strong>Zero verified Philippine pinouts are bundled.</strong> Imported transcripts and their source/reviewer declarations are user-supplied and are <strong>not independently OEM verified</strong>. They stay at USER_TRANSCRIPT and are never upgraded automatically.</p>
      </div>

      {storageError && (
        <div role="alert" data-testid="status-storage-error" className="flex gap-2 rounded-lg border border-red-500/40 bg-red-950/40 p-3 text-sm text-red-200">
          <AlertTriangle className="h-4 w-4 shrink-0" /> {storageError}
        </div>
      )}
      {notice && (
        <div role="status" data-testid="status-notice" className="flex gap-2 rounded-lg border border-emerald-500/30 bg-emerald-950/30 p-3 text-sm text-emerald-200">
          <CheckCircle2 className="h-4 w-4 shrink-0" /> {notice}
        </div>
      )}

      <div className="grid gap-5 xl:grid-cols-[1.1fr_1fr]">
        <section className="rounded-2xl border border-white/5 bg-workstation-panel/70 p-4">
          <h2 className="mb-3 text-sm font-semibold text-white">Source directory</h2>
          <div className="mb-3 flex flex-col gap-2 sm:flex-row">
            <label className="relative flex-1">
              <span className="sr-only">Search sources</span>
              <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
              <input data-testid="input-search-sources" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search title, region, note"
                className="w-full rounded-lg border border-white/10 bg-workstation-bg py-2 pl-9 pr-3 text-sm text-slate-100 outline-none focus:border-workstation-accent/60" />
            </label>
            <select data-testid="select-brand" value={brand} onChange={(e) => setBrand(e.target.value)} aria-label="Filter by brand"
              className="rounded-lg border border-white/10 bg-workstation-bg px-3 py-2 text-sm text-slate-100">
              <option value="ALL">All brands</option>
              {PH_RESEARCH_BRANDS.map((b) => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>
          <ul className="space-y-2">
            {filtered.length === 0 && (
              <li className="rounded-lg border border-dashed border-white/10 p-4 text-sm text-slate-400">
                No reviewed portal page lists {brand === 'ALL' ? 'this search' : brand}. Treat it as an open research lead; no pinout is implied.
              </li>
            )}
            {filtered.map((s) => (
              <li key={s.id} data-testid={`card-source-${s.id}`} className="rounded-lg border border-white/5 bg-workstation-bg/60 p-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`rounded px-1.5 py-0.5 font-mono text-[10px] ${s.evidenceStatus === 'PAGE_REVIEWED' ? 'bg-sky-900/50 text-sky-200' : 'bg-slate-700/60 text-slate-300'}`}>
                    {s.evidenceStatus === 'PAGE_REVIEWED' ? 'PORTAL PAGE REVIEWED' : 'SOURCE LEAD'}
                  </span>
                  <span className="font-mono text-[10px] text-slate-500">{s.kind} / {s.region}</span>
                </div>
                <a href={s.url} target="_blank" rel="noopener noreferrer" data-testid={`link-source-${s.id}`}
                  className="mt-1 inline-flex items-center gap-1 text-sm font-medium text-cyan-200 hover:underline">
                  {s.title} <ExternalLink className="h-3 w-3" />
                </a>
                <p className="mt-1 text-xs leading-5 text-slate-400">{s.note}</p>
                <p className="mt-1 text-[11px] text-slate-500">Page reviewed means the portal page was read, not that any Philippine pinout was confirmed.</p>
              </li>
            ))}
          </ul>
        </section>

        <section className="space-y-4 rounded-2xl border border-white/5 bg-workstation-panel/70 p-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">Import structured transcript</h2>
            <button type="button" data-testid="button-upload-json" onClick={() => fileRef.current?.click()}
              className="inline-flex items-center gap-1.5 rounded-md border border-white/10 px-2.5 py-1.5 text-xs text-slate-200 hover:bg-white/5">
              <Upload className="h-3.5 w-3.5" /> Upload .json
            </button>
            <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={onFile} />
          </div>
          <textarea data-testid="input-reference-json" aria-label="Reference JSON" value={raw} onChange={(e) => { setRaw(e.target.value); setParsed(null); setChecked(false); setErrors([]); }}
            placeholder="Paste reference JSON matching the template" rows={8} spellCheck={false}
            className="w-full rounded-lg border border-white/10 bg-workstation-bg p-3 font-mono text-xs text-slate-200 outline-none focus:border-workstation-accent/60" />
          <button type="button" data-testid="button-validate" disabled={!raw.trim()} onClick={() => validate(raw)}
            className="rounded-lg bg-workstation-accent px-3 py-2 text-sm font-medium text-slate-950 disabled:opacity-40">Validate</button>
          {errors.length > 0 && (
            <ul role="alert" data-testid="list-validation-errors" className="max-h-40 overflow-auto rounded-lg border border-red-500/40 bg-red-950/30 p-3 font-mono text-xs text-red-200">
              {errors.map((e, i) => <li key={i}>{e}</li>)}
            </ul>
          )}
          {parsed && (
            <div className="space-y-3 rounded-lg border border-emerald-500/20 bg-emerald-950/20 p-3 text-sm">
              <p className="text-emerald-200">Schema valid: {parsed.make} {parsed.model} ({parsed.productionYears}), {parsed.connectors.length} connector(s). Schema validity is not factual accuracy.</p>
              <label className="block">
                <span className="text-xs text-slate-400">Reviewer identity (required)</span>
                <input data-testid="input-reviewer" value={reviewer} onChange={(e) => setReviewer(e.target.value)} placeholder="Name and shop"
                  className="mt-1 w-full rounded-lg border border-white/10 bg-workstation-bg px-3 py-2 text-sm text-slate-100" />
              </label>
              <label className="flex items-start gap-2 text-xs text-slate-300">
                <input type="checkbox" data-testid="checkbox-source-check" checked={checked} onChange={(e) => setChecked(e.target.checked)} className="mt-0.5" />
                I compared each pin against "{parsed.source.title}" ({parsed.source.locator}) and confirmed its stated applicability ("{parsed.source.marketApplicability}") matches the vehicle and ECU part {parsed.ecuPartNumber}.
              </label>
              <button type="button" data-testid="button-save-reference" disabled={!canSave} onClick={handleSave}
                className="rounded-lg bg-emerald-500 px-3 py-2 text-sm font-medium text-slate-950 disabled:opacity-40">Save as USER_TRANSCRIPT</button>
            </div>
          )}

          <div>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Saved transcripts ({saved.length})</h3>
            {saved.length === 0 ? (
              <div className="flex items-center gap-2 rounded-lg border border-dashed border-white/10 p-4 text-sm text-slate-400">
                <FileJson className="h-4 w-4" /> Nothing saved in this browser yet.
              </div>
            ) : (
              <ul className="space-y-2">
                {saved.map((r) => (
                  <li key={r.profile.id} data-testid={`row-saved-${r.profile.id}`} className="rounded-lg border border-white/5 bg-workstation-bg/60 p-3">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <span className="text-sm text-white">{r.profile.make} {r.profile.model} <span className="font-mono text-xs text-slate-500">{r.profile.id}</span></span>
                      <span className="rounded bg-amber-900/40 px-1.5 py-0.5 font-mono text-[10px] text-amber-200">USER TRANSCRIPT / NOT OEM VERIFIED</span>
                    </div>
                    <p className="mt-1 text-xs text-slate-500">Reviewed by {r.reviewedBy}, {new Date(r.reviewedAt).toLocaleString()}</p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <button type="button" data-testid={`button-select-${r.profile.id}`} onClick={() => onSelect(r)} className="rounded-md bg-cyan-900/50 px-2.5 py-1 text-xs text-cyan-100 hover:bg-cyan-800/60">Open pinout</button>
                      <button type="button" data-testid={`button-export-${r.profile.id}`} onClick={() => download(`${r.profile.id}.json`, r.profile)} className="rounded-md border border-white/10 px-2.5 py-1 text-xs text-slate-200 hover:bg-white/5">Export</button>
                      <button type="button" onClick={()=>{setRaw(JSON.stringify(r.profile,null,2));setParsed(null);setChecked(false);setReviewer('');setNotice('Loaded for editing. Validate and review again before replacing the saved transcript.');}} className="rounded-md border border-white/10 px-2.5 py-1 text-xs text-slate-200">Edit transcript</button>
                      {confirmDelete === r.profile.id ? (
                        <>
                          <button type="button" data-testid={`button-confirm-delete-${r.profile.id}`} onClick={() => handleDelete(r.profile.id)} className="rounded-md bg-red-600 px-2.5 py-1 text-xs text-white">Confirm delete</button>
                          <button type="button" onClick={() => setConfirmDelete(null)} className="rounded-md px-2.5 py-1 text-xs text-slate-400">Cancel</button>
                        </>
                      ) : (
                        <button type="button" data-testid={`button-delete-${r.profile.id}`} onClick={() => setConfirmDelete(r.profile.id)} className="inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs text-red-300 hover:bg-red-950/40"><Trash2 className="h-3 w-3" /> Delete</button>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};

export default ReferenceLibrary;
