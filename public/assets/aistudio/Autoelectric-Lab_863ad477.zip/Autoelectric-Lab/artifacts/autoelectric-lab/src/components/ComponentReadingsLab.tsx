import React, { useState } from 'react';
import type { VehicleProfile, BenchReading } from '../types/automotive';
import { createManualReading, summarizeReadings } from '../services/readingRecords';

interface Props {
  vehicle: VehicleProfile;
  readings: BenchReading[];
  historyReadings?: BenchReading[];
  onAddReading: (reading: BenchReading) => void;
  onDeleteReading: (id: string) => void;
  onExportPdf: () => void;
  onSelectPinForBench: (pinNumber: number) => void;
}
const units: Record<BenchReading['measurementType'], string> = {
  VOLTAGE_DC: 'V DC', VOLTAGE_AC: 'V AC', RESISTANCE: 'ohm', DIODE: 'V', CONTINUITY: 'ohm', CURRENT: 'A',
};
const empty = { label: '', value: '', connector: '', pin: '', min: '', max: '', source: '', technician: '', notes: '' };
export function ComponentReadingsLab({ vehicle, readings, historyReadings, onAddReading, onDeleteReading, onExportPdf }: Props) {
  const [draft, setDraft] = useState(empty);
  const [mode, setMode] = useState<BenchReading['measurementType']>('VOLTAGE_DC');
  const [editId, setEditId] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('ALL');
  const [showAll,setShowAll]=useState(false);
  const displayed=showAll ? (historyReadings ?? readings) : readings;
  const totals = summarizeReadings(displayed);
  const exportJson=()=>{
    const url=URL.createObjectURL(new Blob([JSON.stringify({format:'autoelectric-observations-v1',activeVehicle:vehicle,readings:displayed},null,2)],{type:'application/json'}));
    const a=document.createElement('a');a.href=url;a.download=`autoelectric-observations-${vehicle.id}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  };
  const field = (key: keyof typeof empty, label: string, type = 'text', required = false) => (
    <label className="text-xs text-slate-300 space-y-1" key={key}>{label}
      <input aria-label={label} required={required} type={type} step={type === 'number' ? 'any' : undefined}
        value={draft[key]} onChange={e => setDraft({ ...draft, [key]: e.target.value })}
        className="block w-full rounded border border-slate-700 bg-slate-950 p-2 text-slate-100" />
    </label>
  );
  const submit = (e: React.FormEvent) => {
    e.preventDefault(); setError(''); setMessage('');
    try {
      if (!draft.value.trim()) throw new Error('Enter a value. A blank input is not zero.');
      const record = createManualReading({
        id: editId ?? crypto.randomUUID(), vehicleId: vehicle.id, pinLabel: draft.label,
        connectorId: draft.connector.trim() || null, pinNumber: draft.pin.trim() ? Number(draft.pin) : null,
        measurementType: mode, measuredValue: Number(draft.value), unit: units[mode],
        expectedMin: draft.min.trim() ? Number(draft.min) : null, expectedMax: draft.max.trim() ? Number(draft.max) : null,
        comparisonSource: draft.source.trim(), technicianName: draft.technician.trim(), notes: draft.notes,
        timestamp: new Date().toISOString(),
      });
      onAddReading(record); setDraft(empty); setEditId(null); setMessage('Record submitted. The storage status above shows whether it was saved.');
    } catch (err) { setError(err instanceof Error ? err.message : 'Invalid reading.'); }
  };
  const edit = (r: BenchReading) => {
    setEditId(r.id); setMode(r.measurementType); setDraft({
      label: r.pinLabel, value: String(r.measuredValue), connector: r.connectorId ?? '', pin: r.pinNumber === null ? '' : String(r.pinNumber),
      min: r.expectedMin == null ? '' : String(r.expectedMin), max: r.expectedMax == null ? '' : String(r.expectedMax),
      source: r.comparisonSource ?? '', technician: r.technicianName ?? '', notes: r.notes,
    });
  };
  const filtered = displayed.filter(r => (status === 'ALL' || r.status === status) &&
    `${r.pinLabel} ${r.connectorId ?? ''} ${r.pinNumber ?? ''} ${r.notes}`.toLowerCase().includes(query.toLowerCase()));
  return <div className="h-full overflow-auto bg-workstation-bg p-4 sm:p-6 text-slate-100 space-y-5">
    <header className="flex flex-wrap justify-between gap-3">
      <div><h2 className="text-xl font-bold">Measurement records</h2><p className="text-sm text-slate-400">{vehicle.make} {vehicle.model} · {vehicle.ecuPartNumber}</p></div>
      <div className="flex gap-3 flex-wrap"><button onClick={exportJson} className="rounded border border-slate-600 px-4 py-2">Export displayed records JSON</button><button onClick={onExportPdf} className="rounded bg-cyan-400 text-slate-950 font-bold px-4 py-2">Export active-context PDF</button></div>
    </header>
    <p className="p-3 border border-amber-500/30 rounded text-sm text-amber-200">Manual entries are declarations, not readings acquired by this app. PASS/FAIL only compares the entered value with your cited range; it does not certify the ECU. No source range means UNVERIFIED. Data is browser-local; export backups.</p>
    <p className="font-mono text-xs">{totals.total} records · {totals.pass} within entered range · {totals.faults} flagged · {totals.unassessed} unassessed · {totals.simulated} simulated</p>
    <form onSubmit={submit} className="rounded-xl bg-slate-900 border border-slate-700 p-4 space-y-4">
      <h3 className="font-bold">{editId ? 'Edit manual record' : 'Add a manual record'}</h3>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {field('label', 'Test point / label', 'text', true)}
        <label className="text-xs text-slate-300">Measurement mode<select aria-label="Measurement mode" className="block w-full rounded border border-slate-700 bg-slate-950 p-2" value={mode} onChange={e => setMode(e.target.value as typeof mode)}>{Object.keys(units).map(k => <option key={k}>{k}</option>)}</select></label>
        {field('value', `Entered value (${units[mode]})`, 'number', true)}
        {field('connector', 'Connector ID (optional)')}{field('pin', 'Pin number (optional)', 'number')}
        {field('technician', 'Recorded by (optional)')}{field('min', 'Comparison minimum (optional)', 'number')}{field('max', 'Comparison maximum (optional)', 'number')}
        {field('source', 'Range source and test conditions')}
      </div>
      <label className="block text-xs text-slate-300">Notes / reference ground / instrument
        <textarea aria-label="Reading notes" className="block w-full rounded border border-slate-700 bg-slate-950 p-2 mt-1" value={draft.notes} onChange={e => setDraft({ ...draft, notes: e.target.value })} />
      </label>
      {error && <p role="alert" className="text-rose-300 text-sm">{error}</p>}
      {message && <p role="status" className="text-cyan-300 text-sm">{message}</p>}
      <div className="flex gap-3"><button className="rounded bg-cyan-400 px-4 py-2 text-slate-950 font-bold">{editId ? 'Update record' : 'Add record'}</button>{editId && <button type="button" onClick={() => { setEditId(null); setDraft(empty); }} className="px-3">Cancel edit</button>}</div>
    </form>
    <div className="flex flex-wrap gap-3">
      <label className="text-xs text-amber-200 flex items-center gap-2"><input type="checkbox" checked={showAll} onChange={e=>setShowAll(e.target.checked)} />Show history from all contexts (PDF remains active context only)</label>
      <input aria-label="Search readings" placeholder="Search readings…" className="bg-slate-900 p-2 rounded border border-slate-700" value={query} onChange={e => setQuery(e.target.value)} />
      <select aria-label="Filter reading status" className="bg-slate-900 p-2 rounded border border-slate-700" value={status} onChange={e => setStatus(e.target.value)}>{['ALL', 'PASS', 'FAIL', 'UNVERIFIED', 'NOT_APPLICABLE'].map(s => <option key={s}>{s}</option>)}</select>
    </div>
    <div className="overflow-x-auto"><table className="w-full text-xs text-left min-w-[800px]"><thead><tr>{['Time / origin', 'Connector / pin', 'Test point', 'Value', 'Comparison', 'Status', 'Notes', 'Actions'].map(t => <th key={t} className="p-3 border-b border-slate-700">{t}</th>)}</tr></thead><tbody>
      {filtered.map(r => <tr key={r.id} className="border-b border-slate-800">
        <td className="p-3">{r.timestamp}<br /><span className="text-amber-300">{r.source ?? 'ORIGIN NOT RECORDED'}</span></td>
        <td className="p-3">{r.connectorId ?? 'Unmapped'} / {r.pinNumber ?? '—'}</td><td className="p-3">{r.pinLabel}<p className="text-slate-400 max-w-xs break-words">{r.vehicleDescription ?? r.vehicleId ?? 'Context not recorded'}</p></td><td className="p-3">{r.measuredValue} {r.unit}</td>
        <td className="p-3">{r.expectedMin == null || r.expectedMax == null ? 'No range' : `${r.expectedMin}–${r.expectedMax} ${r.unit}`}<p className="text-slate-400 max-w-xs break-words">{r.comparisonSource}</p></td>
        <td className="p-3">{r.status}</td><td className="p-3 max-w-xs break-words">{r.notes}</td><td className="p-3"><div className="flex gap-3">{r.source !== 'SIMULATED' && r.vehicleId===vehicle.id && <button onClick={() => edit(r)} className="text-cyan-300" aria-label={`Edit ${r.pinLabel}`}>Edit</button>}<button className="text-rose-300" aria-label={`Delete ${r.pinLabel}`} onClick={() => { if (confirm('Delete this reading from this browser? Export it first if you need a copy.')) onDeleteReading(r.id); }}>Delete</button></div></td>
      </tr>)}
      {!filtered.length && <tr><td colSpan={8} className="p-8 text-slate-400 text-center">No matching records. Nothing has been measured or prefilled.</td></tr>}
    </tbody></table></div>
  </div>;
}
