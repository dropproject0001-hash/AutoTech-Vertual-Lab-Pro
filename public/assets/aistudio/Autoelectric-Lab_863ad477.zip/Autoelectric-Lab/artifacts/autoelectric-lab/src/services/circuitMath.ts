/** Ideal DC resistor model. No ECU fitment, sensor curve, or hardware behavior is implied. */
export function solveResistor(voltage: number, resistance: number) {
  if (!Number.isFinite(voltage) || !Number.isFinite(resistance) || voltage < 0 || voltage > 1000 || resistance <= 0 || resistance > 1e12) {
    throw new Error('Enter a finite voltage from 0–1000 V and resistance greater than 0, up to 1e12 ohm.');
  }
  return { currentAmps: voltage / resistance, powerWatts: voltage * voltage / resistance };
}
