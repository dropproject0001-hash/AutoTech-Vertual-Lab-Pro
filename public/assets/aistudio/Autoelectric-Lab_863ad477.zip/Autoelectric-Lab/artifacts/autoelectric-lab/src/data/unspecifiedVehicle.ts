import { VehicleProfile } from '../types/automotive';

/**
 * UI-only state used while no source-backed vehicle profile is loaded.
 * All descriptive fields explicitly say they were not supplied.
 */
export const UNSPECIFIED_VEHICLE_PROFILE: VehicleProfile = {
  id: 'no-source-profile',
  make: 'Not specified',
  model: 'No source-backed profile',
  productionYears: 'Not specified',
  chassisCode: 'Not specified',
  engineCode: 'Not specified',
  engineDisp: 'Not specified',
  fuelType: 'UNKNOWN',
  market: 'Not specified',
  ecuManufacturer: 'UNKNOWN',
  ecuModel: 'Not specified',
  ecuPartNumber: 'Not specified',
  hardwareNumber: 'Not specified',
  socketCount: 0,
  connectors: [],
  description: 'No vehicle-specific source document has been supplied.',
  verifiedStatus: 'UNVERIFIED',
  pinoutSource: 'No source document supplied.',
  completenessReports: [],
};
