import React, { useState } from 'react';
import { jsPDF } from 'jspdf';
import type { PCBProject } from '../types/pcbScanner';
import { downloadProjectBackup } from '../services/projectBackup';
export function PcbReportExportModal({project,onClose}:{project:PCBProject;onClose:()=>void}) {
  const [error,setError]=useState('');
  const generate=()=>{
    try {
      const pdf=new jsPDF();let y=20;
      const write=(text:string)=>{
        const safe=text.replaceAll('Ω','ohm').replaceAll('—','-').replaceAll('–','-').replace(/[^\x20-\x7E\n]/g,'?');
        for(const line of pdf.splitTextToSize(safe,180) as string[]) {if(y>275){pdf.addPage();y=20;}pdf.text(line,15,y);y+=5;}y+=3;
      };
      pdf.setFontSize(10);
      write('AUTOELECTRIC LAB - MANUAL DOCUMENT REVIEW');
      write('User-entered observations only; no automatic detection, hardware measurement, diagnosis, or calibration certification.');
      write(`Project: ${project.name} | Generated: ${new Date().toISOString()}`);
      write(`Vehicle as recorded: ${project.vehicleModel} | ECU: ${project.ecuModel} | Part: ${project.ecuPartNumber}`);
      write(`Project notes: ${project.notes}`);
      for(const d of project.documents) write(`Document: ${d.name} [${d.id}] | ${d.documentType} | ${d.widthPx}x${d.heightPx} px | Uploaded: ${d.uploadTimestamp} | ${d.description}`);
      for(const c of project.components) {
        write(`Observation: ${c.refDes} [${c.id}] | Document: ${c.sourceImageId}`);
        write(`Category as recorded: ${c.category}; marking: ${c.marking || 'not recorded'}; value: ${c.decodedValue || 'not recorded'}; package: ${c.packageType}`);
        write(`Function as recorded: ${c.circuitFunction}. Source: ${c.datasheetRef || 'not recorded'}. Notes: ${c.notes || 'none'}`);
        write(`Normalized box: ${JSON.stringify(c.bbox)}. Nets: ${c.connectedNetIds.join(', ') || 'none recorded'}. Not independently verified.`);
      }
      for(const n of project.nets) write(`Recorded path: ${n.name} [${n.id}] | Document: ${n.sourceImageId || 'not linked'} | Points: ${n.tracePoints.map(p=>`${p.x},${p.y}`).join('; ')} | Components: ${n.connectedComponentIds.join(', ')} | Notes: ${n.incompleteNotes || 'none'}. Electrical continuity not verified.`);
      for(const a of project.annotations ?? []) write(`Annotation: ${a.text} | Category as recorded: ${a.category} | By: ${a.author} | ${a.timestamp} | Document: ${a.sourceImageId || 'not linked'} | X:${a.x}, Y:${a.y}`);
      for(const a of project.auditHistory) write(`Audit: ${a.timestamp} | ${a.technicianId} | ${a.action} ${a.componentId} | ${a.previousValue} -> ${a.newValue} | Rationale: ${a.rationale}`);
      write('This PDF lists observations; source images and restorable data are included in the separate JSON backup, not this PDF.');
      pdf.save(`autoelectric-manual-review-${project.id}.pdf`);
    }catch(err){setError(err instanceof Error ? err.message : 'Export failed.');}
  };
  return <div role="dialog" aria-modal="true" aria-label="Manual review export" className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 text-slate-100">
    <section className="bg-slate-900 border border-slate-700 rounded-xl p-5 max-w-xl w-full space-y-4">
      <header className="flex justify-between"><h3 className="font-bold text-lg">Export manual review</h3><button onClick={onClose} aria-label="Close manual review export">Close</button></header>
      <p className="text-sm text-amber-200">Not an engineering approval, automated analysis, or certificate. Records have not been independently verified.</p>
      <p className="text-sm">{project.documents.length} images · {project.components.length} component observations · {project.nets.length} paths · {project.annotations?.length ?? 0} annotations</p>
      <p className="text-xs text-slate-400">JSON backups include your source images and may contain private information. Keep them securely. PDFs are summaries; unsupported Unicode is replaced with “?” by the PDF's built-in font.</p>
      {error && <p role="alert" className="text-rose-300">{error}</p>}
      <div className="flex flex-wrap gap-3"><button className="px-4 py-2 rounded bg-cyan-400 text-slate-950 font-bold" onClick={generate}>Download review PDF</button><button className="px-4 py-2 rounded border border-slate-600" onClick={()=>downloadProjectBackup(project)}>Download JSON backup</button></div>
    </section>
  </div>;
}
