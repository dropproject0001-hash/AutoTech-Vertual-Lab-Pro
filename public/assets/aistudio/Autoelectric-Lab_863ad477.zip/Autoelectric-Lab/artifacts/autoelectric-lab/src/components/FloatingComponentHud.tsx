import React from 'react';
import type { DetectedComponent } from '../types/pcbScanner';
interface Props {component:DetectedComponent|null;onClose:()=>void;onEdit?:()=>void;simulatedVoltage?:number|null;}
export function FloatingComponentHud({component,onClose,onEdit}:Props) {
  if (!component) return null;
  return <aside role="dialog" aria-label="Component observation" className="fixed top-20 right-4 z-40 w-80 max-w-[calc(100vw-2rem)] bg-slate-900 border border-slate-700 rounded-xl p-4 max-h-[80vh] overflow-auto text-slate-100 space-y-3">
    <header className="flex justify-between"><h3 className="font-bold">{component.refDes}</h3><button onClick={onClose} aria-label="Close component observation">Close</button></header>
    <p className="text-xs text-amber-200">USER OBSERVATION · Not independently verified. No voltage has been measured or simulated for this component.</p>
    {onEdit && <button onClick={onEdit} className="w-full rounded bg-cyan-400 text-slate-950 font-bold py-2" aria-label={`Edit observation ${component.refDes}`}>Edit observation</button>}
    <dl className="text-xs space-y-3">
      {[
        ['Visible marking',component.marking],['Recorded value',component.decodedValue],['Package',component.packageType],
        ['Function as recorded',component.circuitFunction],['Source as recorded',component.datasheetRef],['Notes',component.notes],
      ].map(([label,value])=><div key={label}><dt className="text-slate-400">{label}</dt><dd className="break-words">{value || 'Not recorded'}</dd></div>)}
    </dl>
    <p className="text-xs text-slate-400">No mapping to an ECU connector pin is established by this annotation. No fault has been injected into hardware or an ECU model.</p>
  </aside>;
}
