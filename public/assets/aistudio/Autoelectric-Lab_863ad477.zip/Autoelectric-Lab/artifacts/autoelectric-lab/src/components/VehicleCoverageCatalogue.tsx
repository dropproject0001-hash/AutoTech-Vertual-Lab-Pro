import { useEffect, useState } from 'react';
import { getGetVehicleCoverageQueryKey, useGetVehicleCoverage } from '@workspace/api-client-react';
import type { RoadVehicleClass, VehicleCoverageItem } from '@workspace/api-client-react';
import { AlertTriangle, ArrowDown, ArrowUpRight, BookOpen, CarFront, FileText, LoaderCircle, RefreshCw, Search, ShieldCheck } from 'lucide-react';

const PAGE_SIZE = 25;

const vehicleClasses: { value: RoadVehicleClass | ''; label: string }[] = [
  { value: '', label: 'All vehicle classes' },
  { value: 'CAR', label: 'Car' },
  { value: 'VAN', label: 'Van' },
  { value: 'PICKUP', label: 'Pickup' },
  { value: 'MOTORCYCLE', label: 'Motorcycle' },
  { value: 'MOTORCYCLE_OR_SCOOTER', label: 'Motorcycle or scooter' },
  { value: 'TRUCK', label: 'Truck' },
  { value: 'BUS', label: 'Bus' },
  { value: 'PUBLIC_UTILITY_VEHICLE', label: 'Public utility vehicle' },
];

const labelForClass = (value: RoadVehicleClass) =>
  vehicleClasses.find((item) => item.value === value)?.label ?? value.replaceAll('_', ' ').toLowerCase();

const recordKindDetails: Record<string, { label: string; description: string; icon: typeof FileText; accent: string }> = {
  OEM_PRODUCT_PAGE: {
    label: 'Product-page observation',
    description: 'Maker product listing',
    icon: CarFront,
    accent: 'text-cyan-300 border-cyan-300/20 bg-cyan-300/[0.07]',
  },
  OEM_OWNER_MANUAL: {
    label: 'Owner-manual observation',
    description: 'Owner-document index',
    icon: BookOpen,
    accent: 'text-amber-200 border-amber-200/20 bg-amber-200/[0.07]',
  },
  OEM_CAMPAIGN_NOTICE: {
    label: 'Campaign-notice observation',
    description: 'Service campaign notice',
    icon: AlertTriangle,
    accent: 'text-orange-200 border-orange-200/20 bg-orange-200/[0.07]',
  },
};

function formatDate(value: string | null | undefined): string {
  if (!value) return 'Not stated by source';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(date);
}

function safeSourceUrl(value: string): string | null {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' || url.protocol === 'http:' ? url.href : null;
  } catch {
    return null;
  }
}

function SourceRecord({ record }: { record: VehicleCoverageItem }) {
  const details = recordKindDetails[record.recordKind] ?? {
    label: 'Source observation',
    description: 'Source record',
    icon: FileText,
    accent: 'text-slate-200 border-slate-300/20 bg-slate-300/[0.06]',
  };
  const Icon = details.icon;
  const sourceUrl = safeSourceUrl(record.sourceUrl);

  return (
    <article
      className="rounded-xl border border-white/[0.08] bg-workstation-panel/70 p-4 sm:p-5"
      data-testid={`card-vehicle-coverage-${record.id}`}
    >
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-lg font-semibold tracking-tight text-slate-100">
              {record.make} <span className="text-workstation-accent">{record.model}</span>
            </span>
            <span className="rounded border border-white/10 bg-white/[0.03] px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-slate-300">
              {labelForClass(record.vehicleClass)}
            </span>
          </div>
          {record.modelYearEvidence && (
            <p className="mt-1 text-xs text-slate-400">
              Model-year evidence <span className="font-mono text-slate-300">{record.modelYearEvidence}</span>
            </p>
          )}
        </div>
        <span className={`inline-flex w-fit shrink-0 items-center gap-2 rounded-md border px-2.5 py-1.5 text-[11px] font-medium ${details.accent}`}>
          <Icon aria-hidden="true" className="h-3.5 w-3.5" />
          {details.label}
        </span>
      </div>

      <div className="mt-4 grid gap-4 border-t border-white/[0.07] pt-4 md:grid-cols-[minmax(0,1fr)_minmax(220px,0.72fr)]">
        <div className="min-w-0">
          <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-500">Observation</p>
          <p className="mt-1.5 whitespace-pre-wrap break-words text-sm leading-6 text-slate-300">{record.observationNote}</p>
          <p className="mt-2 font-mono text-[11px] text-slate-500">
            Observed {formatDate(record.observedOn)}
          </p>
        </div>

        <div className="min-w-0 rounded-lg border border-white/[0.07] bg-workstation-bg/55 p-3.5">
          <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-500">{details.description}</p>
          {sourceUrl ? (
            <a
              href={sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              data-testid={`link-coverage-source-${record.id}`}
              className="mt-2 inline-flex max-w-full items-start gap-1.5 text-sm font-medium leading-5 text-cyan-200 underline decoration-cyan-200/30 underline-offset-4 transition-colors hover:text-cyan-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-workstation-accent"
            >
              <span className="break-words">{record.sourceTitle}</span>
              <ArrowUpRight aria-hidden="true" className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              <span className="sr-only">(opens in a new tab)</span>
            </a>
          ) : (
            <p className="mt-2 break-words text-sm font-medium text-slate-200">{record.sourceTitle}</p>
          )}
          <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-2 text-[11px]">
            <div>
              <dt className="text-slate-500">Published</dt>
              <dd className="mt-0.5 font-mono text-slate-300">{formatDate(record.sourcePublicationDate)}</dd>
            </div>
            <div>
              <dt className="text-slate-500">Source observed</dt>
              <dd className="mt-0.5 font-mono text-slate-300">{formatDate(record.sourceObservedOn)}</dd>
            </div>
          </dl>
        </div>
      </div>
    </article>
  );
}

export function VehicleCoverageCatalogue() {
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [vehicleClass, setVehicleClass] = useState<RoadVehicleClass | ''>('');
  const [offset, setOffset] = useState(0);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setSearch(searchInput.trim());
      setOffset(0);
    }, 250);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  useEffect(() => setOffset(0), [vehicleClass]);

  const params = {
    ...(search ? { search } : {}),
    ...(vehicleClass ? { vehicleClass } : {}),
    limit: PAGE_SIZE,
    offset,
  };
  const { data, isLoading, isError, refetch, isFetching } = useGetVehicleCoverage(params, {
    query: { staleTime: 60_000, queryKey: getGetVehicleCoverageQueryKey(params) },
  });
  const records = data?.records ?? [];
  const total = data?.total ?? 0;
  const pageStart = total === 0 ? 0 : offset + 1;
  const pageEnd = Math.min(offset + records.length, total);

  return (
    <section className="min-h-full overflow-y-auto bg-workstation-bg px-4 py-5 text-slate-100 sm:px-6 sm:py-7 lg:px-8" aria-labelledby="coverage-title">
      <div className="mx-auto max-w-6xl">
        <header className="relative overflow-hidden rounded-2xl border border-white/[0.09] bg-workstation-panel/80 px-5 py-6 sm:px-7 sm:py-8">
          <div aria-hidden="true" className="pointer-events-none absolute inset-y-0 right-0 hidden w-1/3 opacity-30 sm:block">
            <div className="tech-grid h-full w-full [mask-image:linear-gradient(to_left,black,transparent)]" />
          </div>
          <div className="relative">
            <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-workstation-accent">
              <span className="h-px w-6 bg-workstation-accent" />
              Source-backed vehicle records
            </div>
            <div className="mt-4 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
              <div className="max-w-2xl">
                <h1 id="coverage-title" className="text-2xl font-semibold tracking-tight text-slate-100 sm:text-3xl">
                  Vehicle coverage catalogue
                </h1>
                <p className="mt-2 max-w-xl text-sm leading-6 text-slate-400">
                  Inspect what source pages document. These observations are not vehicle-specific electrical specifications.
                </p>
              </div>
              {data && (
                <div className="flex items-center gap-2 self-start rounded-lg border border-workstation-accent/20 bg-workstation-accent/[0.06] px-3 py-2 sm:self-auto">
                  <ShieldCheck aria-hidden="true" className="h-4 w-4 text-workstation-accent" />
                  <div>
                    <p className="font-mono text-lg leading-5 text-slate-100" data-testid="text-verified-pinout-count">
                      {data.verifiedEcuPinoutCount}
                    </p>
                    <p className="mt-1 text-[10px] uppercase tracking-wider text-slate-400">rights-approved exact-variant ECU pinouts</p>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-6 grid gap-3 sm:grid-cols-[minmax(0,1fr)_240px]">
              <label className="relative block">
                <span className="sr-only">Search make or model</span>
                <Search aria-hidden="true" className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                <input
                  type="search"
                  value={searchInput}
                  onChange={(event) => setSearchInput(event.target.value)}
                  placeholder="Search make or model"
                  autoComplete="off"
                  data-testid="input-coverage-search"
                  className="h-11 w-full rounded-lg border border-white/10 bg-workstation-bg/80 pl-10 pr-3 text-sm text-slate-100 placeholder:text-slate-500 focus:border-workstation-accent/60 focus:outline-none focus:ring-2 focus:ring-workstation-accent/20"
                />
              </label>
              <label className="block">
                <span className="sr-only">Filter by vehicle class</span>
                <select
                  value={vehicleClass}
                  onChange={(event) => setVehicleClass(event.target.value as RoadVehicleClass | '')}
                  data-testid="select-coverage-class"
                  className="h-11 w-full rounded-lg border border-white/10 bg-workstation-bg/80 px-3 text-sm text-slate-200 focus:border-workstation-accent/60 focus:outline-none focus:ring-2 focus:ring-workstation-accent/20"
                >
                  {vehicleClasses.map((item) => (
                    <option key={item.value || 'all'} value={item.value}>{item.label}</option>
                  ))}
                </select>
              </label>
            </div>
          </div>
        </header>

        {data && (
          <div className="mt-4 grid gap-3 lg:grid-cols-2">
            <aside className="rounded-xl border border-amber-200/15 bg-amber-200/[0.045] p-4" data-testid="text-coverage-warning">
              <div className="flex gap-3">
                <AlertTriangle aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0 text-amber-200" />
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-amber-100">Coverage limits</p>
                  <p className="mt-1.5 whitespace-pre-wrap break-words text-xs leading-5 text-slate-300">{data.coverageWarning}</p>
                </div>
              </div>
            </aside>
            <aside className="rounded-xl border border-orange-200/15 bg-orange-200/[0.04] p-4" data-testid="text-technical-data-warning">
              <div className="flex gap-3">
                <ArrowDown aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0 text-orange-200" />
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-orange-100">Technical-data limits</p>
                  <p className="mt-1.5 whitespace-pre-wrap break-words text-xs leading-5 text-slate-300">{data.technicalDataWarning}</p>
                </div>
              </div>
            </aside>
          </div>
        )}

        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-b border-white/[0.08] pb-3">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="font-mono text-slate-200" data-testid="text-coverage-result-count">
              {data ? `${pageStart}–${pageEnd} of ${total}` : '—'}
            </span>
            <span>source observations</span>
            {data && <span className="text-slate-600">·</span>}
            {data && <span className="font-mono">Snapshot {formatDate(data.snapshotDate)}</span>}
          </div>
          {data && isFetching && (
            <span className="inline-flex items-center gap-1.5 text-[11px] text-slate-400" role="status">
              <LoaderCircle aria-hidden="true" className="h-3.5 w-3.5 animate-spin motion-reduce:animate-none" />
              Updating results
            </span>
          )}
        </div>

        {isLoading ? (
          <div className="mt-4 space-y-3" aria-label="Loading vehicle coverage" aria-busy="true">
            {[0, 1, 2].map((item) => (
              <div key={item} className="rounded-xl border border-white/[0.07] bg-workstation-panel/50 p-5">
                <div className="h-5 w-48 max-w-full animate-pulse rounded bg-slate-700/50 motion-reduce:animate-none" />
                <div className="mt-4 h-3 w-full animate-pulse rounded bg-slate-800 motion-reduce:animate-none" />
                <div className="mt-2 h-3 w-2/3 animate-pulse rounded bg-slate-800 motion-reduce:animate-none" />
              </div>
            ))}
          </div>
        ) : isError ? (
          <div className="mt-5 rounded-xl border border-red-300/20 bg-red-300/[0.05] p-5" role="alert" data-testid="state-coverage-error">
            <div className="flex items-start gap-3">
              <AlertTriangle aria-hidden="true" className="mt-0.5 h-5 w-5 shrink-0 text-red-200" />
              <div>
                <h2 className="font-medium text-slate-100">Coverage records could not be loaded</h2>
                <p className="mt-1 text-sm leading-5 text-slate-400">The catalogue service did not return a response. Try again to request the source-backed snapshot.</p>
                <button
                  type="button"
                  onClick={() => void refetch()}
                  data-testid="button-retry-coverage"
                  className="mt-4 inline-flex min-h-10 items-center gap-2 rounded-lg border border-white/15 px-3 text-sm font-medium text-slate-100 hover:bg-white/[0.06] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-workstation-accent"
                >
                  <RefreshCw aria-hidden="true" className="h-4 w-4" />
                  Retry
                </button>
              </div>
            </div>
          </div>
        ) : total === 0 ? (
          <div className="mt-5 rounded-xl border border-white/[0.08] bg-workstation-panel/50 px-5 py-10 text-center" data-testid="state-coverage-empty">
            <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-xl border border-workstation-accent/20 bg-workstation-accent/[0.07]">
              {search || vehicleClass ? <Search aria-hidden="true" className="h-5 w-5 text-workstation-accent" /> : <FileText aria-hidden="true" className="h-5 w-5 text-workstation-accent" />}
            </div>
            <h2 className="mt-4 text-base font-semibold text-slate-100">
              {search || vehicleClass ? 'No matching source observations' : 'No source observations in this snapshot'}
            </h2>
            <p className="mx-auto mt-2 max-w-lg text-sm leading-6 text-slate-400">
              {search || vehicleClass
                ? 'Try a different make or model, or broaden the vehicle-class filter.'
                : 'The catalogue response contains no records at this time. This is not evidence about vehicle availability or market coverage.'}
            </p>
          </div>
        ) : (
          <div className="mt-4 space-y-3">
            {records.map((record) => <SourceRecord key={record.id} record={record} />)}
            {records.length === 0 && (
              <div className="rounded-xl border border-white/[0.08] bg-workstation-panel/50 p-5 text-sm text-slate-400" role="status">
                No records are present on this page of the response.
              </div>
            )}
          </div>
        )}

        {!isLoading && !isError && total > PAGE_SIZE && (
          <nav aria-label="Vehicle coverage pages" className="mt-5 flex items-center justify-between gap-3 border-t border-white/[0.08] pt-4">
            <button
              type="button"
              onClick={() => setOffset(Math.max(0, offset - PAGE_SIZE))}
              disabled={offset === 0}
              data-testid="button-coverage-previous"
              className="min-h-10 rounded-lg border border-white/10 px-3 text-sm text-slate-300 hover:bg-white/[0.05] disabled:cursor-not-allowed disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-workstation-accent"
            >
              Previous
            </button>
            <span className="font-mono text-xs text-slate-500">
              Page {Math.floor(offset / PAGE_SIZE) + 1} of {Math.ceil(total / PAGE_SIZE)}
            </span>
            <button
              type="button"
              onClick={() => setOffset(offset + PAGE_SIZE)}
              disabled={offset + PAGE_SIZE >= total}
              data-testid="button-coverage-next"
              className="min-h-10 rounded-lg border border-white/10 px-3 text-sm text-slate-300 hover:bg-white/[0.05] disabled:cursor-not-allowed disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-workstation-accent"
            >
              Next
            </button>
          </nav>
        )}
      </div>
    </section>
  );
}
