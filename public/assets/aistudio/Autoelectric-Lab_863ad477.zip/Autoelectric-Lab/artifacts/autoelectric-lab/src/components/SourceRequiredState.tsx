import React from 'react';
import { FileText, ShieldAlert } from 'lucide-react';

interface SourceRequiredStateProps {
  title: string;
  detail: string;
  onOpenDocuments?: () => void;
}

export const SourceRequiredState: React.FC<SourceRequiredStateProps> = ({
  title,
  detail,
  onOpenDocuments,
}) => (
  <section
    role="status"
    className="m-4 flex min-h-[280px] flex-col items-center justify-center rounded-2xl border border-amber-500/20 bg-workstation-panel/70 p-8 text-center"
  >
    <ShieldAlert className="mb-4 h-9 w-9 text-amber-400" aria-hidden="true" />
    <h2 className="text-lg font-semibold text-white">{title}</h2>
    <p className="mt-2 max-w-xl text-sm leading-6 text-slate-400">{detail}</p>
    {onOpenDocuments && (
      <button
        type="button"
        onClick={onOpenDocuments}
        className="mt-5 inline-flex items-center gap-2 rounded-lg border border-cyan-500/30 bg-cyan-950/40 px-4 py-2 text-sm font-medium text-cyan-200 hover:bg-cyan-900/50"
      >
        <FileText className="h-4 w-4" aria-hidden="true" />
        Review source documents
      </button>
    )}
  </section>
);
