import { pcbProjectSchema } from './pcbValidation';
import type { PCBProject } from '../types/pcbScanner';
export function parseProjectBackup(raw:string):PCBProject {
  if (raw.length > 12_000_000) throw new Error('Backup exceeds 12 MB.');
  const parsed=JSON.parse(raw);
  if (parsed?.format !== 'autoelectric-manual-review-v1') throw new Error('Choose an Autoelectric manual-review JSON backup.');
  const project=pcbProjectSchema.parse(parsed.project) as PCBProject;
  const docIds=new Set(project.documents.map(d=>d.id));
  if (docIds.size !== project.documents.length) throw new Error('Duplicate document IDs.');
  for (const doc of project.documents) {
    if (!/^data:image\/(png|jpeg|webp);base64,[a-zA-Z0-9+/=\r\n]+$/.test(doc.imageUrl)) throw new Error('Backup documents must be embedded PNG, JPEG, or WebP images, not external URLs.');
  }
  if (project.documents.length && !docIds.has(project.activeDocumentId)) throw new Error('The active document is missing.');
  const compIds=new Set(project.components.map(c=>c.id)), netIds=new Set(project.nets.map(n=>n.id));
  if (compIds.size !== project.components.length || netIds.size !== project.nets.length) throw new Error('Duplicate observation IDs.');
  const annotations=project.annotations??[];
  if(new Set(annotations.map(a=>a.id)).size!==annotations.length)throw new Error('Duplicate annotation IDs.');
  if(annotations.some(a=>a.sourceImageId&&!docIds.has(a.sourceImageId)))throw new Error('An annotation refers to a missing document.');
  const labels=project.components.map(c=>`${c.sourceImageId}:${c.refDes.trim().toLowerCase()}`);
  if(new Set(labels).size!==labels.length)throw new Error('Duplicate reference designators on one document.');
  for (const c of project.components) {
    if (!docIds.has(c.sourceImageId) || c.connectedNetIds.some(id=>!netIds.has(id))) throw new Error('Component has a missing document or net link.');
  }
  for (const n of project.nets) {
    if ((n.sourceImageId && !docIds.has(n.sourceImageId)) || n.connectedComponentIds.some(id=>!compIds.has(id))) throw new Error('Path has a missing document or component link.');
    if(n.sourceImageId && n.connectedComponentIds.some(id=>project.components.find(c=>c.id===id)?.sourceImageId!==n.sourceImageId))throw new Error('A path cannot connect observations on unrelated document images.');
  }
  return project;
}
export function downloadProjectBackup(project:PCBProject) {
  const data=JSON.stringify({format:'autoelectric-manual-review-v1',project},null,2);
  const url=URL.createObjectURL(new Blob([data],{type:'application/json'}));
  const a=document.createElement('a');a.href=url;a.download=`autoelectric-review-${project.id}.json`;a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}
