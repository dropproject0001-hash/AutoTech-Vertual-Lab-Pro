import React, { useState } from 'react';
import type { DetectedComponent, ElectricalNet } from '../types/pcbScanner';

interface Props {
  documentId: string;
  kind: 'component' | 'net';
  components: DetectedComponent[];
  net?: ElectricalNet;
  onSaveComponent: (component: DetectedComponent) => void;
  onSaveNet: (net: ElectricalNet) => void;
  onClose: () => void;
}
export function ManualObservationEditor({ documentId, kind, components, net, onSaveComponent, onSaveNet, onClose }: Props) {
  const [name, setName] = useState(net?.name ?? '');
  const [notes, setNotes] = useState(net?.incompleteNotes ?? '');
  const [marking, setMarking] = useState('');
  const [value, setValue] = useState('');
  const [x, setX] = useState('100'); const [y, setY] = useState('100');
  const [points, setPoints] = useState(net?.tracePoints.map(p => `${p.x},${p.y}`).join('; ') ?? '');
  const [selected, setSelected] = useState<string[]>(net?.connectedComponentIds ?? []);
  const [error, setError] = useState('');
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (!name.trim()) throw new Error('Enter a reference or path name.');
      if (kind === 'component') {
        if (components.some(c => c.refDes.toLowerCase() === name.trim().toLowerCase())) throw new Error('This reference designator already exists on this document.');
        const nx = Number(x), ny = Number(y);
        if (!x.trim() || !y.trim() || !Number.isFinite(nx) || !Number.isFinite(ny) || nx < 0 || ny < 0 || nx > 950 || ny > 950) throw new Error('Placement must be 0–950 on each normalized axis.');
        onSaveComponent({
          id: crypto.randomUUID(), sourceImageId: documentId, refDes:name.trim(), category:'UNKNOWN', marking:marking.trim(),
          decodedValue:value.trim(), packageType:'Not recorded', bbox:{xmin:nx,ymin:ny,xmax:nx+50,ymax:ny+50},
          confidenceScore:0, verificationStatus:'UNVERIFIED', circuitFunction:'Not established',
          connectedNetIds:[], notes:notes.trim(),
        });
      } else {
        const tracePoints = points.split(';').map(pair => {
          const values = pair.trim().split(',');
          if (values.length !== 2 || values.some(v => !v.trim())) throw new Error('Use x,y; x,y coordinates.');
          const [px,py] = values.map(Number);
          if (![px,py].every(n => Number.isFinite(n) && n >= 0 && n <= 1000)) throw new Error('Coordinates must be 0–1000.');
          return {x:px,y:py};
        });
        if (tracePoints.length < 2) throw new Error('A path requires at least two coordinate points.');
        onSaveNet({
          id:net?.id ?? crypto.randomUUID(), name:name.trim(), sourceImageId:documentId, signalType:'UNKNOWN',
          connectedComponentIds:selected,connectedTerminalIds:[],tracePoints,verificationStatus:'UNVERIFIED',
          isComplete:false,incompleteNotes:notes.trim() || 'User-recorded path only; hidden connectivity is not verified.',
        });
      }
    } catch (err) { setError(err instanceof Error ? err.message : 'Invalid observation.'); }
  };
  const inputClass = 'block w-full p-2 mt-1 bg-slate-950 border border-slate-700 rounded';
  return <div role="dialog" aria-modal="true" aria-label={`Manual ${kind} observation`} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 text-slate-100">
    <form className="max-w-lg w-full max-h-[90vh] overflow-auto bg-slate-900 border border-slate-700 rounded-xl p-5 space-y-3" onSubmit={submit}>
      <h3 className="font-bold text-lg">{net ? 'Edit' : 'Add'} {kind} observation</h3>
      <p className="text-sm text-amber-200">User observations only. Nothing is automatically identified, electrically verified, or assigned to an ECU pin.</p>
      <label className="block text-sm">{kind === 'component' ? 'Reference designator' : 'Path name'}<input aria-label={kind === 'component' ? 'Reference designator' : 'Path name'} required className={inputClass} value={name} onChange={e => setName(e.target.value)} /></label>
      {kind === 'component' ? <>
        <label className="block text-sm">Visible marking<input aria-label="Visible marking" className={inputClass} value={marking} onChange={e => setMarking(e.target.value)} /></label>
        <label className="block text-sm">Value as recorded (optional)<input aria-label="Recorded component value" className={inputClass} value={value} onChange={e => setValue(e.target.value)} /></label>
        <div className="grid grid-cols-2 gap-3"><label className="text-sm">Placement X (0–950)<input aria-label="Placement X" className={inputClass} type="number" min="0" max="950" value={x} onChange={e => setX(e.target.value)} /></label><label className="text-sm">Placement Y (0–950)<input aria-label="Placement Y" className={inputClass} type="number" min="0" max="950" value={y} onChange={e => setY(e.target.value)} /></label></div>
        <p className="text-xs text-slate-400">Placement is an annotation box, not a measured package dimension.</p>
      </> : <>
        <label className="block text-sm">Normalized path coordinates (0–1000)<textarea aria-label="Path coordinates" required className={inputClass} value={points} onChange={e => setPoints(e.target.value)} placeholder="x,y; x,y; x,y" /></label>
        <fieldset><legend className="text-sm">Components connected in your observation</legend>{components.map(c => <label key={c.id} className="block text-sm"><input type="checkbox" checked={selected.includes(c.id)} onChange={e => setSelected(e.target.checked ? [...selected,c.id] : selected.filter(id => id !== c.id))} /> {c.refDes}</label>)}</fieldset>
      </>}
      <label className="block text-sm">Observation notes / source and page<textarea aria-label="Observation notes" className={inputClass} value={notes} onChange={e => setNotes(e.target.value)} /></label>
      {error && <p role="alert" className="text-rose-300">{error}</p>}
      <div className="flex justify-end gap-3"><button type="button" onClick={onClose}>Cancel</button><button className="bg-cyan-400 text-slate-950 px-4 py-2 rounded font-bold">Save observation</button></div>
    </form>
  </div>;
}
