import React, { useState } from 'react';
import type { VehicleProfile, ConnectorPin, BenchReading, ElectricalFault } from '../types/automotive';
import type { SavedReference } from '../services/referenceLibrary';

interface Props {
  vehicle: VehicleProfile; selectedPin: ConnectorPin | null; readings: BenchReading[]; activeFault: ElectricalFault;
  reference?: SavedReference | null; focusedReading?: BenchReading | null; onOpenLibrary?: () => void;
}
export function AiEngineeringAssistant({ reference, readings, onOpenLibrary }: Props) {
  const [query, setQuery] = useState('');
  const [submitted, setSubmitted] = useState('');
  const matches = reference && submitted ? reference.profile.connectors.flatMap(c =>
    c.pins.filter(p => `${c.id}:${p.number}`.toLowerCase() === submitted.toLowerCase() ||
      `${p.label} ${p.function}`.toLowerCase().includes(submitted.toLowerCase())).map(p => ({connector:c,pin:p}))) : [];
  return <div className="h-full overflow-auto p-4 sm:p-6 text-slate-100 space-y-5">
    <h2 className="text-xl font-bold">Reference assistant</h2>
    <p className="rounded border border-amber-500/30 bg-amber-950/30 p-4 text-sm text-amber-200">
      Generative technical answers are disabled. This tool retrieves literal entries from the selected user transcript; it cannot diagnose a vehicle or fill missing information. A user-provided citation has not been independently authenticated.
    </p>
    {!reference ? <div className="space-y-3"><p>No reference transcript is selected. There is no source-grounded answer available.</p><button className="px-4 py-2 bg-cyan-400 rounded text-slate-950" onClick={onOpenLibrary}>Open Reference Library</button></div> : <>
      <p className="text-sm text-slate-400">{reference.profile.make} {reference.profile.model} · ECU {reference.profile.ecuPartNumber} · USER TRANSCRIPT</p>
      <form onSubmit={e => {e.preventDefault();setSubmitted(query.trim());}} className="flex flex-wrap gap-3">
        <input aria-label="Search transcript" className="flex-1 min-w-0 bg-slate-900 border border-slate-700 rounded p-3" value={query} onChange={e => setQuery(e.target.value)} placeholder="Exact connector:pin, label, or text" required />
        <button className="bg-cyan-400 text-slate-950 px-4 py-2 rounded font-bold">Find cited entries</button>
      </form>
      {submitted && !matches.length && <p role="status">No matching source entry. No technical answer can be supplied from this transcript.</p>}
      {matches.map(({connector:c,pin:p}) => <article key={`${c.id}:${p.number}`} className="bg-slate-900 border border-slate-700 p-4 rounded space-y-2">
        <h3 className="font-bold">{c.id}:{p.number} — {p.label}</h3><p>{p.function}</p>
        <p className="text-sm text-amber-200">View: {c.orientation}. Source locator: {p.sourceLocator}</p>
        <a className="text-cyan-300 underline break-all" href={reference.profile.source.url} target="_blank" rel="noopener noreferrer">{reference.profile.source.title} · {reference.profile.source.revision}</a>
        <p className="text-xs text-slate-400">Literal user transcription, not an AI-derived answer or an independently verified OEM record.</p>
      </article>)}
    </>}
    <div className="text-sm text-slate-400 border-t border-slate-700 pt-4">{readings.length} local records in the current context. Records alone do not establish a root cause, safe pin connection, or repair verdict.</div>
  </div>;
}
