import { z } from 'zod';
import type { BenchReading } from '../types/automotive';

export const readingSchema = z.object({
  id: z.string().min(1),
  pinNumber: z.number().int().positive().nullable(),
  connectorId: z.string().min(1).nullable(),
  pinLabel: z.string().trim().min(1).max(300),
  measurementType: z.enum(['VOLTAGE_DC', 'VOLTAGE_AC', 'RESISTANCE', 'DIODE', 'CONTINUITY', 'CURRENT']),
  measuredValue: z.number().finite(),
  unit: z.string().min(1),
  expectedMin: z.number().finite().nullable().optional(),
  expectedMax: z.number().finite().nullable().optional(),
  status: z.enum(['PASS', 'FAIL', 'OPEN_CIRCUIT', 'SHORT_CIRCUIT', 'INVALID_CONNECTION', 'UNVERIFIED', 'NOT_APPLICABLE']),
  notes: z.string().max(5000),
  timestamp: z.string().datetime(),
  source: z.enum(['SIMULATED', 'TECHNICIAN_ENTERED']).optional(),
  technicianName: z.string().max(200).optional(),
  vehicleId: z.string().optional(),
  vehicleDescription: z.string().max(1000).optional(),
  comparisonSource: z.string().max(2000).optional(),
});

export function createManualReading(input: Omit<BenchReading, 'status' | 'source'>): BenchReading {
  const min = input.expectedMin;
  const max = input.expectedMax;
  const hasMin = typeof min === 'number';
  const hasMax = typeof max === 'number';
  if (hasMin !== hasMax || (hasMin && hasMax && min > max)) throw new Error('Provide both range limits in ascending order, or leave both blank.');
  if (hasMin && !input.comparisonSource?.trim()) throw new Error('A comparison range requires its source and test conditions.');
  if ((input.pinNumber === null) !== (input.connectorId === null)) throw new Error('Record both connector and pin, or leave both blank.');
  if (['RESISTANCE', 'DIODE', 'CONTINUITY'].includes(input.measurementType) && input.measuredValue < 0) throw new Error('This mode requires a non-negative value.');
  return readingSchema.parse({
    ...input,
    source: 'TECHNICIAN_ENTERED',
    status: hasMin && hasMax ? (input.measuredValue >= min && input.measuredValue <= max ? 'PASS' : 'FAIL') : 'UNVERIFIED',
  });
}

export function summarizeReadings(readings: BenchReading[]) {
  return {
    total: readings.length,
    pass: readings.filter(r => r.status === 'PASS').length,
    faults: readings.filter(r => ['FAIL', 'OPEN_CIRCUIT', 'SHORT_CIRCUIT', 'INVALID_CONNECTION'].includes(r.status)).length,
    unassessed: readings.filter(r => ['UNVERIFIED', 'NOT_APPLICABLE'].includes(r.status)).length,
    simulated: readings.filter(r => r.source === 'SIMULATED').length,
  };
}

const KEY = 'autoelectric_readings_v1';
export function loadReadings(): BenchReading[] {
  const raw = localStorage.getItem(KEY);
  return raw ? z.array(readingSchema).parse(JSON.parse(raw)) : [];
}
export function persistReadings(readings: BenchReading[]) {
  localStorage.setItem(KEY, JSON.stringify(z.array(readingSchema).parse(readings)));
}
