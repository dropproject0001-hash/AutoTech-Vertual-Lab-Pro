/**
 * Persistent Project & Annotation Storage Engine for PCB Scanner
 * AutoElectric Lab Pro - RAMT Engineering Suite
 */

import { PCBProject, AuditHistoryRecord, DetectedComponent, ElectricalNet } from '../types/pcbScanner';
import { pcbProjectSchema, pcbProjectsSchema } from './pcbValidation';

const STORAGE_KEY_PROJECTS = 'autoelectric_pcb_projects';
const LEGACY_BACKUP_KEY = 'autoelectric_pcb_projects_legacy_unverified_backup';
const LEGACY_SAMPLE_IDS = new Set([
  'project-hilux-1gd-power',
  'project-isuzu-4jj1-pcb',
  'project-ford-sid208',
]);

export class PcbStorageEngine {
  /**
   * Load all saved PCB projects from persistent storage
   */
  static loadProjects(): PCBProject[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_PROJECTS);
      if (!raw) return [];
      const parsed: unknown = JSON.parse(raw);
      const validated = pcbProjectsSchema.parse(parsed) as PCBProject[];

      const legacySamples = validated.filter(
        (project): project is PCBProject =>
          Boolean(project && typeof project === 'object' && LEGACY_SAMPLE_IDS.has((project as PCBProject).id)),
      );
      if (legacySamples.length > 0 && !localStorage.getItem(LEGACY_BACKUP_KEY)) {
        localStorage.setItem(LEGACY_BACKUP_KEY, JSON.stringify(legacySamples));
      }

      return validated.filter(
        (project): project is PCBProject =>
          Boolean(
            project &&
              typeof project === 'object' &&
              typeof (project as PCBProject).id === 'string' &&
              !LEGACY_SAMPLE_IDS.has((project as PCBProject).id),
          ),
      );
    } catch (e) {
      console.error('Failed to load PCB projects from local storage:', e);
      throw new Error('Saved PCB projects could not be read. Existing storage has not been replaced. Back it up before resetting or repairing it.');
    }
  }

  /**
   * Save a PCB project to persistent storage
   */
  static saveProject(project: PCBProject): boolean {
    try {
      pcbProjectSchema.parse(project);
      const projects = this.loadProjects();
      const idx = projects.findIndex((p) => p.id === project.id);
      project.updatedAt = new Date().toISOString();

      if (idx >= 0) {
        projects[idx] = project;
      } else {
        projects.unshift(project);
      }

      localStorage.setItem(STORAGE_KEY_PROJECTS, JSON.stringify(projects));
      return true;
    } catch (e) {
      console.error('Failed to save PCB project:', e);
      return false;
    }
  }

  /**
   * Delete a PCB project by ID
   */
  static deleteProject(projectId: string): boolean {
    try {
      const projects = this.loadProjects().filter((p) => p.id !== projectId);
      localStorage.setItem(STORAGE_KEY_PROJECTS, JSON.stringify(projects));
      return true;
    } catch (e) {
      console.error('Failed to delete PCB project:', e);
      return false;
    }
  }

  /**
   * Append an audit history record to a project
   */
  static addAuditRecord(projectId: string, record: Omit<AuditHistoryRecord, 'id' | 'timestamp'>): PCBProject | null {
    const projects = this.loadProjects();
    const project = projects.find((p) => p.id === projectId);
    if (!project) return null;

    const fullRecord: AuditHistoryRecord = {
      ...record,
      id: `audit-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toISOString(),
    };

    project.auditHistory.unshift(fullRecord);
    this.saveProject(project);
    return project;
  }
}
