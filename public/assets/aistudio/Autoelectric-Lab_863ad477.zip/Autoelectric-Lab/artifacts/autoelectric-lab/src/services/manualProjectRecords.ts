import type { PCBProject } from '../types/pcbScanner';

export function removeComponentObservation(project:PCBProject,id:string):PCBProject {
  return {...project,components:project.components.filter(c=>c.id!==id),
    nets:project.nets.map(n=>n.connectedComponentIds.includes(id)
      ? {...n,connectedComponentIds:n.connectedComponentIds.filter(c=>c!==id),isComplete:false}:n)};
}
export function removeObservedPath(project:PCBProject,id:string):PCBProject {
  return {...project,nets:project.nets.filter(n=>n.id!==id),
    components:project.components.map(c=>({...c,connectedNetIds:c.connectedNetIds.filter(n=>n!==id)}))};
}
export function removeDocumentNote(project:PCBProject,id:string):PCBProject {
  return {...project,annotations:(project.annotations??[]).filter(a=>a.id!==id)};
}
