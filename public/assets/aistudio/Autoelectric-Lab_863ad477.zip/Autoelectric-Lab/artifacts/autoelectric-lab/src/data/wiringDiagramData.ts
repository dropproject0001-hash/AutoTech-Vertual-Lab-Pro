import { WiringNode, WiringTrace } from '../types/automotive';

export interface WiringDiagramSystem {
  id: string;
  name: string;
  description?: string;
  nodes: WiringNode[];
  traces: WiringTrace[];
  sourceReference?: string;
}

/** No vehicle-specific diagrams are bundled without their source documents. */
export const WIRING_SYSTEMS: WiringDiagramSystem[] = [];
