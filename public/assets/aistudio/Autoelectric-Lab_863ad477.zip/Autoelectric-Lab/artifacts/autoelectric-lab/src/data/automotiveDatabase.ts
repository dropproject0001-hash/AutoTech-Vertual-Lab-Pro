import { DTCRecord, PCBComponent, VehicleProfile } from '../types/automotive';

/**
 * Vehicle-specific records are intentionally empty until matching source
 * documents are supplied and reviewed. Do not add example specifications here.
 */
export const VEHICLE_DATABASE: VehicleProfile[] = [];
export const DTC_DATABASE: DTCRecord[] = [];
export const PCB_COMPONENT_LIBRARY: PCBComponent[] = [];
