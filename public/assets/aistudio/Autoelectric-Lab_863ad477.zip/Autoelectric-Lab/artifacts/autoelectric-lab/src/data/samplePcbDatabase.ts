import { PCBProject } from '../types/pcbScanner';

/** No sample PCB projects are bundled because their technical claims were unsourced. */
export const SAMPLE_PCB_PROJECTS: PCBProject[] = [];
