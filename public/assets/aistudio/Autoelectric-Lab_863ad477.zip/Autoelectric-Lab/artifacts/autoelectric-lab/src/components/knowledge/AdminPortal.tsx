import {
  AlertTriangle,
  ArrowRight,
  BadgeCheck,
  BookOpenCheck,
  ClipboardList,
  Database,
  FileSearch,
  LockKeyhole,
  RefreshCw,
  ShieldCheck,
  Users,
} from "lucide-react";
import {
  getGetKnowledgeAdminSummaryQueryKey,
  useGetKnowledgeAdminAccess,
  useGetKnowledgeAdminSummary,
} from "@workspace/api-client-react";

type CountItemProps = {
  label: string;
  value: number;
  icon: typeof Database;
  detail?: string;
  testId: string;
};

function CountItem({ label, value, icon: Icon, detail, testId }: CountItemProps) {
  return (
    <article
      className="group min-w-0 rounded-xl border border-slate-700/70 bg-slate-900/60 p-4 transition-colors hover:border-slate-600 sm:p-5"
      data-testid={testId}
    >
      <div className="flex items-start justify-between gap-3">
        <p className="max-w-[13rem] text-sm leading-5 text-slate-300">{label}</p>
        <span className="rounded-lg border border-slate-700 bg-slate-800/80 p-2 text-cyan-200" aria-hidden="true">
          <Icon size={17} strokeWidth={1.8} />
        </span>
      </div>
      <p className="mt-5 font-mono text-3xl font-medium tracking-tight text-slate-50" data-testid={`${testId}-value`}>
        {value.toLocaleString()}
      </p>
      {detail && <p className="mt-2 text-xs leading-5 text-slate-500">{detail}</p>}
    </article>
  );
}

function LoadingSummary() {
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4" aria-label="Loading administrative counts" data-testid="admin-summary-loading">
      {Array.from({ length: 8 }, (_, index) => (
        <div key={index} className="h-36 animate-pulse rounded-xl border border-slate-800 bg-slate-900/70 p-5">
          <div className="h-3 w-2/3 rounded bg-slate-800" />
          <div className="mt-8 h-8 w-1/3 rounded bg-slate-800" />
          <div className="mt-4 h-2 w-1/2 rounded bg-slate-800" />
        </div>
      ))}
    </div>
  );
}

export function AdminPortal() {
  const access = useGetKnowledgeAdminAccess();
  const isAdmin = access.data?.isAdmin === true;
  const summary = useGetKnowledgeAdminSummary({
    query: {
      enabled: isAdmin,
      queryKey: getGetKnowledgeAdminSummaryQueryKey(),
    },
  });

  return (
    <main className="min-h-[100dvh] bg-workstation-bg px-4 py-7 text-slate-100 sm:px-7 sm:py-10 lg:px-10">
      <div className="mx-auto w-full max-w-6xl">
        <header className="mb-8 border-b border-slate-800 pb-6 sm:mb-10 sm:pb-8">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-cyan-900/70 bg-cyan-950/30 px-3 py-1.5 text-[11px] font-medium uppercase tracking-[0.16em] text-cyan-200">
                <span className="h-1.5 w-1.5 rounded-full bg-cyan-300" aria-hidden="true" />
                Autoelectric Lab / Administration
              </div>
              <h1 className="text-3xl font-semibold tracking-tight text-slate-50 sm:text-4xl">
                Review summary
              </h1>
              <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-400 sm:text-base">
                A read-only view of access and aggregate knowledge counts.
              </p>
            </div>
            <div className="flex w-fit items-center gap-2 rounded-lg border border-slate-700/80 bg-slate-900/80 px-3 py-2 text-xs text-slate-300">
              <LockKeyhole size={14} className="text-amber-300" aria-hidden="true" />
              Read-only access
            </div>
          </div>
        </header>

        {access.isLoading && (
          <section className="rounded-2xl border border-slate-800 bg-slate-900/50 p-5 sm:p-7" aria-live="polite" data-testid="admin-access-loading">
            <div className="flex items-center gap-4">
              <div className="h-11 w-11 animate-pulse rounded-xl bg-slate-800" />
              <div className="min-w-0 flex-1">
                <div className="h-4 w-44 animate-pulse rounded bg-slate-800" />
                <div className="mt-3 h-3 max-w-sm animate-pulse rounded bg-slate-800" />
              </div>
            </div>
          </section>
        )}

        {!access.isLoading && access.isError && (
          <section className="rounded-2xl border border-rose-900/60 bg-rose-950/20 p-5 sm:p-7" role="alert" data-testid="admin-access-error">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex gap-3">
                <AlertTriangle className="mt-0.5 shrink-0 text-rose-300" size={20} aria-hidden="true" />
                <div>
                  <h2 className="font-medium text-rose-100">Access status unavailable</h2>
                  <p className="mt-1 text-sm leading-6 text-rose-100/70">
                    The service could not confirm administrative access. No summary is shown.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => void access.refetch()}
                className="inline-flex min-h-11 items-center justify-center gap-2 rounded-lg border border-rose-800/80 px-4 text-sm text-rose-100 transition-colors hover:bg-rose-900/30 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-300"
                data-testid="button-retry-admin-access"
              >
                <RefreshCw size={15} aria-hidden="true" />
                Retry access check
              </button>
            </div>
          </section>
        )}

        {!access.isLoading && !access.isError && access.data && !isAdmin && (
          <section className="relative overflow-hidden rounded-2xl border border-amber-900/60 bg-slate-900/70 p-5 sm:p-8" data-testid="admin-non-admin-state">
            <div className="pointer-events-none absolute -right-12 -top-16 h-56 w-56 rounded-full border border-amber-700/15" aria-hidden="true" />
            <div className="relative flex max-w-2xl gap-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-amber-800/70 bg-amber-950/40 text-amber-200">
                <ShieldCheck size={20} aria-hidden="true" />
              </div>
              <div>
                <p className="text-xs font-medium uppercase tracking-[0.15em] text-amber-300/80">Access limited</p>
                <h2 className="mt-2 text-xl font-semibold text-slate-100">Administrative review is unavailable</h2>
                <p className="mt-3 text-sm leading-6 text-slate-400">
                  Your signed-in role does not have administrator access. This page only displays aggregate counts to administrators.
                </p>
              </div>
            </div>
          </section>
        )}

        {isAdmin && (
          <section aria-labelledby="counts-heading" data-testid="admin-summary-section">
            <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-[0.14em] text-emerald-300">
                  <BadgeCheck size={15} aria-hidden="true" />
                  Administrator verified
                </div>
                <h2 id="counts-heading" className="mt-2 text-lg font-semibold text-slate-100">Knowledge counts</h2>
                <p className="mt-1 max-w-2xl text-sm leading-6 text-slate-400">
                  Counts only. No technical evidence or record details are displayed here.
                </p>
              </div>
              {!summary.isLoading && !summary.isError && summary.data && (
                <button
                  type="button"
                  onClick={() => void summary.refetch()}
                  className="inline-flex min-h-10 w-fit items-center justify-center gap-2 rounded-lg border border-slate-700 px-3 text-sm text-slate-300 transition-colors hover:border-slate-500 hover:text-slate-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300"
                  data-testid="button-refresh-admin-summary"
                >
                  <RefreshCw size={14} aria-hidden="true" />
                  Refresh counts
                </button>
              )}
            </div>

            {summary.isLoading && <LoadingSummary />}

            {!summary.isLoading && summary.isError && (
              <div className="rounded-xl border border-rose-900/60 bg-rose-950/20 p-5" role="alert" data-testid="admin-summary-error">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex gap-3">
                    <AlertTriangle size={18} className="mt-0.5 shrink-0 text-rose-300" aria-hidden="true" />
                    <div>
                      <p className="font-medium text-rose-100">Summary could not be loaded</p>
                      <p className="mt-1 text-sm leading-6 text-rose-100/70">Access is confirmed, but counts are currently unavailable.</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => void summary.refetch()}
                    className="inline-flex min-h-11 items-center justify-center gap-2 rounded-lg border border-rose-800/80 px-4 text-sm text-rose-100 hover:bg-rose-900/30 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-300"
                    data-testid="button-retry-admin-summary"
                  >
                    <RefreshCw size={15} aria-hidden="true" />
                    Retry summary
                  </button>
                </div>
              </div>
            )}

            {!summary.isLoading && !summary.isError && summary.data && (
              <>
                {summary.data.ecuRecordCount === 0 &&
                  summary.data.pendingReviewCount === 0 &&
                  summary.data.pinAssignmentCount === 0 &&
                  summary.data.authorizedPinAssignmentCount === 0 &&
                  summary.data.benchProcedureCount === 0 &&
                  summary.data.authorizedBenchProcedureCount === 0 &&
                  summary.data.sourceCount === 0 &&
                  summary.data.userCount === 0 && (
                    <div className="mb-4 flex gap-3 rounded-xl border border-slate-700/70 bg-slate-900/50 p-4" data-testid="admin-empty-counts">
                      <FileSearch className="mt-0.5 shrink-0 text-cyan-200" size={18} aria-hidden="true" />
                      <div>
                        <p className="text-sm font-medium text-slate-200">All reported counts are zero</p>
                        <p className="mt-1 text-sm leading-5 text-slate-400">These values reflect the current summary response; no records are represented or inferred.</p>
                      </div>
                    </div>
                  )}

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4" data-testid="admin-summary-counts">
                  <CountItem label="ECU records" value={summary.data.ecuRecordCount} icon={Database} testId="count-ecu-records" />
                  <CountItem label="Pending review" value={summary.data.pendingReviewCount} icon={ClipboardList} testId="count-pending-review" />
                  <CountItem
                    label="Pin assignments"
                    value={summary.data.pinAssignmentCount}
                    icon={BookOpenCheck}
                    detail={`${summary.data.authorizedPinAssignmentCount.toLocaleString()} authorized`}
                    testId="count-pin-assignments"
                  />
                  <CountItem
                    label="Bench procedures"
                    value={summary.data.benchProcedureCount}
                    icon={ClipboardList}
                    detail={`${summary.data.authorizedBenchProcedureCount.toLocaleString()} authorized`}
                    testId="count-bench-procedures"
                  />
                  <CountItem label="Sources" value={summary.data.sourceCount} icon={FileSearch} testId="count-sources" />
                  <CountItem label="Users" value={summary.data.userCount} icon={Users} testId="count-users" />
                </div>
              </>
            )}
          </section>
        )}

        <footer className="mt-10 border-t border-slate-800 pt-5 sm:mt-12">
          <div className="flex items-start gap-3 text-xs leading-5 text-slate-500" data-testid="admin-limits-note">
            <ArrowRight className="mt-0.5 shrink-0 text-slate-600" size={14} aria-hidden="true" />
            <p>
              This surface provides access checks and aggregate counts only. Counts are not a claim that technical evidence is independently verified or complete.
            </p>
          </div>
        </footer>
      </div>
    </main>
  );
}
