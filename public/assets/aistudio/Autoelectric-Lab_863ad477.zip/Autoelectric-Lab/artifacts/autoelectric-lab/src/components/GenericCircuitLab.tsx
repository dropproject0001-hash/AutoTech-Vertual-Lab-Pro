import React, { useState } from 'react';
import { CheckCircle2, Calculator, PlugZap } from 'lucide-react';
import type { BenchReading, VehicleProfile } from '../types/automotive';
import { solveResistor } from '../services/circuitMath';

interface GenericCircuitLabProps {
  vehicle: VehicleProfile;
  onLogReading: (reading: BenchReading) => void;
}

const fmt = (n: number) => (Math.abs(n) >= 1e4 || (n !== 0 && Math.abs(n) < 1e-3) ? n.toExponential(4) : n.toPrecision(5));

export const GenericCircuitLab: React.FC<GenericCircuitLabProps> = ({ vehicle, onLogReading }) => {
  const [v, setV] = useState('');
  const [r, setR] = useState('');
  const [result, setResult] = useState<{ voltage: number; resistance: number; currentAmps: number; powerWatts: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [logged, setLogged] = useState<string | null>(null);

  const calc = (e: React.FormEvent) => {
    e.preventDefault();
    setLogged(null);
    if (!v.trim() || !r.trim()) { setResult(null); setError('Enter both voltage and resistance.'); return; }
    const voltage = Number(v); const resistance = Number(r);
    try { setResult({ voltage, resistance, ...solveResistor(voltage, resistance) }); setError(null); }
    catch (err) { setResult(null); setError(err instanceof Error ? err.message : 'Invalid input.'); }
  };

  const log = () => {
    if (!result) return;
    const id = typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `sim-${Date.now()}`;
    onLogReading({
      id, pinNumber: null, connectorId: null, pinLabel: 'Ideal resistor model',
      measurementType: 'CURRENT', measuredValue: result.currentAmps, unit: 'A',
      status: 'UNVERIFIED', source: 'SIMULATED', vehicleId: vehicle.id,
      notes: `Calculated, not measured. I = V/R with V=${result.voltage} V, R=${result.resistance} ohm. No instrument connected.`,
      timestamp: new Date().toISOString(),
    });
    setLogged('Logged as SIMULATED / UNVERIFIED current. No expected range attached.');
  };

  const input = 'mt-1 w-full rounded-lg border border-white/10 bg-workstation-bg px-3 py-2 font-mono text-sm text-slate-100 outline-none focus:border-workstation-accent/60';

  return (
    <div className="space-y-5 p-4 md:p-6">
      <header>
        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-workstation-accent">Generic Circuit Lab</p>
        <h1 className="text-xl font-semibold text-white">Ideal DC resistor calculator</h1>
      </header>
      <div role="note" className="flex gap-3 rounded-xl border border-sky-500/30 bg-sky-950/30 p-4 text-sm text-sky-100">
        <PlugZap className="h-5 w-5 shrink-0 text-sky-300" />
        <p><strong>No physical instrument is connected.</strong> This is arithmetic only. It says nothing about any ECU, sensor curve, or wiring on {vehicle.make} {vehicle.model}.</p>
      </div>
      <div className="grid gap-5 lg:grid-cols-2">
        <form onSubmit={calc} noValidate className="space-y-4 rounded-2xl border border-white/5 bg-workstation-panel/70 p-4">
          <label className="block text-sm text-slate-300">Voltage across resistor (V, 0 to 1000)
            <input data-testid="input-voltage" inputMode="decimal" value={v} onChange={(e) => setV(e.target.value)} className={input} />
          </label>
          <label className="block text-sm text-slate-300">Resistance (ohm, greater than 0, up to 1e12)
            <input data-testid="input-resistance" inputMode="decimal" value={r} onChange={(e) => setR(e.target.value)} className={input} />
          </label>
          {error && <p role="alert" data-testid="text-calc-error" className="rounded-lg border border-red-500/40 bg-red-950/40 p-2 text-sm text-red-200">{error}</p>}
          <button type="submit" data-testid="button-calculate" className="inline-flex items-center gap-2 rounded-lg bg-workstation-accent px-3 py-2 text-sm font-medium text-slate-950">
            <Calculator className="h-4 w-4" /> Calculate
          </button>
          <ul className="list-disc space-y-1 pl-5 text-xs text-slate-500">
            <li>Ideal linear resistor, constant value, no temperature coefficient.</li>
            <li>Ideal source: zero internal resistance, no lead or contact resistance.</li>
            <li>Steady-state DC only; no inductance, capacitance, or transients.</li>
          </ul>
        </form>
        <section className="space-y-3 rounded-2xl border border-white/5 bg-workstation-panel/70 p-4">
          {result ? (
            <>
              <div><p className="text-[11px] uppercase tracking-wider text-slate-500">Current, I = V / R</p>
                <p data-testid="text-current" className="font-mono text-2xl text-white">{fmt(result.currentAmps)} A</p></div>
              <div><p className="text-[11px] uppercase tracking-wider text-slate-500">Dissipated power, P = V² / R</p>
                <p data-testid="text-power" className="font-mono text-2xl text-white">{fmt(result.powerWatts)} W</p></div>
              <button type="button" data-testid="button-log-reading" onClick={log} className="rounded-lg border border-cyan-500/30 bg-cyan-950/40 px-3 py-2 text-sm text-cyan-200 hover:bg-cyan-900/50">Log as simulated current</button>
              {logged && <p role="status" className="flex items-center gap-2 text-sm text-emerald-300"><CheckCircle2 className="h-4 w-4" /> {logged}</p>}
            </>
          ) : (
            <p className="text-sm text-slate-400">Enter values and calculate. Results appear here with their formulas.</p>
          )}
        </section>
      </div>
    </div>
  );
};

export default GenericCircuitLab;
