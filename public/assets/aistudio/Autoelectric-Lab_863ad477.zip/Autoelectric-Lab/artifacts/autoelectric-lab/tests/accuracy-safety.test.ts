import { test, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { solveResistor } from '../src/services/circuitMath';
import { parseReference, loadReferences, saveReferences, toVehicleProfile } from '../src/services/referenceLibrary';
import { createManualReading, summarizeReadings, loadReadings, persistReadings } from '../src/services/readingRecords';
import { PcbStorageEngine } from '../src/services/pcbStorageEngine';
import { parseProjectBackup } from '../src/services/projectBackup';
import { LayerManagerService } from '../src/services/pcbLayerManagerService';
import { captureBrowserData } from '../src/services/browserRecovery';
import { removeComponentObservation,removeObservedPath,removeDocumentNote } from '../src/services/manualProjectRecords';
import { VEHICLE_DATABASE, DTC_DATABASE, PCB_COMPONENT_LIBRARY } from '../src/data/automotiveDatabase';
import { WIRING_SYSTEMS } from '../src/data/wiringDiagramData';
import { SAMPLE_PCB_PROJECTS } from '../src/data/samplePcbDatabase';
import { SOURCE_DIRECTORY, PH_RESEARCH_BRANDS } from '../src/data/sourceDirectory';
import type { PCBProject } from '../src/types/pcbScanner';

// Synthetic software fixtures, not vehicle facts. Never imported by the application.
const reference = () => ({
  id:'software-test-fixture',make:'TEST ONLY',model:'No real vehicle',productionYears:'Not applicable',chassisCode:'TEST',
  engineCode:'TEST',transmission:'TEST',market:'Not applicable',ecuPartNumber:'TEST-NO-HARDWARE',hardwareNumber:'TEST',
  source:{title:'Software fixture - not a wiring instruction',publisher:'Test runner',url:'https://example.com/software-test',revision:'test',
    locator:'test',marketApplicability:'NO VEHICLE APPLICABILITY',reusePermission:'Synthetic fixture only'},
  connectors:[{id:'test-a',name:'TEST A',cavityCount:2,orientation:'NO PHYSICAL CONNECTOR',pins:[{number:1,label:'TEST',function:'Software test only',sourceLocator:'test'}]},
    {id:'test-b',name:'TEST B',cavityCount:2,orientation:'NO PHYSICAL CONNECTOR',pins:[{number:1,label:'TEST TWO',function:'Software test only',sourceLocator:'test'}]}],
});
const project=():PCBProject=>({
  id:'software-test-project',name:'TEST ONLY',vehicleModel:'No real vehicle',ecuModel:'No hardware',ecuPartNumber:'TEST',
  documents:[],activeDocumentId:'',components:[],nets:[],annotations:[],auditHistory:[],createdAt:'2026-01-01T00:00:00.000Z',
  updatedAt:'2026-01-01T00:00:00.000Z',notes:'Software test fixture only',
});
const baseReading=()=>({
  id:'software-test-reading',pinNumber:null,connectorId:null,pinLabel:'Software fixture',measurementType:'VOLTAGE_DC' as const,
  measuredValue:0,unit:'V DC',notes:'TEST ONLY',timestamp:'2026-01-01T00:00:00.000Z',vehicleId:'software-test',
});
const data=new Map<string,string>();let quota=false;
Object.defineProperty(globalThis,'localStorage',{value:{
  get length(){return data.size;},
  key:(index:number)=>[...data.keys()][index]??null,
  getItem:(k:string)=>data.get(k)??null,
  setItem:(k:string,v:string)=>{if(quota)throw new Error('Simulated quota failure');data.set(k,v);},
  removeItem:(k:string)=>data.delete(k),clear:()=>data.clear(),
},configurable:true});
beforeEach(()=>{data.clear();quota=false;});

test('ideal resistor math matches independently calculated 12/120 and 144/120',()=>{
  assert.deepEqual(solveResistor(12,120),{currentAmps:0.1,powerWatts:1.2});
});
test('zero volts is valid, unlike missing or zero resistance',()=>assert.deepEqual(solveResistor(0,120),{currentAmps:0,powerWatts:0}));
test('invalid resistor model inputs fail explicitly',()=>{
  for(const [v,r] of [[12,0],[12,-1],[-1,20],[NaN,20],[Infinity,20],[12,Infinity],[12,NaN],[1001,20],[12,1e13]])assert.throws(()=>solveResistor(v,r));
});
test('import allows repeated pin numbers only across distinct connectors',()=>{
  const parsed=parseReference(JSON.stringify(reference()));assert.equal(parsed.connectors.length,2);
});
test('duplicate connector identity is rejected',()=>{
  const r=reference();r.connectors[1].id='test-a';assert.throws(()=>parseReference(JSON.stringify(r)));
});
test('duplicate pins and out-of-bounds cavities are rejected',()=>{
  const r=reference();r.connectors[0].pins.push({...r.connectors[0].pins[0]});assert.throws(()=>parseReference(JSON.stringify(r)));
  const r2=reference();r2.connectors[0].pins[0].number=3;assert.throws(()=>parseReference(JSON.stringify(r2)));
});
test('imports need source locator, orientation, and HTTPS',()=>{
  for(const mutate of [
    (r:ReturnType<typeof reference>)=>{r.source.url='javascript:alert(1)';},
    (r:ReturnType<typeof reference>)=>{r.connectors[0].orientation='';},
    (r:ReturnType<typeof reference>)=>{r.connectors[0].pins[0].sourceLocator='';},
  ]){const r=reference();mutate(r);assert.throws(()=>parseReference(JSON.stringify(r)));}
});
test('malformed and oversized import fails without fallback data',()=>{
  assert.throws(()=>parseReference('{broken'));assert.throws(()=>parseReference(' '.repeat(256001)));
});
test('imported verification claims cannot become trusted source status',()=>{
  const r=parseReference(JSON.stringify({...reference(),verifiedStatus:'VERIFIED'}));
  assert.equal('verifiedStatus' in r,false);
  const saved={profile:r,reviewedBy:'Software test',reviewedAt:'2026-01-01T00:00:00.000Z',status:'USER_TRANSCRIPT' as const};
  saveReferences([saved]);assert.deepEqual(loadReferences(),[saved]);
  assert.equal(toVehicleProfile(saved).verifiedStatus,'UNVERIFIED');
  assert.equal(toVehicleProfile(saved).connectors.length,0);
});
test('ECU identity changes produce a different measurement context',()=>{
  const s={profile:reference(),reviewedBy:'Software test',reviewedAt:'2026-01-01T00:00:00.000Z',status:'USER_TRANSCRIPT' as const};
  const a=toVehicleProfile(s).id;s.profile.ecuPartNumber='DIFFERENT TEST ECU';assert.notEqual(toVehicleProfile(s).id,a);
});
test('corrupt references are not silently loaded as empty valid data',()=>{
  data.set('autoelectric_user_references_v1','invalid');assert.throws(()=>loadReferences());
});
test('reference quota failure preserves previous persisted data',()=>{
  data.set('autoelectric_user_references_v1','[]');quota=true;assert.throws(()=>saveReferences([]));assert.equal(data.get('autoelectric_user_references_v1'),'[]');
});
test('manual zero value remains zero and without a range stays unassessed',()=>{
  const r=createManualReading(baseReading());assert.equal(r.measuredValue,0);assert.equal(r.status,'UNVERIFIED');assert.equal(r.source,'TECHNICIAN_ENTERED');
});
test('comparison requires both finite limits, source and conditions',()=>{
  for(const extra of [{expectedMin:0},{expectedMin:2,expectedMax:1,comparisonSource:'test'},{expectedMin:0,expectedMax:1},{expectedMin:NaN,expectedMax:2,comparisonSource:'test'}])
    assert.throws(()=>createManualReading({...baseReading(),...extra}));
});
test('range comparison handles boundaries without hardware certification',()=>{
  assert.equal(createManualReading({...baseReading(),expectedMin:0,expectedMax:1,comparisonSource:'TEST ONLY'}).status,'PASS');
  assert.equal(createManualReading({...baseReading(),measuredValue:2,expectedMin:0,expectedMax:1,comparisonSource:'TEST ONLY'}).status,'FAIL');
});
test('non-finite and negative resistance entries are rejected',()=>{
  assert.throws(()=>createManualReading({...baseReading(),measuredValue:NaN}));
  assert.throws(()=>createManualReading({...baseReading(),measurementType:'RESISTANCE',measuredValue:-1}));
});
test('connector and pin identity must be paired, including integral pins',()=>{
  assert.throws(()=>createManualReading({...baseReading(),pinNumber:1}));
  assert.throws(()=>createManualReading({...baseReading(),pinNumber:1.5,connectorId:'test'}));
});
test('unknown observations are not counted as diagnosed faults',()=>{
  const r=createManualReading(baseReading());assert.deepEqual(summarizeReadings([r]),{total:1,pass:0,faults:0,unassessed:1,simulated:0});
});
test('reading persistence round-trips without fabricating expected ranges',()=>{
  const r=createManualReading(baseReading());persistReadings([r]);assert.deepEqual(loadReadings(),[r]);
});
test('corrupted reading storage fails, not an invented empty success',()=>{
  data.set('autoelectric_readings_v1','{}');assert.throws(()=>loadReadings());
});
test('manual project create update delete is durable',()=>{
  const p=project();assert.equal(PcbStorageEngine.saveProject(p),true);
  p.name='Edited test';assert.equal(PcbStorageEngine.saveProject(p),true);
  assert.equal(PcbStorageEngine.loadProjects()[0].name,'Edited test');
  assert.equal(PcbStorageEngine.deleteProject(p.id),true);assert.deepEqual(PcbStorageEngine.loadProjects(),[]);
});
test('legacy unsupported seed projects are hidden but backed up',()=>{
  const p=project();p.id='project-hilux-1gd-power';data.set('autoelectric_pcb_projects',JSON.stringify([p]));
  assert.deepEqual(PcbStorageEngine.loadProjects(),[]);
  assert.equal(JSON.parse(data.get('autoelectric_pcb_projects_legacy_unverified_backup')!)[0].id,p.id);
});
test('quota failures never claim project save or deletion succeeded',()=>{
  assert.equal(PcbStorageEngine.saveProject(project()),true);const before=data.get('autoelectric_pcb_projects');
  quota=true;assert.equal(PcbStorageEngine.saveProject({...project(),name:'Will not save'}),false);
  assert.equal(PcbStorageEngine.deleteProject(project().id),false);assert.equal(data.get('autoelectric_pcb_projects'),before);
});
test('corrupt projects are not overwritten by a new save',()=>{
  data.set('autoelectric_pcb_projects','not-json');assert.throws(()=>PcbStorageEngine.loadProjects());
  assert.equal(PcbStorageEngine.saveProject(project()),false);assert.equal(data.get('autoelectric_pcb_projects'),'not-json');
});
test('manual backup format round-trips and rejects unrelated JSON',()=>{
  const p=project();assert.deepEqual(parseProjectBackup(JSON.stringify({format:'autoelectric-manual-review-v1',project:p})),p);
  assert.throws(()=>parseProjectBackup('{}'));
});
test('restored image URLs cannot trigger third-party requests',()=>{
  const p=project();p.documents=[{id:'test-image',name:'TEST',documentType:'UNKNOWN',imageUrl:'https://example.com/image.png',originalFileName:'test.png',
    fileSizeMb:1,uploadTimestamp:'2026-01-01T00:00:00.000Z',widthPx:10,heightPx:10,description:'TEST ONLY'}];p.activeDocumentId='test-image';
  assert.throws(()=>parseProjectBackup(JSON.stringify({format:'autoelectric-manual-review-v1',project:p})));
});
test('layer toggles preserve independently set opacity and contrast',()=>{
  const initial={...LayerManagerService.getDefaultState(),photoOpacity:0.5,photoHighContrast:true};
  const next=LayerManagerService.toggleLayerVisibility(initial,'showTraces');
  assert.equal(next.photoOpacity,0.5);assert.equal(next.photoHighContrast,true);assert.equal(next.showTraces,!initial.showTraces);
});
test('layer persistence validates preferences and reports quota failures',()=>{
  const initial=LayerManagerService.getDefaultState();assert.equal(LayerManagerService.saveLayerState('test',initial),true);
  assert.deepEqual(LayerManagerService.loadLayerState('test'),initial);quota=true;
  assert.equal(LayerManagerService.saveLayerState('test',initial),false);
});
test('corrupt layer state is an explicit error, not a silent reset',()=>{
  data.set('autoelectric_pcb_layer_state_test','{"photoOpacity":9}');assert.throws(()=>LayerManagerService.loadLayerState('test'));
});
test('unsupported automotive data remains absent from bundled datasets',()=>{
  for(const records of [VEHICLE_DATABASE,DTC_DATABASE,PCB_COMPONENT_LIBRARY,WIRING_SYSTEMS,SAMPLE_PCB_PROJECTS])assert.equal(records.length,0);
});
test('source directory has unique HTTPS records for every research brand, not pin assignments',()=>{
  assert.equal(new Set(SOURCE_DIRECTORY.map(s=>s.id)).size,SOURCE_DIRECTORY.length);
  assert.ok(SOURCE_DIRECTORY.every(s=>s.url.startsWith('https://')));
  for(const b of PH_RESEARCH_BRANDS)assert.ok(SOURCE_DIRECTORY.some(s=>s.brands.includes(b)),b);
  assert.ok(SOURCE_DIRECTORY.every(s=>!('pins' in s)));
});
const withDocuments=()=>{
  const p=project();
  p.documents=['doc-a','doc-b'].map(id=>({id,name:'SOFTWARE TEST',documentType:'UNKNOWN',imageUrl:'data:image/png;base64,aA==',
    originalFileName:'test.png',fileSizeMb:0.001,uploadTimestamp:'2026-01-01T00:00:00.000Z',widthPx:1,heightPx:1,description:'Software fixture only'}));
  p.activeDocumentId='doc-a';return p;
};
test('backup rejects annotations attached to absent documents',()=>{
  const p=withDocuments();p.annotations=[{id:'test-note',x:100,y:100,text:'TEST',category:'NOTE',author:'Test runner',
    timestamp:'2026-01-01T00:00:00.000Z',sourceImageId:'missing'}];
  assert.throws(()=>parseProjectBackup(JSON.stringify({format:'autoelectric-manual-review-v1',project:p})),/missing document/);
});
test('backup rejects duplicate annotation IDs',()=>{
  const p=withDocuments();const annotation={id:'test-note',x:100,y:100,text:'TEST',category:'NOTE' as const,author:'Test runner',
    timestamp:'2026-01-01T00:00:00.000Z',sourceImageId:'doc-a'};
  p.annotations=[annotation,annotation];
  assert.throws(()=>parseProjectBackup(JSON.stringify({format:'autoelectric-manual-review-v1',project:p})),/Duplicate annotation/);
});
test('backup cannot attach a path to components on another image',()=>{
  const p=withDocuments();p.components=[{id:'test-component',refDes:'TEST',category:'UNKNOWN',marking:'TEST',decodedValue:'',packageType:'',
    bbox:{xmin:100,ymin:100,xmax:150,ymax:150},confidenceScore:0,verificationStatus:'UNVERIFIED',circuitFunction:'',datasheetRef:'',
    connectedNetIds:['test-path'],sourceImageId:'doc-b',notes:'TEST ONLY'}];
  p.nets=[{id:'test-path',name:'TEST',signalType:'UNKNOWN',sourceImageId:'doc-a',connectedComponentIds:['test-component'],
    connectedTerminalIds:[],tracePoints:[{x:100,y:100},{x:200,y:200}],verificationStatus:'UNVERIFIED',isComplete:false,incompleteNotes:'TEST ONLY'}];
  assert.throws(()=>parseProjectBackup(JSON.stringify({format:'autoelectric-manual-review-v1',project:p})),/unrelated document/);
});
test('raw recovery preserves invalid JSON exactly without importing it',()=>{
  data.set('autoelectric_readings_v1','{broken');const raw=captureBrowserData(localStorage);
  assert.equal(raw.format,'autoelectric-raw-recovery-v1');assert.equal(raw.entries.autoelectric_readings_v1,'{broken');
  assert.equal(data.get('autoelectric_readings_v1'),'{broken');
});
test('raw recovery excludes unrelated browser data',()=>{
  data.set('unrelated_app','not included');data.set('autoelectric_user_references_v1','[]');
  assert.deepEqual(captureBrowserData(localStorage).entries,{autoelectric_user_references_v1:'[]'});
});
const deletionFixture=()=>{
  const p=withDocuments();p.components=[{
    id:'test-component',refDes:'SOFTWARE-TEST',category:'UNKNOWN',marking:'TEST ONLY',decodedValue:'',packageType:'',
    bbox:{xmin:100,ymin:100,xmax:150,ymax:150},confidenceScore:0,verificationStatus:'UNVERIFIED',circuitFunction:'',datasheetRef:'',
    connectedNetIds:['test-path'],sourceImageId:'doc-a',notes:'TEST ONLY',
  }];
  p.nets=['test-path','unrelated-path'].map(id=>({id,name:'TEST ONLY',signalType:'UNKNOWN',sourceImageId:'doc-a',
    connectedComponentIds:id==='test-path'?['test-component']:[],connectedTerminalIds:[],tracePoints:[{x:100,y:100},{x:200,y:200}],
    verificationStatus:'UNVERIFIED',isComplete:true,incompleteNotes:'User-declared software fixture, not actual connectivity'}));
  p.annotations=['note-a','note-b'].map(id=>({id,x:100,y:100,text:'TEST ONLY',category:'NOTE',author:'Test runner',
    timestamp:'2026-01-01T00:00:00.000Z',sourceImageId:'doc-a'}));return p;
};
test('component deletion removes only its observation and memberships, never its source image',()=>{
  const p=deletionFixture();const next=removeComponentObservation(p,'test-component');
  assert.equal(next.components.length,0);assert.equal(next.documents.length,2);assert.deepEqual(next.nets[0].connectedComponentIds,[]);
  assert.equal(next.nets[0].isComplete,false);assert.equal(next.nets[1].isComplete,true);
  assert.equal(p.components.length,1);assert.deepEqual(p.nets[0].connectedComponentIds,['test-component']);
});
test('path deletion preserves observations and notes while removing their path binding',()=>{
  const p=deletionFixture();const next=removeObservedPath(p,'test-path');
  assert.deepEqual(next.nets.map(n=>n.id),['unrelated-path']);assert.deepEqual(next.components[0].connectedNetIds,[]);
  assert.equal(next.annotations?.length,2);assert.equal(next.documents.length,2);assert.deepEqual(p.components[0].connectedNetIds,['test-path']);
});
test('note deletion preserves other notes, observations, paths and images',()=>{
  const p=deletionFixture();const next=removeDocumentNote(p,'note-a');
  assert.deepEqual(next.annotations?.map(a=>a.id),['note-b']);assert.equal(next.components.length,1);assert.equal(next.nets.length,2);
  assert.equal(next.documents.length,2);assert.equal(p.annotations?.length,2);
});
