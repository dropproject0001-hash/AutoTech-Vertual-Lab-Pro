import { readFileSync } from "node:fs";
import { test } from "node:test";
import assert from "node:assert/strict";

const snapshot = JSON.parse(
  readFileSync(
    new URL("../../../research/vehicle-catalogue-snapshot.json", import.meta.url),
    "utf8",
  ),
) as {
  snapshotDate: string;
  scope: string;
  coverageWarning: string;
  technicalDataWarning: string;
  sources: Array<{
    key: string;
    url: string;
    evidencePath: string;
  }>;
  models: Array<{
    modelKey: string;
    sourceKey: string;
    recordKind: string;
    vehicleClass: string;
  }>;
};

test("source-catalogue observations all resolve to saved HTTPS evidence", () => {
  assert.equal(snapshot.scope, "PARTIAL_PHILIPPINE_OEM_PAGE_OBSERVATIONS");
  assert.equal(snapshot.sources.length, 15);
  assert.equal(snapshot.models.length, 63);

  const sourceKeys = new Set(snapshot.sources.map((source) => source.key));
  assert.equal(sourceKeys.size, snapshot.sources.length);

  for (const source of snapshot.sources) {
    assert.match(source.url, /^https:\/\/[^/]+/);
    assert.match(source.evidencePath, /^research\/sources\//);
    assert.ok(
      readFileSync(
        new URL(`../../../${source.evidencePath}`, import.meta.url),
        "utf8",
      ).startsWith("Source: "),
      `Missing saved evidence for ${source.key}`,
    );
  }

  assert.equal(
    new Set(snapshot.models.map((model) => model.modelKey)).size,
    snapshot.models.length,
  );
  assert.ok(snapshot.models.every((model) => sourceKeys.has(model.sourceKey)));
});

test("the snapshot does not claim a fleet census or add unsupported pinouts", () => {
  assert.match(snapshot.coverageWarning, /not a complete/i);
  assert.match(snapshot.coverageWarning, /popularity ranking/i);
  assert.match(snapshot.technicalDataWarning, /No exact-variant/i);
  assert.equal(
    snapshot.models.some((model) => model.recordKind === "VERIFIED_ECU_PINOUT"),
    false,
  );
  assert.ok(snapshot.models.some((model) => model.vehicleClass === "BUS"));
  assert.ok(snapshot.models.some((model) => model.vehicleClass === "MOTORCYCLE"));
  assert.ok(snapshot.models.some((model) => model.vehicleClass === "TRUCK"));
});
