import { Router, type IRouter } from "express";
import autoelectricRouter from "./autoelectric";
import healthRouter from "./health";
import vehicleCoverageRouter from "./vehicleCoverage";
import knowledgeAdminRouter from "./knowledgeAdmin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(autoelectricRouter);
router.use(vehicleCoverageRouter);
router.use(knowledgeAdminRouter);

export default router;
