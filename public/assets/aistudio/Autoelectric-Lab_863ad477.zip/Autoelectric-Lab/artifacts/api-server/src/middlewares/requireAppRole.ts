import { getAuth } from "@clerk/express";
import { appUsersTable, db } from "@workspace/db";
import { eq } from "drizzle-orm";
import type { RequestHandler } from "express";

export const requireSignedInUser: RequestHandler = (req, res, next): void => {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Sign-in is required." });
    return;
  }

  res.locals.clerkUserId = userId;
  next();
};

export const requireAdministrator: RequestHandler = async (
  req,
  res,
  next,
): Promise<void> => {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Sign-in is required." });
    return;
  }

  try {
    const [membership] = await db
      .select({
        role: appUsersTable.role,
        isActive: appUsersTable.isActive,
      })
      .from(appUsersTable)
      .where(eq(appUsersTable.clerkUserId, userId))
      .limit(1);

    if (!membership?.isActive || membership.role !== "ADMIN") {
      res.status(403).json({ error: "Administrator access is required." });
      return;
    }

    res.locals.clerkUserId = userId;
    next();
  } catch (error) {
    req.log.error({ err: error }, "Administrator role check failed");
    res.status(500).json({ error: "Administrator access is temporarily unavailable." });
  }
};
