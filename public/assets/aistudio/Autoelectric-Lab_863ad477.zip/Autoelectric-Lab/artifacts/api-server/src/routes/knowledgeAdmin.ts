import {
  GetKnowledgeAdminAccessResponse,
  GetKnowledgeAdminSummaryResponse,
} from "@workspace/api-zod";
import {
  appUsersTable,
  benchTestingProceduresTable,
  db,
  ecuPinAssignmentsTable,
  ecuTechnicalRecordsTable,
  technicalKnowledgeSourcesTable,
} from "@workspace/db";
import { and, count, eq, inArray } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { requireAdministrator, requireSignedInUser } from "../middlewares/requireAppRole";

const router: IRouter = Router();

router.get(
  "/admin/access",
  requireSignedInUser,
  async (req, res): Promise<void> => {
    const clerkUserId = res.locals.clerkUserId as string;
    try {
      const [membership] = await db
        .select({
          role: appUsersTable.role,
          isActive: appUsersTable.isActive,
        })
        .from(appUsersTable)
        .where(eq(appUsersTable.clerkUserId, clerkUserId))
        .limit(1);

      res.json(
        GetKnowledgeAdminAccessResponse.parse({
          role: membership?.isActive ? membership.role : null,
          isAdmin:
            membership?.isActive === true && membership.role === "ADMIN",
        }),
      );
    } catch (error) {
      req.log.error({ err: error }, "Application access lookup failed");
      res.status(500).json({ error: "Account access is temporarily unavailable." });
    }
  },
);

router.get(
  "/admin/summary",
  requireAdministrator,
  async (req, res): Promise<void> => {
    try {
      const [ecuRecords, pendingRecords, pinAssignments, authorizedPins, procedures, authorizedProcedures, sources, users] =
        await Promise.all([
          db.select({ total: count() }).from(ecuTechnicalRecordsTable),
          db
            .select({ total: count() })
            .from(ecuTechnicalRecordsTable)
            .where(eq(ecuTechnicalRecordsTable.verificationStatus, "PENDING_REVIEW")),
          db.select({ total: count() }).from(ecuPinAssignmentsTable),
          db
            .select({ total: count() })
            .from(ecuPinAssignmentsTable)
            .where(
              eq(
                ecuPinAssignmentsTable.reuseRightsStatus,
                "APPLICATION_REUSE_AUTHORIZED",
              ),
            ),
          db.select({ total: count() }).from(benchTestingProceduresTable),
          db
            .select({ total: count() })
            .from(benchTestingProceduresTable)
            .where(
              and(
                eq(
                  benchTestingProceduresTable.reuseRightsStatus,
                  "APPLICATION_REUSE_AUTHORIZED",
                ),
                eq(benchTestingProceduresTable.safetyStatus, "SAFETY_REVIEWED"),
                inArray(benchTestingProceduresTable.verificationStatus, [
                  "OEM_VERIFIED",
                  "HIGH_CONFIDENCE",
                ]),
              ),
            ),
          db.select({ total: count() }).from(technicalKnowledgeSourcesTable),
          db.select({ total: count() }).from(appUsersTable),
        ]);

      const response = GetKnowledgeAdminSummaryResponse.parse({
        ecuRecordCount: ecuRecords[0]?.total ?? 0,
        pendingReviewCount: pendingRecords[0]?.total ?? 0,
        pinAssignmentCount: pinAssignments[0]?.total ?? 0,
        authorizedPinAssignmentCount: authorizedPins[0]?.total ?? 0,
        benchProcedureCount: procedures[0]?.total ?? 0,
        authorizedBenchProcedureCount: authorizedProcedures[0]?.total ?? 0,
        sourceCount: sources[0]?.total ?? 0,
        userCount: users[0]?.total ?? 0,
      });

      res.json(response);
    } catch (error) {
      req.log.error({ err: error }, "Knowledge administration summary failed");
      res.status(500).json({ error: "Administration summary is temporarily unavailable." });
    }
  },
);

export default router;
