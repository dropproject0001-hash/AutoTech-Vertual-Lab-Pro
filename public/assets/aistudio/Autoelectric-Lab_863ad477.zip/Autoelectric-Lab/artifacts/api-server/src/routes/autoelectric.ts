import { Router, type IRouter } from "express";
import {
  AnalyzeAutoelectricSchematicBody,
  AnalyzeAutoelectricSchematicResponse,
  CreateAutoelectricChatReplyBody,
  CreateAutoelectricChatReplyResponse,
  GetAutoelectricHealthResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/autoelectric/health", (_req, res) => {
  res.json(
    GetAutoelectricHealthResponse.parse({
      status: "ONLINE",
      system: "Autoelectric Lab source-review service",
      hasApiKey: false,
      serviceMode: "SOURCE_REVIEW_ONLY",
      technicalAnswersEnabled: false,
      timestamp: new Date().toISOString(),
    }),
  );
});

router.post("/gemini/chat", (req, res) => {
  const parsed = CreateAutoelectricChatReplyBody.safeParse(req.body);
  if (!parsed.success || !parsed.data.message.trim()) {
    res.status(400).json({ error: "Please provide a valid message." });
    return;
  }

  res.json(
    CreateAutoelectricChatReplyResponse.parse({
      reply:
        "I can’t provide vehicle-specific pinouts, specifications, or test procedures because no matching source documents are loaded. This assistant does not generate technical answers. Supply the exact OEM document and review its relevant page before acting.",
      model: "source-required",
      status: "FALLBACK_READY",
    }),
  );
});

router.post("/gemini/analyze-schematic", (req, res) => {
  const parsed = AnalyzeAutoelectricSchematicBody.safeParse(req.body);
  if (!parsed.success || !parsed.data.documentName.trim()) {
    res.status(400).json({ error: "Please provide a valid document name." });
    return;
  }

  const { documentType } = parsed.data;
  res.json(
    AnalyzeAutoelectricSchematicResponse.parse({
      status: "SUCCESS",
      analysis: {
        documentType: documentType ?? "UNKNOWN",
        confidenceScore: 0,
        detectionMethod: "MANUAL_ONLY",
        analysisSummary:
          "Automated image interpretation is disabled. No components, connections, pinouts, or values were inferred. Review the document manually and record any findings with a source citation.",
        components: [],
        nets: [],
      },
      model: "manual-only",
    }),
  );
});

export default router;
