import {
  GetVehicleCoverageQueryParams,
  GetVehicleCoverageResponse,
} from "@workspace/api-zod";
import {
  db,
  ecuPinoutEvidenceTable,
  vehicleCatalogueModelsTable,
  vehicleCatalogueSourcesTable,
} from "@workspace/db";
import { and, asc, count, eq, or, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";

const router: IRouter = Router();

const coverageWarning =
  "Partial snapshot of reviewed Philippine manufacturer/support pages only. This is not a complete road-vehicle list, a national fleet count, dealer-stock feed, serviceability guarantee, or popularity ranking.";
const technicalDataWarning =
  "No exact-variant, reuse-authorized ECU pinout rows are currently in the catalogue. A product page, owner manual, or campaign notice is not a wiring diagram or repair procedure.";
const emptySnapshotDate = new Date("2026-11-11T00:00:00.000Z");

router.get("/vehicle-coverage", async (req, res): Promise<void> => {
  const parsed = GetVehicleCoverageQueryParams.safeParse(req.query);
  if (!parsed.success) {
    req.log.warn(
      {
        issues: parsed.error.issues.map(({ code, path }) => ({
          code,
          path,
        })),
      },
      "Invalid vehicle-coverage search parameters",
    );
    res.status(400).json({ error: "Invalid vehicle-coverage search." });
    return;
  }

  try {
    const { search, vehicleClass, limit, offset } = parsed.data;
    const where = [];

    if (vehicleClass) {
      where.push(eq(vehicleCatalogueModelsTable.vehicleClass, vehicleClass));
    }

    const term = search?.trim();
    if (term) {
      where.push(
        or(
          sql`strpos(lower(${vehicleCatalogueModelsTable.make}), lower(${term})) > 0`,
          sql`strpos(lower(${vehicleCatalogueModelsTable.model}), lower(${term})) > 0`,
        )!,
      );
    }

    const predicate = where.length ? and(...where) : undefined;
    const [countResult, records, pinoutCountResult, snapshotResult] =
      await Promise.all([
        db
          .select({ total: count() })
          .from(vehicleCatalogueModelsTable)
          .where(predicate),
        db
          .select({
            id: vehicleCatalogueModelsTable.modelKey,
            make: vehicleCatalogueModelsTable.make,
            model: vehicleCatalogueModelsTable.model,
            vehicleClass: vehicleCatalogueModelsTable.vehicleClass,
            recordKind: vehicleCatalogueModelsTable.recordKind,
            modelYearEvidence: vehicleCatalogueModelsTable.modelYearEvidence,
            observedOn: vehicleCatalogueModelsTable.observedOn,
            observationNote: vehicleCatalogueModelsTable.observationNote,
            sourceTitle: vehicleCatalogueSourcesTable.title,
            sourceUrl: vehicleCatalogueSourcesTable.url,
            sourceKind: vehicleCatalogueSourcesTable.sourceKind,
            sourcePublicationDate:
              vehicleCatalogueSourcesTable.publicationDate,
            sourceObservedOn: vehicleCatalogueSourcesTable.observedOn,
            sourceReuseStatus: vehicleCatalogueSourcesTable.reuseStatus,
          })
          .from(vehicleCatalogueModelsTable)
          .innerJoin(
            vehicleCatalogueSourcesTable,
            eq(
              vehicleCatalogueModelsTable.sourceKey,
              vehicleCatalogueSourcesTable.sourceKey,
            ),
          )
          .where(predicate)
          .orderBy(
            asc(vehicleCatalogueModelsTable.make),
            asc(vehicleCatalogueModelsTable.model),
            asc(vehicleCatalogueModelsTable.vehicleClass),
          )
          .limit(limit)
          .offset(offset),
        db
          .select({ total: count() })
          .from(ecuPinoutEvidenceTable)
          .where(
            eq(
              ecuPinoutEvidenceTable.reuseStatus,
              "APPLICATION_REUSE_AUTHORIZED",
            ),
          ),
        db
          .select({
            date: sql<string | null>`max(${vehicleCatalogueModelsTable.observedOn})`,
          })
          .from(vehicleCatalogueModelsTable),
      ]);

    const result = GetVehicleCoverageResponse.parse({
      records,
      total: countResult[0]?.total ?? 0,
      snapshotDate: snapshotResult[0]?.date ?? emptySnapshotDate,
      verifiedEcuPinoutCount: pinoutCountResult[0]?.total ?? 0,
      coverageWarning,
      technicalDataWarning,
    });

    const dateOnly = (value: Date) => value.toISOString().slice(0, 10);
    res.json({
      ...result,
      records: result.records.map((record) => ({
        ...record,
        observedOn: dateOnly(record.observedOn),
        sourcePublicationDate: record.sourcePublicationDate
          ? dateOnly(record.sourcePublicationDate)
          : null,
        sourceObservedOn: dateOnly(record.sourceObservedOn),
      })),
      snapshotDate: dateOnly(result.snapshotDate),
    });
  } catch (error) {
    req.log.error({ err: error }, "Vehicle-coverage database query failed");
    res.status(500).json({ error: "Vehicle coverage is temporarily unavailable." });
  }
});

export default router;
