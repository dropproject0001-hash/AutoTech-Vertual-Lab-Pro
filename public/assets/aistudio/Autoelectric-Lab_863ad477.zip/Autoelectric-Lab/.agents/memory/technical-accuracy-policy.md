---
name: Technical accuracy policy
description: User requirements for Philippine ECU coverage and unsupported technical information.
---

The user specified that Philippine vehicle coverage should include all road-vehicle classes and models currently sold or still serviced, with no purchases. Do not treat a starting make list as a national popularity ranking or claim complete coverage without a source that establishes completeness.

The user approved removing unverified data rather than retaining labeled demonstration records. They require accurate information, no invented technical claims, and functioning, tested features.

**Why:** The user explicitly requested these constraints.

**How to apply:** Research exact Philippine applicability across on-road classes and retain source evidence before publishing technical records. Separate in-use registrations from new sales and OEM website lineups. Leave unsupported facts unknown rather than filling gaps with examples or guesses. Do not purchase data or claim exhaustive coverage unless a qualifying source proves it. Be explicit about software-testing and physical-validation limits.

Software self-consistency checks must never substitute for technical-source validation.

**Why:** The original demonstration tests checked invented constants against the same invented dataset, which could pass without proving the underlying automotive facts.

**How to apply:** Test calculations and workflows separately from source authenticity and applicability. A schema-valid import or reviewer declaration is not independent OEM verification.

Keep measurement history scoped to the exact vehicle/ECU variant, not just a display name.

**Why:** Replacing a transcript with a different ECU configuration must not make earlier readings appear to belong to the replacement.

**How to apply:** Preserve existing logs when changing context, and separate them when part/hardware, engine, production range, transmission, chassis, or market identity changes.

Paid technical-data access is neither independent factual verification nor permission to redistribute it inside the app.

**Why:** Provider research found distinct workshop-viewer and application-integration offerings, copying restrictions, and no universal guarantee that all data is correct.

**How to apply:** Require exact Philippine applicability evidence and written app-use rights before importing provider data. Check display, export, caching, end-user entitlement and AI-processing permissions separately; never substitute a retail login for an integration agreement.
