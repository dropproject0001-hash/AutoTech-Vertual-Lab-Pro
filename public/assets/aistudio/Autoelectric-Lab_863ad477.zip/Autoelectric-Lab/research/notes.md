# Research Notes: Philippine Road-Vehicle and ECU Catalogue

**Status:** cross-checking  
**Depth:** Deep

## Plan

- **Question:** What Philippine-market vehicle and ECU facts can be independently substantiated and stored for road vehicles currently sold or still serviced?
- **Scope:** All road-vehicle classes, all makes, current or still-serviced Philippine variants only where a source identifies their scope. No purchases or subscriptions. No restricted technical documents copied without written reuse permission. Do not infer fleet popularity from new sales or manufacturer pages.
- **Audience:** Autoelectric Lab users and automotive service clients.
- **Deliverable:** Cited research report, saved local source evidence, and a searchable PostgreSQL snapshot. Unknown technical fields stay absent.

## Focus Areas

| # | Area | Status | Sources |
|---|---|---|---|
| 1 | Government registration data; model detail versus totals and sales | done | 7 official/statistical pages |
| 2 | Philippine passenger and light-commercial OEM evidence | done | 7 official maker/support pages |
| 3 | Philippine motorcycle and scooter evidence | done | 8 pages |
| 4 | Philippine truck, bus, and commercial-vehicle evidence | done | 10 pages |
| 5 | ECU source fitment, reuse terms, and app safeguards | done | 8 rights/technical access pages |

## Coverage Checklist

- [x] Establish what public LTO/PSA records identify: class/type/region and model detail. Official registration reports found were aggregate; model-level pages could not be inspected or their releases verified. [@ph-fleet-psa-2024-registration] [@lto-and-psa-model-level-registrations-02-istat-lto] [@lto-and-psa-model-level-registrations-03-lto-annual-report-2022] [@ph-fleet-lto-2023-report]
- [ ] Find complete make/model coverage for every currently sold or still-serviced Philippine road vehicle. Moved to limitations: official pages provide examples and owner-material indexes, not a nationwide in-use census or a definition of commonly used. [@philippine-passenger-light-commercial-lineups-and-service-data-access-06-nissan-ph-range] [@philippine-motorcycles-and-scooters-06-suzuki-downloads] [@philippine-truck-bus-and-commercial-vehicle-models-04-fuso-home]
- [ ] Match a usable technical ECU fact to exact Philippine variant, source edition, and supported reuse rights. Moved to limitations: no pinout or procedure passed all checks; a Toyota campaign notice is not a pinout or a current eligibility lookup. [@public-road-vehicle-data-reuse-ecu-source-rights-and-publication-safeguards-06-toyota-ph-ecu-campaign] [@toyota-01-official-repair-information] [@toyota-04-tis-terms]
- [ ] Establish blanket permission to reproduce source files. Moved to limitations: open-data terms are dataset-specific; public OEM access and government-work rules do not establish OEM-manual rights. No documents were republished. [@public-road-vehicle-data-reuse-ecu-source-rights-and-publication-safeguards-01-open-data-terms] [@public-road-vehicle-data-reuse-ecu-source-rights-and-publication-safeguards-07-ipophil-copyright-reference]
- [x] Exclude unsupported or cross-market ECU pins, DTCs, connector orientation, and test values. None were added from general, US-market, or assumed data. [@toyota-us-scope] [@mitsubishi-us-scope]
- [ ] Persist and search the cited manufacturer-page observations; confirm the database’s exact results and absence of ECU pinout records. Database implementation and tests are not complete.

## Findings Log

Sources marked with [@key] are in research/sources.json; each referenced page has a saved file under research/sources/.

### Government registration evidence

- LTO annual reports and PSA iSTAT located in this search give registered-vehicle totals/categories, not an all-class make/model census. LTO 2023 data cover January–September only and are now older than 18 months. These do not establish current roadworthiness, sales, active fleet or model popularity. [@ph-fleet-psa-2024-registration] [@lto-and-psa-model-level-registrations-02-istat-lto] [@lto-and-psa-model-level-registrations-03-lto-annual-report-2022] [@ph-fleet-lto-2023-report] [@lto-and-psa-model-level-registrations-05-lto-annual-report-2023]
- The 2017 eFOI request title asks for model-level fields, and another request concerns 2023–2024 regional data; both saved page fetches were maintenance notices. Titles or search-result statuses do not prove the released file, its fields or its license. [@ph-fleet-lto-model-foi] [@lto-and-psa-model-level-registrations-01-foi-model-list] [@lto-and-psa-model-level-registrations-04-foi-regional-2023-2024]
- A supplementary deep-tier search pass for request attachments/data.gov.ph returned HTTP 402 before results. It adds no evidence about whether such datasets exist. No purchase or alternative paid search was attempted.

### Philippine vehicle-page observations

- Toyota PH 2025 brochures document Philippine-market Yaris Cross and Hilux product labels, but not a full current Toyota lineup or a model-level census. [@philippine-passenger-light-commercial-lineups-and-service-data-access-07-toyota-yaris-cross-2025-leaflet] [@philippine-passenger-light-commercial-lineups-and-service-data-access-08-toyota-hilux-2025-leaflet]
- Nissan PH’s dynamic page lists product entries and labels some as Coming Soon; distinguish page appearance from a dated availability or sales record. [@philippine-passenger-light-commercial-lineups-and-service-data-access-06-nissan-ph-range]
- Mitsubishi PH’s owner-manual index supplies a limited owner-documentation list, including year-grouped Mirage G4 manuals. Manual links are not proof of present new sales or complete workshop data. [@philippine-passenger-light-commercial-lineups-and-service-data-access-02-mitsubishi-owner-manual-index] [@philippine-passenger-light-commercial-lineups-and-service-data-access-03-mitsubishi-mirage-g4-manual-page]
- The reviewed official motorcycle pages list maker products/support, not sales ranking or regional stock. Yamaha says its authorized locations use a diagnostic tool but provides no exact ECU model coverage or pin data; Honda's checked manual pages returned maintenance notices. [@philippine-motorcycles-and-scooters-04-yamaha-service] [@philippine-motorcycles-and-scooters-05-yamaha-mio-fazzio] [@philippine-motorcycles-and-scooters-06-suzuki-downloads] [@philippine-motorcycles-and-scooters-09-hero-philippines] [@philippine-motorcycles-and-scooters-02-honda-owner-manual]
- Official Hino, UD Trucks, FUSO and Hyundai Truck/Bus pages list product families. Their pages are not registrations, model-year/variant fleet mappings, service-status guarantees, or access to ECU procedures. [@philippine-truck-bus-and-commercial-vehicle-models-09-hino-300] [@philippine-truck-bus-and-commercial-vehicle-models-10-hino-500] [@philippine-truck-bus-and-commercial-vehicle-models-01-hino-buses] [@philippine-truck-bus-and-commercial-vehicle-models-11-ud-philippines-trucks] [@philippine-truck-bus-and-commercial-vehicle-models-04-fuso-home] [@philippine-truck-bus-and-commercial-vehicle-models-06-hyundai-official]
- Class coverage remains incomplete. LTO’s MC/TC/Non-Conv total combines motorcycles, tricycles and non-conventional vehicles; this review does not provide model-level tricycle, PUV-conversion, trailer or special-road-vehicle records. [@philippine-motorcycles-and-scooters-01-lto-annual-report-2023] [@ph-fleet-lto-2023-report]

### ECU and source-use findings

- Toyota PH published an engine-ECU-reprogramming service campaign for Raize units with a stated production range. Its date, VIN eligibility/current status, variant-specific procedure and redistribution rights were not verified; do not present it as an active campaign lookup or a repair instruction. [@public-road-vehicle-data-reuse-ecu-source-rights-and-publication-safeguards-06-toyota-ph-ecu-campaign]
- Toyota repair-information pages and terms describe controlled access; public presence does not establish permission for third-party bulk storage or app redistribution. [@toyota-01-official-repair-information] [@toyota-02-tis-market-coverage] [@toyota-04-tis-terms]
- Data.gov.ph terms make reuse depend on the particular dataset’s metadata and applicable law. The IPOPHL reference discusses government works; it does not turn OEM-authored manuals into government data. [@public-road-vehicle-data-reuse-ecu-source-rights-and-publication-safeguards-01-open-data-terms] [@public-road-vehicle-data-reuse-ecu-source-rights-and-publication-safeguards-07-ipophil-copyright-reference]
- No diagrams, manuals, DTC tables, ECU calibration files, pins, connector views or test values were copied. Exact vehicle applicability, source edition/location, written app rights and user entitlement remain separate gates.

## Conflicts & Open Questions

- The 2023–2024 eFOI search snippet was labeled successful, but the portal page and underlying attachment were unavailable; the fields/geographic coverage and reusable terms cannot be established. This status is not treated as dataset verification.
- LTO class registrations, model lineup pages, dealer aftersales claims, MDPPA-reported wholesale motorcycle sales, and the fleet of vehicles still on the road answer different questions and are not merged as rankings.
- Currently serviced has no verified source-wide threshold here; product page presence and owner manuals are observations only.
- The web-search service returned HTTP 402 on both targeted gap-fill assignments. Per the two-attempt stop rule, both outstanding release-status and exact technical-data questions are limitations, not facts about nonexistence.
- Initial approved Autodata and HaynesPro coverage/licensing enquiries remain unanswered. They cannot be imported into the app until exact PH fitment and use/export/cache/end-user terms are confirmed. No purchase was made.

## Gaps

- **Moved to limitations:** nationwide recent model-level active fleet census; LTO eFOI attachments, exact fields, release disposition and reuse terms; complete list of makes/models currently sold or serviceable; model/variant/make counts by road class; exact Philippines-specific ECU pinouts and procedures; source-specific client application rights; verified active campaign/VIN eligibility.
- **Persisting implementation:** the database/API/front-end search and migration checks remain to be built and verified.
- Research snapshot date: 11 November 2026. This is a bounded review, not a claim that no other sources or data exist.
