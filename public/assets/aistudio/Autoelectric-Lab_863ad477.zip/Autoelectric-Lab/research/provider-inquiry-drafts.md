# Provider enquiries — DRAFTS, NOT SENT

These enquiries contain the project name, intended market, candidate model scope and licensing requirements only. No personal contact details, VINs, account credentials or private vehicle documents are included.

## Short common enquiry for approval

**Proposed recipients:** Autodata's published customer integration address, and the HaynesPro/Infopro Asia Pacific contact listed on its official contact page. Send separate messages, not a shared recipient list.

**Subject:** Philippine ECU coverage and application-licensing enquiry

Hello,

We are evaluating licensed technical data for Autoelectric Lab, a Philippine-focused automotive reference application.

Please confirm exact Philippine/ASEAN coverage for ECU pin connections, wiring and diagnostic procedures. Target makes include Toyota, Mitsubishi, Suzuki, Ford, Nissan, Isuzu, Honda, Hyundai, Kia, MG, BYD and Geely.

Before subscribing, we need a fitment matrix and a permitted pilot sample with vehicle/ECU identifiers, connector orientation, source/revision and test conditions. Please also explain API or portal integration rights; public versus authenticated-user access; caching, PDF/JSON exports, offline retention and any AI-processing restrictions.

Please provide evaluation arrangements and a complete application-licensing quote for the Philippines, including tax/currency, setup fees, minimum term, renewal and usage limits.

This is an enquiry only—not an order, payment authorization or request to email credentials.

Thank you.

The longer provider-specific versions below retain the detailed model checklist for later clarification. They have not been sent either.

## Autodata

**Proposed recipient:** customer-integration@autodata-group.com  
**Source:** https://developer.autodata-group.com/io-docs  
**Subject:** Philippine/ASEAN ECU coverage and application-licensing enquiry

Hello Autodata integration team,

We are evaluating licensed technical data for Autoelectric Lab, a Philippine-focused automotive reference and manual document-review application.

Please confirm:

1. Which Philippine/ASEAN vehicle variants you cover for ECU connector pin assignments, wiring diagrams and diagnostic procedures. Initial priorities include Toyota Vios/Hilux/Innova/Fortuner/Hiace; Mitsubishi Mirage/Xpander/Montero Sport/Strada/Triton/L300; Ford Ranger/Everest; Nissan Navara/Terra/Almera; Isuzu D-Max/mu-X; and relevant Suzuki, Honda, Hyundai, Kia, MG, BYD and Geely variants. This is a scope request, not an assumption of coverage.
2. Whether you can supply an applicability matrix identifying production ranges, chassis/engine/transmission variants and ECU part/hardware identifiers, plus a permitted pilot sample with connector orientation, source/revision/diagram locator and test conditions.
3. Which agreement permits API retrieval and display inside our application, and whether it permits deep linking, caching, PDF/print and JSON exports, offline retention, and any AI processing. Please distinguish public access from authenticated, individually entitled users.
4. Available evaluation arrangements, secure onboarding steps, data-update/versioning information, and the full commercial quote for use in the Philippines, including currency/tax, setup fees, minimum term, renewal conditions and per-user/usage limits.

We have not subscribed or imported your technical data. Please provide written coverage and usage-rights confirmation before we consider a purchase. This enquiry is not an order, payment authorization or request to send credentials by email.

Thank you.

## HaynesPro / Infopro Digital Automotive

**Proposed route:** Asia Pacific contact listed at https://www.infopro-digital-automotive.com/contact-us/  
**Subject:** Philippine coverage and HaynesPro Web Services/portal licensing enquiry

Hello Infopro Digital Automotive Asia Pacific team,

We are evaluating licensed technical data for Autoelectric Lab, a Philippine-focused automotive reference and manual document-review application. Please forward this enquiry to the team responsible for HaynesPro Web Services and portal-to-portal licensing.

Please confirm:

1. Exact Philippine/ASEAN vehicle coverage for ECU connector pin connections, wiring diagrams and diagnostic procedures. Initial priorities are Toyota Vios/Hilux/Innova/Fortuner/Hiace; Mitsubishi Mirage/Xpander/Montero Sport/Strada/Triton/L300; Ford Ranger/Everest; Nissan Navara/Terra/Almera; Isuzu D-Max/mu-X; and relevant Suzuki, Honda, Hyundai, Kia, MG, BYD and Geely variants. European or Australia/New Zealand model presence alone would not establish the required Philippine applicability.
2. Whether a permitted pilot sample and fitment matrix can identify production ranges, chassis/engine/transmission variants, ECU part/hardware identifiers, connector-side orientation, source/revision/diagram locator and relevant test conditions.
3. Whether Web Services or portal-to-portal access is appropriate, and the licence requirements for public versus authenticated/entitled users. Please clarify caching, PDF/print and JSON exports, offline retention, data-update/versioning and any AI-processing restrictions.
4. Evaluation availability and a complete application-licensing quote for the Philippines, including currency/tax, setup fees, minimum term, renewal conditions and per-user/usage limits.

We have not created a paid account or imported your technical data. Please provide written coverage and usage-rights confirmation before we consider a purchase. This enquiry is not an order, payment authorization or request to send credentials by email.

Thank you.
