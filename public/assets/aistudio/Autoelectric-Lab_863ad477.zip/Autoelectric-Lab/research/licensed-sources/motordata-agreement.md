Source: https://motordata.net/en_en/info/agreement/
Fetched: 2026-11-11

Font size

[Reduced font size](https://motordata.net/en_en/info/agreement/ "Reduced font size")

[Normal font size](https://motordata.net/en_en/info/agreement/ "Normal font size")

[ Increased font size](https://motordata.net/en_en/info/agreement/ " Increased font size")

Background and font color

[Black on white background](https://motordata.net/en_en/info/agreement/ "Black on white background")

[White over black background](https://motordata.net/en_en/info/agreement/ "White over black background")

[Blue on blue background](https://motordata.net/en_en/info/agreement/ "Blue on blue background")

[Black over yellow background](https://motordata.net/en_en/info/agreement/ "Black over yellow background")

[Green over black background](https://motordata.net/en_en/info/agreement/ "Green over black background")

Images

[Show images](https://motordata.net/en_en/info/agreement/ "Show images")

[Hide images](https://motordata.net/en_en/info/agreement/ "Hide images")

Text scoring

[Read the text](https://motordata.net/en_en/info/agreement/ "Read the text")

[Do not read the text](https://motordata.net/en_en/info/agreement/ "Do not read the text")

Regular version of the site

[![motordata EN](https://motordata.net/upload/CAllcorp3/8b7/iqa2gzf05ymozhaby9xnnvn3pxnd53fw.png)](https://motordata.net/en_en/)

Software and mobile applications

for automotive diagnostics

[Sign in](https://motordata.net/cab/en/account)

[Our Products](https://motordata.net/en_en/projects/)

- [MotorData Automotive Electrics Software Features](https://motordata.net/en_en/projects/features-motordata-autoelectrics/ "MotorData Automotive Electrics Software Features")

- [MotorData OBD2 mobile app](https://motordata.net/en_en/projects/motorData-OBD2-mobile-app/ "MotorData OBD2 mobile app")


[Tariffs](https://motordata.net/en_en/tariffs/)

- [MotorData Automotive Electrics Tariffs](https://motordata.net/en_en/tariffs/Autoelectrics/ "MotorData Automotive Electrics Tariffs")
  - [Demo Access to MotorData Automotive Electrics](https://motordata.net/en_en/tariffs/Autoelectrics/demo-access-to-motordata-automotive-electrics/ "Demo Access to MotorData Automotive Electrics")
  - [1 Week](https://motordata.net/en_en/tariffs/Autoelectrics/electrics-1-week/ "1 Week")
  - [1 Month](https://motordata.net/en_en/tariffs/Autoelectrics/1-month/ "1 Month")
  - [12 Months](https://motordata.net/en_en/tariffs/Autoelectrics/12-months/ "12 Months")
  - [3 Months](https://motordata.net/en_en/tariffs/Autoelectrics/3-months/ "3 Months")
  - [6 months](https://motordata.net/en_en/tariffs/Autoelectrics/6-months/ "6 months")

[Company](https://motordata.net/en_en/company/)

- [Company](https://motordata.net/en_en/company/index.php "Company")

- [Contacts & Requisites](https://motordata.net/en_en/company/requisites/ "Contacts & Requisites")


[News](https://motordata.net/en_en/news/)

[Information](https://motordata.net/en_en/info/)

- [Help and Support](https://motordata.net/en_en/info/help/ "Help and Support")

- [Quick Start Guide](https://motordata.net/en_en/info/quickstart/ "Quick Start Guide")

- [FAQ](https://motordata.net/en_en/info/faq/ "FAQ")

- [Articles](https://motordata.net/en_en/articles/ "Articles")

- [Integration with Scanners](https://motordata.net/en_en/info/integration/ "Integration with Scanners")

- [How to Obtain Access](https://motordata.net/en_en/info/purchase/ "How to Obtain Access")

- [Payment Methods](https://motordata.net/en_en/info/payments/ "Payment Methods")

- [User License Agreement](https://motordata.net/en_en/info/agreement/ "User License Agreement")

- [Privacy Policy](https://motordata.net/en_en/info/privacy-policy/ "Privacy Policy")

- [Model Catalog (MotorData Automotive Electrics)](https://motordata.net/en_en/models/ "Model Catalog (MotorData Automotive Electrics)")


[Articles](https://motordata.net/en_en/articles/)

[Open MotorData Automotive Electrics](https://motordata.net/client/)

en

[ru](https://motordata.net/) [fr](https://motordata.net/fr_fr/) [es](https://motordata.net/es_es/)

en

[![motordata EN](https://motordata.net/upload/CAllcorp3/8b7/iqa2gzf05ymozhaby9xnnvn3pxnd53fw.png)](https://motordata.net/en_en/)

[![motordata EN](https://motordata.net/upload/CAllcorp3/8b7/iqa2gzf05ymozhaby9xnnvn3pxnd53fw.png)](https://motordata.net/en_en/)

- [Our Products](https://motordata.net/en_en/projects/ "Our Products")


  - [Our Products](https://motordata.net/en_en/projects/)

  - [MotorData Automotive Electrics Software Features](https://motordata.net/en_en/projects/features-motordata-autoelectrics/ "MotorData Automotive Electrics Software Features")

  - [MotorData OBD2 mobile app](https://motordata.net/en_en/projects/motorData-OBD2-mobile-app/ "MotorData OBD2 mobile app")
- [Tariffs](https://motordata.net/en_en/tariffs/ "Tariffs")


  - [Tariffs](https://motordata.net/en_en/tariffs/)

  - [MotorData Automotive Electrics Tariffs](https://motordata.net/en_en/tariffs/Autoelectrics/ "MotorData Automotive Electrics Tariffs")


    - [MotorData Automotive Electrics Tariffs](https://motordata.net/en_en/tariffs/Autoelectrics/)

    - [Demo Access to MotorData Automotive Electrics](https://motordata.net/en_en/tariffs/Autoelectrics/demo-access-to-motordata-automotive-electrics/ "Demo Access to MotorData Automotive Electrics")

    - [1 Week](https://motordata.net/en_en/tariffs/Autoelectrics/electrics-1-week/ "1 Week")

    - [1 Month](https://motordata.net/en_en/tariffs/Autoelectrics/1-month/ "1 Month")

    - [12 Months](https://motordata.net/en_en/tariffs/Autoelectrics/12-months/ "12 Months")

    - [3 Months](https://motordata.net/en_en/tariffs/Autoelectrics/3-months/ "3 Months")

    - [6 months](https://motordata.net/en_en/tariffs/Autoelectrics/6-months/ "6 months")
- [Company](https://motordata.net/en_en/company/ "Company")


  - [Company](https://motordata.net/en_en/company/)

  - [Company](https://motordata.net/en_en/company/index.php "Company")

  - [Contacts & Requisites](https://motordata.net/en_en/company/requisites/ "Contacts & Requisites")
- [News](https://motordata.net/en_en/news/ "News")

- [Information](https://motordata.net/en_en/info/ "Information")


  - [Information](https://motordata.net/en_en/info/)

  - [Help and Support](https://motordata.net/en_en/info/help/ "Help and Support")

  - [Quick Start Guide](https://motordata.net/en_en/info/quickstart/ "Quick Start Guide")

  - [FAQ](https://motordata.net/en_en/info/faq/ "FAQ")

  - [Articles](https://motordata.net/en_en/articles/ "Articles")

  - [Integration with Scanners](https://motordata.net/en_en/info/integration/ "Integration with Scanners")

  - [How to Obtain Access](https://motordata.net/en_en/info/purchase/ "How to Obtain Access")

  - [Payment Methods](https://motordata.net/en_en/info/payments/ "Payment Methods")

  - [User License Agreement](https://motordata.net/en_en/info/agreement/ "User License Agreement")

  - [Privacy Policy](https://motordata.net/en_en/info/privacy-policy/ "Privacy Policy")

  - [Model Catalog (MotorData Automotive Electrics)](https://motordata.net/en_en/models/ "Model Catalog (MotorData Automotive Electrics)")
- [Articles](https://motordata.net/en_en/articles/ "Articles")

- [Open MotorData Automotive Electrics](https://motordata.net/client/ "Open MotorData Automotive Electrics")


[Sign in](https://motordata.net/cab/en/account)

- [en](https://motordata.net/en_en/info/agreement/ "en")




  - [Language](https://motordata.net/en_en/info/agreement/)

  - [en](https://motordata.net/en_en/ "en")

  - [ru](https://motordata.net/ "ru")

  - [fr](https://motordata.net/fr_fr/ "fr")

  - [es](https://motordata.net/es_es/ "es")

- [sales@motordata.net](mailto:sales@motordata.net)


# MotorData End User License Agreement

## MotorData End User License Agreement

Read the following terms carefully before using MotorData System (hereinafter referred to as "the SOFTWARE"). Using the SOFTWARE indicates your full acceptance of these terms.

If you do not fully agree with the terms of this License Agreement, do not use the SOFTWARE or its components.

This End-User License Agreement (hereinafter referred to as the "EULA") is a legal agreement between you, the end user, who uses the SOFTWARE and Legion-Autodata. The SOFTWARE includes any and all associated media, printed materials, and "online" or electronic documentation as well as applications, databases and other software components. By installing, copying, or otherwise using the SOFTWARE, you acknowledge that you have read this EULA and that you understand it and agree to be bound by its terms. This EULA comes into force when you accept all the terms stated herein during the SOFTWARE installation or when you start using the SOFTWARE in any manner. This EULA is binding for the entire period of the SOFTWARE copyright, unless otherwise stated in this EULA or in a separate written agreement between You and Legion-Autodata and may depend on the scope of the License as it is described in this EULA. The SOFTWARE is protected by copyright laws and international treaty provisions. You agree that this EULA is enforceable like any written negotiated agreement signed by you. This EULA is enforceable against you.

### 1\. Definitions

“Legion-Autodata” means AO “Legion-Autodata”, registered at 117525, Moscow, Dnepropetrovskaya street, Building 3, building. 5, ap. 166, Russian Federation.

“MotorData System” means an integral software product that provides user access to technical information on automotive diagnostics and repair. MotorData System consists of MotorData Service, MotorData System Website, User Account, and Client Software. MotorData System is developed and owned by “Legion-Autodata”.

“MotorData Service” means a combination of hardware and software providing for functionality and usability of MotorData System.

“Client Software” means a standalone piece of software, installed on the End User computer, or a web application. Client software provides user interface to connect to MotorData Service and display data received from it.

“MotorData System Website” means a public website (online information resource available for everyone), permanently hosted at [http://motordata.net](https://motordata.net/). MotorData System Website contains general information on MotorData System, its terms and conditions, this EULA, information on MotorData System license options (including prices and relevant terms), necessary documentation and contact information, as well as User Account and other pertinent data.

“You”, “Your” and “End User” refer to and include any person (including individual entrepreneur) and/or any legal entity that has registered on MotorData System Website and uses this SOFTWARE or on whose behalf this SOFTWARE is being used. All risks and responsibility for providing false and/or incomplete personal data during registration lies entirely on the End User.

“User Account” means a personal End User MotorData System Website section designed for placing orders for MotorData System access licenses, editing user profile data, and other interactions between the End User and MotorData System. Only registered End Users can access their User Accounts using their Access Credentials (email address and password).

“Registration” means a procedure of submitting a special completed form on MotorData System Website, with creating unique Access Credentials. Registration procedure is considered complete after End User confirms his/her email address using a confirmation code from the message sent to that email address.

“Access Credentials” means login ID and password used to sign in to User Account and to connect to MotorData Service via MotorData Client Software. Your login is your email address and your password is defined by you during the Registration.

“Registration Approval” means positive result of Registration data check (Access credentials and user Profile, submitted during registration). Registration approval is performed by Legion-Autodata personnel. After the registration approval the End User can access MotorData System.

### 2\. Subject matter

2.1. This EULA sets terms of You accessing MotorData System and Legion-Autodata providing You with this access. Both parties making this agreement imply conscientiousness and good will.

By Registering on the MotorData System Website you adhere to this agreement without any exemptions and corrections. You provide your personal information for processing (including automated processing) at your own will for EULA fulfillment. Gathering and processing your personal data is done by Legion-Autodata only for user identification purposes and to prevent unauthorized access to MotorData System. You can find more details in our [Privacy Policy](https://motordata.net/en_en/info/privacy-policy/ "MotorData Privacy Policy").

2.2. Legion-Autodata provides you with a non-exceptional License for temporal usage of MotorData System only for your personal purposes. You have no right to sublicense your License. User identification is done by comparing Access Credentials against those specified during Registration.

2.3. MotorData System usage is permitted only under the conditions of this EULA. If you do not fully adhere to this EULA, you do not have the right to use MotorData System in any way.

2.4. Access License to MotorData System can be provided in several options of duration and data coverage (including car makes and models sets, diagnostic systems and components, and other types of text and visual data). Those limitations are essential License conditions according to this EULA. License options available for purchasing, their conditions and prices are published on the “ [Licensing Options and Pricing](https://motordata.net/en_en/tariffs/ "Licensing Options and Pricing")” page, which is an integral part of this EULA.

2.5. License acquisition is done by 100% (full license cost) prepayment. Payment currency is RUB (Russian Ruble).

2.6. License acquisition cost can be changed by Legion-Autodata unilaterally. Notification of the License price change is publishing information of the new price on MotorData System Website. You can prolong the license based on the options and prices available after the previous license expiration.

### 3\. Intellectual Property Ownership

MotorData System is a product of Legion-Autodata intellectual labor. It is protected by copyright laws and international copyright treaties, as well as other intellectual property laws and treaties. Russian Federation software registration patent №2008611753, dated 02.04.2008.

It is not permitted to erase any Legion-Autodata identification and copyright labels and references from any data saved from MotorData System. You agree to prevent making any illegal copies (scanning, transfer to other information media, etc.) of MotorData System and its data. All rights not expressly granted to You by the EULA are reserved by Legion-Autodata. This EULA does not grant You any rights in connection with any trademarks, copyrights or know-hows of Legion-Autodata.

Any use of the SOFTWARE and all component parts outside of or in contravention of the terms and conditions of this EULA shall constitute a breach of Legion-Autodata’s intellectual property rights and shall give cause for:

a. the revocation of all rights to use the SOFTWARE granted to You under this EULA;

b. the prosecution of the End User according to the acting legislation;

c. the compensation demand for any direct and indirect losses.

Copyright violations are subject of civil, administrative and criminal prosecution according to the laws of Russian Federation.

### 4\. User Rights

4.1. Legion-Autodata grants you an non-exceptional non-transferable right to use MotorData System in the following ways:

a. You can register on MotorData System Website and access your Account.

b. After your registration is approval by Legion-Autodata you can order and pay for the selected MotorData license option.

c. You can install Client Software which is available for download from your Account or from a distribution package obtained directly from Legion-Autodata.

d. Using Client Software you can connect to MotorData Service during all period or license validity. Start date of the license period is the license issue date. You are notified about this via email, and the issued license appears in the list of active licenses in the Account on MotorData System Website.

e. You can use the information provided by MotorData Service in online mode and as a local file or printed copy.

4.2. End User can install Client Software on the required amount of personal computers, owned by the legal entity that/who obtained the license. Number of concurrent connections to MotorData Service cannot exceed the number of active licenses.

4.3. The End User can use the SOFTWARE for personal (non-commercial) purposes.

### 5\. Limitations

5.1. End User cannot perform or allow performing the following actions on the SOFTWARE and Access Credentials: complete or partial copying, publication, citing, translation, and other modifications except for the usage in ways and volumes specifically allowed by this EULA.

5.2. End User has no right to reproduce and distribute the SOFTWARE both free of charge and on commercial basis (including software collection packages) without written consent of Legion-Autodata.

5.3. End User cannot perform or allow performing the following actions on the SOFTWARE and Access Credentials: change, decompile, disassemble, decipher and other actions aimed at breaking or avoiding SOFTWARE security and authorization system, obtaining knowledge on algorithms used in the SOFTWARE, creating secondary software products using (completely or partially) the SOFTWARE or any of its parts of any size (volume).

5.4. Legion-Autodata reserves the right to deny User registration without any explanation.

5.5. Legion-Autodata reserves the right to limit user access to MotorData System when the volume limit is reached. Limits of data amount available for one user is set by Legion-Autodata.

### 6\. Limitation of Liability

6.1. The SOFTWARE is distributed on the “AS IS” basis. Legion-Autodata does not provide any guaranties that the SOFTWARE will function without any error and all its data is correct. Legion-Autodata does not claim that the SOFTWARE will suit specific needs of the End User.

6.2. To the maximum extent permitted by applicable law, in no event will Legion-Autodata and its partners be liable to You for any damages, business interruption, loss of data or information of any kind, business or otherwise, claims or costs whatsoever, or any consequential, indirect, incidental damage, or any lost profits or lost savings resulting from and/or relating to the use of the SOFTWARE, or damages caused by possible errors or misprints in the SOFTWARE, even if an Legion-Autodata representative has been advised of the possibility of such loss, damages, claims or costs, or for any claim by any third party.

### 7\. Changes and Termination.

7.1. Legion-Autodata reserves the right to change EULA at any time. The changed EULA will be published on MotorData System Website 14 days prior the date when the changes come into effect.

7.2. In the case of violation of any of terms and conditions of this EULA by the user, Legion-Autodata has the right for unilateral Agreement termination, by disabling End User access to MotorData System and notifying him/her of the termination.

7.3. If an excessive or malicious activity under the End User account is detected aimed at Legion-Autodata copyright violation, such an activity is regarded as a breach of items 2.2 and 4.3 of this EULA.

At EULA termination the End User has to stop using the SOFTWARE.

### 8\. Technical Support.

8.1. Legion-Autodata does not guarantee that any specific SOFTWARE defects will be fixed.

8.2. Nevertheless Legion-Autodata will strive to solve all the problems with the SOFTWARE usability and functionality. Technical support contacts can be found on MotorData System Website.

8.3. Legion-Autodata guaranties it will use all its available resources to support the SOFTWARE functionality. At the same time Legion-Autodata bears no responsibility for any interruptions and incomplete functioning of MotorData Service due to the reasons connected to actions (or inactions) of third parties, force majeure and actions dictated by End User, SOFTWARE and Legion-Autodata security considerations.

### 9\. Confidentiality.

9.1. The SOFTWARE in terms of this EULA presents confidential information (hereinafter Confidential Materials). You agree to be bound by the following terms and conditions:

9.1.1 You shall not disclose Confidential Materials without written consent from Legion-Autodata.. The term "disclose" means to lease, loan, rent, assign, transfer or provide access, over a network or otherwise, to Confidential Materials reproduced in any form, including oral communications, to any third party.

9.1.2 You shall take all reasonable steps to prevent the disclosure of Confidential Materials and to keep it confidential. You shall promptly inform Legion-Autodata if You become aware of any disclosure of Confidential Materials.

9.2 You shall keep the SOFTWARE confidentiality the same way as his/her personal data. You shall not be responsible for Confidential Materials disclosure if it is:

– due to requirements of actual legislation;

– due to force majeure;

– by preliminary written consent from Legion-Auodata.

9.3. Legion-Autodata hereby states it applies all possible organizational and technical means for personal data protection from unauthorized use, distribution, copying, blocking, changing, destruction and other illegal actions.

### 10\. Miscellaneous.

10.1 Legion-Autodata may send You e-mails containing product and company news, information about special offers, advices on product usage and other product and company-related information provided You specifically agreed to receive such information from Legion-Autodata. You have the possibility to remove Your address from Legion-Autodata mailing list at any time.

10.2. This EULA defines all essential and required conditions for MotorData System usage and is valid for being accepted by unspecified number of End Users.

10.3. This EULA is a public offer and is considered accepted at the moment of Registration on MotorData System Website.

10.4. All documents, claims and letters that are transmitted electronically and provide possibility to identify the sender and the recipient can be used as written proof when settling a disagreement.

10.5 If any part of this EULA is found void and unenforceable, it will not affect the validity of the balance of the EULA, which shall remain valid and enforceable according to its terms.

### 11\. Governing Law; Arbitration

11.1. This Agreement will be governed by and construed in accordance with the laws of the Russian Federation without reference to conflicts of law rules and principles. This Agreement shall not be governed by the United Nations Convention on Contracts for the International Sale of Goods, the application of which is expressly excluded. Any dispute arising out of the interpretation or application of the terms of this Agreement or any breach thereof shall, unless it is settled by direct negotiation, be settled by in the International Commercial Arbitration Court at the Russian Federation Chamber of Commerce and Industry in Moscow, the Russian Federation. Any award rendered by the arbitrator shall be final and binding on the parties and any judgment on such arbitration award may be enforced in any court of competent jurisdiction. Nothing in this Section 11 shall prevent a Party from seeking or obtaining equitable relief from a court of competent jurisdiction, whether before, during or after arbitration proceedings.

[New Update![New Update](https://motordata.net/upload/iblock/0f4/gewdmhajaxgaev5aym97q69opaajo9ra.png)](https://motordata.net/en_en/news/)

[Homepage](https://motordata.net/en_en/ "Homepage") [Software](https://motordata.net/en_en/projects/ "Software") [Prices](https://motordata.net/en_en/tariffs/ "Prices") [News](https://motordata.net/en_en/news/ "News") [Company](https://motordata.net/en_en/company/index.php "Company") [Help](https://motordata.net/en_en/info/help/ "Help")