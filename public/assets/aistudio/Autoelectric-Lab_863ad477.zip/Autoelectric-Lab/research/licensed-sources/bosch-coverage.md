Source: https://www.downloads.bosch-automotive.com/pl/vehicle-coverage-esitronic
Fetched: 2026-11-11

# Zakres pojazdów ESI\[tronic\]

Profesjonalne oprogramowanie diagnostyczne ESI\[tronic\] firmy Bosch zawiera dane ponad 90 000 pojazdów około 150 marek. Sprawdzaj wygodnie, które dane i informacje są obecnie uwzględnione dla Twojego pojazdu.


## Wyszukiwanie pojazdów

Rozpocznij wyszukiwanie wg marki, modelu lub kodu silnika

- Samochód osobowy / transportowy
Samochód osobowy / transportowy

- Pojazd użytkowy
Pojazd użytkowy

- Pozostałe
Terenowy


Wpisz markę, model, typ, rodzaj paliwa, rok produkcji, kod silnika

Znajdź

#### Did you mean

#### Sprecyzuj swoje wyszukiwanie

Marka (undefined)

Wybierz...

Model (undefined)

Wybierz...

Typ (undefined)

Wybierz...

Rodzaj paliwa (undefined)

Wybierz...

Rok produkcji (undefined)

Wybierz...

Kod silnika (undefined)

Wybierz...

**DEBUG**

search string to server:

Return from Server: **identified criteria**:

### Wybierz poniższy pojazd, aby wyświetlić zakres

Wyszukiwanie zwróciło 0 wyników

##### Za dużo wyników. Dodaj więcej filtrów do wyszukiwania.

## Uzyskaj licencję ESI\[tronic\]

Korzystaj z wiodącego oprogramowania diagnostycznego i uzyskaj licencję na oprogramowanie ESI\[tronic\]! Aby dowiedzieć się więcej, skontaktuj się ze swoim lokalnym sprzedawcą hurtowym lub dystrybutorem. Wejdź na poniższe strony internetowe, aby uzyskać więcej informacji na temat ESI\[tronic\].

- [![Sprzęt do badań diagnostycznych Bosch](https://www.downloads.bosch-automotive.com/fileadmin/user_upload/Medialibrary/VehicleIdent/AA_AS_Key_Visual_Connected_Repair_2_80762__1_small.jpg)\\
**Sprzęt do badań diagnostycznych Bosch**\\
\\
Dowiedz się więcej](https://www.boschaftermarket.com/)

- [![Instrukcje, aktualizacje i informacje](https://www.downloads.bosch-automotive.com/fileadmin/user_upload/Medialibrary/VehicleIdent/AA_AS_Key_Visual_Connected_Repair_2_80762__1_v2_small.jpg)\\
**Instrukcje, aktualizacje i informacje**\\
\\
Dowiedz się więcej](https://www.downloads.bosch-automotive.com/)