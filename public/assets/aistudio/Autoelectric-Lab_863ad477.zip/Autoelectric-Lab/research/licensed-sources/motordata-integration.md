Source: https://motordata.net/en_en/info/integration/
Fetched: 2026-11-11

Font size

[Reduced font size](https://motordata.net/en_en/info/integration/ "Reduced font size")

[Normal font size](https://motordata.net/en_en/info/integration/ "Normal font size")

[ Increased font size](https://motordata.net/en_en/info/integration/ " Increased font size")

Background and font color

[Black on white background](https://motordata.net/en_en/info/integration/ "Black on white background")

[White over black background](https://motordata.net/en_en/info/integration/ "White over black background")

[Blue on blue background](https://motordata.net/en_en/info/integration/ "Blue on blue background")

[Black over yellow background](https://motordata.net/en_en/info/integration/ "Black over yellow background")

[Green over black background](https://motordata.net/en_en/info/integration/ "Green over black background")

Images

[Show images](https://motordata.net/en_en/info/integration/ "Show images")

[Hide images](https://motordata.net/en_en/info/integration/ "Hide images")

Text scoring

[Read the text](https://motordata.net/en_en/info/integration/ "Read the text")

[Do not read the text](https://motordata.net/en_en/info/integration/ "Do not read the text")

Regular version of the site

[![motordata EN](https://motordata.net/upload/CAllcorp3/8b7/iqa2gzf05ymozhaby9xnnvn3pxnd53fw.png)](https://motordata.net/en_en/)

Software and mobile applications

for automotive diagnostics

[Sign in](https://motordata.net/cab/en/account)

[Our Products](https://motordata.net/en_en/projects/)

- [MotorData Automotive Electrics Software Features](https://motordata.net/en_en/projects/features-motordata-autoelectrics/ "MotorData Automotive Electrics Software Features")

- [MotorData OBD2 mobile app](https://motordata.net/en_en/projects/motorData-OBD2-mobile-app/ "MotorData OBD2 mobile app")


[Tariffs](https://motordata.net/en_en/tariffs/)

- [MotorData Automotive Electrics Tariffs](https://motordata.net/en_en/tariffs/Autoelectrics/ "MotorData Automotive Electrics Tariffs")
  - [Demo Access to MotorData Automotive Electrics](https://motordata.net/en_en/tariffs/Autoelectrics/demo-access-to-motordata-automotive-electrics/ "Demo Access to MotorData Automotive Electrics")
  - [1 Week](https://motordata.net/en_en/tariffs/Autoelectrics/electrics-1-week/ "1 Week")
  - [1 Month](https://motordata.net/en_en/tariffs/Autoelectrics/1-month/ "1 Month")
  - [12 Months](https://motordata.net/en_en/tariffs/Autoelectrics/12-months/ "12 Months")
  - [3 Months](https://motordata.net/en_en/tariffs/Autoelectrics/3-months/ "3 Months")
  - [6 months](https://motordata.net/en_en/tariffs/Autoelectrics/6-months/ "6 months")

[Company](https://motordata.net/en_en/company/)

- [Company](https://motordata.net/en_en/company/index.php "Company")

- [Contacts & Requisites](https://motordata.net/en_en/company/requisites/ "Contacts & Requisites")


[News](https://motordata.net/en_en/news/)

[Information](https://motordata.net/en_en/info/)

- [Help and Support](https://motordata.net/en_en/info/help/ "Help and Support")

- [Quick Start Guide](https://motordata.net/en_en/info/quickstart/ "Quick Start Guide")

- [FAQ](https://motordata.net/en_en/info/faq/ "FAQ")

- [Articles](https://motordata.net/en_en/articles/ "Articles")

- [Integration with Scanners](https://motordata.net/en_en/info/integration/ "Integration with Scanners")

- [How to Obtain Access](https://motordata.net/en_en/info/purchase/ "How to Obtain Access")

- [Payment Methods](https://motordata.net/en_en/info/payments/ "Payment Methods")

- [User License Agreement](https://motordata.net/en_en/info/agreement/ "User License Agreement")

- [Privacy Policy](https://motordata.net/en_en/info/privacy-policy/ "Privacy Policy")

- [Model Catalog (MotorData Automotive Electrics)](https://motordata.net/en_en/models/ "Model Catalog (MotorData Automotive Electrics)")


[Articles](https://motordata.net/en_en/articles/)

[Open MotorData Automotive Electrics](https://motordata.net/client/)

en

[ru](https://motordata.net/) [fr](https://motordata.net/fr_fr/) [es](https://motordata.net/es_es/)

en

[![motordata EN](https://motordata.net/upload/CAllcorp3/8b7/iqa2gzf05ymozhaby9xnnvn3pxnd53fw.png)](https://motordata.net/en_en/)

[![motordata EN](https://motordata.net/upload/CAllcorp3/8b7/iqa2gzf05ymozhaby9xnnvn3pxnd53fw.png)](https://motordata.net/en_en/)

- [Our Products](https://motordata.net/en_en/projects/ "Our Products")


  - [Our Products](https://motordata.net/en_en/projects/)

  - [MotorData Automotive Electrics Software Features](https://motordata.net/en_en/projects/features-motordata-autoelectrics/ "MotorData Automotive Electrics Software Features")

  - [MotorData OBD2 mobile app](https://motordata.net/en_en/projects/motorData-OBD2-mobile-app/ "MotorData OBD2 mobile app")
- [Tariffs](https://motordata.net/en_en/tariffs/ "Tariffs")


  - [Tariffs](https://motordata.net/en_en/tariffs/)

  - [MotorData Automotive Electrics Tariffs](https://motordata.net/en_en/tariffs/Autoelectrics/ "MotorData Automotive Electrics Tariffs")


    - [MotorData Automotive Electrics Tariffs](https://motordata.net/en_en/tariffs/Autoelectrics/)

    - [Demo Access to MotorData Automotive Electrics](https://motordata.net/en_en/tariffs/Autoelectrics/demo-access-to-motordata-automotive-electrics/ "Demo Access to MotorData Automotive Electrics")

    - [1 Week](https://motordata.net/en_en/tariffs/Autoelectrics/electrics-1-week/ "1 Week")

    - [1 Month](https://motordata.net/en_en/tariffs/Autoelectrics/1-month/ "1 Month")

    - [12 Months](https://motordata.net/en_en/tariffs/Autoelectrics/12-months/ "12 Months")

    - [3 Months](https://motordata.net/en_en/tariffs/Autoelectrics/3-months/ "3 Months")

    - [6 months](https://motordata.net/en_en/tariffs/Autoelectrics/6-months/ "6 months")
- [Company](https://motordata.net/en_en/company/ "Company")


  - [Company](https://motordata.net/en_en/company/)

  - [Company](https://motordata.net/en_en/company/index.php "Company")

  - [Contacts & Requisites](https://motordata.net/en_en/company/requisites/ "Contacts & Requisites")
- [News](https://motordata.net/en_en/news/ "News")

- [Information](https://motordata.net/en_en/info/ "Information")


  - [Information](https://motordata.net/en_en/info/)

  - [Help and Support](https://motordata.net/en_en/info/help/ "Help and Support")

  - [Quick Start Guide](https://motordata.net/en_en/info/quickstart/ "Quick Start Guide")

  - [FAQ](https://motordata.net/en_en/info/faq/ "FAQ")

  - [Articles](https://motordata.net/en_en/articles/ "Articles")

  - [Integration with Scanners](https://motordata.net/en_en/info/integration/ "Integration with Scanners")

  - [How to Obtain Access](https://motordata.net/en_en/info/purchase/ "How to Obtain Access")

  - [Payment Methods](https://motordata.net/en_en/info/payments/ "Payment Methods")

  - [User License Agreement](https://motordata.net/en_en/info/agreement/ "User License Agreement")

  - [Privacy Policy](https://motordata.net/en_en/info/privacy-policy/ "Privacy Policy")

  - [Model Catalog (MotorData Automotive Electrics)](https://motordata.net/en_en/models/ "Model Catalog (MotorData Automotive Electrics)")
- [Articles](https://motordata.net/en_en/articles/ "Articles")

- [Open MotorData Automotive Electrics](https://motordata.net/client/ "Open MotorData Automotive Electrics")


[Sign in](https://motordata.net/cab/en/account)

- [en](https://motordata.net/en_en/info/integration/ "en")




  - [Language](https://motordata.net/en_en/info/integration/)

  - [en](https://motordata.net/en_en/ "en")

  - [ru](https://motordata.net/ "ru")

  - [fr](https://motordata.net/fr_fr/ "fr")

  - [es](https://motordata.net/es_es/ "es")

- [sales@motordata.net](mailto:sales@motordata.net)


# MotorData Integration with Scanners


We are paying a lot of attention to MotorData integration with automotive diagnostic equipment.

To support our effort we are providing free full access to MotorData for new scanners users. Among those car scanners are CarmanScan, ScanDoc and others. Durations of these Promo licenses depend on scanner manufacturer.

Some scanners support seamless integration with MotorData and allow easy transitions from the DTC data read out from a car to the corresponding MotorData section where users can get additional information on possible trouble causes, check relevant wiring diagrams and pinouts and all other information to have the car fixed.

MotorData online system contains professional diagnostic data for over 400 models from leading manufacturers from Korea, Japan, China and Russia.

- Over 18,000 colored wiring diagrams
- Over 55,000 DTCs with possible causes and conditions
- Over 4,500 pinout and waveform records

# CarmanScan

![carmanscan-logo.png](https://motordata.net/upload/medialibrary/c39/fonu4oi1pcdt2w1hjr7ufxeiq9ifxmdf.png)

Welcome! This page is designed for CarmanScan International scanners users. Starting October 2014 all new scanners produced by NexTech, including Carman AUTO i-300 and AUTO i-700 come with an activation code for a Full access 3-month MotorData license.

![carmanscan.jpg](https://motordata.net/upload/medialibrary/b70/p0zdzc7p444a53f9reuasd5lzylffahr.jpg)Obtaining access is easy. You will need to:

- Register on this website and confirm your email address
- Activate your free promo license in your Account using the activation code you got from CarmanScan
- Download and install MotorData client software on your PC

# ScanDoc

![scandoc1.jpg](https://motordata.net/upload/medialibrary/0f3/hf4aturjc862hyf3kj0d5oe1gpvbklr0.jpg)

Welcome! This page is designed for ScanDoc scanners users. Since October 2014 all ScanDoc scanners come with an activation code for a Full access 1-month MotorData license.

ScanDoc scanners are integrated with MotorData information system. Users who have an active MotorData license can pull up MotorData catalog on the model they are connected to directly from their scanner interface. Thus users can quickly get information on possible DTC causes, relevant wiring diagrams, pinouts as well as component locations, fuse boxes, element check procedures and other data.

![scandoc2.jpg](https://motordata.net/upload/medialibrary/847/2u5aadmmm69ymtk8wtjlg9smfld75pme.jpg)Obtaining access is easy. You will need to:

- Register on this website and confirm your email address
- Activate your free promo license in your Account using the activation code you got from ScanDoc
- Download and install MotorData client software on your PC

[New Update![New Update](https://motordata.net/upload/iblock/0f4/gewdmhajaxgaev5aym97q69opaajo9ra.png)](https://motordata.net/en_en/news/)

[Homepage](https://motordata.net/en_en/ "Homepage") [Software](https://motordata.net/en_en/projects/ "Software") [Prices](https://motordata.net/en_en/tariffs/ "Prices") [News](https://motordata.net/en_en/news/ "News") [Company](https://motordata.net/en_en/company/index.php "Company") [Help](https://motordata.net/en_en/info/help/ "Help")