Source: https://developer.autodata-group.com/io-docs
Fetched: 2026-11-11

[Skip Navigation](https://developer.autodata-group.com/io-docs#content)

# Autodata interactive API Documentation

Please use our interactive documentation to interact with the with the Autodata API without the need to write any code. By using this page you will be able to learn, evaluate and test by making live calls within seconds to our API. You can also view our [written documentation](https://developer.autodata-group.com/docs).

An API key is needed to use this interactive documentation, please contact our customer integration team (customer-integration@autodata-group.com) if you have any questions.

Download GraphQL Specification

Download Specification