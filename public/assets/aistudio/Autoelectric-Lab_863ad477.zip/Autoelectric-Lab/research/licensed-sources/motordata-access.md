Source: https://motordata.net/en_en/info/purchase
Fetched: 2026-11-11

Font size

[Reduced font size](https://motordata.net/en_en/info/purchase/ "Reduced font size")

[Normal font size](https://motordata.net/en_en/info/purchase/ "Normal font size")

[ Increased font size](https://motordata.net/en_en/info/purchase/ " Increased font size")

Background and font color

[Black on white background](https://motordata.net/en_en/info/purchase/ "Black on white background")

[White over black background](https://motordata.net/en_en/info/purchase/ "White over black background")

[Blue on blue background](https://motordata.net/en_en/info/purchase/ "Blue on blue background")

[Black over yellow background](https://motordata.net/en_en/info/purchase/ "Black over yellow background")

[Green over black background](https://motordata.net/en_en/info/purchase/ "Green over black background")

Images

[Show images](https://motordata.net/en_en/info/purchase/ "Show images")

[Hide images](https://motordata.net/en_en/info/purchase/ "Hide images")

Text scoring

[Read the text](https://motordata.net/en_en/info/purchase/ "Read the text")

[Do not read the text](https://motordata.net/en_en/info/purchase/ "Do not read the text")

Regular version of the site

[![motordata EN](https://motordata.net/upload/CAllcorp3/8b7/iqa2gzf05ymozhaby9xnnvn3pxnd53fw.png)](https://motordata.net/en_en/)

Software and mobile applications

for automotive diagnostics

[Sign in](https://motordata.net/cab/en/account)

[Our Products](https://motordata.net/en_en/projects/)

- [MotorData Automotive Electrics Software Features](https://motordata.net/en_en/projects/features-motordata-autoelectrics/ "MotorData Automotive Electrics Software Features")

- [MotorData OBD2 mobile app](https://motordata.net/en_en/projects/motorData-OBD2-mobile-app/ "MotorData OBD2 mobile app")


[Tariffs](https://motordata.net/en_en/tariffs/)

- [MotorData Automotive Electrics Tariffs](https://motordata.net/en_en/tariffs/Autoelectrics/ "MotorData Automotive Electrics Tariffs")
  - [Demo Access to MotorData Automotive Electrics](https://motordata.net/en_en/tariffs/Autoelectrics/demo-access-to-motordata-automotive-electrics/ "Demo Access to MotorData Automotive Electrics")
  - [1 Week](https://motordata.net/en_en/tariffs/Autoelectrics/electrics-1-week/ "1 Week")
  - [1 Month](https://motordata.net/en_en/tariffs/Autoelectrics/1-month/ "1 Month")
  - [12 Months](https://motordata.net/en_en/tariffs/Autoelectrics/12-months/ "12 Months")
  - [3 Months](https://motordata.net/en_en/tariffs/Autoelectrics/3-months/ "3 Months")
  - [6 months](https://motordata.net/en_en/tariffs/Autoelectrics/6-months/ "6 months")

[Company](https://motordata.net/en_en/company/)

- [Company](https://motordata.net/en_en/company/index.php "Company")

- [Contacts & Requisites](https://motordata.net/en_en/company/requisites/ "Contacts & Requisites")


[News](https://motordata.net/en_en/news/)

[Information](https://motordata.net/en_en/info/)

- [Help and Support](https://motordata.net/en_en/info/help/ "Help and Support")

- [Quick Start Guide](https://motordata.net/en_en/info/quickstart/ "Quick Start Guide")

- [FAQ](https://motordata.net/en_en/info/faq/ "FAQ")

- [Articles](https://motordata.net/en_en/articles/ "Articles")

- [Integration with Scanners](https://motordata.net/en_en/info/integration/ "Integration with Scanners")

- [How to Obtain Access](https://motordata.net/en_en/info/purchase/ "How to Obtain Access")

- [Payment Methods](https://motordata.net/en_en/info/payments/ "Payment Methods")

- [User License Agreement](https://motordata.net/en_en/info/agreement/ "User License Agreement")

- [Privacy Policy](https://motordata.net/en_en/info/privacy-policy/ "Privacy Policy")

- [Model Catalog (MotorData Automotive Electrics)](https://motordata.net/en_en/models/ "Model Catalog (MotorData Automotive Electrics)")


[Articles](https://motordata.net/en_en/articles/)

[Open MotorData Automotive Electrics](https://motordata.net/client/)

en

[ru](https://motordata.net/) [fr](https://motordata.net/fr_fr/) [es](https://motordata.net/es_es/)

en

[![motordata EN](https://motordata.net/upload/CAllcorp3/8b7/iqa2gzf05ymozhaby9xnnvn3pxnd53fw.png)](https://motordata.net/en_en/)

[![motordata EN](https://motordata.net/upload/CAllcorp3/8b7/iqa2gzf05ymozhaby9xnnvn3pxnd53fw.png)](https://motordata.net/en_en/)

- [Our Products](https://motordata.net/en_en/projects/ "Our Products")


  - [Our Products](https://motordata.net/en_en/projects/)

  - [MotorData Automotive Electrics Software Features](https://motordata.net/en_en/projects/features-motordata-autoelectrics/ "MotorData Automotive Electrics Software Features")

  - [MotorData OBD2 mobile app](https://motordata.net/en_en/projects/motorData-OBD2-mobile-app/ "MotorData OBD2 mobile app")
- [Tariffs](https://motordata.net/en_en/tariffs/ "Tariffs")


  - [Tariffs](https://motordata.net/en_en/tariffs/)

  - [MotorData Automotive Electrics Tariffs](https://motordata.net/en_en/tariffs/Autoelectrics/ "MotorData Automotive Electrics Tariffs")


    - [MotorData Automotive Electrics Tariffs](https://motordata.net/en_en/tariffs/Autoelectrics/)

    - [Demo Access to MotorData Automotive Electrics](https://motordata.net/en_en/tariffs/Autoelectrics/demo-access-to-motordata-automotive-electrics/ "Demo Access to MotorData Automotive Electrics")

    - [1 Week](https://motordata.net/en_en/tariffs/Autoelectrics/electrics-1-week/ "1 Week")

    - [1 Month](https://motordata.net/en_en/tariffs/Autoelectrics/1-month/ "1 Month")

    - [12 Months](https://motordata.net/en_en/tariffs/Autoelectrics/12-months/ "12 Months")

    - [3 Months](https://motordata.net/en_en/tariffs/Autoelectrics/3-months/ "3 Months")

    - [6 months](https://motordata.net/en_en/tariffs/Autoelectrics/6-months/ "6 months")
- [Company](https://motordata.net/en_en/company/ "Company")


  - [Company](https://motordata.net/en_en/company/)

  - [Company](https://motordata.net/en_en/company/index.php "Company")

  - [Contacts & Requisites](https://motordata.net/en_en/company/requisites/ "Contacts & Requisites")
- [News](https://motordata.net/en_en/news/ "News")

- [Information](https://motordata.net/en_en/info/ "Information")


  - [Information](https://motordata.net/en_en/info/)

  - [Help and Support](https://motordata.net/en_en/info/help/ "Help and Support")

  - [Quick Start Guide](https://motordata.net/en_en/info/quickstart/ "Quick Start Guide")

  - [FAQ](https://motordata.net/en_en/info/faq/ "FAQ")

  - [Articles](https://motordata.net/en_en/articles/ "Articles")

  - [Integration with Scanners](https://motordata.net/en_en/info/integration/ "Integration with Scanners")

  - [How to Obtain Access](https://motordata.net/en_en/info/purchase/ "How to Obtain Access")

  - [Payment Methods](https://motordata.net/en_en/info/payments/ "Payment Methods")

  - [User License Agreement](https://motordata.net/en_en/info/agreement/ "User License Agreement")

  - [Privacy Policy](https://motordata.net/en_en/info/privacy-policy/ "Privacy Policy")

  - [Model Catalog (MotorData Automotive Electrics)](https://motordata.net/en_en/models/ "Model Catalog (MotorData Automotive Electrics)")
- [Articles](https://motordata.net/en_en/articles/ "Articles")

- [Open MotorData Automotive Electrics](https://motordata.net/client/ "Open MotorData Automotive Electrics")


[Sign in](https://motordata.net/cab/en/account)

- [en](https://motordata.net/en_en/info/purchase/ "en")




  - [Language](https://motordata.net/en_en/info/purchase/)

  - [en](https://motordata.net/en_en/ "en")

  - [ru](https://motordata.net/ "ru")

  - [fr](https://motordata.net/fr_fr/ "fr")

  - [es](https://motordata.net/es_es/ "es")

- [sales@motordata.net](mailto:sales@motordata.net)


# How to Obtain Access to MotorData


To order MotorData access licenses you need to [Register or Sign in](https://motordata.net/cab/en/account) to your existing Account.

## Licenses and Access Options

Access to MotorData is subscription-based and is managed with licenses that are issued to registered users. Licenses determine access parameters, such as access option and duration. Access option defines data set (makes and models) available to the user, while the duration defines the time period during which the access is permitted.

Currently there are 3 types of licenses:

- Demo license is a free license that is issued to new users for system evaluation. Users can see the full list of makes, models and systems available, but the access to the actual data (wiring diagrams, DTCs, etc.) is limited to 10 models from 7 manufacturers. Demo license can be requested during user registration and is active for 2 weeks.
- Promo license are distributed through official MotorData representatives and our partners (for example, [scanner manufacturers](https://motordata.net/en_en/info/integration/)) as activation codes. MotorData users can use those codes to activate Promo licenses in their Account. Promo licenses provide Full access to MotorData database. Duration of these licenses can vary from several weeks to several months.
- Paid license is the main type of license that can be ordered and purchased by MotorData users. Access option and license duration are chosen by the user while placing an order.

There are several access options based on the makes and models markets. You can find detailed information on MotorData licensing options here:

[Licensing Options and Pricing](https://motordata.net/en_en/tariffs/Autoelectrics/) →

Licenses can be obtained by users who have completed the registration procedure including email verification and approval from MotorData administration. Any user can have only one active license at a time.

## Payment

Once any commercial license is ordered, it needs to be paid by the user. Once it is fully paid, the license becomes active. The moment of activation is defined as the moment when a notification email is sent to the user. Please note, that activated licenses cannot be reimbursed.

More information on how to pay for MotorData licenses can be found here:

[Purchase Methods](https://motordata.net/en_en/info/payments/) →

Step-by-step instructions on how to start working with MotorData can be found in the « [MotorData Quick Start](https://motordata.net/en_en/info/quickstart/)» section.

In case you have any issues or questions regarding the payment procedure and license activation, please contact our [Customer Support](https://motordata.net/en_en/info/help/) service.

[New Update![New Update](https://motordata.net/upload/iblock/0f4/gewdmhajaxgaev5aym97q69opaajo9ra.png)](https://motordata.net/en_en/news/)

[Homepage](https://motordata.net/en_en/ "Homepage") [Software](https://motordata.net/en_en/projects/ "Software") [Prices](https://motordata.net/en_en/tariffs/ "Prices") [News](https://motordata.net/en_en/news/ "News") [Company](https://motordata.net/en_en/company/index.php "Company") [Help](https://motordata.net/en_en/info/help/ "Help")