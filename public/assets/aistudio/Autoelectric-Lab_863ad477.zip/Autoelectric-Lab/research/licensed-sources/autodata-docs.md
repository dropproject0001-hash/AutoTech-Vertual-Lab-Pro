Source: https://developer.autodata-group.com/docs
Fetched: 2026-11-11

[Skip Navigation](https://developer.autodata-group.com/docs#content)

# Technical Overview

_Please log in to view our full documentation._

Autodata API (Application Programming Interface)

The new Autodata API provides developers with a suite of technologies and tools designed to facilitate the integration of our data.

This solution aims to:

- Enable web applications to embed Autodata’s technical information
- Facilitate the integration and the maintenance of this information
- Support innovation and the delivery of customers’ benefits
- Allow partner setup within a few hours
- Provide tools and resources to ease the integration process
- Be based on the latest web standards and API best practice
- Ensure high performance and the secure exchange of data

## Content coverage

Autodata will progressively make all of its technical content available through the API: vehicle identification, technical specifications, service instructions, labour times, repair procedures, images, diagrams, etc.

The content covered by the API will continue to evolve in order to address the evolution of the car park, to enhance the comprehensive nature of the information and to improve the ways of handling it.

## Authentication: API Key and OAuth 2.0

The API we will be using OAuth 2.0 for access authentication. This is the current prevailing authorisation protocol that allows third-party websites and applications to access data. As such, lots of companies are already using this technology and plenty of resources about it are openly available.

Please refer to [http://oauth.net/2/](http://oauth.net/2/) and [http://tools.ietf.org/html/rfc6749](http://tools.ietf.org/html/rfc6749) for information about OAuth 2.

## Query format: RESTful

The Autodata API will include a suite of web services that will allow developers to interact with our data. All web services available through the API will be RESTful (i.e. conforming to the REST standards - Representational State Transfer).

Adopting a RESTful standard is easy for developers to use, supporting multiple data formats and following the industry trend for APIs. This means there is a widely available knowledge base on the subject.

## Response formats supported: JSON and XML

Users will be able to choose between two different response formats:

- JSON (JavaScript Object Notation) will be the default output for all web services available via the Autodata API. Please refer to [http://www.json.org/](http://www.json.org/) for more information about JSON.
- XML format will also be available as an optional output from the Autodata API.

The API may also support additional formats in the future as they become relevant.

version 22as of 9 years agoby Laura Macek

## Documentation

- [Technical Overview](https://developer.autodata-group.com/docs/read/Home)
- vehicle identifiers v1