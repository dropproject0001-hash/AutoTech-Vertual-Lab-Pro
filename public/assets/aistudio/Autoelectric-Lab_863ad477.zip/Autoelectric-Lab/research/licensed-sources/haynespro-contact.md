Source: https://www.infopro-digital-automotive.com/contact-us/
Fetched: 2026-11-11

Cookie settings

- [Main navigation menu](https://www.infopro-digital-automotive.com/contact-us/#menu)
- [Main content](https://www.infopro-digital-automotive.com/contact-us/#content)
- [Footer](https://www.infopro-digital-automotive.com/contact-us/#footer)

[Automotive](https://www.infopro-digital-automotive.com/) » Contact us

# Contact us

![Do you have questions? contact Infopro Digital Automotive Offices](<Base64-Image-Removed>)

**Infopro Digital Automotive**

20, rue des Aqueducs

94250 GENTILLY

France

[Locate us on a map](https://www.google.com/maps/place/20+Rue+des+Aqueducs,+94250+Gentilly,+Francia/@48.8160065,2.3289761,17z/data=!3m1!4b1!4m6!3m5!1s0x47e671082113bb95:0x2843c515c30f6080!8m2!3d48.816003!4d2.331551!16s%2Fg%2F11vlfb8bfn?entry=ttu)

Phone

[+33 (0)1 46 99 24 76](tel:+33 (0)1 46 99 24 76)

Email

[marketing.automotive@infopro-digital.com](mailto:marketing.automotive@infopro-digital.com)

Social networks

- [New window to infopro digital](https://www.linkedin.com/company/infopro-digital-automotive)
- [New window to infopro digital](https://www.youtube.com/channel/UClRvCr3VyPXWdCkMaEDsk1g)

## Do you have questions? Contact our offices

We are happy to help. Are you wondering whether we have the right tool for your company or are you simply curious about more details? We are ready to answer all questions. Just send us a message!

### Submit Your Request

\*Afghanistan (‫افغانستان‬‎)Albania (Shqipëri)Algeria (‫الجزائر‬‎)American SamoaAndorraAngolaAnguillaAntigua and BarbudaArgentinaArmenia (Հայաստան)ArubaAustraliaAustria (Österreich)Azerbaijan (Azərbaycan)BahamasBahrain (‫البحرين‬‎)Bangladesh (বাংলাদেশ)BarbadosBelarus (Беларусь)Belgium (België)BelizeBenin (Bénin)BermudaBhutan (འབྲུག)BoliviaBosnia and Herzegovina (Босна и Херцеговина)BotswanaBrazil (Brasil)British Indian Ocean TerritoryBritish Virgin IslandsBruneiBulgaria (България)Burkina FasoBurundi (Uburundi)Cambodia (កម្ពុជា)Cameroon (Cameroun)CanadaCape Verde (Kabu Verdi)Caribbean NetherlandsCayman IslandsCentral African Republic (République centrafricaine)Chad (Tchad)ChileChina (中国)ColombiaComoros (‫جزر القمر‬‎)Congo (DRC) (Jamhuri ya Kidemokrasia ya Kongo)Congo (Republic) (Congo-Brazzaville)Cook IslandsCosta RicaCôte d’IvoireCroatia (Hrvatska)CubaCuraçaoCyprus (Κύπρος)Czech Republic (Česká republika)Denmark (Danmark)DjiboutiDominicaDominican Republic (República Dominicana)EcuadorEgypt (‫مصر‬‎)El SalvadorEquatorial Guinea (Guinea Ecuatorial)EritreaEstonia (Eesti)EthiopiaFalkland Islands (Islas Malvinas)Faroe Islands (Føroyar)FijiFinland (Suomi)FranceFrench Guiana (Guyane française)French Polynesia (Polynésie française)GabonGambiaGeorgia (საქართველო)Germany (Deutschland)Ghana (Gaana)GibraltarGreece (Ελλάδα)Greenland (Kalaallit Nunaat)GrenadaGuadeloupeGuamGuatemalaGuinea (Guinée)Guinea-Bissau (Guiné Bissau)GuyanaHaitiHondurasHong Kong (香港)Hungary (Magyarország)Iceland (Ísland)India (भारत)IndonesiaIran (‫ایران‬‎)Iraq (‫العراق‬‎)IrelandIsrael (‫ישראל‬‎)Italy (Italia)JamaicaJapan (日本)Jordan (‫الأردن‬‎)Kazakhstan (Казахстан)KenyaKiribatiKosovoKuwait (‫الكويت‬‎)Kyrgyzstan (Кыргызстан)Laos (ລາວ)Latvia (Latvija)Lebanon (‫لبنان‬‎)LesothoLiberiaLibya (‫ليبيا‬‎)LiechtensteinLithuania (Lietuva)LuxembourgMacau (澳門)Macedonia (FYROM) (Македонија)Madagascar (Madagasikara)MalawiMalaysiaMaldivesMaliMaltaMarshall IslandsMartiniqueMauritania (‫موريتانيا‬‎)Mauritius (Moris)Mexico (México)MicronesiaMoldova (Republica Moldova)MonacoMongolia (Монгол)Montenegro (Crna Gora)MontserratMorocco (‫المغرب‬‎)Mozambique (Moçambique)Myanmar (Burma) (မြန်မာ)Namibia (Namibië)NauruNepal (नेपाल)Netherlands (Nederland)New Caledonia (Nouvelle-Calédonie)New ZealandNicaraguaNiger (Nijar)NigeriaNiueNorfolk IslandNorth Korea (조선 민주주의 인민 공화국)Northern Mariana IslandsNorway (Norge)Oman (‫عُمان‬‎)Pakistan (‫پاکستان‬‎)PalauPalestine (‫فلسطين‬‎)Panama (Panamá)Papua New GuineaParaguayPeru (Perú)PhilippinesPoland (Polska)PortugalPuerto RicoQatar (‫قطر‬‎)Réunion (La Réunion)Romania (România)Russia (Россия)RwandaSaint Barthélemy (Saint-Barthélemy)Saint HelenaSaint Kitts and NevisSaint LuciaSaint Martin (Saint-Martin (partie française))Saint Pierre and Miquelon (Saint-Pierre-et-Miquelon)Saint Vincent and the GrenadinesSamoaSan MarinoSão Tomé and Príncipe (São Tomé e Príncipe)Saudi Arabia (‫المملكة العربية السعودية‬‎)Senegal (Sénégal)Serbia (Србија)SeychellesSierra LeoneSingaporeSint MaartenSlovakia (Slovensko)Slovenia (Slovenija)Solomon IslandsSomalia (Soomaaliya)South AfricaSouth Korea (대한민국)South Sudan (‫جنوب السودان‬‎)Spain (España)Sri Lanka (ශ්‍රී ලංකාව)Sudan (‫السودان‬‎)SurinameSwazilandSweden (Sverige)Switzerland (Schweiz)Syria (‫سوريا‬‎)Taiwan (台灣)TajikistanTanzaniaThailand (ไทย)Timor-LesteTogoTokelauTongaTrinidad and TobagoTunisia (‫تونس‬‎)Turkey (Türkiye)TurkmenistanTurks and Caicos IslandsTuvaluU.S. Virgin IslandsUgandaUkraine (Україна)United Arab Emirates (‫الإمارات العربية المتحدة‬‎)United KingdomUnited StatesUruguayUzbekistan (Oʻzbekiston)VanuatuVatican City (Città del Vaticano)VenezuelaVietnam (Việt Nam)Wallis and FutunaYemen (‫اليمن‬‎)ZambiaZimbabwe

Select your country\*ItalyFranceSpainPortugalUnited KingdomAustraliaNederlandPolandUnited StatesBrazilGermanyAustriaSwitzerlandBelgiumIrelandOther

Select your activity\*OEMs & Manufacturers (parts, tyres, tools)Distribution Channels (wholesalers, ITGs, tyre networks, e-commerce)Workshops & Repair (workshops, bodyshops, tyre shops, fast-fit)Fleets, Leasing, Insurance & Dealership GroupsTool manufacturersWorkshops networkDistribution networkSoftware house, E-commerce, automotive platform

Type of lead

UTM\_Source

UTM\_Product

UTM\_Medium

UTM\_Content

UTM\_Campaign

## Contact by country

- [France](https://www.infopro-digital-automotive.com/contact-us/#region-1)
- [United Kingdom](https://www.infopro-digital-automotive.com/contact-us/#region-2)
- [Netherlands](https://www.infopro-digital-automotive.com/contact-us/#region-3)
- [Italy](https://www.infopro-digital-automotive.com/contact-us/#region-4)
- [Spain](https://www.infopro-digital-automotive.com/contact-us/#region-5)
- [Portugal](https://www.infopro-digital-automotive.com/contact-us/#region-6)
- [Germany](https://www.infopro-digital-automotive.com/contact-us/#region-7)
- [Eastern Europe](https://www.infopro-digital-automotive.com/contact-us/#region-8)
- [Australia](https://www.infopro-digital-automotive.com/contact-us/#region-9)
- [Americas](https://www.infopro-digital-automotive.com/contact-us/#region-10)
- [Asia Pacific](https://www.infopro-digital-automotive.com/contact-us/#region-11)

### France Contacts

#### Get in touch

We would be pleased to hear from you!
Contact us to talk about company projects, to request a quote or simply to say hello to our French team and we will be happy to answer you!

[New windowvisit the website](https://www.infopro-digital-automotive.fr/)

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Olivier Sindezingue

France Key Accounts Sales Director

[olivier.sindezingue@infopro-digital.com](mailto:olivier.sindezingue@infopro-digital.com)

[LinkedIn contact](https://www.linkedin.com/in/olivier-sindezingue-323b4326/)

### Infopro Digital Automotive France

##### ETAI

20, rue des Aqueducs
94250 GENTILLY, France

[marketing.automotive@infopro-digital.com](mailto:marketing.automotive@infopro-digital.com)

[+33 (0)1 46 99 24 76](tel:+33 (0)1 46 99 24 76)

##### Innovaxo

11 Rue du Petit Châtelier
44300 Nantes, France

[sedentaire@inovaxo.fr](mailto:sedentaire@inovaxo.fr)

[+33 (0)2 51 13 37 27](tel:+33 (0)2 51 13 37 27)

##### GIPA sas Headquarter

11 rue du Chevalier de Saint-George
75008 Paris

[\+ 33 1 53 04 08 54](tel:+ 33 1 53 04 08 54)

### United Kingdom Contact

#### Get in touch with United Kingdom team of experts

We would be pleased to hear from you!
Contact us to talk about company projects, to request a quote or simply to say hello to our English Automotive team and we will be happy to answer you!

[New windowVisit the website](https://www.haynespro.co.uk/)

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Chris Ives

Business Development Manager

[chris.ives@infopro-digital.com](mailto:chris.ives@infopro-digital.com)

[LinkedIn contact](https://www.linkedin.com/in/chris-ives-ab983897/)

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Sam Spray

Business Development Manager

[sam.spray@infopro-digital.com](mailto:sam.spray@infopro-digital.com)

[LinkedIn contact](https://www.linkedin.com/in/sam-spray-1420073a/)

### Infopro Digital Automotive UK

133 Houndsditch
London
EC3A 7BX
United Kingdom

[info.haynespro@infopro-digital.com](mailto:info.haynespro@infopro-digital.com)

[+44 (0) 333 320 8636](tel:+44 (0) 333 320 8636)

### Netherlands Contacts

#### Get in touch with Dutch team of experts

We would be pleased to hear from you!
Contact us to talk about company projects, to request a quote or simply to say hello to our Dutch Automotive team and we will be happy to answer you!

### Infopro Digital Automotive Netherlands

##### HaynesPro

Brouwershof
Stationsstraat 79F
3811 MH Amersfoort

[info.haynespro@infopro-digital.com](mailto:info.haynespro@infopro-digital.com)

[+31 (35) 603 6270](tel:+31 (35) 603 6270)

### Italy Contacts

#### Get in touch with Italian team of experts

We would be pleased to hear from you!
Contact us to talk about company projects, to request a quote or simply to say hello to our Italian Automotive team and we will be happy to answer you!

[New windowVisit the website](https://www.infopro-digital-automotive.it/contatti/)

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Michael Krampe

Managing Director Dach & Italy

[michael.krampe@infopro-digital.com](mailto:michael.krampe@infopro-digital.com)

[LinkedIn contact](https://www.linkedin.com/in/michael-krampe-72409b4a/)

### Infopro Digital Automotive Italy

##### Autronica

Via Nazionale 42/A
33010 Tavagnacco UD
Italia

[automotive.ita@infopro-digital.com](mailto:automotive.ita@infopro-digital.com)

[+39 0432 561543](tel: +39 0432 561543)

### Spain Contacts

#### Get in touch with Spanish of experts

We would be pleased to hear from you!
Contact us to talk about company projects, to request a quote or simply to say hello to our Spanish Automotive team and we will be happy to answer you!

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Antonio Maldonado

Sales Manager Spain

[antonio.maldonado@infopro-digital.com](mailto:antonio.maldonado@infopro-digital.com)

[LinkedIn contact](https://www.linkedin.com/in/antonio-maldonado-s%C3%A1nchez-888875118/)

### Infopro Digital Automotive Spain

##### ETAI IBERICA and ISI Condal

Ctra. de l’Hospitalet, 147.
CITYPARK, Edificio Roma planta 3ª
08940 Cornellá de Llobregat (Barcelona)

[automotive.spain@infopro-digital.com](mailto:automotive.spain@infopro-digital.com)

[+34 933 737 100](tel:+34 933 737 100)

### Portugal Contacts

#### Get in touch with Portuguese team of experts

We would be pleased to hear from you!
Contact us to talk about company projects, to request a quote or simply to say hello to our Portuguese Automotive team and we will be happy to answer you!

[New windowVisit the website](https://www.infopro-digital-automotive.pt/contactos/)

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

CHAMPETIER DE RIBES, Emmanuel

Key Account Manager

[emmanuel.champetier@infopro-digital.com](mailto:emmanuel.champetier@infopro-digital.com)

### Infopro Digital Automotive Portugal

[automotive@infopro-digital.com](mailto:automotive@infopro-digital.com)

[+34 93 373 71 00](tel:+34 93 373 71 00)

### Germany Contacts

#### Get in touch with German team of experts

We would be pleased to hear from you!
Contact us to talk about company projects, to request a quote or simply to say hello to our German Automotive team, and we will be happy to answer you!

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Michael Krampe

Managing Director D.A.CH & Italy

[michael.krampe@infopro-digital.com](mailto:michael.krampe@infopro-digital.com)

[LinkedIn contact](https://www.linkedin.com/in/michael-krampe-72409b4a/)

### Infopro Digital Automotive Germany

##### Infopro Digital Automotive

Stammheimerstraße 10
Kornwestheim D-70806
Germany

[automotive@infopro-digital.com](mailto:automotive@infopro-digital.com)

[+49 (0) 7141 503 9003](tel:+49 (0) 7141 503 9003)

##### Eucon GmbH

Martin-Luther-King-Weg 2
48155 Münster
Germany

[info@eucon.com](mailto:info@eucon.com)

[+49 251144960](tel:+49 251144960)

### Eastern Europe Contacts

#### Get in touch with Eastern Europe team of experts

We would be pleased to hear from you!
Contact us to talk about company projects, to request a quote or simply to say hello to our Eastern Europe Automotive team and we will be happy to answer you!

![Illustration of a female avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2024/05/contact-female-staff-infopro-digital.png)

ILIE, Larisa Marina

Key Account Manager

[larisa.ilie@infopro-digital.com](mailto:larisa.ilie@infopro-digital.com)

### Infopro Digital Automotive E-EU

##### Infopro Digital Automotive Srl

GREEN GATE,
Bulevardul Tudor Vladimirescu 22, Offices, Etaj 8,
050881 București,
Romania

[+40 31 425 3701](tel:+40 31 425 3701)

##### Aurelis Consulting Sp. z o.o.

Platinum Towers complex
ul. Grzybowska 61, A2202
00-844 Warsaw,
Poland

[service@aurelisconsulting.com](mailto:service@aurelisconsulting.com)

[+48 575 666 195](tel:+48 575 666 195)

### Australia Contact

#### Get in touch with our team of experts in the Asia Pacific region

We would be happy to hear from you!
Contact us to talk about company projects, to request a quotation or simply to say hello to our team based in Australia. We are happy to answer your questions!

[New windowVisit the website](https://haynespro.com.au/)

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Gary Knight

Key Account Manager

[gary.knight@infopro-digital.com](mailto:gary.knight@infopro-digital.com)

[LinkedIn contact](https://www.linkedin.com/in/gary-knight-ab272924/)

### Infopro Digital Automotive Australia

##### Haynes Australia Pty Limited

Suite 2
6 The Crescent Kingsgrove
NSW 1480
Australia

[automotive@infopro-digital.com](mailto:automotive@infopro-digital.com)

[+61 (0)2 8713 1400](tel:+61 (0)2 8713 1400)

### Americas Contacts

#### Get in touch with our team of experts in the Americas

We would be happy to hear from you!
Contact us to talk about company projects, to request a quotation or simply to say hello to our Automotive team in North and South America. We are happy to answer your questions!

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Johnnie Cocus

Key Account Relations Manager

[johnnie.cocus@infopro-digital.com](mailto:johnnie.cocus@infopro-digital.com)

[+1 (929) 475-6215](tel:+1 (929) 475-6215)

[LinkedIn contact](https://www.linkedin.com/in/johnnie-cocus-462a38100/)

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Jorge Chipantiza

New Sales & Account Management

[jorge.chipantiza@infopro-digital.com](mailto:jorge.chipantiza@infopro-digital.com)

[+1 (929) 475-5043](tel:+1 (929) 475-5043)

[LinkedIn contact](https://www.linkedin.com/in/jorge-chipantiza-273b7216a)

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Gilbreth Brown

Business Development Manager

[gilbreth.brown@infopro-digital.com](mailto:gilbreth.brown@infopro-digital.com)

[+1 (929) 475-5384](tel:+1 (929) 475-5384)

[LinkedIn contact](https://www.linkedin.com/in/gilbrethbrown/)

Glen Hinkle

Business Development Manager

[glen.hinkle@infopro-digital.com](mailto:glen.hinkle@infopro-digital.com)

[+1 (929) 553-1522](tel:+1 (929) 553-1522)

[LinkedIn contact](https://www.linkedin.com/in/glen-hinkle-95684a5a/)

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Ryan Galmish

Key Account & Development Manager - Haynes Consumer

[ryan.galmish@infopro-digital.com](mailto:ryan.galmish@infopro-digital.com)

[+1 (615) 516-6533](tel:+1 (615) 516-6533)

[LinkedIn contact](https://www.linkedin.com/in/ryan-galmish-95b50347/)

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Anthony Seadon

New Sales & Account Management - South America

[anthony.seadon@infopro-digital.com](mailto:anthony.seadon@infopro-digital.com)

[+55 11 96070 6205](tel:+55 11 96070 6205)

[LinkedIn contact](https://www.linkedin.com/in/anthony-r-l-s-27267738/)

### Infopro Digital Automotive Americas

##### Infopro Digital Automotive - Americas HQ

One Nashville Place,
150 4th Ave. North,
Nashville,
TS 37219

[sales@haynes.com](mailto:sales@haynes.com)

##### Eucon Americas LLC

1201 Peachtree Street NE, Suite 100
Atlanta, GA 30361
USA

[us.info@eucon.com](mailto:us.info@eucon.com)

[+1 404 906 9670](tel:+1 404 906 9670)

##### Eucon Canada Ltd.

130 King Street W Suite 1800
Toronto ON Canada M5X 1E3

[ca.info@eucon.com](mailto:ca.info@eucon.com)

[+1 647 802 7379](tel:+1 647 802 7379)

##### Eucon LATAM S. DE R.L. DE C.V.

Av. Presidente Mazarik 111
– 1st Floor
11560, Polanco. Ciudad de México

[mx.info@eucon.com](mailto:mx.info@eucon.com)

##### Haynes North America, Inc (B2C)

2801 Townsgate Rd Ste 340
Westlake Village, CA, 91361-5855
United States

### Asia Pacific Contact

#### Get in touch with our team of experts

We would be happy to hear from you!
Contact us to talk about company projects, to request a quotation or simply to say hello to our Asian Automotive team. We will be happy to answer you!

![Illustration of an avatar, visual representation for the contact page of Infopro Digital Automotive](https://www.infopro-digital-automotive.com/app/uploads/sites/3/2023/11/contact-kee-account-infopro-digital-2.png)

Muhammad Paracha

Key Account Manager

[muhammad.paracha@infopro-digital.com](mailto:muhammad.paracha@infopro-digital.com)

[LinkedIn contact](https://www.linkedin.com/in/muhammad-paracha-17302a18/)

### Infopro Digital Automotive Asia

##### Eucon China

Room 902-2, # 33, lane 1228
Jiang Chang Road
Jing An District, Shanghai, China

[cn.info@eucon.com](mailto:cn.info@eucon.com)

[+86 21 3387 0259](tel:+86 21 3387 0259)

##### Eucon Japan

2F, W Building
1-8-15
Konan Minato-ku
Tokyo 108-0075 Japan

[jp.info@eucon.com](mailto:jp.info@eucon.com)

[+81 90 7191 1021](tel:+81 90 7191 1021)

3656RE2119U2BT5L1APQ