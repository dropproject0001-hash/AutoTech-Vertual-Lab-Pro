Source: https://motordata.net/en_en/models/
Fetched: 2026-11-11

Font size

[Reduced font size](https://motordata.net/en_en/models/ "Reduced font size")

[Normal font size](https://motordata.net/en_en/models/ "Normal font size")

[ Increased font size](https://motordata.net/en_en/models/ " Increased font size")

Background and font color

[Black on white background](https://motordata.net/en_en/models/ "Black on white background")

[White over black background](https://motordata.net/en_en/models/ "White over black background")

[Blue on blue background](https://motordata.net/en_en/models/ "Blue on blue background")

[Black over yellow background](https://motordata.net/en_en/models/ "Black over yellow background")

[Green over black background](https://motordata.net/en_en/models/ "Green over black background")

Images

[Show images](https://motordata.net/en_en/models/ "Show images")

[Hide images](https://motordata.net/en_en/models/ "Hide images")

Text scoring

[Read the text](https://motordata.net/en_en/models/ "Read the text")

[Do not read the text](https://motordata.net/en_en/models/ "Do not read the text")

Regular version of the site

[![motordata EN](https://motordata.net/upload/CAllcorp3/8b7/iqa2gzf05ymozhaby9xnnvn3pxnd53fw.png)](https://motordata.net/en_en/)

Software and mobile applications

for automotive diagnostics

[Sign in](https://motordata.net/cab/en/account)

[Our Products](https://motordata.net/en_en/projects/)

- [MotorData Automotive Electrics Software Features](https://motordata.net/en_en/projects/features-motordata-autoelectrics/ "MotorData Automotive Electrics Software Features")

- [MotorData OBD2 mobile app](https://motordata.net/en_en/projects/motorData-OBD2-mobile-app/ "MotorData OBD2 mobile app")


[Tariffs](https://motordata.net/en_en/tariffs/)

- [MotorData Automotive Electrics Tariffs](https://motordata.net/en_en/tariffs/Autoelectrics/ "MotorData Automotive Electrics Tariffs")
  - [Demo Access to MotorData Automotive Electrics](https://motordata.net/en_en/tariffs/Autoelectrics/demo-access-to-motordata-automotive-electrics/ "Demo Access to MotorData Automotive Electrics")
  - [1 Week](https://motordata.net/en_en/tariffs/Autoelectrics/electrics-1-week/ "1 Week")
  - [1 Month](https://motordata.net/en_en/tariffs/Autoelectrics/1-month/ "1 Month")
  - [12 Months](https://motordata.net/en_en/tariffs/Autoelectrics/12-months/ "12 Months")
  - [3 Months](https://motordata.net/en_en/tariffs/Autoelectrics/3-months/ "3 Months")
  - [6 months](https://motordata.net/en_en/tariffs/Autoelectrics/6-months/ "6 months")

[Company](https://motordata.net/en_en/company/)

- [Company](https://motordata.net/en_en/company/index.php "Company")

- [Contacts & Requisites](https://motordata.net/en_en/company/requisites/ "Contacts & Requisites")


[News](https://motordata.net/en_en/news/)

[Information](https://motordata.net/en_en/info/)

- [Help and Support](https://motordata.net/en_en/info/help/ "Help and Support")

- [Quick Start Guide](https://motordata.net/en_en/info/quickstart/ "Quick Start Guide")

- [FAQ](https://motordata.net/en_en/info/faq/ "FAQ")

- [Articles](https://motordata.net/en_en/articles/ "Articles")

- [Integration with Scanners](https://motordata.net/en_en/info/integration/ "Integration with Scanners")

- [How to Obtain Access](https://motordata.net/en_en/info/purchase/ "How to Obtain Access")

- [Payment Methods](https://motordata.net/en_en/info/payments/ "Payment Methods")

- [User License Agreement](https://motordata.net/en_en/info/agreement/ "User License Agreement")

- [Privacy Policy](https://motordata.net/en_en/info/privacy-policy/ "Privacy Policy")

- [Model Catalog (MotorData Automotive Electrics)](https://motordata.net/en_en/models/ "Model Catalog (MotorData Automotive Electrics)")


[Articles](https://motordata.net/en_en/articles/)

[Open MotorData Automotive Electrics](https://motordata.net/client/)

en

[ru](https://motordata.net/) [fr](https://motordata.net/fr_fr/) [es](https://motordata.net/es_es/)

en

[![motordata EN](https://motordata.net/upload/CAllcorp3/8b7/iqa2gzf05ymozhaby9xnnvn3pxnd53fw.png)](https://motordata.net/en_en/)

[![motordata EN](https://motordata.net/upload/CAllcorp3/8b7/iqa2gzf05ymozhaby9xnnvn3pxnd53fw.png)](https://motordata.net/en_en/)

- [Our Products](https://motordata.net/en_en/projects/ "Our Products")


  - [Our Products](https://motordata.net/en_en/projects/)

  - [MotorData Automotive Electrics Software Features](https://motordata.net/en_en/projects/features-motordata-autoelectrics/ "MotorData Automotive Electrics Software Features")

  - [MotorData OBD2 mobile app](https://motordata.net/en_en/projects/motorData-OBD2-mobile-app/ "MotorData OBD2 mobile app")
- [Tariffs](https://motordata.net/en_en/tariffs/ "Tariffs")


  - [Tariffs](https://motordata.net/en_en/tariffs/)

  - [MotorData Automotive Electrics Tariffs](https://motordata.net/en_en/tariffs/Autoelectrics/ "MotorData Automotive Electrics Tariffs")


    - [MotorData Automotive Electrics Tariffs](https://motordata.net/en_en/tariffs/Autoelectrics/)

    - [Demo Access to MotorData Automotive Electrics](https://motordata.net/en_en/tariffs/Autoelectrics/demo-access-to-motordata-automotive-electrics/ "Demo Access to MotorData Automotive Electrics")

    - [1 Week](https://motordata.net/en_en/tariffs/Autoelectrics/electrics-1-week/ "1 Week")

    - [1 Month](https://motordata.net/en_en/tariffs/Autoelectrics/1-month/ "1 Month")

    - [12 Months](https://motordata.net/en_en/tariffs/Autoelectrics/12-months/ "12 Months")

    - [3 Months](https://motordata.net/en_en/tariffs/Autoelectrics/3-months/ "3 Months")

    - [6 months](https://motordata.net/en_en/tariffs/Autoelectrics/6-months/ "6 months")
- [Company](https://motordata.net/en_en/company/ "Company")


  - [Company](https://motordata.net/en_en/company/)

  - [Company](https://motordata.net/en_en/company/index.php "Company")

  - [Contacts & Requisites](https://motordata.net/en_en/company/requisites/ "Contacts & Requisites")
- [News](https://motordata.net/en_en/news/ "News")

- [Information](https://motordata.net/en_en/info/ "Information")


  - [Information](https://motordata.net/en_en/info/)

  - [Help and Support](https://motordata.net/en_en/info/help/ "Help and Support")

  - [Quick Start Guide](https://motordata.net/en_en/info/quickstart/ "Quick Start Guide")

  - [FAQ](https://motordata.net/en_en/info/faq/ "FAQ")

  - [Articles](https://motordata.net/en_en/articles/ "Articles")

  - [Integration with Scanners](https://motordata.net/en_en/info/integration/ "Integration with Scanners")

  - [How to Obtain Access](https://motordata.net/en_en/info/purchase/ "How to Obtain Access")

  - [Payment Methods](https://motordata.net/en_en/info/payments/ "Payment Methods")

  - [User License Agreement](https://motordata.net/en_en/info/agreement/ "User License Agreement")

  - [Privacy Policy](https://motordata.net/en_en/info/privacy-policy/ "Privacy Policy")

  - [Model Catalog (MotorData Automotive Electrics)](https://motordata.net/en_en/models/ "Model Catalog (MotorData Automotive Electrics)")
- [Articles](https://motordata.net/en_en/articles/ "Articles")

- [Open MotorData Automotive Electrics](https://motordata.net/client/ "Open MotorData Automotive Electrics")


[Sign in](https://motordata.net/cab/en/account)

- [en](https://motordata.net/en_en/models/ "en")




  - [Language](https://motordata.net/en_en/models/)

  - [en](https://motordata.net/en_en/ "en")

  - [ru](https://motordata.net/ "ru")

  - [fr](https://motordata.net/fr_fr/ "fr")

  - [es](https://motordata.net/es_es/ "es")

- [sales@motordata.net](mailto:sales@motordata.net)


# Model Catalog (Automotive Electrics)

The list below shows current data availability in MotorData. Information is structured by vehicle makes, models, on-board diagnostic systems and sections (data types, modules). We are constantly adding new information to the database. You can stay updated about the new content by subscribing to our mailing list or send us a message regarding availability of data on a particular model.

To view the detailed data coverage please click on the make or model of interest.

**Please note:** MotorData primary language is Russian and the content in other languages may appear in the database with some delay. In that case you will see a “Content is being translated” string. Please be sure that we are working on translation to provide the best service to all of our customers.

## Vehicle makes

[ACURAShow model coverage\\
\\
models: 10 systems: 24](https://motordata.net/en_en/models/acura/ "show model ranges \"ACURA\"") [ALFA ROMEOShow model coverage\\
\\
models: 10 systems: 1](https://motordata.net/en_en/models/alfa-romeo/ "show model ranges \"ALFA ROMEO\"") [AUDIShow model coverage\\
\\
models: 12 systems: 1](https://motordata.net/en_en/models/audi/ "show model ranges \"AUDI\"") [BMWShow model coverage\\
\\
models: 12 systems: 1](https://motordata.net/en_en/models/bmw/ "show model ranges \"BMW\"") [BYDShow model coverage\\
\\
models: 10 systems: 16](https://motordata.net/en_en/models/byd/ "show model ranges \"BYD\"") [CADILLACShow model coverage\\
\\
models: 8 systems: 1](https://motordata.net/en_en/models/cadillac/ "show model ranges \"CADILLAC\"") [CHANGANShow model coverage\\
\\
models: 13 systems: 11](https://motordata.net/en_en/models/changan/ "show model ranges \"CHANGAN\"") [CHERYShow model coverage\\
\\
models: 22 systems: 34](https://motordata.net/en_en/models/chery/ "show model ranges \"CHERY\"") [CHEVROLETShow model coverage\\
\\
models: 29 systems: 21](https://motordata.net/en_en/models/chevrolet/ "show model ranges \"CHEVROLET\"") [CITROENShow model coverage\\
\\
models: 10 systems: 18](https://motordata.net/en_en/models/citroen/ "show model ranges \"CITROEN\"") [CUMMINSShow model coverage\\
\\
models: 1 systems: 1](https://motordata.net/en_en/models/cummins/ "show model ranges \"CUMMINS\"") [DACIAShow model coverage\\
\\
models: 7 systems: 21](https://motordata.net/en_en/models/dacia/ "show model ranges \"DACIA\"") [DAEWOOShow model coverage\\
\\
models: 14 systems: 10](https://motordata.net/en_en/models/daewoo/ "show model ranges \"DAEWOO\"") [DAIHATSUShow model coverage\\
\\
models: 29 systems: 24](https://motordata.net/en_en/models/daihatsu/ "show model ranges \"DAIHATSU\"") [DATSUNShow model coverage\\
\\
models: 3 systems: 2](https://motordata.net/en_en/models/datsun/ "show model ranges \"DATSUN\"") [DODGEShow model coverage\\
\\
models: 8 systems: 1](https://motordata.net/en_en/models/dodge/ "show model ranges \"DODGE\"") [DONGFENGShow model coverage\\
\\
models: 5 systems: 1](https://motordata.net/en_en/models/dongfeng/ "show model ranges \"DONGFENG\"") [EXEEDShow model coverage\\
\\
models: 4 systems: 10](https://motordata.net/en_en/models/exeed/ "show model ranges \"EXEED\"") [FAWShow model coverage\\
\\
models: 3 systems: 1](https://motordata.net/en_en/models/faw/ "show model ranges \"FAW\"") [FIATShow model coverage\\
\\
models: 6 systems: 1](https://motordata.net/en_en/models/fiat/ "show model ranges \"FIAT\"") [FORDShow model coverage\\
\\
models: 32 systems: 9](https://motordata.net/en_en/models/ford/ "show model ranges \"FORD\"") [FOTONShow model coverage\\
\\
models: 1 systems: 1](https://motordata.net/en_en/models/foton/ "show model ranges \"FOTON\"") [GACShow model coverage\\
\\
models: 1 systems: 1](https://motordata.net/en_en/models/gac/ "show model ranges \"GAC\"") [GAZShow model coverage\\
\\
models: 9 systems: 14](https://motordata.net/en_en/models/gaz/ "show model ranges \"GAZ\"") [GEELYShow model coverage\\
\\
models: 10 systems: 27](https://motordata.net/en_en/models/geely/ "show model ranges \"GEELY\"") [GENESISShow model coverage\\
\\
models: 5 systems: 1](https://motordata.net/en_en/models/genesis/ "show model ranges \"GENESIS\"") [GREAT WALLShow model coverage\\
\\
models: 18 systems: 32](https://motordata.net/en_en/models/great-wall/ "show model ranges \"GREAT WALL\"") [HAVALShow model coverage\\
\\
models: 15 systems: 28](https://motordata.net/en_en/models/haval/ "show model ranges \"HAVAL\"") [HINOShow model coverage\\
\\
models: 9 systems: 5](https://motordata.net/en_en/models/hino/ "show model ranges \"HINO\"") [HONDAShow model coverage\\
\\
models: 79 systems: 44](https://motordata.net/en_en/models/honda/ "show model ranges \"HONDA\"") [HUMMERShow model coverage\\
\\
models: 2 systems: 1](https://motordata.net/en_en/models/hummer/ "show model ranges \"HUMMER\"") [HYUNDAIShow model coverage\\
\\
models: 60 systems: 39](https://motordata.net/en_en/models/hyundai/ "show model ranges \"HYUNDAI\"") [INFINITIShow model coverage\\
\\
models: 11 systems: 22](https://motordata.net/en_en/models/infiniti/ "show model ranges \"INFINITI\"") [IRAN KHODROShow model coverage\\
\\
models: 3 systems: 1](https://motordata.net/en_en/models/iran-khodro/ "show model ranges \"IRAN KHODRO\"") [ISUZUShow model coverage\\
\\
models: 25 systems: 20](https://motordata.net/en_en/models/isuzu/ "show model ranges \"ISUZU\"") [IVECOShow model coverage\\
\\
models: 1 systems: 1](https://motordata.net/en_en/models/iveco/ "show model ranges \"IVECO\"") [JACShow model coverage\\
\\
models: 5 systems: 27](https://motordata.net/en_en/models/jac/ "show model ranges \"JAC\"") [JAECOOShow model coverage\\
\\
models: 1 systems: 7](https://motordata.net/en_en/models/jaecoo/ "show model ranges \"JAECOO\"") [JCBShow model coverage\\
\\
models: 1 systems: 14](https://motordata.net/en_en/models/jcb/ "show model ranges \"JCB\"") [JETOURShow model coverage\\
\\
models: 1 systems: 6](https://motordata.net/en_en/models/jetour/ "show model ranges \"JETOUR\"") [KIAShow model coverage\\
\\
models: 45 systems: 38](https://motordata.net/en_en/models/kia/ "show model ranges \"KIA\"") [LADAShow model coverage\\
\\
models: 28 systems: 28](https://motordata.net/en_en/models/lada/ "show model ranges \"LADA\"") [LEXUSShow model coverage\\
\\
models: 12 systems: 43](https://motordata.net/en_en/models/lexus/ "show model ranges \"LEXUS\"") [LIFANShow model coverage\\
\\
models: 13 systems: 28](https://motordata.net/en_en/models/lifan/ "show model ranges \"LIFAN\"") [MAHINDRAShow model coverage\\
\\
models: 3 systems: 1](https://motordata.net/en_en/models/mahindra/ "show model ranges \"MAHINDRA\"") [MARUTI SUZUKIShow model coverage\\
\\
models: 15 systems: 1](https://motordata.net/en_en/models/maruti-suzuki/ "show model ranges \"MARUTI SUZUKI\"") [MAZShow model coverage\\
\\
models: 1 systems: 1](https://motordata.net/en_en/models/maz/ "show model ranges \"MAZ\"") [MAZDAShow model coverage\\
\\
models: 73 systems: 39](https://motordata.net/en_en/models/mazda/ "show model ranges \"MAZDA\"") [MERCEDES-BENZShow model coverage\\
\\
models: 11 systems: 1](https://motordata.net/en_en/models/mercedes-benz/ "show model ranges \"MERCEDES-BENZ\"") [MINIShow model coverage\\
\\
models: 8 systems: 1](https://motordata.net/en_en/models/mini/ "show model ranges \"MINI\"") [MITSUBISHIShow model coverage\\
\\
models: 77 systems: 46](https://motordata.net/en_en/models/mitsubishi/ "show model ranges \"MITSUBISHI\"") [MITSUBISHI FUSOShow model coverage\\
\\
models: 7 systems: 17](https://motordata.net/en_en/models/mitsubishi-fuso/ "show model ranges \"MITSUBISHI FUSO\"") [MOSKVICHShow model coverage\\
\\
models: 1 systems: 22](https://motordata.net/en_en/models/moskvich/ "show model ranges \"MOSKVICH\"") [MTZShow model coverage\\
\\
models: 1 systems: 1](https://motordata.net/en_en/models/mtz/ "show model ranges \"MTZ\"") [NISSANShow model coverage\\
\\
models: 88 systems: 40](https://motordata.net/en_en/models/nissan/ "show model ranges \"NISSAN\"") [NISSAN DIESELShow model coverage\\
\\
models: 8 systems: 1](https://motordata.net/en_en/models/nissan-diesel/ "show model ranges \"NISSAN DIESEL\"") [OMODAShow model coverage\\
\\
models: 3 systems: 8](https://motordata.net/en_en/models/omoda/ "show model ranges \"OMODA\"") [OPELShow model coverage\\
\\
models: 12 systems: 1](https://motordata.net/en_en/models/opel/ "show model ranges \"OPEL\"") [PAZShow model coverage\\
\\
models: 2 systems: 3](https://motordata.net/en_en/models/paz/ "show model ranges \"PAZ\"") [PERODUAShow model coverage\\
\\
models: 5 systems: 1](https://motordata.net/en_en/models/perodua/ "show model ranges \"PERODUA\"") [PEUGEOTShow model coverage\\
\\
models: 15 systems: 23](https://motordata.net/en_en/models/peugeot/ "show model ranges \"PEUGEOT\"") [PONTIACShow model coverage\\
\\
models: 1 systems: 1](https://motordata.net/en_en/models/pontiac/ "show model ranges \"PONTIAC\"") [RAMShow model coverage\\
\\
models: 7 systems: 1](https://motordata.net/en_en/models/ram/ "show model ranges \"RAM\"") [RAVONShow model coverage\\
\\
models: 4 systems: 1](https://motordata.net/en_en/models/ravon/ "show model ranges \"RAVON\"") [RENAULTShow model coverage\\
\\
models: 17 systems: 29](https://motordata.net/en_en/models/renault/ "show model ranges \"RENAULT\"") [SAMSUNGShow model coverage\\
\\
models: 4 systems: 1](https://motordata.net/en_en/models/samsung/ "show model ranges \"SAMSUNG\"") [SCIONShow model coverage\\
\\
models: 3 systems: 7](https://motordata.net/en_en/models/scion/ "show model ranges \"SCION\"") [SHAANXIShow model coverage\\
\\
models: 2 systems: 2](https://motordata.net/en_en/models/shaanxi/ "show model ranges \"SHAANXI\"") [SSANGYONGShow model coverage\\
\\
models: 11 systems: 36](https://motordata.net/en_en/models/ssangyong/ "show model ranges \"SSANGYONG\"") [SUBARUShow model coverage\\
\\
models: 16 systems: 36](https://motordata.net/en_en/models/subaru/ "show model ranges \"SUBARU\"") [SUZUKIShow model coverage\\
\\
models: 34 systems: 28](https://motordata.net/en_en/models/suzuki/ "show model ranges \"SUZUKI\"") [TAGAZShow model coverage\\
\\
models: 3 systems: 1](https://motordata.net/en_en/models/tagaz/ "show model ranges \"TAGAZ\"") [TANKShow model coverage\\
\\
models: 2 systems: 6](https://motordata.net/en_en/models/tank/ "show model ranges \"TANK\"") [TATAShow model coverage\\
\\
models: 3 systems: 1](https://motordata.net/en_en/models/tata/ "show model ranges \"TATA\"") [TOYOTAShow model coverage\\
\\
models: 205 systems: 58](https://motordata.net/en_en/models/toyota/ "show model ranges \"TOYOTA\"") [UAZShow model coverage\\
\\
models: 4 systems: 4](https://motordata.net/en_en/models/uaz/ "show model ranges \"UAZ\"") [VOLKSWAGENShow model coverage\\
\\
models: 11 systems: 20](https://motordata.net/en_en/models/volkswagen/ "show model ranges \"VOLKSWAGEN\"") [VOLVOShow model coverage\\
\\
models: 10 systems: 1](https://motordata.net/en_en/models/volvo/ "show model ranges \"VOLVO\"") [WEICHAIShow model coverage\\
\\
models: 1 systems: 2](https://motordata.net/en_en/models/weichai/ "show model ranges \"WEICHAI\"") [YaMZShow model coverage\\
\\
models: 2 systems: 1](https://motordata.net/en_en/models/yamz/ "show model ranges \"YaMZ\"")

[Homepage](https://motordata.net/en_en/ "Homepage") [Software](https://motordata.net/en_en/projects/ "Software") [Prices](https://motordata.net/en_en/tariffs/ "Prices") [News](https://motordata.net/en_en/news/ "News") [Company](https://motordata.net/en_en/company/index.php "Company") [Help](https://motordata.net/en_en/info/help/ "Help")