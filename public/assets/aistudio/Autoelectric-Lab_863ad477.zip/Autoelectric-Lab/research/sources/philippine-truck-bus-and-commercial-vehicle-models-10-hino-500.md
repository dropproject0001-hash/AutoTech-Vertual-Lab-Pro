Source: https://www.hino.com.ph/500-series
Title: Hino Motors Philippines
Fetched: 2026-11-11T12:56:05.626Z

![](https://www.hino.com.ph/assets/images/PerProduct/500/Img/500SeriesFrontBanner.jpg)

Businesses are constantly on the move 24 hours a day, 7 days a week.
The Hino 500 Series aims for the highest operational uptime in the field,
which means you can carry out tasks more efficiently than ever.
The Hino 500 Series is your trusted partner for the years to come.


## DRIVING PERFORMANCE

Talking about durability, reliability, and optimal driving performance, it has to be the Hino 500 Series! This line is designed to get the job done even under the harshest operating conditions.


Equipped with Variable Nozzle Turbo Charger (VNT), the Hino 500 Series guarantees optimal torque and power without engine strain. Acceleration is also improved, including an overall cleaner combustion.


The exterior of the Hino 500 Series has also been redesigned for a bolder and more commanding appearance with enhanced aerodynamics.


![](https://www.hino.com.ph/assets/images/PerProduct/500/Img/500SeriesHigh_Level_of_Driving_Performance.jpg)

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Copy%20of%20Reliable%20and%20Powerful%20Engine.png)Reliable andFuel-efficient Engine

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Copy%20of%20Copy%20of%20Max%20Output%20Icon_No%20Text.png)215 PS - 360 PS Max. Output(ISO Net)

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Copy%20of%20Copy%20of%20Max%20Torque_No%20Text.png)637Nm - 1,422NmMax. Torque (ISO Net)

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Copy%20of%20Aero%20dynamic.png)AerodynamicDesign

## DURABILITY AND RELIABILITY

The Hino 500 Series’ robust chassis allows for smooth and confident cargo transport. Designed for stability, the Hino 500 Series’ tapered leaf suspension is effective for driving at optimum loading even on the most unforgiving terrain. Its larger spring design also enhances durability.


![](https://www.hino.com.ph/assets/images/PerProduct/500/Img/500SeriesDurability_and_Reliability.jpg)

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Copy%20of%20Robust%20Chassis.png)Robust Chassis

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Copy%20of%20Heavy%20Duty%20Suspension.png)Heavy-duty SuspensionComponents

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Copy%20of%20Full%20Air%20Brake%20System.png)Full-air BrakeSystem

## EASE OF OPERATION

The concept keyword for the driver’s space is “Roundish and Flat Space Interior.”
The top edge of the instrument panel is designed low to keep good front visibility.
Switches used while driving are all laid out for easy viewing and operation.


A semi-float (rubber type) construction was adopted for the cab mount and mounting
bushes were added. Road vibrations are reduced, providing better ride comfort and reducing cabin noise.


The 1927 Auto model also features a fully automatic transmission, for effortless operability. Helping drivers run longer miles safely, with much less physical fatigue.


![](https://www.hino.com.ph/assets/images/PerProduct/500/Img/500SeriesEase_of_Operation.jpg)

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Copy%20of%20Automatic%20Transmission.png)AutomaticTransmission\*1927 Auto model

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Copy%20of%20Power%20Door%20and%20Windor_No%20Text.png)Power Doorand Window \*1021\. 1625. and 2629 6x2 models

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Copy%20of%20Improved%20meter%20cluster.png)LargeInstrument Panel

## SAFETY

The Hino 500 Series continues to raise the bar when it comes to safety.
Headlights are thoughtfully positioned to achieve a larger and brighter
coverage for night-driving. Visibility is further optimized not only with
its large wing mirrors, but also the greater downward view of its wide windscreen.


The Anti-Lock Brake System (ABS) gives drivers greater peace of mind especially on wet
driving conditions. On the other hand, the adoption of the full-air brake system
on select models enhances braking response and performance.


![](https://www.hino.com.ph/assets/images/PerProduct/500/Img/500SeriesSafety.jpg)

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Copy%20of%20ABS_No%20Text.png)Anti-lock BrakeSystem

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Copy%20of%20Copy%20of%20Improved%20headlights.png)ImprovedHeadlight Designfor Better Visibility when Driving at Night

![](https://www.hino.com.ph/assets/images/PerProduct/500/Icons/Side%20door%20Beam.png)SideDoor Beamfor Better Impact Protection

## HINO 500 SERIES SPECIFICATIONS

| RANGE | MODEL | AXLES | GVW | Ps \|Nm | WHEELBASE | TRANS | SPECS | INQUIRE |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| HINO 500 Series | 1021 | 4 x 2 (6W) | 10,400 | 210 \| 637 | 4,990 | 6-Speed M/T with Overdrive | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/500%20Series/01%20Hino%20500%201021%20(FC9JL7A)%20Brochure.pdf) |  |
| 1625 | 16,000 | 240 \| 716 | 4,330 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/500%20Series/02%20Hino%20500%201625%20(FG8JJ7A)%20and%201625%20Long%20(FG8JP7A)%20Brochure.pdf) |  |
| 1625 Long | 5,530 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/500%20Series/1625LongBrochure.pdf) |  |
| 1927 Auto | 18,200 | 260 \| 794 | 5,080 | 6-Speed A/T with Overdrive | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/500%20Series/03%20Hino%20500%201927%20Auto%20(GH8JM7A)%20Brochure.pdf) |  |
| 2629 6x2 | 6 x 2 (10W) | 26,000 | 280 \| 824 | 6,130 + 1,350 | 9-Speed M/T with Direct - Drive | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/500%20Series/26296x2Brochure.pdf) |  |
| 2629 6x4 | 6 x 4 (10W) | 28,000 | 4,630 + 1,350 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/500%20Series/05%20Hino%20500%202629%206x4%20(FM8JR7A)%20Brochure.pdf) |  |
| 2836 | 350 \| 1,422 | 4,530 + 1,350 | 9-Speed M/T with Overdrive | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/500%20Series/06%20Hino%20500%202836%20(FM1AR7A)%20Brochure.pdf) |  |
| 2836 Long | 4,530 + 1,350 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/500%20Series/06%20Hino%20500%202836%20(FM1AR7A)%20Brochure.pdf) |  |
| 2836 Dump | 3,480 + 1,350 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/500%20Series/07%20Hino%20500%202836%20Dump%20(FM1AL7D)%20Brochure.pdf) |  |

| #### TRACTOR HEADS |
| --- |
| Range | Model | AXLES | GCM | Ps \|Nm | WHEELBASE | TRANS | SPECS | INQUIRE |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 500 Series | 2836 Tractor | 6x4 (10W) | 50,500 | 360 \| 1,463 | 3,480 + 1,350 | 9-Speed M/T with Direct - Drive | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/500%20Series/2836TractorBrochure.pdf) |  |
| 1735 Tractor | 4x2 (6W) | 32,000 | 3,630 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/500%20Series/1735TractorBrochure.pdf) |  |

## Get in touch with our teamteam

[![](https://www.hino.com.ph/assets/images/Icon/Telephone.png)\\
\\
Call (+63)2-7368-5800](tel:(+63)2-7368-5800)

[![](https://www.hino.com.ph/assets/images/Icon/Location.png)\\
\\
Find a dealer](https://www.hino.com.ph/FindaDealer.aspx)

Disclaimers:

_†Active safety systems are an aid to assist the driver and have performance limitations. Please refer to owner’s manual for system operations and functionality._

_#Refer to specification sheet for specific wheelbase._