Source: https://www.hino.com.ph/300-series
Title: Hino Motors Philippines
Fetched: 2026-11-11T12:55:56.608Z

![](https://www.hino.com.ph/assets/images/PerProduct/300/Img/300SeriesFrontBanner.jpg)

Ready for new businesses opportunities!


Don’t compromise on quality and functionality when you can have it both. Durable yet user-friendly,
economical yet reliable, the Hino 300 Series carries your businesses to new heights.


Compact in size but big in reliability, the Hino 300 Series is the ideal partner in driving your businesses forward.


## PERFORMANCE

Equipped with the powerful yet economical Hino N04C engine range,
the Hino 300 Series’ performance is maximized at every turn, making
it a trusted business partner. It does not only meet the Euro 4 emission
standards, but also deliver an ideal combination of power and efficiency.


![](https://www.hino.com.ph/assets/images/PerProduct/300/Img/300SeriesPowerfullEngine.jpg)

![](https://www.hino.com.ph/assets/images/PerProduct/300/Icons/Piston%20Icon_No%20Text.png)4.009 LEngine Displacement

![](https://www.hino.com.ph/assets/images/PerProduct/300/Icons/Max%20Output%20Icon_No%20Text.png)136 PS - 150 PSMax. Output (ISO Net)

![](https://www.hino.com.ph/assets/images/PerProduct/300/Icons/Max%20Torque_No%20Text.png)390 Nm - 420 NmMax. Torque (ISO Net)

## COMFORT

Intuitively designed, roomy, and comfortable, the cab space of the Hino
300 Series gives drivers what they need to perform at their best.


Loaded with features to make every drive enjoyable, select models under
this truck range are equipped with true automatic transmission, power door
and window, cab air-conditioning, improved meter cluster, various storage
spaces, and many other amenities that make driving easier.


![](https://www.hino.com.ph/assets/images/PerProduct/300/Img/300SeriesComfort.jpg)

![](https://www.hino.com.ph/assets/images/PerProduct/300/Icons/Automatic%20Transmission.png)AutomaticTransmission\*514 Auto model

![](https://www.hino.com.ph/assets/images/PerProduct/300/Icons/Power%20Door%20and%20Windor_No%20Text.png)Power Doorand Window

![](https://www.hino.com.ph/assets/images/PerProduct/300/Icons/Improved%20meter%20cluster.png)ImprovedMeter Cluster

## SAFETY

Safety is always a priority at Hino. With a comprehensive
suite of complementing passive and active safety systems,
the Hino 300 Series features an enhanced braking performance
with Anti-lock Brake System (ABS) and SRS Airbag for added
protection of drivers.


![](https://www.hino.com.ph/assets/images/PerProduct/300/Img/300SeriesSafety.jpg)

![](https://www.hino.com.ph/assets/images/PerProduct/300/Icons/ABS_No%20Text.png)Anti-lock BrakeSystem (ABS)\\* 514 Auto, 514, and 916 models

![](https://www.hino.com.ph/assets/images/PerProduct/300/Icons/SRS%20Bag_No%20Text.png)SRSAIRBAG\\* 514 Auto, 514 models

## STYLISH AND FUNCTIONAL

The aerodynamic design of the Hino 300 Series’ cab contributes to fuel
economy, while the tilt cabin enhances efficiency and reduces downtime by
allowing convenient access to maintenance and routine inspections.


The Hino 300 Series also features an elegant chrome front grille.
The 616 model is equipped with LED headlights and fog lights for
additional safety and visibility when driving at night and when raining.


![](https://www.hino.com.ph/assets/images/PerProduct/300/Img/300SeriesStylish.jpg)

## HINO 300 SERIES SPECIFICATIONS

| RANGE | MODEL | Drive<br>System | GVW | Power \|Torque | WHEELBASE | TRANSMISSION | PDF File | INQUIRE |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| HINO 300 Series | 414i | 4 x 2 (4W) | 4,490 | 136 \| 390 | 2,545 | 5-Speed M/T with Over Drive | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/300%20Series/01%20Hino%20300%20414i%20(XZU309LN)%20Brochure.pdf) |  |
| 414i Long | 3,405 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/300%20Series/02%20Hino%20300%20414i%20Long%20(XZU349LN),%20414i%206W%20(XZU349LM)%20and%20814i%20(XZU349LH)%20Brochure.pdf) |  |
| 414i 6W | 4 x 2 (6W) | 3,380 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/300%20Series/02%20Hino%20300%20414i%20Long%20(XZU349LN),%20414i%206W%20(XZU349LM)%20and%20814i%20(XZU349LH)%20Brochure.pdf) |  |
| 814i | 7,500 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/300%20Series/02%20Hino%20300%20414i%20Long%20(XZU349LN),%20414i%206W%20(XZU349LM)%20and%20814i%20(XZU349LH)%20Brochure.pdf) |  |
| 814i Extra Long | 4,000 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/300%20Series/03%20Hino%20300%20814i%20Extra%20Long%20(XZU359LE)%20Brochure.pdf) |  |
| 514 Auto | 4 x 2 (4W) | 4,490 | 136 \| 390 | 2,525 | 6-Speed A/T with Over Drive | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/300%20Series/04%20Hino%20300%20514%20Auto%20(XZU600LA)%20and%20514%20(XZU600LM)%20Brochure.pdf) |  |
| 514 | 5-Speed M/T with Over Drive | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/300%20Series/04%20Hino%20300%20514%20Auto%20(XZU600LA)%20and%20514%20(XZU600LM)%20Brochure.pdf) |  |
| 616 | 4 x 2 (6W) | 150 \| 420 | 3,430 | 6-Speed M/T with Over Drive | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/300%20Series/05%20Hino%20300%20616%20(XZU710LN)%20and%20716%20(XZU710LT)%20Brochure.pdf) |  |
| 716 | 6,500 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/300%20Series/05%20Hino%20300%20616%20(XZU710LN)%20and%20716%20(XZU710LT)%20Brochure.pdf) |  |
| 716 Double | 3,870 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/300%20Series/06%20Hino%20300%20716%20Double%20(XZU720LD)%20Brochure.pdf) |  |
| 916 | 8,500 | 4,200 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/300%20Series/07%20Hino%20300%20916%20(XZU730LN)%20Brochure.pdf) |  |

## Get in touch with our team

[![](https://www.hino.com.ph/assets/images/Icon/Telephone.png)\\
\\
Call (+63)2-7368-5800](tel:(+63)2-7368-5800)

[![](https://www.hino.com.ph/assets/images/Icon/Location.png)\\
\\
Find a dealer](https://www.hino.com.ph/FindaDealer.aspx)

Disclaimers:

_†Active safety systems are an aid to assist the driver and have performance limitations. Please refer to owner’s manual for system operations and functionality._

_#Refer to specification sheet for specific wheelbase._