Source: https://www.hino.com.ph/corporate-information
Title: Hino Motors Philippines
Fetched: 2026-11-11T12:54:37.696Z

![](https://www.hino.com.ph/assets/images/banner/Hino_Corporate_Information.jpg)

Established in March 1975, HINO MOTORS PHILIPPINES CORPORATION (HMP), formerly Pilipinas Hino, Inc.,
is a joint-venture among Filipino investors, Hino Motors, Ltd. and Marubeni Corp. of Japan. Originally
majority-owned by the local partner, HMP has been relaunched under the new majority ownership of Hino Motors, Ltd.


A participant in the Commercial Vehicle Development Program (CVDP), HMP is engaged in the assembly and distribution
of quality HINO trucks, buses and spare parts.

Aside from manufacturing vehicles and bodies, HMP also distributesgenuine Hino parts and accessories and provides long-term
maintenance services to its clients. It is also the only company which offers customization thus becoming a “one-stop shop” –
from chassis assembly to building the body based on the desired specification of the client and further to vehicle maintenance, repair and refurbishing.

The company currently has over 20 Dealers in several locations around Metro Manila, as well as in most key provincial cities. Now on its 45th year,
HMP recognizes the challenges of increasing competition that comes with new trade policies on both local and global level.


Hino Motors Philippines Corporation is the first bus body manufacturer in the country to receive ISO 9001:2000 Certification,
a distinction that serves as a proof of unmatched product quality. It’s leadership in the industry can be attributed to the
durability and cost-effectiveness of Hino products and this is reflected in its tag line “Hino - Global brand, lifetime value.”


To make the world a better place to live by helping people and goods get where they need to go safety, economically and with environmental responsibility - while focusing on sustainable development.


![](https://www.hino.com.ph/assets/images/Icon/Integrity.png)

We are committed to acting with integrity and in a compliant manager.Compliance is the basis of all corporate activities.

We must act with integrity to meet the expectations of our customers and society.

![](https://www.hino.com.ph/assets/images/Icon/Contribution.png)

We support a future society by committing to safety and environmental sustainability.By providing safe and environmentally friendly products and services,

we work to solve social issues and challenges for a better future.We support the businesses of our customers by committing to quality and professionalism.In order to contribute to our customers 'business'

we humbly listen to them, continue to kaizen and challenge ourselves, and pursue high quality.

![](https://www.hino.com.ph/assets/images/Icon/Empathy.png)

We respect divesity and inclusion, and build a safe working environment.We respect divesity, recognize the uniqueness of every individual, and stand by each other.

we create an open workplace where we collaborate, learn, and cooperate with colleagues.