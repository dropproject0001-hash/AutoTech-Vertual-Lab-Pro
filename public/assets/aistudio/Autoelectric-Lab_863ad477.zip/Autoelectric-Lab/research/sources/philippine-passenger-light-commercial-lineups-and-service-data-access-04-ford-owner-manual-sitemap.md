Source: https://www.ford.com.ph/support/owner-manuals/owner-manuals-sitemap
Title: Ford Vehicle Owner Manuals Sitemap
Fetched: 2026-11-11T12:55:02.783Z

The website uses cookies to enable it to perform properly, remember your browsing history and to arrange content to match your preferred interests more quickly. Details of the cookies Ford use and instructions on how to disable them can be found in the Privacy Policy & Disclaimer Page . By clicking the Accept button, you agree to our use of cookies.

AcceptReject

# Owner Manual Sitemap

## Owner Manuals, Warranties, and Other Information

Listed below are all available vehicles to select from. Choose your Model Year and then select the specific vehicle's whose Owner Manual information you're interested in seeing.

[Owner Manual](https://www.ford.com.ph/support/owner-manuals/)

By ModelBy Year

By Year

Bantam

Year List

Details

[2009](https://www.ford.com.ph/support/vehicle/bantam/2009/owner-manuals/)

[2008](https://www.ford.com.ph/support/vehicle/bantam/2008/owner-manuals/)

[2007](https://www.ford.com.ph/support/vehicle/bantam/2007/owner-manuals/)

Bronco

Year List

Details

[2026](https://www.ford.com.ph/support/vehicle/bronco/2026/owner-manuals/)

[2025](https://www.ford.com.ph/support/vehicle/bronco/2025/owner-manuals/)

E-150

Year List

Details

[2013](https://www.ford.com.ph/support/vehicle/e-150/2013/owner-manuals/)

[2012](https://www.ford.com.ph/support/vehicle/e-150/2012/owner-manuals/)

[2011](https://www.ford.com.ph/support/vehicle/e-150/2011/owner-manuals/)

[2010](https://www.ford.com.ph/support/vehicle/e-150/2010/owner-manuals/)

EcoSport

Year List

Details

[2020](https://www.ford.com.ph/support/vehicle/ecosport/2020/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/ecosport/2017/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/ecosport/2016/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/ecosport/2016/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/ecosport/2015/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/ecosport/2015/owner-manuals/)

[2014](https://www.ford.com.ph/support/vehicle/ecosport/2014/owner-manuals/)

[2014](https://www.ford.com.ph/support/vehicle/ecosport/2014/owner-manuals/)

[2013](https://www.ford.com.ph/support/vehicle/ecosport/2013/owner-manuals/)

EcoSport - BW

Year List

Details

[2021](https://www.ford.com.ph/support/vehicle/ecosport-bw/2021/owner-manuals/)

[2020](https://www.ford.com.ph/support/vehicle/ecosport-bw/2020/owner-manuals/)

EcoSport - BX

Year List

Details

[2019](https://www.ford.com.ph/support/vehicle/ecosport-bx/2019/owner-manuals/)

[2018](https://www.ford.com.ph/support/vehicle/ecosport-bx/2018/owner-manuals/)

EcoSport - R6

Year List

Details

[2023](https://www.ford.com.ph/support/vehicle/ecosport-r6/2023/owner-manuals/)

[2022](https://www.ford.com.ph/support/vehicle/ecosport-r6/2022/owner-manuals/)

[2021](https://www.ford.com.ph/support/vehicle/ecosport-r6/2021/owner-manuals/)

EcoSport (India)

Year List

Details

[2019](https://www.ford.com.ph/support/vehicle/ecosport-india/2019/owner-manuals/)

[2018](https://www.ford.com.ph/support/vehicle/ecosport-india/2018/owner-manuals/)

EcoSport (Romania)

Year List

Details

[2018](https://www.ford.com.ph/support/vehicle/ecosport-romania/2018/owner-manuals/)

Escape

Year List

Details

[2019](https://www.ford.com.ph/support/vehicle/escape/2019/owner-manuals/)

[2018](https://www.ford.com.ph/support/vehicle/escape/2018/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/escape/2017/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/escape/2015/owner-manuals/)

[2012](https://www.ford.com.ph/support/vehicle/escape/2012/owner-manuals/)

[2011](https://www.ford.com.ph/support/vehicle/escape/2011/owner-manuals/)

[2010](https://www.ford.com.ph/support/vehicle/escape/2010/owner-manuals/)

Escape - TC

Year List

Details

[2026](https://www.ford.com.ph/support/vehicle/escape-tc/2026/owner-manuals/)

[2025](https://www.ford.com.ph/support/vehicle/escape-tc/2025/owner-manuals/)

Everest

Year List

Details

[2026](https://www.ford.com.ph/support/vehicle/everest/2026/owner-manuals/)

[2025](https://www.ford.com.ph/support/vehicle/everest/2025/owner-manuals/)

[2024](https://www.ford.com.ph/support/vehicle/everest/2024/owner-manuals/)

[2021](https://www.ford.com.ph/support/vehicle/everest/2021/owner-manuals/)

[2021](https://www.ford.com.ph/support/vehicle/everest/2021/owner-manuals/)

[2020](https://www.ford.com.ph/support/vehicle/everest/2020/owner-manuals/)

[2020](https://www.ford.com.ph/support/vehicle/everest/2020/owner-manuals/)

[2019](https://www.ford.com.ph/support/vehicle/everest/2019/owner-manuals/)

[2019](https://www.ford.com.ph/support/vehicle/everest/2019/owner-manuals/)

[2018](https://www.ford.com.ph/support/vehicle/everest/2018/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/everest/2017/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/everest/2017/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/everest/2015/owner-manuals/)

[2011](https://www.ford.com.ph/support/vehicle/everest/2011/owner-manuals/)

[2010](https://www.ford.com.ph/support/vehicle/everest/2010/owner-manuals/)

[2009](https://www.ford.com.ph/support/vehicle/everest/2009/owner-manuals/)

[2007](https://www.ford.com.ph/support/vehicle/everest/2007/owner-manuals/)

Everest - EC

Year List

Details

[2022](https://www.ford.com.ph/support/vehicle/everest-ec/2022/owner-manuals/)

Everest - ED

Year List

Details

[2022](https://www.ford.com.ph/support/vehicle/everest-ed/2022/owner-manuals/)

Everest

Year List

Details

[2023](https://www.ford.com.ph/support/vehicle/everest-ek/2023/owner-manuals/)

[2022](https://www.ford.com.ph/support/vehicle/everest-ek/2022/owner-manuals/)

Everest (S. Africa)

Year List

Details

[2018](https://www.ford.com.ph/support/vehicle/everest-s-africa/2018/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/everest-s-africa/2016/owner-manuals/)

Everest

Year List

Details

[2016](https://www.ford.com.ph/support/vehicle/everest-thailand/2016/owner-manuals/)

Expedition

Year List

Details

[2026](https://www.ford.com.ph/support/vehicle/expedition/2026/owner-manuals/)

[2025](https://www.ford.com.ph/support/vehicle/expedition/2025/owner-manuals/)

[2018](https://www.ford.com.ph/support/vehicle/expedition/2018/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/expedition/2017/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/expedition/2016/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/expedition/2015/owner-manuals/)

[2014](https://www.ford.com.ph/support/vehicle/expedition/2014/owner-manuals/)

[2013](https://www.ford.com.ph/support/vehicle/expedition/2013/owner-manuals/)

[2012](https://www.ford.com.ph/support/vehicle/expedition/2012/owner-manuals/)

[2011](https://www.ford.com.ph/support/vehicle/expedition/2011/owner-manuals/)

[2010](https://www.ford.com.ph/support/vehicle/expedition/2010/owner-manuals/)

Explorer

Year List

Details

[2027](https://www.ford.com.ph/support/vehicle/explorer/2027/owner-manuals/)

[2026](https://www.ford.com.ph/support/vehicle/explorer/2026/owner-manuals/)

[2025](https://www.ford.com.ph/support/vehicle/explorer/2025/owner-manuals/)

[2024](https://www.ford.com.ph/support/vehicle/explorer/2024/owner-manuals/)

[2023](https://www.ford.com.ph/support/vehicle/explorer/2023/owner-manuals/)

[2022](https://www.ford.com.ph/support/vehicle/explorer/2022/owner-manuals/)

[2021](https://www.ford.com.ph/support/vehicle/explorer/2021/owner-manuals/)

[2020](https://www.ford.com.ph/support/vehicle/explorer/2020/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/explorer/2017/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/explorer/2016/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/explorer/2015/owner-manuals/)

[2014](https://www.ford.com.ph/support/vehicle/explorer/2014/owner-manuals/)

[2013](https://www.ford.com.ph/support/vehicle/explorer/2013/owner-manuals/)

[2012](https://www.ford.com.ph/support/vehicle/explorer/2012/owner-manuals/)

[2011](https://www.ford.com.ph/support/vehicle/explorer/2011/owner-manuals/)

[2010](https://www.ford.com.ph/support/vehicle/explorer/2010/owner-manuals/)

F-150

Year List

Details

[2026](https://www.ford.com.ph/support/vehicle/f150/2026/owner-manuals/)

[2025](https://www.ford.com.ph/support/vehicle/f150/2025/owner-manuals/)

F-250 - G2

Year List

Details

[2006](https://www.ford.com.ph/support/vehicle/f-250-g2/2006/owner-manuals/)

[2005](https://www.ford.com.ph/support/vehicle/f-250-g2/2005/owner-manuals/)

Fiesta

Year List

Details

[2020](https://www.ford.com.ph/support/vehicle/fiesta/2020/owner-manuals/)

[2019](https://www.ford.com.ph/support/vehicle/fiesta/2019/owner-manuals/)

[2018](https://www.ford.com.ph/support/vehicle/fiesta/2018/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/fiesta/2017/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/fiesta/2017/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/fiesta/2016/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/fiesta/2016/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/fiesta/2015/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/fiesta/2015/owner-manuals/)

[2014](https://www.ford.com.ph/support/vehicle/fiesta/2014/owner-manuals/)

[2013](https://www.ford.com.ph/support/vehicle/fiesta/2013/owner-manuals/)

[2013](https://www.ford.com.ph/support/vehicle/fiesta/2013/owner-manuals/)

[2010](https://www.ford.com.ph/support/vehicle/fiesta/2010/owner-manuals/)

Fiesta

Year List

Details

[2012](https://www.ford.com.ph/support/vehicle/fiesta-apa/2012/owner-manuals/)

[2011](https://www.ford.com.ph/support/vehicle/fiesta-apa/2011/owner-manuals/)

Fiesta - B1

Year List

Details

[2008](https://www.ford.com.ph/support/vehicle/fiesta-b1/2008/owner-manuals/)

Fiesta - B1 (B299)

Year List

Details

[2012](https://www.ford.com.ph/support/vehicle/fiesta-b1-b299/2012/owner-manuals/)

[2011](https://www.ford.com.ph/support/vehicle/fiesta-b1-b299/2011/owner-manuals/)

[2010](https://www.ford.com.ph/support/vehicle/fiesta-b1-b299/2010/owner-manuals/)

[2009](https://www.ford.com.ph/support/vehicle/fiesta-b1-b299/2009/owner-manuals/)

Fiesta - BK (B256/257)

Year List

Details

[2008](https://www.ford.com.ph/support/vehicle/fiesta-bk-b256-257/2008/owner-manuals/)

[2007](https://www.ford.com.ph/support/vehicle/fiesta-bk-b256-257/2007/owner-manuals/)

[2006](https://www.ford.com.ph/support/vehicle/fiesta-bk-b256-257/2006/owner-manuals/)

[2005](https://www.ford.com.ph/support/vehicle/fiesta-bk-b256-257/2005/owner-manuals/)

Fiesta - C3 (B299 MCA Thailand)

Year List

Details

[2018](https://www.ford.com.ph/support/vehicle/fiesta-c3-b299-mca-thailand/2018/owner-manuals/)

Fiesta ST

Year List

Details

[2013](https://www.ford.com.ph/support/vehicle/fiesta-st/2013/owner-manuals/)

Figo

Year List

Details

[2016](https://www.ford.com.ph/support/vehicle/figo/2016/owner-manuals/)

Figo - New (B562)

Year List

Details

[2015](https://www.ford.com.ph/support/vehicle/figo-new-b562/2015/owner-manuals/)

Figo MCA

Year List

Details

[2019](https://www.ford.com.ph/support/vehicle/figo-mca/2019/owner-manuals/)

[2018](https://www.ford.com.ph/support/vehicle/figo-mca/2018/owner-manuals/)

Focus

Year List

Details

[2017](https://www.ford.com.ph/support/vehicle/focus/2017/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/focus/2016/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/focus/2015/owner-manuals/)

[2014](https://www.ford.com.ph/support/vehicle/focus/2014/owner-manuals/)

[2012](https://www.ford.com.ph/support/vehicle/focus/2012/owner-manuals/)

[2011](https://www.ford.com.ph/support/vehicle/focus/2011/owner-manuals/)

[2010](https://www.ford.com.ph/support/vehicle/focus/2010/owner-manuals/)

Focus - AK (C170)

Year List

Details

[2005](https://www.ford.com.ph/support/vehicle/focus-ak-c170/2005/owner-manuals/)

Focus - AP (C307 EU)

Year List

Details

[2007](https://www.ford.com.ph/support/vehicle/focus-ap-c307-eu/2007/owner-manuals/)

[2006](https://www.ford.com.ph/support/vehicle/focus-ap-c307-eu/2006/owner-manuals/)

Focus - AP (C307)

Year List

Details

[2005](https://www.ford.com.ph/support/vehicle/focus-ap-c307/2005/owner-manuals/)

Focus - AP (C307/C307ST)

Year List

Details

[2008](https://www.ford.com.ph/support/vehicle/focus-ap-c307-c307st/2008/owner-manuals/)

Focus - AX

Year List

Details

[2007](https://www.ford.com.ph/support/vehicle/focus-ax/2007/owner-manuals/)

Focus - B4 (C307)

Year List

Details

[2010](https://www.ford.com.ph/support/vehicle/focus-b4-c307/2010/owner-manuals/)

Focus - B4 (C307/C307ST)

Year List

Details

[2008](https://www.ford.com.ph/support/vehicle/focus-b4-c307-c307st/2008/owner-manuals/)

Focus - EU (C346)

Year List

Details

[2013](https://www.ford.com.ph/support/vehicle/focus-eu-c346/2013/owner-manuals/)

[2012](https://www.ford.com.ph/support/vehicle/focus-eu-c346/2012/owner-manuals/)

[2011](https://www.ford.com.ph/support/vehicle/focus-eu-c346/2011/owner-manuals/)

Focus - MCA

Year List

Details

[2016](https://www.ford.com.ph/support/vehicle/focus-mca/2016/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/focus-mca/2015/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/focus-mca/2015/owner-manuals/)

Focus MCA

Year List

Details

[2016](https://www.ford.com.ph/support/vehicle/focus-mca/2016/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/focus-mca/2015/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/focus-mca/2015/owner-manuals/)

Focus

Year List

Details

[2013](https://www.ford.com.ph/support/vehicle/focus-new-c346/2013/owner-manuals/)

[2012](https://www.ford.com.ph/support/vehicle/focus-new-c346/2012/owner-manuals/)

Focus RS

Year List

Details

[2018](https://www.ford.com.ph/support/vehicle/focus-rs/2018/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/focus-rs/2017/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/focus-rs/2016/owner-manuals/)

Fusion/Mondeo

Year List

Details

[2015](https://www.ford.com.ph/support/vehicle/fusion-mondeo/2015/owner-manuals/)

Ikon

Year List

Details

[2009](https://www.ford.com.ph/support/vehicle/ikon/2009/owner-manuals/)

[2008](https://www.ford.com.ph/support/vehicle/ikon/2008/owner-manuals/)

Ka

Year List

Details

[2008](https://www.ford.com.ph/support/vehicle/ka/2008/owner-manuals/)

[2007](https://www.ford.com.ph/support/vehicle/ka/2007/owner-manuals/)

[2006](https://www.ford.com.ph/support/vehicle/ka/2006/owner-manuals/)

[2005](https://www.ford.com.ph/support/vehicle/ka/2005/owner-manuals/)

Kuga

Year List

Details

[2013](https://www.ford.com.ph/support/vehicle/kuga/2013/owner-manuals/)

[2012](https://www.ford.com.ph/support/vehicle/kuga/2012/owner-manuals/)

[2011](https://www.ford.com.ph/support/vehicle/kuga/2011/owner-manuals/)

Kuga - BS

Year List

Details

[2020](https://www.ford.com.ph/support/vehicle/kuga-bs/2020/owner-manuals/)

Kuga (C520 EU)

Year List

Details

[2013](https://www.ford.com.ph/support/vehicle/kuga-c520-eu/2013/owner-manuals/)

Mondeo

Year List

Details

[2017](https://www.ford.com.ph/support/vehicle/mondeo/2017/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/mondeo/2016/owner-manuals/)

Mondeo - ND

Year List

Details

[2005](https://www.ford.com.ph/support/vehicle/mondeo-nd/2005/owner-manuals/)

Mustang

Year List

Details

[2026](https://www.ford.com.ph/support/vehicle/mustang/2026/owner-manuals/)

[2025](https://www.ford.com.ph/support/vehicle/mustang/2025/owner-manuals/)

[2024](https://www.ford.com.ph/support/vehicle/mustang/2024/owner-manuals/)

[2023](https://www.ford.com.ph/support/vehicle/mustang/2023/owner-manuals/)

[2022](https://www.ford.com.ph/support/vehicle/mustang/2022/owner-manuals/)

[2021](https://www.ford.com.ph/support/vehicle/mustang/2021/owner-manuals/)

[2020](https://www.ford.com.ph/support/vehicle/mustang/2020/owner-manuals/)

[2019](https://www.ford.com.ph/support/vehicle/mustang/2019/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/mustang/2017/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/mustang/2016/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/mustang/2015/owner-manuals/)

[2014](https://www.ford.com.ph/support/vehicle/mustang/2014/owner-manuals/)

[2013](https://www.ford.com.ph/support/vehicle/mustang/2013/owner-manuals/)

Mustang Mach-E

Year List

Details

[2025](https://www.ford.com.ph/support/vehicle/mustang-mach-e/2025/owner-manuals/)

Mustang Mach-E - GW

Year List

Details

[2026](https://www.ford.com.ph/support/vehicle/mustang-mach-e-gw/2026/owner-manuals/)

Ranger

Year List

Details

[2021](https://www.ford.com.ph/support/vehicle/ranger/2021/owner-manuals/)

[2020](https://www.ford.com.ph/support/vehicle/ranger/2020/owner-manuals/)

[2019](https://www.ford.com.ph/support/vehicle/ranger/2019/owner-manuals/)

[2018](https://www.ford.com.ph/support/vehicle/ranger/2018/owner-manuals/)

[2018](https://www.ford.com.ph/support/vehicle/ranger/2018/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/ranger/2017/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/ranger/2017/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/ranger/2016/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/ranger/2016/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/ranger/2015/owner-manuals/)

[2015](https://www.ford.com.ph/support/vehicle/ranger/2015/owner-manuals/)

[2014](https://www.ford.com.ph/support/vehicle/ranger/2014/owner-manuals/)

[2013](https://www.ford.com.ph/support/vehicle/ranger/2013/owner-manuals/)

[2012](https://www.ford.com.ph/support/vehicle/ranger/2012/owner-manuals/)

Ranger - K5

Year List

Details

[2006](https://www.ford.com.ph/support/vehicle/ranger-k5/2006/owner-manuals/)

[2005](https://www.ford.com.ph/support/vehicle/ranger-k5/2005/owner-manuals/)

Ranger - K7

Year List

Details

[2006](https://www.ford.com.ph/support/vehicle/ranger-k7/2006/owner-manuals/)

[2005](https://www.ford.com.ph/support/vehicle/ranger-k7/2005/owner-manuals/)

Ranger - KD

Year List

Details

[2022](https://www.ford.com.ph/support/vehicle/ranger-kd/2022/owner-manuals/)

Ranger - KE

Year List

Details

[2021](https://www.ford.com.ph/support/vehicle/ranger-ke/2021/owner-manuals/)

[2020](https://www.ford.com.ph/support/vehicle/ranger-ke/2020/owner-manuals/)

[2019](https://www.ford.com.ph/support/vehicle/ranger-ke/2019/owner-manuals/)

[2014](https://www.ford.com.ph/support/vehicle/ranger-ke/2014/owner-manuals/)

[2013](https://www.ford.com.ph/support/vehicle/ranger-ke/2013/owner-manuals/)

[2012](https://www.ford.com.ph/support/vehicle/ranger-ke/2012/owner-manuals/)

[2011](https://www.ford.com.ph/support/vehicle/ranger-ke/2011/owner-manuals/)

Ranger - KI

Year List

Details

[2008](https://www.ford.com.ph/support/vehicle/ranger-ki/2008/owner-manuals/)

[2007](https://www.ford.com.ph/support/vehicle/ranger-ki/2007/owner-manuals/)

[2006](https://www.ford.com.ph/support/vehicle/ranger-ki/2006/owner-manuals/)

Ranger - RA

Year List

Details

[2026](https://www.ford.com.ph/support/vehicle/ranger-ra/2026/owner-manuals/)

[2025](https://www.ford.com.ph/support/vehicle/ranger-ra/2025/owner-manuals/)

[2024](https://www.ford.com.ph/support/vehicle/ranger-ra/2024/owner-manuals/)

[2023](https://www.ford.com.ph/support/vehicle/ranger-ra/2023/owner-manuals/)

[2022](https://www.ford.com.ph/support/vehicle/ranger-ra/2022/owner-manuals/)

Ranger - Raptor

Year List

Details

[2022](https://www.ford.com.ph/support/vehicle/ranger-raptor/2022/owner-manuals/)

[2021](https://www.ford.com.ph/support/vehicle/ranger-raptor/2021/owner-manuals/)

Ranger - Raptor - KE

Year List

Details

[2020](https://www.ford.com.ph/support/vehicle/ranger-raptor-ke/2020/owner-manuals/)

[2019](https://www.ford.com.ph/support/vehicle/ranger-raptor-ke/2019/owner-manuals/)

Ranger - RB

Year List

Details

[2023](https://www.ford.com.ph/support/vehicle/ranger-rb/2023/owner-manuals/)

[2022](https://www.ford.com.ph/support/vehicle/ranger-rb/2022/owner-manuals/)

Ranger K5

Year List

Details

[2006](https://www.ford.com.ph/support/vehicle/ranger-k5/2006/owner-manuals/)

[2005](https://www.ford.com.ph/support/vehicle/ranger-k5/2005/owner-manuals/)

Ranger K7

Year List

Details

[2006](https://www.ford.com.ph/support/vehicle/ranger-k7/2006/owner-manuals/)

[2005](https://www.ford.com.ph/support/vehicle/ranger-k7/2005/owner-manuals/)

Ranger Raptor - KE

Year List

Details

[2020](https://www.ford.com.ph/support/vehicle/ranger-raptor-ke/2020/owner-manuals/)

[2019](https://www.ford.com.ph/support/vehicle/ranger-raptor-ke/2019/owner-manuals/)

Ranger VLKA

Year List

Details

[2007](https://www.ford.com.ph/support/vehicle/ranger-vlka/2007/owner-manuals/)

Territory

Year List

Details

[2026](https://www.ford.com.ph/support/vehicle/territory/2026/owner-manuals/)

[2025](https://www.ford.com.ph/support/vehicle/territory/2025/owner-manuals/)

[2024](https://www.ford.com.ph/support/vehicle/territory/2024/owner-manuals/)

[2023](https://www.ford.com.ph/support/vehicle/territory/2023/owner-manuals/)

[2022](https://www.ford.com.ph/support/vehicle/territory/2022/owner-manuals/)

[2021](https://www.ford.com.ph/support/vehicle/territory/2021/owner-manuals/)

[2020](https://www.ford.com.ph/support/vehicle/territory/2020/owner-manuals/)

Territory - ST

Year List

Details

[2007](https://www.ford.com.ph/support/vehicle/territory-st/2007/owner-manuals/)

[2006](https://www.ford.com.ph/support/vehicle/territory-st/2006/owner-manuals/)

Territory - YL

Year List

Details

[2005](https://www.ford.com.ph/support/vehicle/territory-yl/2005/owner-manuals/)

[2004](https://www.ford.com.ph/support/vehicle/territory-yl/2004/owner-manuals/)

Tourneo Connect

Year List

Details

[2015](https://www.ford.com.ph/support/vehicle/tourneo-connect/2015/owner-manuals/)

[2014](https://www.ford.com.ph/support/vehicle/tourneo-connect/2014/owner-manuals/)

Tourneo Custom

Year List

Details

[2020](https://www.ford.com.ph/support/vehicle/tourneo-custom/2020/owner-manuals/)

[2019](https://www.ford.com.ph/support/vehicle/tourneo-custom/2019/owner-manuals/)

[2018](https://www.ford.com.ph/support/vehicle/tourneo-custom/2018/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/tourneo-custom/2017/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/tourneo-custom/2016/owner-manuals/)

Transit Cargo

Year List

Details

[2022](https://www.ford.com.ph/support/vehicle/transit-cargo/2022/owner-manuals/)

[2021](https://www.ford.com.ph/support/vehicle/transit-cargo/2021/owner-manuals/)

[2020](https://www.ford.com.ph/support/vehicle/transit-cargo/2020/owner-manuals/)

[2019](https://www.ford.com.ph/support/vehicle/transit-cargo/2019/owner-manuals/)

Transit Connect

Year List

Details

[2018](https://www.ford.com.ph/support/vehicle/transit-connect/2018/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/transit-connect/2017/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/transit-connect/2016/owner-manuals/)

Transit Custom

Year List

Details

[2022](https://www.ford.com.ph/support/vehicle/transit-custom/2022/owner-manuals/)

[2021](https://www.ford.com.ph/support/vehicle/transit-custom/2021/owner-manuals/)

[2020](https://www.ford.com.ph/support/vehicle/transit-custom/2020/owner-manuals/)

[2019](https://www.ford.com.ph/support/vehicle/transit-custom/2019/owner-manuals/)

[2018](https://www.ford.com.ph/support/vehicle/transit-custom/2018/owner-manuals/)

[2017](https://www.ford.com.ph/support/vehicle/transit-custom/2017/owner-manuals/)

[2016](https://www.ford.com.ph/support/vehicle/transit-custom/2016/owner-manuals/)

2027

Vehicle List

Details

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2027/owner-manuals/)

2026

Vehicle List

Details

[Bronco](https://www.ford.com.ph/support/vehicle/bronco/2026/owner-manuals/)

[Escape - TC](https://www.ford.com.ph/support/vehicle/escape-tc/2026/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2026/owner-manuals/)

[Expedition](https://www.ford.com.ph/support/vehicle/expedition/2026/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2026/owner-manuals/)

[F-150](https://www.ford.com.ph/support/vehicle/f150/2026/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2026/owner-manuals/)

[Mustang Mach-E - GW](https://www.ford.com.ph/support/vehicle/mustang-mach-e-gw/2026/owner-manuals/)

[Ranger - RA](https://www.ford.com.ph/support/vehicle/ranger-ra/2026/owner-manuals/)

[Territory](https://www.ford.com.ph/support/vehicle/territory/2026/owner-manuals/)

2025

Vehicle List

Details

[Bronco](https://www.ford.com.ph/support/vehicle/bronco/2025/owner-manuals/)

[Escape - TC](https://www.ford.com.ph/support/vehicle/escape-tc/2025/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2025/owner-manuals/)

[Expedition](https://www.ford.com.ph/support/vehicle/expedition/2025/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2025/owner-manuals/)

[F-150](https://www.ford.com.ph/support/vehicle/f150/2025/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2025/owner-manuals/)

[Mustang Mach-E](https://www.ford.com.ph/support/vehicle/mustang-mach-e/2025/owner-manuals/)

[Ranger - RA](https://www.ford.com.ph/support/vehicle/ranger-ra/2025/owner-manuals/)

[Territory](https://www.ford.com.ph/support/vehicle/territory/2025/owner-manuals/)

2024

Vehicle List

Details

[Everest](https://www.ford.com.ph/support/vehicle/everest/2024/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2024/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2024/owner-manuals/)

[Ranger - RA](https://www.ford.com.ph/support/vehicle/ranger-ra/2024/owner-manuals/)

[Territory](https://www.ford.com.ph/support/vehicle/territory/2024/owner-manuals/)

2023

Vehicle List

Details

[EcoSport - R6](https://www.ford.com.ph/support/vehicle/ecosport-r6/2023/owner-manuals/)

[Everest - EK](https://www.ford.com.ph/support/vehicle/everest-ek/2023/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2023/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2023/owner-manuals/)

[Ranger - RA](https://www.ford.com.ph/support/vehicle/ranger-ra/2023/owner-manuals/)

[Ranger - RB](https://www.ford.com.ph/support/vehicle/ranger-rb/2023/owner-manuals/)

[Territory](https://www.ford.com.ph/support/vehicle/territory/2023/owner-manuals/)

2022

Vehicle List

Details

[EcoSport - R6](https://www.ford.com.ph/support/vehicle/ecosport-r6/2022/owner-manuals/)

[Everest - EC](https://www.ford.com.ph/support/vehicle/everest-ec/2022/owner-manuals/)

[Everest - ED](https://www.ford.com.ph/support/vehicle/everest-ed/2022/owner-manuals/)

[Everest - EK](https://www.ford.com.ph/support/vehicle/everest-ek/2022/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2022/owner-manuals/)

[F-150](https://www.ford.com.ph/support/vehicle/f-150/2022/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2022/owner-manuals/)

[Ranger - KD](https://www.ford.com.ph/support/vehicle/ranger-kd/2022/owner-manuals/)

[Ranger - RA](https://www.ford.com.ph/support/vehicle/ranger-ra/2022/owner-manuals/)

[Ranger - Raptor](https://www.ford.com.ph/support/vehicle/ranger-raptor/2022/owner-manuals/)

[Ranger - RB](https://www.ford.com.ph/support/vehicle/ranger-rb/2022/owner-manuals/)

[Territory](https://www.ford.com.ph/support/vehicle/territory/2022/owner-manuals/)

[Transit Cargo](https://www.ford.com.ph/support/vehicle/transit-cargo/2022/owner-manuals/)

[Transit Custom](https://www.ford.com.ph/support/vehicle/transit-custom/2022/owner-manuals/)

2021

Vehicle List

Details

[EcoSport - BW](https://www.ford.com.ph/support/vehicle/ecosport-bw/2021/owner-manuals/)

[EcoSport - R6](https://www.ford.com.ph/support/vehicle/ecosport-r6/2021/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2021/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2021/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2021/owner-manuals/)

[F-150](https://www.ford.com.ph/support/vehicle/f-150/2021/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2021/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2021/owner-manuals/)

[Ranger - KE](https://www.ford.com.ph/support/vehicle/ranger-ke/2021/owner-manuals/)

[Ranger - Raptor](https://www.ford.com.ph/support/vehicle/ranger-raptor/2021/owner-manuals/)

[Territory](https://www.ford.com.ph/support/vehicle/territory/2021/owner-manuals/)

[Transit Cargo](https://www.ford.com.ph/support/vehicle/transit-cargo/2021/owner-manuals/)

[Transit Custom](https://www.ford.com.ph/support/vehicle/transit-custom/2021/owner-manuals/)

2020

Vehicle List

Details

[EcoSport](https://www.ford.com.ph/support/vehicle/ecosport/2020/owner-manuals/)

[EcoSport - BW](https://www.ford.com.ph/support/vehicle/ecosport-bw/2020/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2020/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2020/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2020/owner-manuals/)

[F-150](https://www.ford.com.ph/support/vehicle/f-150/2020/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2020/owner-manuals/)

[Kuga - BS](https://www.ford.com.ph/support/vehicle/kuga-bs/2020/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2020/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2020/owner-manuals/)

[Ranger - KE](https://www.ford.com.ph/support/vehicle/ranger-ke/2020/owner-manuals/)

[Ranger - Raptor - KE](https://www.ford.com.ph/support/vehicle/ranger-raptor-ke/2020/owner-manuals/)

[Territory](https://www.ford.com.ph/support/vehicle/territory/2020/owner-manuals/)

[Tourneo Custom](https://www.ford.com.ph/support/vehicle/tourneo-custom/2020/owner-manuals/)

[Transit Cargo](https://www.ford.com.ph/support/vehicle/transit-cargo/2020/owner-manuals/)

[Transit Custom](https://www.ford.com.ph/support/vehicle/transit-custom/2020/owner-manuals/)

2019

Vehicle List

Details

[EcoSport - BX](https://www.ford.com.ph/support/vehicle/ecosport-bx/2019/owner-manuals/)

[EcoSport (India)](https://www.ford.com.ph/support/vehicle/ecosport-india/2019/owner-manuals/)

[Escape](https://www.ford.com.ph/support/vehicle/escape/2019/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2019/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2019/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2019/owner-manuals/)

[Figo MCA](https://www.ford.com.ph/support/vehicle/figo-mca/2019/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2019/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2019/owner-manuals/)

[Ranger - KE](https://www.ford.com.ph/support/vehicle/ranger-ke/2019/owner-manuals/)

[Ranger Raptor - KE](https://www.ford.com.ph/support/vehicle/ranger-raptor-ke/2019/owner-manuals/)

[Tourneo Custom](https://www.ford.com.ph/support/vehicle/tourneo-custom/2019/owner-manuals/)

[Transit Cargo](https://www.ford.com.ph/support/vehicle/transit-cargo/2019/owner-manuals/)

[Transit Custom](https://www.ford.com.ph/support/vehicle/transit-custom/2019/owner-manuals/)

2018

Vehicle List

Details

[EcoSport - BX](https://www.ford.com.ph/support/vehicle/ecosport-bx/2018/owner-manuals/)

[EcoSport (India)](https://www.ford.com.ph/support/vehicle/ecosport-india/2018/owner-manuals/)

[EcoSport (Romania)](https://www.ford.com.ph/support/vehicle/ecosport-romania/2018/owner-manuals/)

[Escape](https://www.ford.com.ph/support/vehicle/escape/2018/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2018/owner-manuals/)

[Everest (S. Africa)](https://www.ford.com.ph/support/vehicle/everest-s-africa/2018/owner-manuals/)

[Expedition](https://www.ford.com.ph/support/vehicle/expedition/2018/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2018/owner-manuals/)

[Fiesta - C3 (B299 MCA Thailand)](https://www.ford.com.ph/support/vehicle/fiesta-c3-b299-mca-thailand/2018/owner-manuals/)

[Figo MCA](https://www.ford.com.ph/support/vehicle/figo-mca/2018/owner-manuals/)

[Focus RS](https://www.ford.com.ph/support/vehicle/focus-rs/2018/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2018/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2018/owner-manuals/)

[Tourneo Custom](https://www.ford.com.ph/support/vehicle/tourneo-custom/2018/owner-manuals/)

[Transit Connect](https://www.ford.com.ph/support/vehicle/transit-connect/2018/owner-manuals/)

[Transit Custom](https://www.ford.com.ph/support/vehicle/transit-custom/2018/owner-manuals/)

2017

Vehicle List

Details

[EcoSport](https://www.ford.com.ph/support/vehicle/ecosport/2017/owner-manuals/)

[Escape](https://www.ford.com.ph/support/vehicle/escape/2017/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2017/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2017/owner-manuals/)

[Expedition](https://www.ford.com.ph/support/vehicle/expedition/2017/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2017/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2017/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2017/owner-manuals/)

[Focus](https://www.ford.com.ph/support/vehicle/focus/2017/owner-manuals/)

[Focus RS](https://www.ford.com.ph/support/vehicle/focus-rs/2017/owner-manuals/)

[Mondeo](https://www.ford.com.ph/support/vehicle/mondeo/2017/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2017/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2017/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2017/owner-manuals/)

[Tourneo Custom](https://www.ford.com.ph/support/vehicle/tourneo-custom/2017/owner-manuals/)

[Transit Connect](https://www.ford.com.ph/support/vehicle/transit-connect/2017/owner-manuals/)

[Transit Custom](https://www.ford.com.ph/support/vehicle/transit-custom/2017/owner-manuals/)

2016

Vehicle List

Details

[EcoSport](https://www.ford.com.ph/support/vehicle/ecosport/2016/owner-manuals/)

[EcoSport](https://www.ford.com.ph/support/vehicle/ecosport/2016/owner-manuals/)

[Everest (S. Africa)](https://www.ford.com.ph/support/vehicle/everest-s-africa/2016/owner-manuals/)

[Everest (Thailand)](https://www.ford.com.ph/support/vehicle/everest-thailand/2016/owner-manuals/)

[Expedition](https://www.ford.com.ph/support/vehicle/expedition/2016/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2016/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2016/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2016/owner-manuals/)

[Figo](https://www.ford.com.ph/support/vehicle/figo/2016/owner-manuals/)

[Focus](https://www.ford.com.ph/support/vehicle/focus/2016/owner-manuals/)

[Focus MCA](https://www.ford.com.ph/support/vehicle/focus-mca/2016/owner-manuals/)

[Focus RS](https://www.ford.com.ph/support/vehicle/focus-rs/2016/owner-manuals/)

[Mondeo](https://www.ford.com.ph/support/vehicle/mondeo/2016/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2016/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2016/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2016/owner-manuals/)

[Tourneo Custom](https://www.ford.com.ph/support/vehicle/tourneo-custom/2016/owner-manuals/)

[Transit Connect](https://www.ford.com.ph/support/vehicle/transit-connect/2016/owner-manuals/)

[Transit Custom](https://www.ford.com.ph/support/vehicle/transit-custom/2016/owner-manuals/)

2015

Vehicle List

Details

[EcoSport](https://www.ford.com.ph/support/vehicle/ecosport/2015/owner-manuals/)

[EcoSport](https://www.ford.com.ph/support/vehicle/ecosport/2015/owner-manuals/)

[Escape](https://www.ford.com.ph/support/vehicle/escape/2015/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2015/owner-manuals/)

[Expedition](https://www.ford.com.ph/support/vehicle/expedition/2015/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2015/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2015/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2015/owner-manuals/)

[Figo - New (B562)](https://www.ford.com.ph/support/vehicle/figo-new-b562/2015/owner-manuals/)

[Focus](https://www.ford.com.ph/support/vehicle/focus/2015/owner-manuals/)

[Focus - MCA](https://www.ford.com.ph/support/vehicle/focus-mca/2015/owner-manuals/)

[Focus MCA](https://www.ford.com.ph/support/vehicle/focus-mca/2015/owner-manuals/)

[Fusion/Mondeo](https://www.ford.com.ph/support/vehicle/fusion-mondeo/2015/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2015/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2015/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2015/owner-manuals/)

[Tourneo Connect](https://www.ford.com.ph/support/vehicle/tourneo-connect/2015/owner-manuals/)

2014

Vehicle List

Details

[EcoSport](https://www.ford.com.ph/support/vehicle/ecosport/2014/owner-manuals/)

[EcoSport](https://www.ford.com.ph/support/vehicle/ecosport/2014/owner-manuals/)

[Expedition](https://www.ford.com.ph/support/vehicle/expedition/2014/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2014/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2014/owner-manuals/)

[Focus](https://www.ford.com.ph/support/vehicle/focus/2014/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2014/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2014/owner-manuals/)

[Ranger - KE](https://www.ford.com.ph/support/vehicle/ranger-ke/2014/owner-manuals/)

[Tourneo Connect](https://www.ford.com.ph/support/vehicle/tourneo-connect/2014/owner-manuals/)

2013

Vehicle List

Details

[E-150](https://www.ford.com.ph/support/vehicle/e-150/2013/owner-manuals/)

[EcoSport](https://www.ford.com.ph/support/vehicle/ecosport/2013/owner-manuals/)

[Expedition](https://www.ford.com.ph/support/vehicle/expedition/2013/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2013/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2013/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2013/owner-manuals/)

[Fiesta ST](https://www.ford.com.ph/support/vehicle/fiesta-st/2013/owner-manuals/)

[Focus - EU (C346)](https://www.ford.com.ph/support/vehicle/focus-eu-c346/2013/owner-manuals/)

[Focus New (C346)](https://www.ford.com.ph/support/vehicle/focus-new-c346/2013/owner-manuals/)

[Kuga](https://www.ford.com.ph/support/vehicle/kuga/2013/owner-manuals/)

[Kuga (C520 EU)](https://www.ford.com.ph/support/vehicle/kuga-c520-eu/2013/owner-manuals/)

[Mustang](https://www.ford.com.ph/support/vehicle/mustang/2013/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2013/owner-manuals/)

[Ranger - KE](https://www.ford.com.ph/support/vehicle/ranger-ke/2013/owner-manuals/)

2012

Vehicle List

Details

[E-150](https://www.ford.com.ph/support/vehicle/e-150/2012/owner-manuals/)

[Escape](https://www.ford.com.ph/support/vehicle/escape/2012/owner-manuals/)

[Expedition](https://www.ford.com.ph/support/vehicle/expedition/2012/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2012/owner-manuals/)

[Fiesta - APA](https://www.ford.com.ph/support/vehicle/fiesta-apa/2012/owner-manuals/)

[Fiesta - B1 (B299)](https://www.ford.com.ph/support/vehicle/fiesta-b1-b299/2012/owner-manuals/)

[Focus](https://www.ford.com.ph/support/vehicle/focus/2012/owner-manuals/)

[Focus - EU (C346)](https://www.ford.com.ph/support/vehicle/focus-eu-c346/2012/owner-manuals/)

[Focus New (C346)](https://www.ford.com.ph/support/vehicle/focus-new-c346/2012/owner-manuals/)

[Kuga](https://www.ford.com.ph/support/vehicle/kuga/2012/owner-manuals/)

[Ranger](https://www.ford.com.ph/support/vehicle/ranger/2012/owner-manuals/)

[Ranger - KE](https://www.ford.com.ph/support/vehicle/ranger-ke/2012/owner-manuals/)

2011

Vehicle List

Details

[E-150](https://www.ford.com.ph/support/vehicle/e-150/2011/owner-manuals/)

[Escape](https://www.ford.com.ph/support/vehicle/escape/2011/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2011/owner-manuals/)

[Expedition](https://www.ford.com.ph/support/vehicle/expedition/2011/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2011/owner-manuals/)

[Fiesta - APA](https://www.ford.com.ph/support/vehicle/fiesta-apa/2011/owner-manuals/)

[Fiesta - B1 (B299)](https://www.ford.com.ph/support/vehicle/fiesta-b1-b299/2011/owner-manuals/)

[Focus](https://www.ford.com.ph/support/vehicle/focus/2011/owner-manuals/)

[Focus - EU (C346)](https://www.ford.com.ph/support/vehicle/focus-eu-c346/2011/owner-manuals/)

[Kuga](https://www.ford.com.ph/support/vehicle/kuga/2011/owner-manuals/)

[Ranger - KE](https://www.ford.com.ph/support/vehicle/ranger-ke/2011/owner-manuals/)

2010

Vehicle List

Details

[E-150](https://www.ford.com.ph/support/vehicle/e-150/2010/owner-manuals/)

[Escape](https://www.ford.com.ph/support/vehicle/escape/2010/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2010/owner-manuals/)

[Expedition](https://www.ford.com.ph/support/vehicle/expedition/2010/owner-manuals/)

[Explorer](https://www.ford.com.ph/support/vehicle/explorer/2010/owner-manuals/)

[Fiesta](https://www.ford.com.ph/support/vehicle/fiesta/2010/owner-manuals/)

[Fiesta - B1 (B299)](https://www.ford.com.ph/support/vehicle/fiesta-b1-b299/2010/owner-manuals/)

[Focus](https://www.ford.com.ph/support/vehicle/focus/2010/owner-manuals/)

[Focus - B4 (C307)](https://www.ford.com.ph/support/vehicle/focus-b4-c307/2010/owner-manuals/)

2009

Vehicle List

Details

[Bantam](https://www.ford.com.ph/support/vehicle/bantam/2009/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2009/owner-manuals/)

[Fiesta - B1 (B299)](https://www.ford.com.ph/support/vehicle/fiesta-b1-b299/2009/owner-manuals/)

[Ikon](https://www.ford.com.ph/support/vehicle/ikon/2009/owner-manuals/)

2008

Vehicle List

Details

[Bantam](https://www.ford.com.ph/support/vehicle/bantam/2008/owner-manuals/)

[Fiesta - B1](https://www.ford.com.ph/support/vehicle/fiesta-b1/2008/owner-manuals/)

[Fiesta - BK (B256/257)](https://www.ford.com.ph/support/vehicle/fiesta-bk-b256-257/2008/owner-manuals/)

[Focus - AP (C307/C307ST)](https://www.ford.com.ph/support/vehicle/focus-ap-c307-c307st/2008/owner-manuals/)

[Focus - B4 (C307/C307ST)](https://www.ford.com.ph/support/vehicle/focus-b4-c307-c307st/2008/owner-manuals/)

[Ikon](https://www.ford.com.ph/support/vehicle/ikon/2008/owner-manuals/)

[Ka](https://www.ford.com.ph/support/vehicle/ka/2008/owner-manuals/)

[Ranger - KI](https://www.ford.com.ph/support/vehicle/ranger-ki/2008/owner-manuals/)

2007

Vehicle List

Details

[Bantam](https://www.ford.com.ph/support/vehicle/bantam/2007/owner-manuals/)

[Everest](https://www.ford.com.ph/support/vehicle/everest/2007/owner-manuals/)

[Fiesta - BK (B256/257)](https://www.ford.com.ph/support/vehicle/fiesta-bk-b256-257/2007/owner-manuals/)

[Focus - AP (C307 EU)](https://www.ford.com.ph/support/vehicle/focus-ap-c307-eu/2007/owner-manuals/)

[Focus - AX](https://www.ford.com.ph/support/vehicle/focus-ax/2007/owner-manuals/)

[Ka](https://www.ford.com.ph/support/vehicle/ka/2007/owner-manuals/)

[Ranger - KI](https://www.ford.com.ph/support/vehicle/ranger-ki/2007/owner-manuals/)

[Ranger VLKA](https://www.ford.com.ph/support/vehicle/ranger-vlka/2007/owner-manuals/)

[Territory - ST](https://www.ford.com.ph/support/vehicle/territory-st/2007/owner-manuals/)

2006

Vehicle List

Details

[F-250 - G2](https://www.ford.com.ph/support/vehicle/f-250-g2/2006/owner-manuals/)

[Fiesta - BK (B256/257)](https://www.ford.com.ph/support/vehicle/fiesta-bk-b256-257/2006/owner-manuals/)

[Focus - AP (C307 EU)](https://www.ford.com.ph/support/vehicle/focus-ap-c307-eu/2006/owner-manuals/)

[Ka](https://www.ford.com.ph/support/vehicle/ka/2006/owner-manuals/)

[Ranger - K5](https://www.ford.com.ph/support/vehicle/ranger-k5/2006/owner-manuals/)

[Ranger - K7](https://www.ford.com.ph/support/vehicle/ranger-k7/2006/owner-manuals/)

[Ranger - KI](https://www.ford.com.ph/support/vehicle/ranger-ki/2006/owner-manuals/)

[Territory - ST](https://www.ford.com.ph/support/vehicle/territory-st/2006/owner-manuals/)

2005

Vehicle List

Details

[F-250 - G2](https://www.ford.com.ph/support/vehicle/f-250-g2/2005/owner-manuals/)

[Fiesta - BK (B256/257)](https://www.ford.com.ph/support/vehicle/fiesta-bk-b256-257/2005/owner-manuals/)

[Focus - AK (C170)](https://www.ford.com.ph/support/vehicle/focus-ak-c170/2005/owner-manuals/)

[Focus - AP (C307)](https://www.ford.com.ph/support/vehicle/focus-ap-c307/2005/owner-manuals/)

[Ka](https://www.ford.com.ph/support/vehicle/ka/2005/owner-manuals/)

[Mondeo - ND](https://www.ford.com.ph/support/vehicle/mondeo-nd/2005/owner-manuals/)

[Ranger K5](https://www.ford.com.ph/support/vehicle/ranger-k5/2005/owner-manuals/)

[Ranger K7](https://www.ford.com.ph/support/vehicle/ranger-k7/2005/owner-manuals/)

[Territory - YL](https://www.ford.com.ph/support/vehicle/territory-yl/2005/owner-manuals/)

2004

Vehicle List

Details

[Territory - YL](https://www.ford.com.ph/support/vehicle/territory-yl/2004/owner-manuals/)