Source: https://www.gmanetwork.com/news/money/companies/974146/over-491-000-vehicles-added-to-ph-roads-in-2025/story
Title: Over 491,000 vehicles added to PH roads in 2025 | GMA News Online
Fetched: 2026-11-11T10:05:58.298Z

[![NPC Seal](https://images.gmanetwork.com/res/img/gno-npc-seal.webp)](https://www.gmanetwork.com/news/privacy-notice/)

We use cookies to ensure you get the best browsing experience. By continued use, you agree to our privacy policy and accept our use of such cookies. For further information, click FIND OUT MORE.

[I AGREE](https://www.gmanetwork.com/news/money/companies/974146/over-491-000-vehicles-added-to-ph-roads-in-2025/story/) [FIND OUT MORE](https://www.gmanetwork.com/privacypolicy)

[Sara Duterte Impeached: The Vice President on Trial](https://www.gmanetwork.com/news/topstories/nation/1009063/live-updates-sara-duterte-impeachment-trial-november-11-2026/story/ "Sara Duterte Impeached: The Vice President on Trial")

[Sara Duterte Impeached: The Vice President on Trial](https://www.gmanetwork.com/news/topstories/nation/1009063/live-updates-sara-duterte-impeachment-trial-november-11-2026/story/ "Sara Duterte Impeached: The Vice President on Trial")

[Sara Duterte Impeached: The Vice President on Trial](https://www.gmanetwork.com/news/topstories/nation/1009063/live-updates-sara-duterte-impeachment-trial-november-11-2026/story/ "Sara Duterte Impeached: The Vice President on Trial")

Filtered by: Money

Money

By [JON VIKTOR D. CABUENAS](https://www.gmanetwork.com/news/archives/authors/jonviktordcabuenas/), GMA Integrated News

**Published** January 26, 2026 11:12am

[+\\
\\
Add GMA on Google](https://www.google.com/preferences/source?q=gmanetwork.com)

Make this your preferred source to get more updates from this publisher on Google.

![](https://images.gmanews.tv/webpics/2026/01/2024-07-04T152451Z_779431146_RC24O8AFJAQL_RTRMADP_3_EUROPE-CHINA-AUTOS-SUBSIDIES_2024_07_05_09_18_30_2026_01_26_11_07_44.jpeg)

Electric vehicles make a steady rise in market share in the Philippines. File photo

A record 491,395 vehicles were added to Philippine roads in 2025, narrowly missing the [500,000-unit sales target](https://www.gmanetwork.com/news/money/economy/936871/ph-auto-manufacturers-target-500-000-unit-sales-in-2025/story/) set by local automotive manufacturers, amid the reimposition of excise taxes on pickup trucks and the impact of several natural calamities.

Data from the Chamber of Automotive Manufacturers of the Philippines Inc. (CAMPI) and the Truck Manufacturers Association (TMA) showed that industry sales rose by 3.7% in 2025, from 473,842 units in 2024.

CAMPI and TMA members accounted for 463,646 units sold, slightly lower than the 467,252 units recorded in 2024, following the removal of pickup trucks’ excise tax exemption under the Capital Market Efficiency Promotion Act (CMEPA) in July 2025.

Electric vehicles made up a growing share of the market, with sales reaching 58,903 units, or 12% of total industry sales for the year, up from 5.5% in 2024.

Toyota maintained market leadership with a 46.7% share, followed by Mitsubishi at 18.0%, Suzuki at 4.5%, Ford at 4.4%, and Nissan at 4.2%.

In December alone, CAMPI and TMA sold 42,870 units, up 2.0% from the 42,044 units sold in December 2024, marking the industry’s strongest monthly performance since 2017.

“We attribute last year’s achievement to aggressive promotional campaigns and new product introductions that expanded consumer options, particularly in the electrified and commercial vehicle segments,” CAMPI President Jose Maria Atienza said in a statement.

Commercial vehicles continued to dominate sales, accounting for 81.32% of the total, or 34,861 units, while passenger cars comprised 18.68%, or 8,009 units.

By vehicle type, light commercial vehicles led sales with 24,669 units, followed by Asian utility vehicles with 9,266 units.

Electric vehicle sales in December totaled 4,358 units, including 3,717 hybrid electric vehicles, 349 battery electric vehicles, and 292 plug-in hybrid electric vehicles.

Monthly sales also included 526 light-duty trucks and buses, 379 medium-duty trucks and buses, and 21 heavy-duty trucks and buses. **—MCG, GMA Integrated News**

Tags: [campi](https://www.gmanetwork.com/news/tracking/campi/), [TMA](https://www.gmanetwork.com/news/tracking/tma/), [new vehicles](https://www.gmanetwork.com/news/tracking/new_vehicles/)

![GNO Newsletter Logo](https://images.gmanetwork.com/res/img/newsletter/gno-logo.png)

×

![GNO Newsletter Sending Email Logo](https://images.gmanetwork.com/res/img/newsletter/sending-emails.svg)

**Need a wellness break? Sign up for The Boost!**

Stay up-to-date with the latest health and wellness reads.

Please enter a valid email address

Sign Up

Your email is safe with us

Facebook

More Videos

Most Popular

[![](https://images.gmanews.tv/webpics/2025/04/Bongbong_sara_2025_04_29_09_44_37.jpeg)\\
\\
**Marcos trust, performance ratings fall; Sara Duterte hold steady in OCTA Q3 survey**](https://www.gmanetwork.com/news/topstories/nation/1009116/marcos-trust-performance-ratings-fall-sara-duterte-hold-steady-in-octa-q3-survey/story/) [![](https://images.gmanews.tv/webpics/2026/11/suspects_arrested_pro_3__2026_11_11_15_38_09.jpg)\\
\\
**6 robbery suspects arrested after Nueva Ecija convenience store heist**](https://www.gmanetwork.com/news/topstories/regions/1009123/6-robbery-suspects-arrested-after-nueva-ecija-convenience-store-heist/story/) [![](https://images.gmanews.tv/webpics/2026/11/2026-10-23T170038Z_1360837691_RC2SOKAYB15N_RTRMADP_3_FRANCE-EMIRATES-WARPLANE_2026_11_11_16_29_04.jpg)\\
\\
**Baltics, Finland issue overnight drone warnings as Russia, Ukraine exchange strikes**](https://www.gmanetwork.com/news/topstories/world/1009130/baltics-finland-issue-overnight-drone-warnings-as-russia-ukraine-exchange-strikes/story/) [![](https://images.gmanews.tv/webpics/2026/11/Engineer_Adain_(2)_2026_11_11_17_04_38.jpg)\\
\\
**Reintroducing PH cuisine through slow food movement in ASEAN**](https://www.gmanetwork.com/news/lifestyle/food/1009138/reintroducing-ph-cuisine-through-slow-food-movement-in-asean/story/)

LOADING CONTENT

[LOAD MORE ARTICLES](https://www.gmanetwork.com/news/money/companies/974146/over-491-000-vehicles-added-to-ph-roads-in-2025/story/)

RETRY LOADING

[Next Story\\
\\
Future of ASEAN tourism not shaped by one nation — DOT exec](https://www.gmanetwork.com/news/money/economy/974142/future-of-asean-tourism-not-shaped-by-one-nation-dot-exec/story/)