Source: https://techinfo.toyota.com/techInfoPortal/appmanager/t3/ti?_nfpb=true&_pageLabel=ti_whats_tis
Title: TIS
Fetched: 2026-11-11T10:05:58.179Z

ms6

|     |     |     |     |
| --- | --- | --- | --- |
| ![](https://techinfo.toyota.com/techInfoPortal/resources/images/utils/clear.gif) | ![](https://techinfo.toyota.com/techInfoPortal/resources/images/globals/header/tis.headerbar.left.jpg) |  | ![](https://techinfo.toyota.com/techInfoPortal/resources/images/globals/header/tis.headerbar.right.jpg) |

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| |     |     |     |     |     |
| --- | --- | --- | --- | --- |
| |     |     |     |     |     |
| --- | --- | --- | --- | --- |
| |     |     |     |     |     |
| --- | --- | --- | --- | --- |
| |     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | The TIS Library |  |  |  |

The TIS Library

|     |
| --- |
| TIS contains all of the product support information necessary to maintain, diagnose, and repair vehicles<br>manufactured by Toyota and marketed in North America. As a general rule, model coverage begins with the 1990<br>model year with some information, like Technical Service Bulletins, available back to 1987.<br> <br>Our on-line library is organized by publication or information type and can be searched by topical area or text<br>(word, multiple-word or phrase). You also have the option to search for specific text across model years, vehicle models,<br>and publication types.<br> <br>New information is added to TIS when it becomes available.  These pages contain graphical summaries of all available TIS content. |
| [>>TIS Content Examples](https://techinfo.toyota.com/techInfoPortal/appmanager/t3/ti?_nfpb=true&_pageLabel=ti_whats_tis#TIS%20Content%20Examples) |
| >>Lexus TIS Library |
| >>Scion TIS Library |
| >>Toyota TIS Library |

|     |     |     |
| --- | --- | --- |
| ![](https://techinfo.toyota.com/techInfoPortal/framework/skins/t3/details/images/tab.bar.bot.left.wht2gry.gif) | ![](https://techinfo.toyota.com/techInfoPortal/resources/images/utils/clear.png) | ![](https://techinfo.toyota.com/techInfoPortal/framework/skins/t3/details/images/tab.bar.bot.right.wht2gry.gif) | |
| |     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | Subscription Options & Pricing |  |  |  |

Subscription Options

|     |     |     |     |
| --- | --- | --- | --- |
| TIS is offered on a subscription basis. Your TIS account will allow you to access the service information
content available for all Toyota marketing divisions in North America.
**Before you subscribe, please note that this site does not contain information in support of vehicles**
**that were not available for sale in North America.**

Subscription access to TIS is offered in 2 day, monthly, or yearly intervals following the rate schedule
noted below. Note: All pricing is in US dollars.

|     |     |     |     |
| --- | --- | --- | --- |
| Subscription Type | Standard | Professional<br>Diagnostic | Security<br>Professional\* |
| **2 Day** | **$30 US** | **$80 US** | **$80 US** |
| **Monthly** | **$105 US** | **NA** | **NA** |
| **Yearly** | **$580 US** | **$1500 US** | **$1500 US** |

NOTE: All subscriptions expire at midnight, Pacific Time on the last day of your term.


This means a two-day subscription may actually provide greater than 48 hours of usable access.

|     |
| --- |
| A **Standard** TIS subscription provides access to the technical information library for all Toyota, Scion, and Lexus vehicles marketed in North America. A Standard subscription allows vehicle model and year specific publication searches for the information needed to maintain, diagnose, and repair all Toyota, Scion, and Lexus vehicles. As a general rule, model coverage begins with the 1990 model year with some information, like Technical Service Bulletins, available back to 1987. |
|  |
| A **Professional Diagnostic** TIS subscription provides the same access to the technical information library provided with the Standard subscription. A Professional Diagnostic subscription also allows use of Techstream scantool software, all available ECU calibration files, and Identifix Direct-Hit (details below). Package a Professional Diagnostic subscription with a TIS Techstream or Techstream Lite to fully enable scantool diagnostics and vehicle reprogramming capability (USA/Mexico VIN information only). For more information on scantools and vehicle reprogramming, click here.<br>**Note:** Techstream software registration is limited to one PC per each professional level subscription. You must purchase additional professional level subscriptions to use Techstream software on additional PCs. |
|  |
| \*A **Security Professional** TIS subscription provides the same access provided with the Professional Diagnostic subscription along with access to vehicle security information, including key codes and immobilizer/smart reset capability. Before you can purchase this subscription level, you must be a current member of the NASTF Vehicle Security Professional Registry. For more details and requirements, <br> click here. |
|  |
| **TIS Technical Assistance Powered by Identifix**<br>Check out the all-new technical assistance feature for Professional Diagnostic and Security Professional subscribers. Professional Subscribers receive complimentary access to Identifix Direct-Hit for Toyota, Scion, and Lexus models. In addition, each annual Professional Subscription receives one complementary Identifix Technical Assistance call. To learn more about Identifix, click here. |
|  |


To establish your TIS account, please review the Terms, Conditions and Privacy Policy below and then
select Create A New Account Now.

Once activated your personal TIS account will remain active even after your subscription term expires. In the event you want to purchase additional time simply follow the Manage My Account link below. |
| >>Terms of Use and Privacy Policy |
| [>>Create A New Account Now](https://techinfo.toyota.com/techInfoPortal/ManageAccounts?urlKey=Register) |
| [>>Manage My Account](https://techinfo.toyota.com/techInfoPortal/ManageAccounts?urlKey=ManageAccount) |

|     |     |     |
| --- | --- | --- |
| ![](https://techinfo.toyota.com/techInfoPortal/framework/skins/t3/details/images/tab.bar.bot.left.wht2gry.gif) | ![](https://techinfo.toyota.com/techInfoPortal/resources/images/utils/clear.png) | ![](https://techinfo.toyota.com/techInfoPortal/framework/skins/t3/details/images/tab.bar.bot.right.wht2gry.gif) | |
| |     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | TIS Content Examples |  |  |  |

TIS Content Examples

|     |
| --- |
| TIS is a robust information service that requires, for best results, modern PC hardware and reasonable Internet<br> bandwidth. Follow the system requirements link below for more details on how to optimize your experience.<br> <br> Most TIS content is provided in Adobe PDF format. If you have the PDF viewer installed, you may view some<br> example TIS articles by following the links provided below. |
| [>>Sample Repair Manual](https://techinfo.toyota.com/techInfoPortal/staticcontent/en/techinfo/html/prelogin/docs/rm.pdf) |
| [>>Sample Service Bulletin](https://techinfo.toyota.com/techInfoPortal/staticcontent/en/techinfo/html/prelogin/docs/tsb.pdf) |
| [>>Sample Electrical Wiring Diagram](https://techinfo.toyota.com/techInfoPortal/staticcontent/en/techinfo/html/prelogin/docs/ewd.pdf) |

|     |     |     |
| --- | --- | --- |
| ![](https://techinfo.toyota.com/techInfoPortal/framework/skins/t3/details/images/tab.bar.bot.left.wht2gry.gif) | ![](https://techinfo.toyota.com/techInfoPortal/resources/images/utils/clear.png) | ![](https://techinfo.toyota.com/techInfoPortal/framework/skins/t3/details/images/tab.bar.bot.right.wht2gry.gif) | | | | |

|     |     |     |
| --- | --- | --- |
| Toyota Motor Sales, Inc. | ![](https://techinfo.toyota.com/techInfoPortal/resources/images/utils/clear.png) | [Home](https://techinfo.toyota.com/techInfoPortal/appmanager/t3/ti;TISESSIONID=QgGzq02GL51ycvbvD1yqJc8v4MJ320mDK7MhQB2w6dPvyCgq2gHw!1167030303?_nfpb=true&_pageLabel=ti_home_page)  \|<br> [Contact Us](https://techinfo.toyota.com/techInfoPortal/appmanager/t3/ti;TISESSIONID=QgGzq02GL51ycvbvD1yqJc8v4MJ320mDK7MhQB2w6dPvyCgq2gHw!1167030303?_nfpb=true&_pageLabel=ti_contact_us)  \|<br> [FAQ](https://techinfo.toyota.com/techInfoPortal/appmanager/t3/ti;TISESSIONID=QgGzq02GL51ycvbvD1yqJc8v4MJ320mDK7MhQB2w6dPvyCgq2gHw!1167030303?_nfpb=true&_pageLabel=ti_faq_page)  \|<br> [System Requirements](https://techinfo.toyota.com/techInfoPortal/appmanager/t3/ti;TISESSIONID=QgGzq02GL51ycvbvD1yqJc8v4MJ320mDK7MhQB2w6dPvyCgq2gHw!1167030303?_nfpb=true&_pageLabel=ti_sys_req_page)  \|<br> [Toyota & Industry Links](https://techinfo.toyota.com/techInfoPortal/appmanager/t3/ti;TISESSIONID=QgGzq02GL51ycvbvD1yqJc8v4MJ320mDK7MhQB2w6dPvyCgq2gHw!1167030303?_nfpb=true&_pageLabel=ti_links)  \|<br> [Payments and Refunds](https://techinfo.toyota.com/techInfoPortal/appmanager/t3/ti;TISESSIONID=QgGzq02GL51ycvbvD1yqJc8v4MJ320mDK7MhQB2w6dPvyCgq2gHw!1167030303?_nfpb=true&_pageLabel=t3_payments)  \|<br> [Privacy Policy](https://techinfo.toyota.com/techInfoPortal/appmanager/t3/ti;TISESSIONID=QgGzq02GL51ycvbvD1yqJc8v4MJ320mDK7MhQB2w6dPvyCgq2gHw!1167030303?_nfpb=true&_pageLabel=t3_privacy)  \|<br> [Terms of Use](https://techinfo.toyota.com/techInfoPortal/appmanager/t3/ti;TISESSIONID=QgGzq02GL51ycvbvD1yqJc8v4MJ320mDK7MhQB2w6dPvyCgq2gHw!1167030303?_nfpb=true&_pageLabel=ti_legal) |