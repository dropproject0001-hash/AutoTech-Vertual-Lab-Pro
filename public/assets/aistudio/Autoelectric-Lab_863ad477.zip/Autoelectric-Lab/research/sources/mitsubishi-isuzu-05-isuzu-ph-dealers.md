Source: https://www.isuzuphil.com/dealers
Title: Find an Isuzu Dealer
Fetched: 2026-11-11T10:06:08.122Z

Isuzu Philippines

# Find a Dealer Near You

We will always be where you need us most.

Explore our nationwide dealer network and find one near you.

Google Map

Isuzu Alabang

4.2

( [265](https://maps.google.com/?cid=17638658349305179724&g_mp=CiVnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLkdldFBsYWNlEAMYASAF&hl=en-US&source=embed))

Reviews aren't verified by Google, but Google checks for and removes fake content when it's identified.


[Learn more](https://support.google.com/contributionpolicy/answer/7422880)

1780 Alabang-Zapote Road, Corner Acacia Ave, New Alabang Village, Muntinlupa, 1780 Metro Manila, Philippines

[Open in Maps](https://maps.google.com/?cid=17638658349305179724&g_mp=CiVnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLkdldFBsYWNlEAMYASAF)

[Get directions (opens in new tab)](https://www.google.com/maps/dir//''/data=!4m7!4m6!1m1!4e2!1m2!1m1!1s0x3397d1cf963b97bd:0xf4c91a50a8d02e4c!3e0?g_mp=CiVnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLkdldFBsYWNlEAMYASAF)

| Keystroke | Action |
| --- | --- |
| `←` | Move left |
| `→` | Move right |
| `↑` | Move up |
| `↓` | Move down |
| `+` | Zoom in |
| `-` | Zoom out |
| `Home` | Jump left by 75% |
| `End` | Jump right by 75% |
| `Page Up` | Jump up by 75% |
| `Page Down` | Jump down by 75% |

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109599!3i60226!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=22728)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109600!3i60226!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=119245)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109598!3i60226!4i256!2m3!1e0!2sm!3i803569096!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=2746)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109597!3i60224!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=52448)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109598!3i60227!4i256!2m3!1e0!2sm!3i803569096!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=70897)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109599!3i60227!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=90879)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109597!3i60225!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=120599)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109599!3i60225!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=85648)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109600!3i60224!4i256!2m3!1e0!2sm!3i803569096!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=11021)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109601!3i60224!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=31003)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109598!3i60225!4i256!2m3!1e0!2sm!3i803569096!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=65666)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109600!3i60227!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=56325)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109600!3i60225!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=51094)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109598!3i60224!4i256!2m3!1e0!2sm!3i803569096!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=128586)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109599!3i60224!4i256!2m3!1e0!2sm!3i803569096!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=45575)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109601!3i60225!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=99154)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109601!3i60227!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=104385)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109597!3i60227!4i256!2m3!1e0!2sm!3i803569096!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=22837)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109600!3i60228!4i256!2m3!1e0!2sm!3i803569096!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=21483)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109597!3i60228!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=62910)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109597!3i60226!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=57679)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109601!3i60228!4i256!2m3!1e0!2sm!3i803569096!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=69543)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109601!3i60226!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=36234)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109596!3i60226!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=9619)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109599!3i60228!4i256!2m3!1e0!2sm!3i803569096!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=56037)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109596!3i60227!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=77770)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109596!3i60224!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=4388)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109598!3i60228!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=110970)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109596!3i60228!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=14850)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i17!2i109596!3i60225!4i256!2m3!1e0!2sm!3i803569150!2m3!1e2!2sspotlit!5i1!3m13!2sen-US!3sUS!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m15!299174093m14!14m13!1m8!1m2!1y3717670706926557117!2y17638658349305179724!2s%2Fg%2F1thn30zp!4m2!1x144272383!2x1210234344!15sgcid%3Aisuzu_dealer!2b0!6b0!8b0!9b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=72539)

![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%2018%2018%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22M0%200v6h2V2h4V0zm16%200h-4v2h4v4h2V0zm0%2016h-4v2h6v-6h-2zM2%2012H0v6h6v-2H2z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%2018%2018%22%3E%3Cpath%20fill%3D%22%23333%22%20d%3D%22M0%200v6h2V2h4V0zm16%200h-4v2h4v4h2V0zm0%2016h-4v2h6v-6h-2zM2%2012H0v6h6v-2H2z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%2018%2018%22%3E%3Cpath%20fill%3D%22%23111%22%20d%3D%22M0%200v6h2V2h4V0zm16%200h-4v2h4v4h2V0zm0%2016h-4v2h6v-6h-2zM2%2012H0v6h6v-2H2z%22/%3E%3C/svg%3E)

![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2019.175%202.125-2.125%201.425%201.4L12%2022l-3.55-3.55%201.425-1.4zM4.825%2012l2.125%202.125-1.4%201.425L2%2012l3.55-3.55%201.4%201.425zm14.35%200L17.05%209.875l1.4-1.425L22%2012l-3.55%203.55-1.4-1.425zM12%204.825%209.875%206.95%208.45%205.55%2012%202l3.55%203.55-1.425%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2019.175%202.125-2.125%201.425%201.4L12%2022l-3.55-3.55%201.425-1.4zM4.825%2012l2.125%202.125-1.4%201.425L2%2012l3.55-3.55%201.4%201.425zm14.35%200L17.05%209.875l1.4-1.425L22%2012l-3.55%203.55-1.4-1.425zM12%204.825%209.875%206.95%208.45%205.55%2012%202l3.55%203.55-1.425%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%231a73e8%22%20d%3D%22m12%2019.175%202.125-2.125%201.425%201.4L12%2022l-3.55-3.55%201.425-1.4zM4.825%2012l2.125%202.125-1.4%201.425L2%2012l3.55-3.55%201.4%201.425zm14.35%200L17.05%209.875l1.4-1.425L22%2012l-3.55%203.55-1.4-1.425zM12%204.825%209.875%206.95%208.45%205.55%2012%202l3.55%203.55-1.425%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23d1d1d1%22%20d%3D%22m12%2019.175%202.125-2.125%201.425%201.4L12%2022l-3.55-3.55%201.425-1.4zM4.825%2012l2.125%202.125-1.4%201.425L2%2012l3.55-3.55%201.4%201.425zm14.35%200L17.05%209.875l1.4-1.425L22%2012l-3.55%203.55-1.4-1.425zM12%204.825%209.875%206.95%208.45%205.55%2012%202l3.55%203.55-1.425%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2010.8-4.6%204.6L6%2014l6-6%206%206-1.4%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23333%22%20d%3D%22m12%2010.8-4.6%204.6L6%2014l6-6%206%206-1.4%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2010.8-4.6%204.6L6%2014l6-6%206%206-1.4%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23d1d1d1%22%20d%3D%22m12%2010.8-4.6%204.6L6%2014l6-6%206%206-1.4%201.4z%22/%3E%3C/svg%3E)
![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m14%2018-6-6%206-6%201.4%201.4-4.6%204.6%204.6%204.6z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23333%22%20d%3D%22m14%2018-6-6%206-6%201.4%201.4-4.6%204.6%204.6%204.6z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m14%2018-6-6%206-6%201.4%201.4-4.6%204.6%204.6%204.6z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23d1d1d1%22%20d%3D%22m14%2018-6-6%206-6%201.4%201.4-4.6%204.6%204.6%204.6z%22/%3E%3C/svg%3E)
![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22M12.6%2012%208%207.4%209.4%206l6%206-6%206L8%2016.6z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23333%22%20d%3D%22M12.6%2012%208%207.4%209.4%206l6%206-6%206L8%2016.6z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22M12.6%2012%208%207.4%209.4%206l6%206-6%206L8%2016.6z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23d1d1d1%22%20d%3D%22M12.6%2012%208%207.4%209.4%206l6%206-6%206L8%2016.6z%22/%3E%3C/svg%3E)
![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2015.4-6-6L7.4%208l4.6%204.6L16.6%208%2018%209.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23333%22%20d%3D%22m12%2015.4-6-6L7.4%208l4.6%204.6L16.6%208%2018%209.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2015.4-6-6L7.4%208l4.6%204.6L16.6%208%2018%209.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2015.4-6-6L7.4%208l4.6%204.6L16.6%208%2018%209.4z%22/%3E%3C/svg%3E)
![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23666%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M440-440H200v-80h240v-240h80v240h240v80H520v240h-80z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23333%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M440-440H200v-80h240v-240h80v240h240v80H520v240h-80z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23111%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M440-440H200v-80h240v-240h80v240h240v80H520v240h-80z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23d1d1d1%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M440-440H200v-80h240v-240h80v240h240v80H520v240h-80z%22/%3E%3C/svg%3E)
![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23666%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M200-440v-80h560v80z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23333%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M200-440v-80h560v80z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23111%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M200-440v-80h560v80z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23d1d1d1%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M200-440v-80h560v80z%22/%3E%3C/svg%3E)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i12!2i3425!3i1882!4i256!2m1!1e1!3m12!2sen-US!3sUS!5e289!12m3!1e37!2m1!1ssmartmaps!12m4!1e26!2m2!1sstyles!2zcy5lOmx8cC52Om9mZg!4e0!5m1!1e3!23i47083502&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=17775)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i12!2i3424!3i1882!4i256!2m1!1e1!3m12!2sen-US!3sUS!5e289!12m3!1e37!2m1!1ssmartmaps!12m4!1e26!2m2!1sstyles!2zcy5lOmx8cC52Om9mZg!4e0!5m1!1e3!23i47083502&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=20708)

![Google](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2069%2029%22%3E%3Cg%20fill%3D%22%23fff%22%20stroke%3D%22%23fff%22%20stroke-width%3D%221.5%22%20opacity%3D%22.6%22%3E%3Cpath%20d%3D%22m17.4706%207.33616.5412-.54112-.5519-.53011c-1.3636-1.30974-3.2017-2.31971-5.7591-2.31971-4.6137%200-8.50262%203.75517-8.50262%208.39578%200%204.6407%203.88892%208.3958%208.50262%208.3958%202.4704%200%204.3765-.8188%205.8732-2.3679%201.5695-1.5729%202.0216-3.7363%202.0216-5.4119%200-.5232-.044-1.0254-.1295-1.4529l-.1206-.6029h-8.3947v3.5942h4.8301c-.1724.5966-.4321%201.0286-.7491%201.3461-.6288.6214-1.5823%201.3094-3.331%201.3094-2.65245%200-4.73598-2.1312-4.73598-4.8099%200-2.67861%202.08353-4.80981%204.73598-4.80981%201.4362%200%202.4752.5607%203.257%201.29229l.5298.49574.513-.51303z%22/%3E%3Cpath%20d%3D%22M24.8656%2020.7286c3.089%200%205.6036-2.4192%205.6036-5.6692%200-3.2681-2.5162-5.66929-5.6036-5.66929-3.0873%200-5.6035%202.40119-5.6035%205.66929%200%203.25%202.5145%205.6692%205.6035%205.6692Zm0-7.9004c1.014%200%201.9766.837%201.9766%202.2312%200%201.3805-.9653%202.2311-1.9766%202.2311-1.0099%200-1.9765-.8574-1.9765-2.2311%200-1.3874.9639-2.2312%201.9765-2.2312Z%22/%3E%3Cpath%20d%3D%22M35.7511%2017.2905h-.0042c-1.0099%200-1.9766-.8574-1.9766-2.2311%200-1.3874.964-2.2312%201.9766-2.2312%201.0139%200%201.9765.837%201.9765%202.2312%200%201.3845-.968%202.2368-1.9723%202.2311Zm-.0124%203.4381c3.089%200%205.6035-2.4192%205.6035-5.6692%200-3.2681-2.5162-5.66929-5.6035-5.66929-3.0874%200-5.6036%202.40119-5.6036%205.66929%200%203.2508%202.5236%205.6692%205.6036%205.6692Z%22/%3E%3Cpath%20d%3D%22M51.953%2010.4357v-.74997h-3.5531v.12253c-.55-.26178-1.2022-.42639-1.9191-.42639-2.8837%200-5.464%202.51793-5.464%205.69393%200%202.1269%201.164%203.9479%202.8033%204.9137l-.0658.0273-1.8806.7802-.6929.2874.2876.6928c.6228%201.5004%202.2776%203.3697%205.0535%203.3697%201.4105%200%202.787-.4145%203.814-1.4093%201.0332-1.0009%201.6171-2.4965%201.6171-4.4653zm-7.2194%209.9844-.0002-.0005c.5552.2005%201.1446.309%201.7474.309.6808%200%201.3058-.1467%201.841-.3891-.0876.3891-.2417.671-.4252.8682-.2812.3022-.7202.5011-1.3747.5011-.91190000000001%200-1.5201-.6476-1.7883-1.2887Zm1.9361-7.5919c.9722%200%201.878.8483%201.878%202.2558%200%201.3796-.8956%202.2147-1.878%202.2147-1.0428%200-1.993-.8738-1.993-2.2147%200-1.3754.9595-2.2558%201.993-2.2558Zm9.069-7.60737v-.75h-3.6599V20.4412h3.6599z%22/%3E%3Cpath%20d%3D%22m63.9128%2016.0614-.6183-.4122-.4179.6145c-.4562.6709-1.0102%201.0432-1.8025%201.0432-.4306%200-.7595-.0981-1.0197-.2622-.07-.0441-.1383-.0951-.2046-.1536l5.6999-2.3625.6825-.283L65.9596%2013.5589l-.219-.5514c-.4528-1.2075-1.8899-3.60918-4.9128-3.60918-2.9833%200-5.3244%202.36358-5.3244%205.66928%200%203.1475%202.3222%205.6693%205.5625%205.6693%202.6043%200%204.1111-1.5991%204.7283-2.5156l.421-.625L65.5882%2017.1783zm-2.5667-3.2103-1.9353.8015c.3795-.5743%201.0107-.8572%201.4909-.8572.1653%200%20.3136.0207.4444.0557Z%22/%3E%3C/g%3E%3Cpath%20fill%3D%22%234285f4%22%20d%3D%22M11.7008%2019.9868c-4.21304%200-7.75262-3.4328-7.75262-7.6458%200-4.21297%203.53958-7.64578%207.75262-7.64578%202.3323%200%203.9912.91159%205.2395%202.11061l-1.47%201.47003c-.8952-.83767-2.1106-1.49467-3.7695-1.49467-3.07972%200-5.48598%202.48016-5.48598%205.55981%200%203.0797%202.40626%205.5599%205.48598%205.5599%201.9956%200%203.1289-.8048%203.8598-1.5275.5995-.5996.9855-1.4537%201.1333-2.628h-4.9931v-2.0942h7.0298c.0739.3695.115.8212.115%201.3058%200%201.5685-.427%203.5067-1.8067%204.8864-1.3469%201.3961-3.0551%202.1434-5.3381%202.1434%22/%3E%3Cpath%20fill%3D%22%23e94235%22%20d%3D%22M29.7192%2015.0594c0%202.8333-2.1763%204.9192-4.8536%204.9192-2.6772%200-4.8535-2.0859-4.8535-4.9192%200-2.8498%202.1763-4.9193%204.8535-4.9193%202.6773%200%204.8536%202.0695%204.8536%204.9193m-2.127%200c0-1.7739-1.2648-2.9812-2.7266-2.9812s-2.7265%201.2155-2.7265%202.9812c0%201.7492%201.2647%202.9811%202.7265%202.9811s2.7266-1.2237%202.7266-2.9811%22/%3E%3Cpath%20fill%3D%22%23fabb05%22%20d%3D%22M40.5922%2015.0594c0%202.8333-2.1763%204.9192-4.8535%204.9192-2.6691%200-4.8536-2.0859-4.8536-4.9192%200-2.8498%202.1763-4.9193%204.8536-4.9193%202.6772%200%204.8535%202.0695%204.8535%204.9193m-2.1188%200c0-1.7739-1.2647-2.9812-2.7265-2.9812s-2.7266%201.2155-2.7266%202.9812c0%201.7492%201.2648%202.9811%202.7266%202.9811%201.4618.0082%202.7265-1.2237%202.7265-2.9811%22/%3E%3Cpath%20fill%3D%22%234285f4%22%20d%3D%22M51.203%2010.4357v8.8366c0%203.6382-2.1435%205.1246-4.6811%205.1246-2.3899%200-3.8188-1.6014-4.3609-2.9072l1.8807-.7802c.3367.8048%201.158%201.7493%202.4802%201.7493%201.626%200%202.628-1.0101%202.628-2.8908v-.7063h-.074c-.4845.5995-1.4207%201.1169-2.5951%201.1169-2.4637%200-4.714-2.1434-4.714-4.9028%200-2.7758%202.2585-4.9439%204.714-4.9439%201.1744%200%202.1106.5256%202.5951%201.1004h.074v-.7966zm-1.9053%204.6483c0-1.7328-1.158-3.0058-2.628-3.0058-1.4947%200-2.743%201.2647-2.743%203.0058%200%201.7164%201.2483%202.9647%202.743%202.9647%201.47%200%202.628-1.2483%202.628-2.9647%22/%3E%3Cpath%20fill%3D%22%2334a853%22%20d%3D%22M54.9887%205.22083V19.6912h-2.1599V5.22083z%22/%3E%3Cpath%20fill%3D%22%23e94235%22%20d%3D%22m63.4968%2016.6854%201.6754%201.1169c-.5421.8049-1.8478%202.1846-4.1063%202.1846-2.8004%200-4.8125-2.1599-4.8125-4.9193%200-2.9237%202.0367-4.9193%204.5744-4.9193%202.554%200%203.8023%202.0285%204.213%203.129l.2217.5584-6.5782%202.7266c.501.9855%201.2894%201.4946%202.3898%201.4946%201.1005%200%201.8643-.5502%202.4227-1.3715m-5.1656-1.7739%204.4019-1.8231c-.2464-.616-.9691-1.043-1.8314-1.043-1.1005%200-2.628.9691-2.5705%202.8661%22/%3E%3C/svg%3E)

Keyboard shortcuts

Map DataMap data ©2026 Google

Map data ©2026 Google

50 m

Click to toggle between metric and imperial units

[Terms](https://www.google.com/intl/en-US_US/help/terms_maps.html)

[Report a map error](https://www.google.com/maps/@14.4272383,121.0234344,17z/data=!10m1!1e1!12b1?source=apiv3&rapsrc=apiv3 "Report errors in the road map or imagery to Google")

Search by City:

USE MY LOCATION


Or Search by the City

#ABCDEILMNPQRSTVZ

### Isuzu Alabang

1780 Alabang-Zapote RoadCorner Acacia Avenue, Ayala Alabang, Muntinlupa City

Contacts:

PARTS - (02) 88071788 Loc 8808


SALES - (02) 88071788 Loc 8709


SERVICE - (02) 88071788 Loc 8806


TRUNKLINE / CUSTOMER RELATIONS - (02) 88071788 loc 8802


Sales

SALES - (0997) 781-5278


SERVICE ADMIN / APPOINTMENT - (0921) 2298139


PARTS - (0917) 8074194


Customer Relations

CUSTOMER RELATIONS - (0999) 8852986 / (0917) 8114607


Parts Counter & Accessories:

[ialb.partsanalyst@acmobility.ph](mailto:ialb.partsanalyst@acmobility.ph)

Customer Relations:

[ialb.crd@acmobility.ph](mailto:ialb.crd@acmobility.ph)

Service:

[ialb.serviceadmin@acmobility.ph](mailto:ialb.serviceadmin@acmobility.ph)

Sales:

[ialb.salesadmin@acmobility.ph](mailto:ialb.salesadmin@acmobility.ph)

Warranty:

[ialb.warranty@acmobility.ph](mailto:ialb.warranty@acmobility.ph)

Parts Counter & Accessories:

[ialb.parts@acmobility.ph](mailto:ialb.parts@acmobility.ph)

Website: [http://isuzuautodealer.com.ph](http://isuzuautodealer.com.ph/)

Website: [http://isuzuautodealer.com.ph](http://isuzuautodealer.com.ph/)

### Isuzu Bacolod

Gen. Lacson St., Mandalagan, Bacolod City 6100

Contacts:

Landline - (034) 441-2050
/ (034) 441-2584


Trunkline - (034) 441-1876


Customer Relations

Customer Relations - 0985-8585530 - 0954-9805838


Sales:

[isuzubacolod@hotmail.com](mailto:isuzubacolod@hotmail.com)

CRT:

[crosamtcbcd@gmail.com](mailto:crosamtcbcd@gmail.com)

Website: [http://isuzuautodealer.com.ph](http://isuzuautodealer.com.ph/)

Website: [http://isuzuautodealer.com.ph](http://isuzuautodealer.com.ph/)

### Isuzu Bacoor

4652-B Molino Boulevard, Brgy. Bayanan, Bacoor City, Cavite 4102

Contacts:

CUSTOMER RELATIONS - (046) 4198550 (02) 84245200 Loc 700


PARTS - (046) 4198550 (02) 84245200 Loc 723


SALES - (046) 4198550 (02) 84245200 Loc 713 to 715


SERVICE - (046) 4198550 (02) 84245200 Loc 741 to 745


TRUNKLINE - Cavite Line (046) 4198550 Manila Line (02) 84245200


Sales

SERVICE ADMIN / APPOINTMENT - (0917) 8695955 / (0998) 9600387


Customer Relations

CUSTOMER RELATIONS - (0917) 8114507


Warranty:

[ibac.warranty@acmobility.ph](mailto:ibac.warranty@acmobility.ph)

Customer Relation:

[ibac.crd@acmobility.ph](mailto:ibac.crd@acmobility.ph)

Parts Counter & Accessories:

[ibac.parts@acmobility.ph](mailto:ibac.parts@acmobility.ph)

Service:

[ibac.serviceadmin@acmobility.ph](mailto:ibac.serviceadmin@acmobility.ph)

Sales:

[ibac.salesadmin@acmobility.ph](mailto:ibac.salesadmin@acmobility.ph)

Parts Counter & Accessories:

[ibac.partscounter@acmobility.ph](mailto:ibac.partscounter@acmobility.ph)

Website: [http://www.isuzuautodealer.com.ph](http://www.isuzuautodealer.com.ph%20/)

Facebook: [Isuzu Bacoor](https://www.facebook.com/isuzubacoor.iadi)

Website: [http://www.isuzuautodealer.com.ph](http://www.isuzuautodealer.com.ph/)

### Isuzu Baguio

Naguilian Road Corner Sophia Quezon Hill Proper, Baguio City 2600

Contacts:

\- (074) 661-7989


Sales

\- 0916-9444920
/ 0950-8125409


Customer Relations:

[croisuzuurdaneta@gmail.com](mailto:croisuzuurdaneta@gmail.com)

Website: [http://www.intecophil.com/inteco\_Baguio.html](http://www.intecophil.com/inteco_Baguio.html)

Website: [http://www.intecophil.com/inteco\_Baguio.html](http://www.intecophil.com/inteco_Baguio.html)

### Isuzu Batangas (Sto. Tomas)

Crossing Barrio San Roque, Sto. Tomas, Batangas 4234

Contacts:

Manila Line - (02) 8584-4783


Sales - (043) 778-1227


Service / Parts - (043) 778-1225


Sales

Sales - 0908- 380-9109


Parts - 0946-5715435


Customer Relations - 0998-4215653/0906-3018877


Service - 0922-8662005 / 0947-7556366 / 0905-4457888


Customer Relation:

[cro.isuzubatangas@gmail.com](mailto:cro.isuzubatangas@gmail.com)

Sales:

[isuzumarketing.batangas@gmail.com](mailto:isuzumarketing.batangas@gmail.com)

Service:

[admservice\_isuzubatangas@yahoo.com](mailto:admservice_isuzubatangas@yahoo.com)

Facebook: [www.facebook.com/gencarsbatangas](https://www.facebook.com/gencarsbatangas)

Instagram: [www.instagram.com/isuzu\_batangas](https://www.instagram.com/isuzu_batangas)

Website: [www.isuzubatangas.com](http://www.isuzubatangas.com/)

Website: [http://www.isuzubatangas.com](http://www.isuzubatangas.com/)

### Isuzu Batangas City

9008 Diversion Road, Alangilan, Batangas City

Contacts:

Manila Line - (02) 8584-4118


Sales / Service / Parts / Customer Relation - (043) 702-2091


Service / Parts / Customer Relation - (043) 774-4099


Sales:

[marketing.isuzubatangascity@gmail.com](mailto:marketing.isuzubatangascity@gmail.com)

Service:

[admnservice.isuzugencarsbats16@gmail.com](mailto:admnservice.isuzugencarsbats16@gmail.com)

Parts:

[ato\_jaycee@yahoo.com](mailto:ato_jaycee@yahoo.com)

Facebook: [www.facebook.com/GencarsBatangasCity](https://www.facebook.com/GencarsBatangasCity/)

Instagram: [www.instagram.com/isuzubatangascity](https://www.instagram.com/isuzubatangascity/)

Website: [http://www.isuzubatangascity.com](http://www.isuzubatangascity.com/)

Website: [http://www.isuzubatangascity.com](http://www.isuzubatangascity.com/)

### Isuzu Bohol

CPG North Avenue, Cogon District, Tagbilaran City, Bohol 6300

Contacts:

Customer Relations - (032) 3463090


Sales / Service / Parts - (038) 4124253


TrunkLine - (038) 4120098


Sales

Sales - (0970) 8124694


Service Admin / Appointment - 0992-927-6426 / 0999-975-9116


Parts - 09925257589


Customer Relation:

[imde.crd@acmobility.ph](mailto:imde.crd@acmobility.ph)

Sales:

[iboh.salesadmin@acmobility.ph](mailto:iboh.salesadmin@acmobility.ph)

Service:

[iboh.servicemarketing@acmobility.ph](mailto:iboh.servicemarketing@acmobility.ph)

Parts Counter & Accessories:

[iboh.parts@acmobility.ph](mailto:iboh.parts@acmobility.ph)

Website: [https://acmobility.ph/](https://acmobility.ph/)

### Isuzu Bulacan

Km. 40 Cagayan Valley Road, Tabang, Plaridel, Bulacan 3004

Contacts:

\- (044) 795-2342


Marketing - (044) 760-0004


Sales - 044-795-1378


Sales

Sales and Marketing - 0917-572-5513 / 0922-856-1315


Services

\- 0922-809-2156 / 0917-572-1222


Parts - 09437052257


Sales:

[sales-bulacan@bmdmotors.com](mailto:sales-bulacan@bmdmotors.com)

Service:

[service-bulacan@bmdmotors.com](mailto:service-bulacan@bmdmotors.com)

Parts:

[parts-inquiry@bmdmotors.com](mailto:parts-inquiry@bmdmotors.com)

Customer Relations Team:

[crt-bulacan@bmdmotors.com](mailto:crt-bulacan@bmdmotors.com)

### Isuzu Butuan

Brgy. Baan Km3, Butuan City 8600

Contacts:

\- (085) 818-6811


Sales

\- 0956-0968838 and 0939-267-2398


Sales:

[isuzubtn@yahoo.com](mailto:isuzubtn@yahoo.com)

Service:

[isuzubtn@gmail.com](mailto:isuzubtn@gmail.com)

Customer Relations Team:

[isuzubtncrt@gmail.com](mailto:isuzubtncrt@gmail.com)

### Isuzu Cabanatuan

Km. 109 Sumacab Este, Maharlika Highway, Cabanatuan City Nueva Ecija 3100

Sales

Sales - 0961-2089460


Service / Customer Relations - 0917-6226750 / 0923-7433815 / 044-463-8214


Parts - 0966-8873281 / 0923-7433814


Sales Admin:

[sales-cabanatuan@bmdmotors.com](mailto:sales-cabanatuan@bmdmotors.com)

Service:

[service-cabanatuan@bmdmotors.com](mailto:service-cabanatuan@bmdmotors.com)

Customer Relations:

[crt-cabanatuan@bmdmotors.com](mailto:crt-cabanatuan@bmdmotors.com)

Parts:

[parts-cabanatuan@bmdmotors.com](mailto:parts-cabanatuan@bmdmotors.com)

Facebook: [https://www.facebook.com/IsuzuCabanatuanOfficial/](https://www.facebook.com/IsuzuCabanatuanOfficial/)

Website: [http://www.bmdmotors.com](http://www.bmdmotors.com/)

### Isuzu Cagayan De Oro

National Highway, Lapasan, Cagayan de Oro City 9000

Contacts:

Trunkline - (088) 856-1892


Sales

Sales - 0916-3614457


Service - 0905-5232706 / 0977-1135312


Customer Relations - 0905-3664612


Parts - 0915-4337542


Sales:

[isuzucdo@gmail.com](mailto:isuzucdo@gmail.com)

Customer Relations:

[nmadicdoservice@isuzunmadi.ph](mailto:nmadicdoservice@isuzunmadi.ph)

Parts:

[parts\_cdo@yahoo.com.ph](mailto:parts_cdo@yahoo.com.ph)

### Isuzu Calapan

Km. 9 Nautical Highway, Puting Tubig National Highway, Calapan City, Oriental Mindoro, 5200

Sales

Customer Service - 0926-7230988 / 09209769552


Service - 0998-4269542


Parts - 0963-7330963


Sales - 0917-8830488


Sales:

[kathleene.velasquez@isuzucalapan.com](mailto:kathleene.velasquez@isuzucalapan.com)

Service:

[kimberly.dejaro@isuzucalapan.com](mailto:kimberly.dejaro@isuzucalapan.com)

Parts:

[ronio.deroxas@isuzucalapan.com](mailto:ronio.deroxas@isuzucalapan.com)

Insurance Claim (Body Repair):

[sales.admin@isuzucalapan.com](mailto:sales.admin@isuzucalapan.com)

Customer Relations:

[customer.service@isuzucalapan.com](mailto:customer.service@isuzucalapan.com)

Facebook: [Isuzu Calapan-Mina De Oro Motors Incorporated](https://www.facebook.com/IsuzuCalapanOfficial)

Instagram: [isuzucalapanofficial](https://www.instagram.com/isuzucalapanofficial/)

### Isuzu Cebu

A. Soriano Avenue, North Reclamation Area, Cebu City, Cebu 6000

Contacts:

\- (032) 384 9498


Sales

Customer Relations - (0917) 5849033


Service Admin / Appointment - (0908) 3110039


Sales:

[iceb.salesadmin@acmobility.ph](mailto:iceb.salesadmin@acmobility.ph)

Service:

[iceb.serviceadmin@acmobility.ph](mailto:iceb.serviceadmin@acmobility.ph)

Customer Relation:

[iceb.crd@acmobility.ph](mailto:iceb.crd@acmobility.ph)

Parts Counter & Accessories:

[iceb.parts@acmobility.ph](mailto:iceb.parts@acmobility.ph)

Warranty:

[iceb.warranty@acmobility.ph](mailto:iceb.warranty@acmobility.ph)

Website: [https://acmobility.ph](https://acmobility.ph/)

### Isuzu Cebu South

South Road, Calajoan, Minglanilla, Cebu 6046

Contacts:

Customer Relations - (032) 2340471 Loc 110


Sales - (032) 2727138 Loc 107


TrunkLine - (032) 272 7138


Sales

Customer Relations - (0917) 5849033


Service Admin / Appointment / Warranty - 0995 194 8006 Globe 0922 239 1779 Sun


Service:

[iceb.serviceadmin@acmobility.ph](mailto:iceb.serviceadmin@acmobility.ph)

Customer Relation:

[iceb.crd@acmobility.ph](mailto:iceb.crd@acmobility.ph)

Parts Counter & Accessories:

[iceb.parts@acmobility.ph](mailto:iceb.parts@acmobility.ph)

Warranty:

[iceb.warranty@acmobility.ph](mailto:iceb.warranty@acmobility.ph)

Sales:

[gulane.lp@acmobility.ph](mailto:gulane.lp@acmobility.ph)

Sales:

[icebsouth.salesadmin@acmobility.ph](mailto:icebsouth.salesadmin@acmobility.ph)

Website: [https://acmobility.ph](https://acmobility.ph/)

### Isuzu Commonwealth

Villanueva Drive corner Commonwealth Avenue Old Balara, Quezon City, 1121

Contacts:

Customer Relations - (02) 8952-2764


Parts - (02) 8952-2762


Sales - (02) 8952-2760/68


Service - (02) 8952-2766 / (02) 8952-2763


Sales

Sales - 0919-9938368


Service - 0918-9900649 / 0918-9929261


Customer Relations - 0917-6359109


Sales:

[sales\_icw@ygccars.com](mailto:sales_icw@ygccars.com)

Parts:

[dmmanaois@ygccars.com](mailto:dmmanaois@ygccars.com)

Service:

[service\_icw@ygccars.com](mailto:service_icw@ygccars.com)

Customer Relations:

[customer-relations\_icw@ygccars.com](mailto:customer-relations_icw@ygccars.com)

### Isuzu Dagupan

Brgy. II (Nueva), Rizal St., Dagupan City

Contacts:

Sales - (075) 636-9598


Customer Relations:

[croisuzuurdaneta@gmail.com](mailto:croisuzuurdaneta@gmail.com)

Website: [isuzuintecogroup.com](https://www.isuzuphil.com/isuzuintecogroup.com)

### Isuzu Dasmariñas

Lot 3869-N-6-A Gen. Emilio Aguinaldo Highway, Brgy. Sampaloc 1, Dasmariñas City, Cavite 4114

Contacts:

TRUNKLINE - (046) 866 7300
/ (046) 866 7306
/ (046) 866 7050


Warranty:

[ibac.warranty@acmobility.ph](mailto:ibac.warranty@acmobility.ph)

Customer Relation:

[ibac.crd@acmobility.ph](mailto:ibac.crd@acmobility.ph)

Parts Counter & Accessories:

[ibac.parts@acmobility.ph](mailto:ibac.parts@acmobility.ph)

Service:

[ibac.serviceadmin@acmobility.ph](mailto:ibac.serviceadmin@acmobility.ph)

Sales:

[ibac.salesadmin@acmobility.ph](mailto:ibac.salesadmin@acmobility.ph)

Parts Counter & Accessories:

[ibac.partscounter@acmobility.ph](mailto:ibac.partscounter@acmobility.ph)

Website: [https://acmobility.ph](https://acmobility.ph/)

Facebook: [Isuzu Cavite - Iconic Dealership Inc.](https://www.facebook.com/isuzucaviteofficial)

Website: [http://www.isuzuautodealer.com.ph](http://www.isuzuautodealer.com.ph/)

### Isuzu Davao

122 MacArthur Highway, SMDI Building, Matina, Davao City 8000

Contacts:

Parts - (082) 297-3344 local 303 / (082) 297-8855


Sales - (075) 636-9598


Service - (082) 297-3344 local 207 / (082) 297-8866


Sales

Sales - 0917-123-1656


Parts - 0917-702-9526 (Globe); 0919-085-6768 (Smart)


Services

Service - 0908-885-9813 (Smart) ; 0908-885-9814 (Smart); 0917-822-7748 (Globe)


Sales:

[isuzu\_davao@yahoo.com](mailto:isuzu_davao@yahoo.com)

CRT:

[isuzudavaocustomerservice@yahoo.com](mailto:isuzudavaocustomerservice@yahoo.com)

Service:

[smdiservice@yahoo.com](mailto:smdiservice@yahoo.com)

Parts:

[smdi\_parts@yahoo.com](mailto:smdi_parts@yahoo.com)

Website: [http://www.facebook.com/pages/Isuzu-Davao-Southern-Motors-of-Davao-Inc/178760412179009](https://www.facebook.com/pages/Isuzu-Davao-Southern-Motors-of-Davao-Inc/178760412179009)

### Isuzu Dipolog

National Highway, Minaog, Dipolog City

Sales

Globe - (0995)161 8483


Smart - (0928) 970 4829


### Isuzu Dumaguete

Lot 541D 541C 541B, Brgy. Bajumpandan, Dumaguete City

Contacts:

\- (035) 522-3641


Sales:

[isuzudumaguete@hotmail.com](mailto:isuzudumaguete@hotmail.com)

### Isuzu EDSA

1127 EDSA BALINTAWAK, BRGY. APOLONIO SAMSON, QUEZON CITY 1100

Sales

Parts and Service - 09150681447


Customer Relations:

[croisuzuurdaneta@gmail.com](mailto:croisuzuurdaneta@gmail.com)

Website: [http://www.isuzuintecogroup.com](http://www.isuzuintecogroup.com/)

### Isuzu General Santos

National Highway, MTL Building, Barangay Labangal, General Santos City 9500

Contacts:

Trunk line - (083) 552-2255
/ (083) 552-2277
/ (083) 522-2299


Sales

Globe - (0917) 712 1188


Sun - (0922) 822 9091


Sales:

[isuzugensan@yahoo.com](mailto:isuzugensan@yahoo.com)

Service:

[isuzugensan\_service@yahoo.com](mailto:isuzugensan_service@yahoo.com)

### Isuzu Iguig

National H-way Brgy. Sta. Teresa Iguig, Cagayan 3504

Contacts:

Trunkline - (078) 844-4758


Sales

Sales - 0917-5221-385


Service & Parts - 0917-8429-556


Customer Relations Team:

[crt-iguig@bmdmotors.com](mailto:crt-iguig@bmdmotors.com)

### Isuzu Iloilo

Benigno Aquino Avenue, Mandurriao, Iloilo City, Iloilo 5000

Contacts:

Parts - (033) 323-1641


Service - (033) 3203459


Sales

Customer Relations - (0977) 2178442


Telemarketer / Appointment - (0977) 6027495 (0961) 4173321


Parts - (0927) 7308973


Sales:

[iic.salesadmin@acmobility.ph](mailto:iic.salesadmin@acmobility.ph)

Service:

[iic.serviceadmin@acmobility.ph](mailto:iic.serviceadmin@acmobility.ph)

Customer Relation:

[iic.customerrelations@acmobility.ph](mailto:iic.customerrelations@acmobility.ph)

Parts Counter and Accessories:

[iic.parts@acmobility.ph](mailto:iic.parts@acmobility.ph)

Warranty:

[iic.warranty@acmobility.ph](mailto:iic.warranty@acmobility.ph)

Website: [https://acmobility.ph](https://acmobility.ph/)

Website: [http://www.isuzuautodealer.com.ph](http://www.isuzuautodealer.com.ph/)

### Isuzu Isabela

349 Maharlika Highway, San Fermin, Cauayan City, Isabela 3305

Contacts:

Sales - (078) 652 5430


Service & Parts - (078) 652-3142


Trunkline - (078) 652-2030


Sales

Sales - 0917-5725514


Service - 0917-5648829


Service & Parts - 0927-2939893


Sales:

[sales-isabela@bmdmotors.com](mailto:sales-isabela@bmdmotors.com)

Service:

[service-isabela@bmdmotors.com](mailto:service-isabela@bmdmotors.com)

Customer Relations Team:

[crt-isabela@bmdmotors.com](mailto:crt-isabela@bmdmotors.com)

Parts:

[parts-isabela@bmdmotors.com](mailto:parts-isabela@bmdmotors.com)

### Isuzu La Union

Paringao, Bauang, La Union

Sales

Sales - 09173024186/0967-624-9802


Services

\- 0917-718-0086


Customer Relations

Parts - 0931-827-0569


Sales:

[onemaharlikaipc@gmail.com](mailto:onemaharlikaipc@gmail.com)

Customer Relations:

[customerrelations.isuzulaunion@gmail.com](mailto:customerrelations.isuzulaunion@gmail.com)

Sales:

[markvivienchiu06@gmail.com](mailto:markvivienchiu06@gmail.com)

Sales:

[apostolovely@gmail.com](mailto:apostolovely@gmail.com)

Facebook: [www.facebook.com/isuzulaunionofficials](https://www.facebook.com/isuzulaunionofficials)

### Isuzu Legazpi

G/F ALC Fortune Bldg., Rizal St., Legazpi City, Albay

Sales

Sales - 0945-5592056


Service and Parts - 0953-9481906


Service and Parts:

[isuzulegazpi@gmail.com](mailto:isuzulegazpi@gmail.com)

Sales:

[isuzulegaspisales@gmail.com](mailto:isuzulegaspisales@gmail.com)

Facebook: [Gencars Legazpi, Inc. - Isuzu Legazpi](https://www.facebook.com/isuzugencarslegazpi)

Instagram: [isuzulegazpi](https://www.instagram.com/isuzulegazpi/)

Website: [http://www.isuzulegazpi.com](http://www.isuzulegazpi.com/)

### Isuzu Leyte

Brgy. 77 Fatima Village Marasbaras Tacloban City, Leyte 6500

Contacts:

Landline numbers - (053) 523-0032 or (053) 888-5759


Sales

Customer Relations Officer - 0919-0640193


Service - 0919-9938320


Parts - 0912-5391949


Sales - 0917-3147057


Customer Relations Officer:

[jrdorimon@ygccars.com](mailto:jrdorimon@ygccars.com)

Parts:

[aglacdaying@ygccars.com](mailto:aglacdaying@ygccars.com)

Facebook: [ISUZU LEYTE – YGC Group](https://www.facebook.com/IsuzuleyteOfficial)

### Isuzu Makati

2113 Chino Roces Avenue, Corner Dela Rosa Street, Makati City 1200

Contacts:

Connecting all departments - 8819-1219
/ 8819-1213
/ 8893-8963
/ 8893-1664
/ 8893-8895
/ 8893-1673


Parts - 0961-567-1969


Sales - (02)-8819-1219


Sales

Sales - 0922-866-2002
/ 0929-314-1841
/ 0915-596-9138


Parts - 0956-567-5839


Customer Relations - 0945-849-0572
/ 0921-646-3680


Services

\- 0906-572-7073
/ 0920-222-5541


Customer Relations

Service / Customer Relation - 09216463680


Sales:

[salesadmin-makati@isuzugencars.com](mailto:salesadmin-makati@isuzugencars.com)

Service / Parts:

[salesadmin-makati@isuzugencars.com](mailto:salesadmin-makati@isuzugencars.com)

Customer Relation:

[customerservice-makati@isuzugencars.com](mailto:customerservice-makati@isuzugencars.com)

Sales:

[salesadmin-makati@isuzugencars.com](mailto:salesadmin-makati@isuzugencars.com)

Facebook: [www.facebook.com/isuzugencars](https://www.facebook.com/isuzugencars)

Instagram: [www.instagram.com/isuzugencarsmakati/](https://www.instagram.com/isuzugencarsmakati/)

Website: [http://www.isuzumakati.com](http://www.isuzumakati.com/)

### Isuzu Mandaluyong

351 Shaw Blvd, Mandaluyong City, Metro Manila

Contacts:

Parts - (02) 5322-1033 Loc 1124


Sales - (02) 5322-1033 Loc 1121


Service - (02) 8354-0825


Sales

Service Appointment - 0955-1125727


Service Advisor - 0948-9744007


Parts Counter - 0961-4346395


Sales:

[imnd.salesadmin@idi.acmobility.ph](mailto:imnd.salesadmin@idi.acmobility.ph)

Service Admin:

[imnd.serviceadmin@acmobility.ph](mailto:imnd.serviceadmin@acmobility.ph)

Service Advisor:

[delossantos.vt@acmobility.ph](mailto:delossantos.vt@acmobility.ph)

Parts Counter:

[imnd.partscounter@acmobility.ph](mailto:imnd.partscounter@acmobility.ph)

Customer Relations:

[ipsg.crd@acmobility.ph](mailto:ipsg.crd@acmobility.ph)

Website: [https://www.acmobility.ph](https://www.acmobility.ph/)

### Isuzu Mandaue

North Highway, Jagobiao Road, Mandaue City, Cebu 6014

Contacts:

Customer Relations - (032) 3463090 Loc 832


Parts - (032) 3463090 Loc 845


Sales - (032) 3463090 Loc 848


Service - (032) 3463090 Loc 838


TrunkLine - (032) 3463090 / (032) 4222288


Sales

Sales (Mobile/Viber) - (0945) 9806144


Service Admin / Appointment / Parts - (0905) 5632047


Sales:

[iman.salesadmin@acmobility.ph](mailto:iman.salesadmin@acmobility.ph)

Service:

[iman.serviceadmin@acmobility.ph](mailto:iman.serviceadmin@acmobility.ph)

Customer Relation:

[imde.crd@acmobility.ph](mailto:imde.crd@acmobility.ph)

Parts Counter and Accessories:

[iman.partscounter@acmobility.ph](mailto:iman.partscounter@acmobility.ph)

Warranty:

[iman.warranty@acmobility.ph](mailto:iman.warranty@acmobility.ph)

Facebook Page: [Isuzu Cebu Inc.- Mandaue Branch](https://www.facebook.com/IsuzuMandaueOfficial)

Website: [https://acmobility.ph](https://acmobility.ph/)

Website: [http://www.isuzuautodealer.com.ph](http://www.isuzuautodealer.com.ph/)

### Isuzu Manila

1502 Paz Guazon Street, Paco, Manila

Contacts:

Trunkline - (02)562-4601 / (0998) 966-7291 / (0917) 327-9906


Sales

Service by Appointment - +639209104739


Sales - 0919-0876395


Service & Parts - 09989667291


Customer Relations

\- 0999-9931549


Sales:

[sales\_ima@ygccars.com](mailto:sales_ima@ygccars.com)

Service:

[service\_ima@ygccars.com](mailto:service_ima@ygccars.com)

Customer Relations Team:

[customer-relations\_ima@ygccars.com](mailto:customer-relations_ima@ygccars.com)

Isuzu Manila: [https://www.facebook.com/isuzumanila.ph/](https://www.facebook.com/isuzumanila.ph/)

Website: [http://www.isuzumanila.com](http://www.isuzumanila.com/)

### Isuzu Meycauayan

Purok Maligaya, Bulak Road, Malhacan, Meycauayan, Bulacan

Sales

Sales - 0922-823-1327


Services

\- 0917-811-2512


Sales:

[sales-meycauayan@bmdmotors.com](mailto:sales-meycauayan@bmdmotors.com)

Parts:

[parts-meycauayan@bmdmotors.com](mailto:parts-meycauayan@bmdmotors.com)

Service:

[service-meycauayan@bmdmotors.com](mailto:service-meycauayan@bmdmotors.com)

### Isuzu Naga

Km. 443 Maharlika Highway, Palestina, Pili, Camarines Sur

Contacts:

Sales / Service / Parts - (054) 477-8886


Telefax - (054) 477- 2177


Sales

Sales - 0927-018-9912


Service / Parts - 0942-611-5502
/ 0977-124-9114


Sales:

[isuzunagasales@gmail.com](mailto:isuzunagasales@gmail.com)

Service:

[isuzunaga\_service@yahoo.com](mailto:isuzunaga_service@yahoo.com)

Parts:

[isuzu.nagaparts@gmail.com](mailto:isuzu.nagaparts@gmail.com)

Facebook: [www.facebook.com/IsuzuGencarsNaga](https://www.facebook.com/IsuzuGencarsNaga/)

Instagram: [www.instagram.com/isuzu\_naga](https://www.instagram.com/isuzu_naga/)

Website: [http://www.isuzunaga.com](http://www.isuzunaga.com/)

### Isuzu Pagadian

Brgy. Tiguma, Pagadian City, Zamboanga del Sur

Contacts:

Contact Number - 062-945-4165


Email:

[isuzu.pagadian@yahoo.com](mailto:isuzu.pagadian@yahoo.com)

### Isuzu Pampanga

Olongapo-Gapan Road, Dolores, City of San Fernando, Pampanga 2000

Sales

\- 0905 7710408
/ 0920 06004435


Service:

[service\_dept\_isuzu\_pamp@yahoo.com](mailto:service_dept_isuzu_pamp@yahoo.com)

Customer Relations:

[intecopamp.cro@yahoo.com](mailto:intecopamp.cro@yahoo.com)

Website: [http://www.intecophil.com](http://www.intecophil.com/)

### Isuzu Pangasinan

National Highway, Brgy. Tulong, Urdaneta City, Pangasinan

Customer Relations

\- 0981-6856330
/ 0929-2823950


Customer Relations:

[croisuzuurdaneta@gmail.com](mailto:croisuzuurdaneta@gmail.com)

Website: [http://www.intecophil.com](http://www.intecophil.com/)

### Isuzu Pasig

E. Rodriguez Jr. Avenue, Corner Calle Industria, Brgy. Bagumbayan, Quezon City 1110

Contacts:

CUSTOMER RELATIONS - (02) 86713434 Loc 727


PARTS - (02) 86319318


SALES - (02) 86713434 Loc 715 & 717


SERVICE - (02) 82432945


TRUNKLINE - (02) 8671 3434


Sales

CUSTOMER RELATIONS - (0917) 8114453 / (0999) 8852987


SALES - (0917) 8358286 / (0998) 9624590


PARTS - 09972944094


Customer Relations

SERVICE ADMIN / APPOINTMENT - (0917) 8474679 / (0960) 4577359


Customer Relations:

[ipsg.crd@acmobility.ph](mailto:ipsg.crd@acmobility.ph)

Service:

[ipsg.serviceadmin@acmobility.ph](mailto:ipsg.serviceadmin@acmobility.ph)

Sales:

[sblondon@isuzupasig.com](mailto:sblondon@isuzupasig.com)

Parts Counter & Accessories:

[ipsg.parts@acmobility.ph](mailto:ipsg.parts@acmobility.ph)

Insurance Claim (Body Repair):

[bodyrepair@isuzupasig.com](mailto:bodyrepair@isuzupasig.com)

Warranty:

[ipsg.warranty@acmobility.ph](mailto:ipsg.warranty@acmobility.ph)

Parts Counter & Accessories:

[ipsg.partscounter@acmobility.ph](mailto:ipsg.partscounter@acmobility.ph)

Parts Counter & Accessories:

[ipsg.partswarehouse@acmobility.ph](mailto:ipsg.partswarehouse@acmobility.ph)

Parts Counter & Accessories:

[ipsg.partsadmin@acmobility.ph](mailto:ipsg.partsadmin@acmobility.ph)

Website: [https://acmobility.ph](https://acmobility.ph/)

Facebook: [Isuzu Pasig - Iconic Dealership Inc.](https://www.facebook.com/isuzupasigofficial)

### Isuzu Quezon Avenue

1669 QUEZON AVENUE COR. SGT. ESGUERRA ST, WEST TRIANGLE, QUEZON CITY 1100

Contacts:

Credit & Collection Dept. - 8-925-4211 / 8-920-9499


Parts - 8-920-3426


Sales

Service - 0938-6140204


Customer Relations:

[croisuzuurdaneta@gmail.com](mailto:croisuzuurdaneta@gmail.com)

Service:

[intecoqaservice@yahoo.com](mailto:intecoqaservice@yahoo.com)

Parts:

[parts.isuzuqa@gmail.com](mailto:parts.isuzuqa@gmail.com)

### Isuzu Rizal

1033 Marcos Highway, Brgy. Mayamot, Antipolo City, Rizal 1870

Contacts:

SALES - (02) 86455558 Loc 614


SERVICE - (02) 82492521


SERVICE ADMIN / APPOINTMENT - (0917) 3274614 / (0999) 8859668


TRUNKLINE - (02) 86455558


Sales

Customer Relations - (0920) 1429095


SALES - (0917) 8478659 / (0998) 5868622


SERVICE ADMIN / APPOINTMENT - (0917) 3274614 (0999) 8859668


Sales:

[irzl.salesadmin@acmobility.ph](mailto:irzl.salesadmin@acmobility.ph)

Service:

[irzl.serviceadmin@acmobility.ph](mailto:irzl.serviceadmin@acmobility.ph)

Parts Counter & Accessories:

[irzl.parts@acmobility.ph](mailto:irzl.parts@acmobility.ph)

Warranty:

[irzl.warranty@acmobility.ph](mailto:irzl.warranty@acmobility.ph)

Customer Relations:

[irzl.crd@acmobility.ph](mailto:irzl.crd@acmobility.ph)

Website: [https://acmobility.ph](https://acmobility.ph/)

Facebook: [Isuzu Rizal - Iconic Dealership Inc.](https://www.facebook.com/IsuzuRizalOfficial)

### Isuzu Roxas

Brgy. Bolo, Roxas City, Capiz 5800

Contacts:

Trunkline - (036) 620-3287


Sales

Customer Relations - (0977) 2178442


Sales / Service Admin / Appointment Parts - (0905) 4981271


Sales:

[iic.salesadmin@acmobility.ph](mailto:iic.salesadmin@acmobility.ph)

Customer Relation:

[iic.customerrelations@acmobility.ph](mailto:iic.customerrelations@acmobility.ph)

Parts Counter and Accessories:

[iic.parts@acmobility.ph](mailto:iic.parts@acmobility.ph)

Warranty:

[iic.warranty@acmobility.ph](mailto:iic.warranty@acmobility.ph)

Service:

[aponesto.ri@acmobility.ph](mailto:aponesto.ri@acmobility.ph)

Website: [https://acmobility.ph](https://acmobility.ph/)

### Isuzu San Pablo

KM 85 Maharlika Highway, Brgy. San Ignacio, San Pablo City, Laguna

Contacts:

Manila Line - (02) 8584-4814
/ (02) 520-6014


Parts / Service - (049) 562-0512


Sales - (049) 503-3377
/ (049) 562-9996


Service / Parts - (049) 503-3374


Telefax - (049) 562-8200


Sales

Sales - 0922-8662012
/ 0921-462-7391


Service / Customer Relation - 0923-373-8477
/ 0932-233-8697


Parts - 0922-752-2829


Services

\- 0927-676-9411
/ 0916-221-7769
/ 0947-691-1961


Service:

[isuzusanpabloservice@gmail.com](mailto:isuzusanpabloservice@gmail.com)

Customer Relation:

[customerrelations.gencarsspc@gmail.com](mailto:customerrelations.gencarsspc@gmail.com)

Sales:

[isuzusanpablosales@gmail.com](mailto:isuzusanpablosales@gmail.com)

Parts:

[isuzusanpabloparts@gmail.com](mailto:isuzusanpabloparts@gmail.com)

Facebook: [www.facebook.com/gencarssanpablo](https://www.facebook.com/gencarssanpablo/)

Instagram: [www.instagram.com/isuzusanpablo](https://www.instagram.com/isuzusanpablo/)

Website: [http://www.isuzusanpablo.com](http://www.isuzusanpablo.com/)

### Isuzu Sta. Rosa

Tagaytay-Sta Rosa Road, Pulong Sta. Cruz, Sta. Rosa City, Laguna

Sales

Service - 0905-3178766 / 0928-1571871 / 0917-4563091


Sales - 0962-1373099


Parts - 0995-8960188 / 0915-43987223


Service:

[gencarssvc\_isuzustarosa86@yahoo.com](mailto:gencarssvc_isuzustarosa86@yahoo.com)

Sales:

[gencars.santarosa@gmail.com](mailto:gencars.santarosa@gmail.com)

Parts:

[partsisuzustarosa@gmail.com](mailto:partsisuzustarosa@gmail.com)

Customer Relations:

[isuzustarosa.customerrelations@gmail.com](mailto:isuzustarosa.customerrelations@gmail.com)

Facebook: [www.facebook.com/gencarsstarosa](https://www.facebook.com/gencarsstarosa/)

Instagram: [www.instagram.com/isuzu\_starosa/](https://www.instagram.com/isuzu_starosa/)

Website: [http://www.isuzustarosa.com](http://www.isuzustarosa.com/)

### Isuzu Subic

Block 3 Former Marshalling Yard, Subic Gateway District, Subic Bay Freeport Zone, Subic 2222

Sales

Sales - 0917-1800010


Service - 0917-1550452


Parts - 0917-1073516


Customer Relations Team - 0917-1005756


Sales:

[sales.isuzusubic@gmail.com](mailto:sales.isuzusubic@gmail.com)

Service:

[aftersalesad.isuzusubic@gmail.com](mailto:aftersalesad.isuzusubic@gmail.com)

Parts:

[parts.isuzusubic@gmail.com](mailto:parts.isuzusubic@gmail.com)

Customer Relations Team:

[crm.isuzusubic@gmail.com](mailto:crm.isuzusubic@gmail.com)

### Isuzu Tagum

National Highway, Purok 1- Rizal, Canocotan, Tagum City 8100

Contacts:

Trunk Line - (084) 645 3077 / (084) 645 3078 / (084) 645 3079


Sales

Parts - 0908-8152831


Sales - 0917-183-7967


Service - 0909-8330375


Sales:

[isuzutagum.sales@imagemotors.ph](mailto:isuzutagum.sales@imagemotors.ph)

Parts:

[isuzutagum.parts@imagemotors.ph](mailto:isuzutagum.parts@imagemotors.ph)

CRO:

[isuzutagum.support@imagemotors.ph](mailto:isuzutagum.support@imagemotors.ph)

### Isuzu Tarlac

Sitio Valdez Mc. Arthur Highway, San Rafael, Tarlac City, Tarlac 2300

Contacts:

Trunk line - (045) 456-9955


Sales

Sales - 0917-6259584


Customer Relations - 0927-0023682


Service - 0923-7433936 / 0909-7685000


Sales:

[sales-tarlac@bmdmotors.com](mailto:sales-tarlac@bmdmotors.com)

Services:

[service-tarlac@bmdmotors.com](mailto:service-tarlac@bmdmotors.com)

Customer Relation:

[crt-tarlac@bmdmotors.com](mailto:crt-tarlac@bmdmotors.com)

Facebook: [https://www.facebook.com/IsuzuTarlacOfficial](https://www.facebook.com/IsuzuTarlacOfficial)

Website: [http://www.bmdmotors.com/](http://www.bmdmotors.com/)

### Isuzu Taytay

Manila East Road, Brgy. Dolores, Taytay, Rizal 1920

Contacts:

Customer Relations - (02) 79087190 Loc 811


Parts - (02) 79087190 loc 817


Sales - (02) 79087190 loc 809


Service - (02) 79087190 loc 810


Trunkline - (02) 79087190


Sales

Customer Relations - (0920) 1429095


Sales - (0933) 8246650 / (0917) 8523795


Service Admin / Appointment - (0917) 8523804


Service:

[irzl.serviceadmin@acmobility.ph](mailto:irzl.serviceadmin@acmobility.ph)

Warranty:

[irzl.warranty@acmobility.ph](mailto:irzl.warranty@acmobility.ph)

Customer Relations:

[irzl.crd@acmobility.ph](mailto:irzl.crd@acmobility.ph)

Sales:

[itay.salesadmin@acmobility.ph](mailto:itay.salesadmin@acmobility.ph)

Parts Counter & Accessories:

[itay.parts@acmobility.ph](mailto:itay.parts@acmobility.ph)

Website: [https://acmobility.ph](https://acmobility.ph/)

Website: [http://www.isuzuautodealer.com.ph](http://www.isuzuautodealer.com.ph/)

### Isuzu Valenzuela

429 Mc. Arthur Hi-way corner Bartolome St., Malanday Valenzuela City

Sales

Sales - 0917 903 9646/09279439080


Parts - 0963 948 8058


Services

Service Admins / Appointment - 0947 645 0690


Customer Relations

Customer Relations - 0947 645 0690


Parts Counter & Accessories:

[inosante.valenzuela.parts@gmail.com](mailto:inosante.valenzuela.parts@gmail.com)

Customer Relations:

[isuzuvalenzuela.cro@gmail.com](mailto:isuzuvalenzuela.cro@gmail.com)

Service:

[rperez.isuzuvalenzuela@gmail.com](mailto:rperez.isuzuvalenzuela@gmail.com)

Sales:

[jonny\_isuzu@yahoo.com](mailto:jonny_isuzu@yahoo.com)

Warranty:

[isuzuvalenzuela.aleawarranty@gmail.com](mailto:isuzuvalenzuela.aleawarranty@gmail.com)

Parts Counter & Accessories:

[dehonormigs@yahoo.com](mailto:dehonormigs@yahoo.com)

### Isuzu Zamboanga

MCLL Highway, Tetuan, Zamboanga City 7000

Contacts:

Trunk line - (062) 991-2088
/ (062) 984-2853


Sales

Mobile - (0917) 537-8779


Website: [http://isuzuautodealer.com.ph](http://isuzuautodealer.com.ph/)