# Search-result snippets (not independently fetched)

These are preserved only to document search evidence. Claims based on them remain limited to the visible snippets; the linked pages were not fetched successfully.

## National Privacy Commission Advisory Opinion No. 2022-005
- URL: https://privacy.gov.ph/wp-content/uploads/2022/08/Advisory-Opinion-No.-2022-005_Redacted.pdf
- Date visible: Opinion number 2022-005; URL indicates August 2022, exact issuance date not visible in snippet.
- Search title: PRIVACY POLICY OFFICE ADVISORY OPINION NO. 2022-005 1
- Snippet: “Local Government (DILG), on the Land Transportation Office’s (LTO’s) denial of your request for the names and addresses of the owners of some allegedly noisy vehicles in a certain locality.” The snippet then says the owners were to be given due process to show cause and LTO likewise... (snippet truncated).
- Limit: Do not infer the full legal reasoning or a general rule beyond the snippet. Fetch attempt returned 429; URL was not retried.

## LTO eFOI request on 2023–2024 registration data
- URL: https://www.foi.gov.ph/agencies/lto/motor-vehicle-registration-data-by-region-for-the-years-2023-and-2024
- Date visible: Request submitted Aug. 11, 2025, 3:36 p.m. in search snippet.
- Search title: Motor vehicle registration data by region for the years 2023 and 2024
- Snippet: “REQUEST SUBMITTED ... Date: Aug. 11, 2025 ... PROCESSING ... Motor vehicle registration data by region for the years 2023 and 2024.”
- Limit: This proves only that a request was listed as submitted/processing in the snippet, not that the data was released. Fetch displayed an eFOI maintenance advisory, not the record.

## LTO eFOI request on registered vehicles by region/type/use
- URL: https://www.foi.gov.ph/requests/list-of-registered-motor-vehicles-by-region-vehicle-type-and-use-eg-private-government-etc-lto-915124584342
- Date visible: Request submitted Jan. 31, 2017, 1:15 p.m. in search snippet.
- Search title: List of Registered Motor Vehicles by Region, Vehicle Type, and Use (e.g. Private, Government, Etc.) LTO-915124584342
- Snippet: LTO FOI request listing for “List of Registered Motor Vehicles by Region, Vehicle Type, and Use (e.g. Private, Government, Etc.).”
- Limit: The snippet describes the requested categories, not a data release, technical fields, currentness, licensing, or reuse permission.
