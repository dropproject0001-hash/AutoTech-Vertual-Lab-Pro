Source: https://content.toyota.com.ph/uploads/vehicles/28/001_28_1749545908466_000.pdf
Title: 2025 Toyota Hilux Leaflet
Fetched: 2026-11-11T12:55:54.454Z

# Toyota Hilux

# THOROUGHBRED CONFIDENCE. EVERY INCH A HILUX.

Conquer every terrain with Toyota Hilux's outstanding confidence on and off-road.
With its advanced features, superb safety, and trusted quality, it gives you great pride in every ride.

SCAN TO
LEARN MORE

Disclaimer: Toyota Motor Philippines Corporation reserves the right to change the vehicle specifications without prior notice.
Vehicle featured is the Hilux 4x4 Conquest.

Move your world

---

| MODEL |  | HILUX |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| VARIANT |  | Conquest |  | G |  | E |  |
| VARIANT |  | 2.8 4x4 A/T | 2.8 4x4 M/T | 2.4 4x2 A/T | 2.4 4x2 M/T | 2.4 4x2 A/T | 2.4 4x2 M/T |
| OVERALL DIMENSIONS |  |  |  |  |  |  |  |
| Length x Width x Height | mm | 5,325 x 2,020 x 1,845 |  | 5,325 x 1,900 x 1,845 | 5,365 x 1,855 x 1,815 |  |  |
| ENGINE &amp; TRANSMISSION |  |  |  |  |  |  |  |
| Model |  | 1GD-FTV (High) |  | 2GD-FTV (High) |  |  |  |
| Type |  | 2.8L Diesel, 4-Cylinder, 16-Valve DOHC Variable Nozzle Turbo with Air-cooled Intercooler |  | 2.4L Diesel, 4-Cylinder, 16-Valve DOHC Variable Nozzle Turbo with Air-cooled Intercooler |  |  |  |
| Displacement | cc | 2,755 |  | 2,393 |  |  |  |
| Max Output | PS / Rpm | 204 / 3,000 ~ 3,400 |  | 150 / 3,400 |  |  |  |
| Max Torque | Nm / Rpm | 500 / 1,600 ~ 2,800 | 420 / 1,400 ~ 3,400 | 400 / 1,600 ~ 2,000 |  |  |  |
| Transmission |  | 6-Speed AT | 6-Speed MT w/ iMT | 6-Speed AT | 6-Speed MT | 6-Speed AT | 6-Speed MT |
| CHASSIS |  |  |  |  |  |  |  |
| Auto Disconnect Differential |  | With |  | - |  |  |  |
| Differential Lock |  | With |  | - |  |  |  |
| Suspension | Front | Double Wishbone |  |  |  |  |  |
| Suspension | Rear | Leaf Spring Rigid Axle |  |  |  |  |  |
| Brakes | Front | Ventilated Discs |  |  |  |  |  |
| Brakes | Rear | Disc Type |  | Drum Type |  |  |  |
| Tires / Wheels |  | 265 / 60 R18 Alloy |  |  |  | 265 / 65 R17 Alloy |  |
| Spare Tire |  | Ground Tire (Alloy Wheel) |  |  |  |  |  |
| EXTERIOR |  |  |  |  |  |  |  |
| Headlamps |  | LED with Auto-Leveling |  |  |  | Multi-Reflector Halogen |  |
| Daytime Running Lights |  | LED |  | - |  |  |  |
| Front Fog Lamps |  | LED |  |  |  |  |  |
| Rear Combination Lamp |  | LED + Line Guide + Bulb |  |  |  | Bulb |  |
| Outside Rear View Mirror | Bowers Features | Bowers Adjust + Bowers Fold |  |  |  |  |  |
| Outside Rear View Mirror | Power Features | Power Adjust + Power Fold |  |  |  |  |  |
| Windshield Wiper | With | Intermittent + Time Adjust |  |  |  |  |  |
| Tailgate Assist | With | - |  |  |  |  |  |
| Hoodlift Assist | With | - |  |  |  |  |  |
| Overfenders | Wide (Matte Black) |  | Wide |  |  |  |  |
| Bedliner | With |  |  |  |  |  |  |
| Sports Bar | With | - |  |  |  |  |  |
| Roof Ornament | With | - |  |  |  |  |  |
| Side Decals | With | - |  |  |  |  |  |
| Antenna | Pole Type |  |  |  |  |  |  |
| INTERIOR |  |  |  |  |  |  |  |
| Seat Material | Leather |  | Fabric |  |  |  |  |
| Seat Type Adjustment | Front | D: 8-Way Power Adjust P: 4-Way Manual Adjust | D: 6-Way Manual Adjust P: 4-Way Manual Adjust |  |  |  |  |
| Seat Type Adjustment | Rear | 60/40 Separate |  |  |  |  |  |
| Multi-Information Display (MID) | 4.2" TFT |  |  |  |  |  |  |
| Steering Type | Power Steering + Variable Flow Control |  |  |  |  |  |  |
| Steering Wheel | Material | Leather | Urethane |  |  |  |  |
| Steering Wheel | Switch | Audio + Phone + Voice Command + MID + Cruise Control + Lane Departure Alert | Audio + Phone + Voice Command + MID |  |  |  |  |
| Inside Rear View Mirror | Auto-Dimming |  | Day &amp; Night |  |  |  |  |
| Door Trim | Leather + Interior Illumination |  | Fabric + Silver |  |  |  |  |
| Cup / Bottle Holder | Front | Cup Holder: 4 + Bottle Holder: 2 |  |  |  |  |  |
| Cup / Bottle Holder | Rear | Cup Holder: 2 + Bottle Holder: 2 |  |  |  |  |  |
| FUNCTION |  |  |  |  |  |  |  |
| Keyless Entry | Smart Entry |  | With |  |  |  |  |
| Ignition System | Push Start System |  | Rotary Type |  |  |  |  |
| Data Communication Module | With |  |  |  |  |  |  |
| Power Features | Windows | All: Auto Up/Down + Jam Protect | D: Auto Up/Down + Jam Protect |  |  |  |  |
| Power Features | Door Locks | Speed-Sensing |  |  |  |  |  |
| Air Conditioning System |  | Dual Zone Automatic Climate Control |  |  |  |  |  |
| Rear A/C Vent |  | With | - |  |  |  |  |
| Cruise Control |  | With | - |  |  |  |  |
| Audio System | Type | 9" Display Audio | 8" Display Audio |  |  |  |  |
| Audio System | Function | AM/FM/Bluetooth/USB/Apple Carplay (Wireless) /Android Auto (Wireless) | AM/FM/Bluetooth/USB/Apple Carplay/Android Auto |  |  |  |  |
| Audio System | Speakers | 6 |  |  |  |  |  |
| Accessory Outlet (12V) |  | 2 |  |  |  |  |  |
| SAFETY &amp; SECURITY |  |  |  |  |  |  |  |
| Toyota Safety Sense (TSS) | Pre-Collision System (PCS) | With | - |  |  |  |  |
| Toyota Safety Sense (TSS) | Lane Departure Alert (LDA) | With | - |  |  |  |  |
| Toyota Safety Sense (TSS) | Dynamic Radar Cruise Control (DRCC) | With | - |  |  |  |  |
| Blind Spot Monitor (BSM) |  | With | - |  |  |  |  |
| Rear Cross Traffic Alert (RCTA) |  | With | - |  |  |  |  |
| SRS Airbags |  | Driver + Front Passenger + Side + Curtain Shield + Knee (Dr) | Driver + Front Passenger + Knee (Dr) |  |  |  |  |
| Anti-Lock Brake System (ABS) |  | With + Brake Assist + EBD |  |  |  |  |  |
| Vehicle Stability Control (VSC) |  | With |  |  |  |  |  |
| Hill-Start Assist Control (HAC) |  | With |  |  |  |  |  |
| Downhill Assist Control (DAC) |  | With | - |  |  |  |  |
| Seatbelts | Front Seats | 3 pt. ELR + Pretensioner + Force Limiter |  |  |  |  |  |
| Seatbelts | Rear Seats | 3 pt. ELR x3 |  |  |  |  |  |
| Child Restraint System |  | ISOFIX: 2 + Tether Anchor: 2 |  |  |  |  |  |
| Toyota Vehicle Security System (TVSS) |  | Immobilizer + Horn |  |  |  |  |  |
| Camera |  | Panoramic View Monitor | Reverse Camera |  |  |  |  |
| Clearance and Back Sonar |  | Front: 2 + Rear: 4 | Rear: 2 |  |  |  |  |

**COLORS CONQUEST G E**
Emotional Red
Attitude Black Mica
Oxide Bronze Metallic
Gray Metallic
Silver Metallic
Dark Blue Mica
Super White II

**Attitude Black Mica**

**Emotional Red**

**Oxide Bronze Metallic**