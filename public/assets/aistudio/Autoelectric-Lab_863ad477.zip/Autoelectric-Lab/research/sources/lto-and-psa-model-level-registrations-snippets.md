# Search-result snippets: LTO and PSA model-level registrations

Search snippets saved because the corresponding FOI pages fetched as temporary eFOI maintenance notices. Treat these as limited search-result evidence, not as verified page contents.

## 1. LTO request for model-level data
- Title: List of Registered Motor Vehicles By Make, Model, Type, Use by Year by Region by LTO Branch
- URL: https://www.foi.gov.ph/requests/list-of-registered-motor-vehicles-by-make-model-type-use-by-year-by-region-by-lto-branch
- Visible date: Published by LTO on Jan. 31, 2017; request submitted Jan. 31, 2017.
- Search-result snippet: “List of Registered Motor Vehicles By Make, Model, Type, Use by Year by Region by LTO Branch. Published by Land Transportation Office(LTO) on Jan. 31, 2017. Requested from LTO by R. Basalo at 11:39 AM on Jan. 31, 2017. Purpose: Create a demographic report of vehicle by these available information …”
- Limit: Snippet does not show disposition or the data supplied; do not treat it as evidence that a data file was released.

## 2. 2023–2024 regional registration request
- Title: Motor vehicle registration data by region for the years 2023 and 2024
- URL: https://www.foi.gov.ph/agencies/lto/motor-vehicle-registration-data-by-region-for-the-years-2023-and-2024
- Visible dates: Request submitted Aug. 11, 2025; processing activity Aug. 13, 2025.
- Search-result snippet: “Motor vehicle registration data by region for the years 2023 and 2024”; the agency result snippet identifies the request as SUCCESSFUL.
- Limit: The available snippet does not show the actual attached data, its variables, model-level detail, or exact release date. The page fetch returned a maintenance notice.
