Source: https://hino.com.ph/Products(BUS).aspx
Title: Hino Motors Philippines
Fetched: 2026-11-11T12:54:26.250Z

![](https://hino.com.ph/assets/images/PerProduct/BUS/img/01_Hino_Buses_Product_Page_Banner2.jpg)

Ranging from MINI, MIDI and BIG, there is a Hino Bus that can cater to your specific transport needs. Each designed for its own specific purpose but built under the same standards to achieve the highest level of quality, durability, and reliability.


We are proud to be one of the trusted and established bus body building facilities in the country. We believe our customers deserve only the best-fit products for their requirements and with Hino’s in-house body building advantage, only we can assure truly customized bodies tailored to provide the best people transport solution.


All Hino Buses are built with functionality, comfort, safety, and performance in mind to make every journey wonderful.


![](https://hino.com.ph/assets/images/PerProduct/BUS/img/02_Hino_Buses_Product_Page_MINI1.jpg)

## HINO MINI BUS

The Hino Mini Bus features a blend of functionality and modern design. The light but sturdy body structure makes driving smooth and easy. With its simple dash design and wide view of the windscreen, the driver is more focused on the road.


Hino Mini Buses are capable of performing diverse tasks efficiently and economically, so driving around the city is not a problem. This lightweight contender can definitely provide what you are looking for in a mini bus.


![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Copy%20of%20Piston%20Icon_No%20Text.png)4.009 LEngine Displacement

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Copy%20of%20Max%20Output%20Icon_No%20Text.png)136 PS - 150 PSMax. Output (ISO Net)

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Copy%20of%20Max%20Torque_No%20Text.png)420 N.mMax. Output (ISO Net)

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Copy%20of%20ABS_No%20Text.png)Anti-lock BrakeSystem (ABS)

## HINO MINI BUS SPECIFICATIONS

| RANGE | MODEL | AXLES | GVW | Ps \|Nm | WHEELBASE | TRANS | SPECS | INQUIRE |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| HINO MINI BUS | 916 Cerito | 4 x 2 (6X) | 8,500 | 150 \| 420 | 4,400 | 6-Speed, Overdrive, Sychromesh 1st - 6th | [![](https://hino.com.ph/assets/images/Icon/pdf-download.png)](https://hino.com.ph/File/Bus/01%20Hino%20Bus%20Cerito%20916%20and%20916%20(XZU730LN)%20Brochure.pdf) |  |
| 916 | 4,200 | [![](https://hino.com.ph/assets/images/Icon/pdf-download.png)](https://hino.com.ph/File/Bus/01%20Hino%20Bus%20Cerito%20916%20and%20916%20(XZU730LN)%20Brochure.pdf) |  |

![](https://hino.com.ph/assets/images/PerProduct/BUS/img/03_Hino_Buses_Product_Page_MIDI.jpg)

## HINO MIDI BUS

Hino’s craftsmanship and advanced engineering makes the medium-sized Midi Bus the perfect people mover with operational versatility and true riding comfort. Seating 36 to 61 passengers, its smart styling and efficient performance also make our Midi Bus suitable for navigating city traffic or coursing through provincial roads.


![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Reliable%20and%20Powerful%20Engine_Black.png)Reliable andFuel-efficient Engine

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Max%20Output_No%20Text_Black.png)210 PS - 240 PSMax.Output (ISO Net)

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Max%20Torque_No%20Text_Black.png)637 Nm - 716 NmMax.Torque (ISO Net)

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/ABS_No%20Text_Black.png)Anti-lock BrakeSystem (ISO Net)

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Copy%20of%20Robust%20Chassis.png)Robust ChassisConstruction

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Copy%20of%20Copy%20of%20Full%20Air%20Brake%20System.png)Full-air BrakeSystem

## HINO MIDI BUS SPECIFICATIONS

| RANGE | MODEL | AXLES | GVW | Ps \|Nm | WHEELBASE | TRANS | SPECS | INQUIRE |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| HINO MIDI BUS | 1021 | 4 x 2 (6W) | 10,400 | 210 \| 637 | 4,990 | 6-Speed, Overdrive, Sychromesh 2nd - 6th | [![](https://hino.com.ph/assets/images/Icon/pdf-download.png)](https://hino.com.ph/File/Bus/02%20Hino%20Bus%201021%20(FC9JL7A),%201625%20(FG8JP7A)%20and%201625%20Long%20(FG8JP7A%20with%20FOH%20Extension)%20Brochure.pdf) |  |
| 1625 | 16,000 | 240 \| 716 | 5,530 | [![](https://hino.com.ph/assets/images/Icon/pdf-download.png)](https://hino.com.ph/File/Bus/02%20Hino%20Bus%201021%20(FC9JL7A),%201625%20(FG8JP7A)%20and%201625%20Long%20(FG8JP7A%20with%20FOH%20Extension)%20Brochure.pdf) |  |

![](https://hino.com.ph/assets/images/PerProduct/BUS/img/04_Hino_Buses_Product_Page_BIG2.jpg)

## HINO BIG BUS

Hino Big Buses are developed with strict attention to safety, comfort, and performance with the aim of transporting people in the best possible way.


The specially-designed chassis provides maximum stability and strength under stress of all operational conditions. So, whether it’s on city traffic or long-haul travels, riding a Hino Big Bus is comfortable and even enjoyable.


![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Copy%20of%20Piston%20Icon_No%20Text.png)7.684 LEngine Displacement

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Copy%20of%20Max%20Output%20Icon_No%20Text.png)250 PS - 280 PSMax. Output (ISO Net)

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Copy%20of%20Max%20Torque_No%20Text.png)739 Nm - 824NmMax. Output (ISO Net)

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Copy%20of%20ABS_No%20Text.png)Anti-lock BrakeSystem (ABS)

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Robust%20Chassis_White.png)Robust ChassisConstruction

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Heavy%20Duty%20Suspension_White.png)Heavy-duty SuspensionComponents

![](https://hino.com.ph/assets/images/PerProduct/BUS/icons/Full%20Air%20Brake%20System_White.png)Full-air BrakeSystem

## HINO BIG BUS SPECIFICATIONS

| RANGE | MODEL | AXLES | GVW | Ps \|Nm | WHEELBASE | TRANS | SPECS | INQUIRE |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| HINO BIG BUS | FG8J Bus | 4 x 2 | 16,000 | 240 \| 716 | 5,530 | 6-Speed, Overdrive, Synchromesh, 2nd-6th | [![](https://hino.com.ph/assets/images/Icon/pdf-download.png)](https://hino.com.ph/File/Bus/FG%20Bus%20Brochure%20(A4)%20individual.pdf) |  |

## Get in touch with our team

[![](https://hino.com.ph/assets/images/Icon/Telephone.png)\\
\\
Call (+63)2-7368-5800](tel:(+63)2-7368-5800)

[![](https://hino.com.ph/assets/images/Icon/Location.png)\\
\\
Find a dealer](https://hino.com.ph/FindaDealer.aspx)

Disclaimers:

_†Active safety systems are an aid to assist the driver and have performance limitations. Please refer to owner’s manual for system operations and functionality._

_#Refer to specification sheet for specific wheelbase._