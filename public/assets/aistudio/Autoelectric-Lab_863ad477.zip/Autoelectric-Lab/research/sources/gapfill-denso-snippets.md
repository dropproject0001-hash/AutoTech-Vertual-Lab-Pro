# Gap-fill DENSO/Toyota search snippets (not fetched)

Research date: 2026-11-11. Search snippets are leads only, not evidence for exact ECU pins, orientation, license, or Philippine applicability. Reposts and aggregators are not treated as official documents.

## Search 1 — DENSO common-rail manual / Hilux

- Query: Does DENSO publish an official common rail system service manual for Toyota Hilux or Innova 1KD/2KD, and does it include ECU terminal diagrams?
- Title: DENSO Common Rail System Service Manual for Toyota Hilux/Innova 1KD/2KD Engines (Manuals.plus)
- URL: https://manuals.plus/m/b82c963b8d73f6ab83a433f9aec3a53f7f0a9a8bc12a5375cbd4eaa3ab712958
- Search snippet: Converted preview identifies a 68-page DENSO Common Rail System Service Manual. Repost/aggregator; authorship, edition, market, and permission were not established by the snippet.
- Title: TOYOTA 1KD/2KD ENGINE COMMON RAIL SYSTEM (CRS) (PDF on Jimcontent)
- URL: https://sc80f9ecf73beaece.jimcontent.com/download/version/1617734502/module/13959221827/name/4.%20Denso%20Toyota%20hilux%201KD.pdf
- Search snippet: “Issued: September 2009,” “Revised: October 2009,” © 2009 DENSO CORPORATION; states all rights reserved. The host is third-party, so hosting/authenticity and redistribution license are unverified.
- Title: TOYOTA HILUX KIJYANG INNOVA 2.pdf (Service-engine.com.ua)
- URL: https://www.service-engine.com.ua/webroot/pdf/TOYOTA%20HILUX%20%20KIJYANG%20INNOVA%20%202.pdf
- Search snippet: “Common Rail System for TOYOTA HILUX / KIJYANG INNOVA / INNOVA 1KD/2KD,” July 2004, © 2004 DENSO. Reposted copy; exact vehicle market and permission unknown.

## Search 2 — Toyota ASEAN EWD / terminal documents

- Query: Does Toyota provide publicly accessible ASEAN electrical wiring diagrams or technical terminal documents for Hilux, Innova, and Vios?
- Title: HILUX Electrical Wiring Diagram (Tuning Concepts PDF)
- URL: https://www.tuningconcepts.com/Cars/Hilux/VigoElecWiringDiagram.pdf
- Search snippet: Identifies “Pub. No. DR114W”; third-party repost, with no provenance, licensing, exact Philippine vehicle applicability, or connector orientation established.
- Title: Toyota Hilux Electrical Wiring Diagram (ManualsLib)
- URL: https://www.manualslib.com/manual/1355103/Toyota-Hilux.html
- Search snippet: Lists fuse/relay locations and wiring information, but does not establish OEM hosting, exact ASEAN/Philippines variant, or ECU terminal mapping.
- Additional leads: Slideshare uploads “HILUX ELECRICAL EWD307F.pdf” and “HILUX ELECTRICALSUP. EWD378F.pdf” (https://www.slideshare.net/slideshow/hilux-elecrical-ewd307fpdf/252352973 and https://www.slideshare.net/slideshow/hilux-electricalsup-ewd378fpdf/252352971). User-uploaded copies; not accepted as primary technical evidence.
- No public official Toyota ASEAN EWD/terminal page appeared in these search results.

## Search 3 — DENSO aftermarket service PDF

- Query: Does DENSO aftermarket provide a publicly accessible service PDF with ECU terminal information for Toyota Hilux or Innova?
- The returned candidate was the same Manuals.plus DENSO 1KD/2KD repost above, plus a PDFCoffee user-upload of a purported 2004 DENSO manual: https://pdfcoffee.com/denso-toyota-hilux-common-rail-9-pdf-free.html . Neither result establishes an official DENSO aftermarket publication or a redistribution license.
- No official DENSO aftermarket document page appeared in the result set.

## Search 4 — Philippine exact ECU coverage

- Query: Can an official Toyota or DENSO source identify exact Philippine-market ECU terminal diagrams for Hilux 1KD/2KD/1GD, Innova, or Vios 1NZ?
- Title: Toyota ECU Pinout (PDFCoffee) and Toyota ECU Pinout Guide 2015+ (Scribd)
- URLs: https://pdfcoffee.com/toyota-ecu-pinout-3-pdf-free.html ; https://www.scribd.com/document/643835216/Toyota-ECU-Pinout-1
- Search snippets mention Hilux/Fortuner/Revo engine families, including 1GD/2GD and 1KD/2KD, but these are third-party uploads; no source provenance, terminal orientation, Toyota/DENSO authorization, or Philippine applicability is established. No pins accepted from snippets.
- No result supplied an official Philippines-specific Vios 1NZ ECU document.
