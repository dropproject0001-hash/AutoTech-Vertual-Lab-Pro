Source: https://psa.gov.ph/sites/default/files/ncs-manuscripts-powerpoint/7.5.1%2520Current%2520State%2520of%2520Transportation%2520Data%2520and%2520Statistics%2520in%2520the%2520Philippines%2520and%2520Opportunities%2520for%2520Improvement%2520Towards%2520Usability%2520_0.pdf
Title: 
Fetched: 2026-11-11T12:55:33.155Z

**14th National Convention on Statistics (NCS)** 
Crowne Plaza Manila Galleria, Quezon City,
October 1-3, 2019

# CURRENT STATE OF TRANSPORTATION DATA AND STATISTICS IN THE PHILIPPINES AND OPPORTUNITIES FOR IMPROVEMENT TOWARDS USABILITY

by
**Jose Regin F. Regidor**

For additional information, please contact:

Author’s name

Designation

Jose Regin F. Regidor

Affiliation

Address

Fellow

Tel. no.

National Center for Transportation Studies

E-mail

Apacible Street, University of the Philippines, Diliman, Quezon City 1101

928 8305

jfregidor@up.edu.ph

Page 1of **17**

---

# CURRENT STATE OF TRANSPORTATION DATA AND STATISTICS IN THE PHILIPPINES AND OPPORTUNITIES FOR IMPROVEMENT TOWARDS USABILITY

by

**Jose Regin F. Regidor<sup>1</sup>**

## ABSTRACT

Data and statistics on transportation come in various formats. Data collected by 
various sources are processed and presented in many ways. In certain cases, there are 
forms or templates that agencies have developed or adopted that they eventually used to 
generate reports. For example, the Land Transportation Office (LTO) publishes statistics 
on vehicle registration every year, and the same are submitted to the Philippine Statistics 
Authority (PSA) for the compilation the agency publishes every year. Meanwhile, 
agencies like the Philippine Ports Authority (PPA) also publishes reports containing the 
summaries of inbound and outbound passengers and freights at ports across the 
country. A basic question that needs to be answered is if the data and statistics being 
published are readily usable for other purposes such as in-depth analysis, modelling, 
forecasting or back-casting. This paper presents on the current ways transportation data 
and statistics are produced and published. More importantly, the paper discusses the 
requirements for in-depth transportation data analysis and relates this to the form and 
quality of data that can be acquired from various sources. Recommendations are made 
for more effective data collection, processing and presentation that will enable users to 
maximize the use of data.

### 1. Introduction

Data and statistics on transportation come in various formats. Data collected by various 
sources are processed and presented in many ways. In certain cases, there are forms or 
templates that agencies have developed or adopted that they eventually used to generate 
reports. For example, the Land Transportation Office (LTO) publishes statistics on vehicle 
registration every year, and the same is submitted to the Philippine Statistics Authority (PSA) for 
the compilation the agency publishes every year. Meanwhile, the Philippine Ports Authority 
(PPA) also publishes reports containing the summaries of inbound and outbound passengers 
and freights at ports across the country.

This paper has the following objectives:

a. Present an inventory of transportation data sources

b. Assess the usability of the data according to the purpose

c. Formulate recommendations for more effective data collection, processing and 
presentation

### 2. Data Sources

The following agencies are the typical sources of data, which they currently publish or 
share in various forms and content. These are categorized under four transport sectors:

<sup>1</sup>Dr. Jose Regin F. Regidor is a Professor at the Institute of Civil Engineering, College of Engineering, 
University of the Philippines Diliman. He is also a Research and Extension Fellow of the National Center for 
Transportation Studies.

Page 2of **17**

---

### • Air transport

o Department of Transportation (DOTr) – Air transport division

▪ Summary of Air Transport Statistics

o Civil Aviation Authority of the Philippines (CAAP)

▪ Air transport statistics

▪ GHG inventory for aviation

o Clark International Airport Corporation (CIAC)

▪ GHG emissions calculation

▪ Clark Flight Traffic Statistical Reports

▪ Domestic and International Traffic Movements

o Mactan Cebu International Airport Authority (MCIAA)

▪ MCIAA Flight Traffic Statistical Reports

▪ Domestic and International Traffic Movements

o Manila International Airport Authority

▪ MIAA Flight Schedule

### • Maritime transport

▪ MIAA Flight Traffic Statistical Reports

▪ Domestic and International Traffic Movements

o Cebu Ports Authority (CPA)

▪ Bulk cargo statistics

▪ Cargo throughput

▪ Container traffic

▪ Passenger traffic

▪ Rolling Cargo

▪ Shipping traffic

o Maritime Industry Authority (MARINA)

▪ Registered vessels

o Philippine Coast Guard

▪ Floating assets

▪ Fuel oil requirements

▪ Vessels

o Philippine Ports Authority (PPA)

▪ Summary port statistics

▪ Summary shipping, cargo and passenger statistics

▪ Cargo handling tariffs

▪ RoRo Traffic summary

▪ Container statistics summary

### • Rail transport

o Light Rail Transport Authority (LRTA)

▪ Lines 1 and 2 audit reports

▪ Lines 1 and 2 ridership statistics

▪ Lines 1 and 2 train schedules

o Metro Rail Transit Corporation (MRTC)

▪ MRT3 train schedule

▪ MRT3 Average trips/train/day

▪ MRT3 Average round trips

▪ MRT3 ridership statistics

o Philippine National Railways (PNR)

▪ Passenger-Kilometers

Page 3of **17**

---

▪ Ridership statistics

▪ Summary passenger-kilometers for commuter and Bicol Express

• Road transport

o Department of Transportation (DOTr) – Road Transport Division

▪ Project study reports

▪ Summary reports submitted to the DOTr by agencies under them

o Land Transportation Office (LTO)

▪ Motor vehicle registration – new and renewals

▪ Motor vehicle fuel used

o Land Transportation Franchising and Regulatory Board (LTFRB)

▪ Inventory of routes, regional

▪ Public utility bus (PUB) routes with distance

▪ Public utility jeepney (PUJ) routes with distance

▪ UV Express routes with distance

o Department of Public Works and Highways (DPWH)

▪ Traffic counts along national roads

▪ Inventory of national roads and bridges

o Metropolitan Manila Development Authority (MMDA)

▪ Road crash statistics via MMARAS

o Philippine National Police (PNP)

▪ Road crash reports via e-blotter

Aside from these data sets, various reports and other references are available with the 
various agencies. The DPWH annually publishes an Atlas that contains a wealth of information 
that are used by Traffic and Highway Engineers and Planners. Annual reports are published by 
the same agencies and corporations above and others that also deal with transportation. The 
latter include tollways operators like the Metro Pacific/Manila North Tollways Corporation, 
Skyway Corporation and TPLEX. Among the national agencies, perhaps the National Economic 
and Development Agency (NEDA) would also have a significant collection of transport-related 
data and reports from various studies undertaken through or commissioned by the agency.

Others transportation data sources would be local government units (i.e., cities and 
municipalities), the academe and private companies. LGUs regularly collect data though types 
and formats may vary from one LGU to another with the more progressive ones usually having 
more data. What is untapped are the data from various transport or traffic studies submitted to 
them that are the outputs of projects in their localities.

Academic institutions such as the University of the Philippines, De La Salle University, 
Ateneo De Manila University, Polytechnic University of the Philippines, Xavier University and 
Mindanao State University, among others, conduct transportation researches. They generate 
data and reports containing the outcomes of analysis performed by students, faculty and staff of 
these institutions.

### 3. Purposes of data collection and use

Data is collected for certain purposes. More specifically, these include the most basic, 
which is reporting traffic or transport statistics (e.g., traffic counts along roads, number road 
crashes, number of passengers, volume of freight, etc.). Following are more in-depth objectives 
for data collection and analysis.

Page 4of **17**

---

#### 3.1 Determination of mode share

The percentage shares according to vehicle classification can be referenced from the 
LTO, which publishes the data on the annual vehicle registration. However, these do not reflect 
the actual traffic and usage of vehicles. DPWH has the traffic counts data in the form of Annual 
Average Daily Traffic (AADT) for national roads, which vary from one road to another depending 
on factors like urbanization and vehicle ownership. The share of vehicles for various road 
classifications are not generally available. The DPWH publishes traffic counts data for national 
roads so perhaps these can substitute for the data. However, this requires additional data in the 
form of vehicle occupancies for the determination of mode shares in terms of person trips.

The best (i.e., ideal) source or reference would be mode shares derived from surveys 
such as Household Information Surveys (HIS). For example, JICA has derived the shares by 
mode including an estimate for walking based on the responses to surveys conducted in Metro 
Manila and adjacent areas. These are among the inputs for developing transport models 
employed for travel demand forecasting and evaluation of identified scenarios for infrastructure 
development as well as transport policies or traffic schemes. Table 1 shows an example of % 
share of person trips as estimated by JICA in MUCEP, 2014.

**Table 1: Trip composition by mode (JICA, 2014)**

| Mode | No. of Trips (000) | % of Public or Private | % to Total |
| --- | --- | --- | --- |
| Public Mode | 17,337 | 100.0 | 48.8 |
| Train | 1,485 | 8.6 | 4.2 |
| Bus | 2,352 | 13.6 | 6.6 |
| Jeepney | 6,763 | 39.0 | 19.1 |
| Tricycle | 5,687 | 32.8 | 16.0 |
| UV/HOV | 261 | 1.5 | 0.7 |
| Pedicab | 631 | 3.6 | 1.8 |
| Others | 156 | 0.9 | 0.4 |
| Private Mode | 7,263 | 100.0 | 20.4 |
| Motorcycle | 2,948 | 40.6 | 8.3 |
| Car | 2,894 | 39.9 | 8.2 |
| Taxi | 315 | 4.3 | 0.9 |
| Truck | 270 | 3.7 | 0.8 |
| Others | 826 | 11.4 | 2.3 |
| Walking | 10,913 | - | 30.7 |
| Total | 35,503 | - | 100.0 |

Source: JICA Project Team

Note: Trips are by residents inside study area only.

Another source of data for the determination of mode shares, non-motorized modes are 
not considered in the modelling work. Modes or vehicle types are adopted from the LTO, which 
already has a good summary as stated in their Motor Vehicle Registration (MVR) data:

• Passenger Cars (PC)

Page 5of **17**

---

• Utility Vehicles (UV)

• SUV

• Buses

• Trucks

• Motorcycles (MC)

• Tricycles (TC)

• Non-Conventional (NC)

#### 3.2 Determination of occupancy

Vehicle occupancy is used to determine the number of passengers traveling. Occupancy 
is multiplied to the estimated number of vehicles traveling (i.e., in the form of either 
vehicles/hour or vehicle-kilometers traveled) to obtain the number of passengers traveling (i.e., 
in the form of either passengers/hour or passenger-kilometers traveled). Table 2 shows the 
average passenger occupancy values employed for the modeling in this study.

**Table 2: Average passenger occupancy per vehicle**
Vehicle Occupancy

| Vehicle Type | Vehicle Occupancy MUCEP (2012/2014) | Vehicle Occupancy MMUTIS (1997/1999) |
| --- | --- | --- |
| Car | 1.7 | 2.5 |
| Jeepney | 10 | 15.1 |
| Bus | 35.3 | 46.5 |
| Trucka | 2 | 2 |
| MCb | 1.2 | n/a |

<sup>a</sup>Assumed based on typical driver and helper crew of trucks.

<sup>b</sup>Determined based on research at the National Center for

*Transportation Studies (NCTS).*

Again, these values are required to estimate total passengers from travel demand 
models. Passenger-kilometers can be estimated if average travel distances are also known.

In the cases of rail, air and maritime transport, it may be possible to obtain data to 
directly estimate the number of passengers, passenger-kilometers and vehicle-kilometers since 
vehicle movements are recorded. It is just a matter of processing and reporting such data in 
forms that are readily usable for analytical or modelling purposes.

#### 3.3 Determination of fuel economy

Fuel economy is another input to the transport models derived for this study. Fuel 
economy values for jeepneys can be determined based on the distance traveled and the 
amount of fuel consumed over those distances. Table 3 shows jeepney route classifications 
derived in a 2009 study at the NCTS. Also shown are the average total distance traveled per 
day by jeepneys from the same study.

Page 6of **17**

---

**Table 3: Jeepney route classifications based on travel distance and average total distance 
traveled per day**
Route Class Coverage Distance Distance traveled, km

(Region III & 68.75 Region IV-A)

Techn ical Report N Medium o. 1 Environment and H azard Risk Reduc 6 tio –n 9 kilometers Analysis

| Route Class | Coverage Distance | Distance traveled, km |
| --- | --- | --- |
| Short | 5 kilometers or less | 68.75 |
| Medium | 6 – 9 kilometers | 98.24 |
| Long | 10 – 19 kilometers | 111.22 |
| Extra Long | 20 kilometers &amp; above | 164.00 |

**Table 2.3.4 Vehicle Emission Factors in Metro Manila (2001)**
*Source: Regidor, Vergel&Napalang, 2009, Environment Friendly Paratransit: Re-Engineering the* 
*Jeepney, Proceedings of the Eastern Asia Society for Transportation Studies, Vol. 7* V=0 V<10 kph V=10-20 kph V>20 kp.h
Vehicle Type
(g/sec) (g/km) (g/km) (g/km)

CO<sup>2</sup> Car 350 200 80 60
Table 4 shows the average daily consumption and computed fuel efficiency for Truck 450 280 120 95
jeepneys. Jeepney 400 230 100 80
Bus 450 280 120 95

CO Car 0.0858
**Table 4: Average daily consumption and computed fuel efficiency** Truck 0.0781
**Route Class Kilometers/Liter**

27.57 23.5
47.58 52.2

| Route Class | Kilometers/Liter | Liters/Day |
| --- | --- | --- |
| Short | 6.00 | 11.00 |
| Medium | 5.53 | 19.97 |
| Long | 5.68 | 20.64 |
| Extra Long | 5.61 | 31.64 |

*Source: Regidor, Vergel&Napalang, 2009, Environment Friendly* Bus 12.6
*Jeepney, Proceedings of the Eastern Asia Society for Transportation Studies, Vol. 7* SOx Car 0.018
Truck 1.511

11.24 *Paratransit: Re* 10.59-*Engineering the* 9.22
0.013 0.011. 0.011
4.7 3.59 3.53

#### 3.4 Estimation of Emissions Bus

### SPM Car

3.4 Estimation of Emissions Bus

Truck 0.1 0.07 0.06 0.05
The reference values used by JICA in the MUCEP study in 2015 are shown in Table 5 
Jeepney 1.5 1.8 0.9 0.81
and 6. These are related to the speeds of vehicles along the road network considered in the 
Bus 1.5 2.3 1.5 0.8
transport models they developed to estimate the total emissions per type of vehicle.
Source: UP-NCTS.

**Table 2.3.5 Fuel Consumption for Vehicles and NOx Emission Factors in Metro Manila (2011)**
**Table 5: Fuel consumption for vehicles and NOx emission factors in Metro Manila**

| Vehicle Type | Speed Classes / Speed of Representative (km/h) |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Vehicle Type | 3 to 5 | 5 to 10 | 10 to 15 | 15 to 25 | 25 to 40 | 40 to 60 | 60 to 80 |
| Vehicle Type | 4 | 7.5 | 12.5 | 20 | 32.5 | 50 | 70 |
| Fuel consumption for Bus | 0.809 | 0.681 | 0.602 | 0.532 | 0.455 | 0.383 | 0.337 |
| Fuel consumption for Passenger car | 0.167 | 0.123 | 0.099 | 0.079 | 0.061 | 0.048 | 0.045 |
| NOx Emission factor for Bus | 22.7 | 16.2 | 12.9 | 10.7 | 8.8 | 7.3 | 6.5 |

## Table 2.3.6 Reference Emission Factors in Metro Manila

*SourSource: MUCEP, 201* ce: MLIT 2011. *5*

1.056 0.398
Page 1.8576of 171.198

---

**Table 2.3.6 Reference Emission Factors in Metro Manila**
**Table 6: Reference emission factors in Metro Manila**

|  | Speed Classes / Speed of Representative (km/h) |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Vehicle Type | 3 to 54 | 5 to 107.5 | 10 to 1512.5 | 15 to 2520 | 25 to 4032.5 | 40 to 6050 | 60 to 8070 |
| CO2 | Gas car | 447.6 | 363.7 | 327.5 | 306.3 | 292.0 | 282.5 | 277.3 |
| CO2 | Diesel utility vehicle/ jeepney | 643.7 | 544.6 | 501.8 | 476.7 | 459.9 | 448.7 | 442.5 |
| CO2 | Diesel truck/ bus | 1182.9 | 1083.9 | 1041.1 | 1016.0 | 999.1 | 987.9 | 981.7 |
| NOx | Gas car | 5.512 | 3.656 | 2.998 | 2.700 | 2.546 | 2.462 | 2.424 |
| NOx | Diesel utility vehicle/ jeepney | 4.212 | 2.356 | 1.698 | 1.400 | 1.246 | 1.162 | 1.124 |
| NOx | Diesel truck/ bus | 15.312 | 13.456 | 12.798 | 12.500 | 12.346 | 12.262 | 12.224 |
| PM | Gas car | 2.912 | 1.056 | 0.398 | 0.100 | 0.100 | 0.100 | 0.100 |
| PM | Diesel utility vehicle/ jeepney | 3.712 | 1.856 | 1.198 | 0.900 | 0.746 | 0.662 | 0.624 |
| PM | Diesel truck/ bus | 3.712 | 1.856 | 1.198 | 0.900 | 0.746 | 0.662 | 0.624 |
| CO | Gas car | 52.312 | 50.456 | 49.798 | 49.500 | 49.346 | 49.262 | 49.224 |
| CO | Diesel utility vehicle/ jeepney | 5.312 | 3.456 | 2.798 | 2.500 | 2.346 | 2.262 | 2.224 |
| CO | Diesel truck/ bus | 15.212 | 13.356 | 12.698 | 12.400 | 12.246 | 12.162 | 12.124 |
| SOx | Gas car | 2.823 | 0.967 | 0.309 | 0.011 | 0.011 | 0.011 | 0.011 |
| SOx | Diesel utility vehicle/ jeepney | 2.933 | 1.077 | 0.419 | 0.121 | 0.121 | 0.121 | 0.121 |
| SOx | Diesel truck/ bus | 3.186 | 1.330 | 0.672 | 0.374 | 0.220 | 0.136 | 0.098 |
| HC | Gas car | 8.812 | 6.956 | 6.298 | 6.000 | 5.846 | 5.762 | 5.724 |
| HC | Diesel utility vehicle/ jeepney | 3.512 | 1.656 | 0.998 | 0.700 | 0.546 | 0.462 | 0.424 |
| HC | Diesel truck/ bus | 6.512 | 4.656 | 3.998 | 3.700 | 3.546 | 3.462 | 3.424 |

*SourSource: MUCEP, 201* ce: JICA Study team *5*
Note: Dr. Karl N. Vergel of UP-NCTS updated existing Manila emission factors (1992, 1996) upon request of study team as a reference.

#### 3.5 Estimation of Vehicle Speeds

Vehicle speeds are estimated using a variety of techniques including conventional 
approaches (e.g., trap length method) and instruments (e.g., speed guns or radars). These, 
however, only allow for spot speeds to be obtained. The more useful data would be travel 
2-20
speeds, which can be estimated by recording travel times along specific routes. Again, these 
can be through conventional means (e.g., travel time surveys) or by using more sophisticated 
approaches such as test cars. Such data can now also be outsourced via smartphones onboard vehicles (e,g,, via apps like Waze).

For driving speeds, there are scarce data for this as agencies and local government 
units do not usually collect such data. The following Table 7 shows the maximum speeds used 
for modelling travel from past studies including MMUTIS (1999) and MUCEP (2015).

Page 8of **17**

---

**Table 7: Road capacity and maximum speed by road category**

| Area | Road Category | Carriageway Type | Capacity 1-way pcu/day/lane | Maximum Speed (km/h) |
| --- | --- | --- | --- | --- |
| Inside EDSA | Local road | Single | 2,200 | 30 |
| Inside EDSA | Secondary | Single | 4,400 | 40 |
| Inside EDSA | Primary | Single | 6,600 | 45 |
| Outside EDSA Inside MM (including EDSA) | Secondary | Single | 7,700 | 50 |
| Outside EDSA Inside MM (including EDSA) | Primary | Single | 8,250 | 60 |
| Outside EDSA Inside MM (including EDSA) | Secondary | Divided | 14,000 | 70 |
| Outside EDSA Inside MM (including EDSA) | Primary | Divided | 16,500 | 80 |
| Outside MM | Local road | Single | 8,000 | 30 |
| Outside MM | Secondary | Single | 11,000 | 55 |
| Outside MM | Primary | Single | 15,400 | 60 |
| Urban / Intercity | Access / egress | Single | 15,000 | 80 |
| Urban / Intercity | Expressway | Single | 17,000 | 80 |
| Urban / Intercity | Expressway | Divided | 20,000 | 100 |

*Source: JICA, 2015, “The Project for Capacity Development on Transportation Planning and Database* 
*Management in the Republic of the Philippines: MMUTIS Update and Enhancement Project (MUCEP);* 
*Manual Vol. 2, Travel Demand Forecasting.” JICA and DOTC.*

*http://open_jicareport.jica.go.jp/pdf/12247649.pdf.*

Since these are maximum speeds, lower average speeds may be assumed (perhaps 
10% less than the maximum). For more accurate and “real-time” estimates, possible sources of 
speed data could be Waze and Grab. Google Traffic’s data is supposed to come from Waze 
and is presented for varying conditions throughout the week (day of the week) and day (time of 
day).

#### 3.6 PKT and VKT Estimation

### a. Land transportation

Passenger-kilometers traveled (PKT) and vehicle-kilometers traveled (VKT) may be 
derived in a number of ways. The best but not necessarily the easiest approach is through 
travel demand modelling and forecasting using established models and software. Among the 
more popular commercial software, for example, are CUBE, VISSUM and EMME. These allow 
for the estimation of the characteristics of a system, network or perhaps a corridor. In the 
Philippines, detailed models have been developed for only a few cities including Cebu City and 
Davao City.

These models, however, require much information including origin-destination tables 
and travel patterns and preferences (i.e., modes and routes) to establish the number of vehicles 
and their loads (i.e., passengers and freight) traveling from one point to another. In the absence 
of such computer models, the PKT and VKT values can still be estimated but using an approach

Page 9of **17** employing proportioning and regression of available data.

Due to the lack of reliable data such as those ideally produced by detailed transport 
studies across the country, we can only use those published in reports showing estimates of 
PKT or VKT for specific modes of transport such as reports from studies the Japan International 
Cooperation Agency (JICA) for Metro Manila and its adjoining areas. These include PKT 
estimates from the Metro Manila Urban Transportation Integration Study (MMUTIS) in 1999 and 
the MMUTIS Update and Capacity Enhancement Project (MUCEP) in 2014. These reports only 
state the cases of Mega Manila.

Tables 8 to 10 show the estimated passenger-kilometers traveled for three scenarios 
simulated by JICA in the Roadmap 2 study: do-nothing, with BBB, and with Roadmap. ‘Donothing’ corresponds to the Business-As-Usual (BAU) case. ‘BBB’ refers to the current 
administration’s “Build, Build, Build” projects while ‘Roadmap’ refers to the long list of projects 
identified by the JICA study that are proposed to address the transport problems (e.g., 
congestion, inefficient services, etc.) and the backlog of transportation infrastructure in the 
Mega Manila area.

**Table 8: Estimated person-kilometers for the Mega Manila area from the JICA Roadmap 2 
transport model**

| Mega Manila |  | 2017 | 2022 Do-Nothing | 2022 with BBB | 2035 Do-Nothing | 2035 with BBB | 2035 with Roadmap |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Person-km ('000) | Car | 63,736 | 66,133 | 64,126 | 73,769 | 74,641 | 73,499 |
| Person-km ('000) | Public | 84,042 | 93,582 | 78,451 | 121,701 | 93,611 | 95,733 |
| Person-km ('000) | Rail | 8,550 | 9,726 | 21,630 | 11,015 | 39,702 | 35,251 |
| Person-km ('000) | Total | 156,328 | 169,442 | 164,207 | 206,485 | 207,953 | 204,483 |

*Source: JICA Roadmap 2 (2019)*

**Table 9: Estimated person-kilometers for the Metro Manila area from the JICA Roadmap 2 
transport model**

| Metro Manila |  | 2017 | 2022 Do-Nothing | 2022 with BBB | 2035 Do-Nothing | 2035 with BBB | 2035 with Roadmap |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Person-km ('000) | Car | 40,860 | 41,098 | 39,820 | 42,524 | 42,529 | 44,050 |
| Person-km ('000) | Public | 49,115 | 54,789 | 41,189 | 71,974 | 45,674 | 49,302 |
| Person-km ('000) | Rail | 8,550 | 9,726 | 21,630 | 11,015 | 39,702 | 35,251 |
| Person-km ('000) | Total | 98,526 | 105,614 | 102,639 | 125,512 | 127,906 | 128,602 |

*Source: JICA Roadmap 2 (2019)*

**Table 10: Estimated person-kilometers for the adjoining areas of Metro Manila area from 
the JICA Roadmap 2 transport model**

| Adjoining Area |  | 2017 | 2022 Do-Nothing | 2022 with BBB | 2035 Do-Nothing | 2035 with BBB | 2035 with Roadmap |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Person-km ('000) | Car | 22,876 | 25,035 | 24,305 | 31,245 | 32,111 | 29,449 |
| Person-km ('000) | Public | 34,927 | 38,793 | 37,263 | 49,728 | 47,936 | 46,431 |
| Person-km ('000) | Rail | - | - | - | - | - | - |
| Person-km ('000) | Total | 57,803 | 63,828 | 61,568 | 80,972 | 80,048 | 75,880 |

*Source: JICA Roadmap 2 (2019)*

Page **10of 17**

---

Note from the tables that the vehicle classifications are quite general with ‘car’ 
representing all types of private vehicles (e.g., cars, vans, SUV, motorcycles, etc.), ‘public’ 
representing all types of public utility vehicles (e.g., jeepneys, vans, buses, etc.), and ‘rail’ 
representing what appears as only commuter rail services (e.g., Lines 1, 2 and 3 & PNR 
commuter rail). That means there is still a need to disaggregate these into more detailed vehicle 
types depending on the purpose of analysis. For our case, such a disaggregation is required 
since energy modelling requires specific types of vehicles for correspondence with fuel 
efficiency and consumption data. These were disaggregated according to the vehicle types and 
VKT values can be determined using the occupancy values in Table 2.

Since the available data are for specific years 2017, 2022 and 2035, regression models 
were employed to determine future PKTs for Metro Manila. For the rest of the country, the 
options were to use either population and GDP to estimate/proportion the total. Metro Manila is 
the NCR and has the largest share for economic activity for the country. GDP was determined 
to be a more reliable parameter to estimate PKT across the regions compared to population. 
Figure 1 shows the regression model for estimating future PKT for Metro Manila.

**Figure 1: Example regression of PKT for Metro Manila**

| Year | PKT-ALL-MM (x 1,000,000) | Linear (PKT-ALL-MM) (x 1,000,000) |
| --- | --- | --- |
| 2017 | 33000 | 32000 |
| 2022 | 35200 | 35000 |
| 2035 | 41800 | 41800 |

For specific projects such as BRT, the PKT attributed to the project can be derived from 
the GHG estimates for both the proposed Cebu and Metro Manila BRT projects. These are 
sourced from the reports for each project but are presented in different ways as shown in 
Tables 11 and 12. For the case of the proposed Cebu BRT corridor, emissions were presented 
per vehicle type and emissions specifically attributed to BRT buses can be isolated. These are 
divided by the corresponding emission values per passenger-kilometer to determine PKT 
values.

Page **11of 17**

---

**Table 11:** <u><strong>PKT estimates for the Cebu BRT corridor</strong></u>
Vehicle type Tons CO2 emitted along BRT corridor

| Vehicle type | Tons CO2 emitted along BRT corridor 2015 | Tons CO2 emitted along BRT corridor 2020 | Tons CO2 emitted along BRT corridor 2025 | Tons CO2 emitted along BRT corridor 2035 |
| --- | --- | --- | --- | --- |
| Cars | 30,469 | 47,855 | 71,141 | 121,890 |
| Taxis | 12,562 | 16,880 | 22,525 | 28,059 |
| Jeepneys | 13,179 | 14,417 | 22,629 | 33,072 |
| Inter-urban buses | 8,142 | 7,796 | 7,252 | 1,187 |
| BRT buses | 6,620 | 9,046 | 11,862 | 27,605 |
| MC/TC | 6,723 | 7,203 | 4,769 | 11,429 |
| Trucks | 7,435 | 9,430 | 13,988 | 20,094 |
| TOTAL | 85,130 | 112,627 | 154,166 | 243,336 |
| BRT corridor emissions per person-km, grams CO2e | 75.2 | 81.3 | 91.6 | 82.6 |
| Person-kilometers, BRT Corridor | 1,132,047,872 | 1,385,325,953 | 1,683,034,934 | 2,945,956,416 |
| Person-kilometers, BRT buses | 88,031,915 | 111,266,913 | 129,497,817 | 334,200,969 |

*Reference: World Bank (2012) Cebu City Urban Transport Greenhouse Gas Emissions Study, Final Report.*

For the Manila-Quezon City BRT corridor, the emissions attributed specifically to the 
BRT are presented in the report instead of a breakdown similar to the Cebu case. As such, a 
simpler table is presented below.

**Table 12:** <u><strong>PKT estimates for the Manila-Quezon City BRT corridor</strong></u>
**GHG emissions per**

| Year | Annual GHG Emissions (tons CO2e) | GHG emissions per person-km (g/pkm CO2e) | Passenger-kilometers from model |
| --- | --- | --- | --- |
| 2016 | 6,200 | 140 | 44,285,714 |
| 2020 | 12,735 | 174 | 73,189,655 |
| 2025 | 94,833 | 201 | 471,805,970 |
| 2035 | 357,246 | 213 | 1,677,211,268 |

*Reference: World Bank (2013) Manila-Quezon Corridor Improvement Project, Detailed Technical Study,* 
*Final Report.*

The PKT estimates in Tables 11 and 12 are estimated from transport model outcomes 
for the two studies conducted in support of the projects. These were modeled using similar 
approach and software by the JICA Roadmap 2 study.

### b. Rail transportation

One approach for estimating PKT for rail transport is by using the train capacity, 
operating hours, and number of trains operating per hour to estimate the number of passengers

Page **12of 17** per day. If the average distance traveled per passenger is known, then the PKT can be directly 
calculated from these values. This is shown in Table 13 where the PKTs for the four railway 
lines in Metro Manila are estimated.

**Table 13: Example data and calculations for railways in Metro Manila**
Line 1 Line 2 Line 3

|  | Line 1 | Line 2 | Line 3 | PNR |
| --- | --- | --- | --- | --- |
| Capacity, passengers per traina | 1,358 | 1,628 | 1,182 | 1,348d |
| Operating hoursa | 17 | 17 | 18 | 14 |
| Average trains per houra | 9.5 | 3.4 | 9.0 | 1.2 |
| Directions | 2 | 2 | 2 | 2 |
| Pax per dayb | 438,634 | 188,197 | 382,968 | 45,293 |
| Average distance traveled per passenger, kilometersc | 7.5 | 7.5 | 7.5 | 7.5 |
| PKT/dayb | 3,289,755 | 1,411,476 | 2,872,260 | 339,696 |
| Passengers per yearb | 160,101,410 | 68,691,832 | 139,783,320 | 16,531,872 |
| PKT per yearb | 1,200,760,575 | 515,188,740 | 1,048,374,900 | 123,989,040 |

<sup>a</sup>Reference: LRTA and MRTC

<sup>b</sup>Calculated

<sup>c</sup>Reference: JICA: Metro Manila Strategic Mass Rail Transit Development (2009)

<sup>d</sup>The PNR operates two configurations of trains: 3-car and 6-car configuration. The capacity assumed is that 
*for a 6-car train, which is the more frequent set.*

The ideal case is if the railway companies process their data and report on the PKT. 
Lines 1, 2 and 3 only report the number of passengers arriving or departing at each station but 
does not report the PKT. Meanwhile, the Philippine National Railways (PNR), reports statistics 
on passenger-kilometers traveled. Table 14 shows the monthly and total passenger-kilometers 
statistics from 2010 to 2017 as reported by the PNR.

**Table 14: Passenger-kilometers for the PNR Metro Manila Commuter Line**
**2010 2011 2012 2013 2014 2015**

|  | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| JAN | 4,432,274 | 16,085,762 | 19,529,412 | 18,141,578 | 34,006,853 | 36,301,867 | 37,942,765 |
| FEB | 4,687,256 | 15,878,870 | 19,447,582 | 17,628,548 | 33,509,270 | 32,350,308 | 35,883,449 |
| MAR | 7,758,170 | 18,559,632 | 20,327,188 | 18,344,396 | 39,621,590 | 39,295,745 | 32,777,765 |
| APR | 7,635,978 | 15,099,350 | 16,579,150 | 19,629,988 | 33,827,346 | 32,218,542 | 32,109,825 |
| MAY | 8,792,140 | 17,341,422 | 17,803,310 | 21,153,328 | 37,493,404 | 3,505,818 | 31,125,155 |
| JUN | 10,634,722 | 17,575,250 | 17,931,746 | 21,620,536 | 34,022,051 | - | 30,895,223 |
| JUL | 12,841,332 | 18,123,574 | 17,761,520 | 25,246,872 | 34,630,021 | 7,380,948 | 29,752,548 |
| AUG | 12,751,774 | 18,381,650 | 13,579,020 | 22,322,216 | 34,294,939 | 29,942,926 | 29,282,517 |
| SEP | 12,919,970 | 18,725,644 | 15,386,714 | 25,043,620 | 34,163,112 | 34,371,817 | 29,559,730 |
| OCT | 13,821,248 | 19,433,624 | 17,485,132 | 26,831,168 | 35,764,053 | 32,631,060 | 32,051,587 |
| NOV | 14,738,038 | 19,029,738 | 17,498,796 | 22,964,346 | 36,620,564 | 37,781,009 | 28,834,979 |
| DEC | 16,278,416 | 20,354,278 | 18,008,494 | 26,527,875 | 36,816,325 | 39,199,580 | 24,472,125 |
| TOTAL | 127,291,318 | 214,588,794 | 211,338,064 | 265,454,471 | 424,769,528 | 324,979,620 | 374,687,668 |

*Source: Philippine National Railways*

Page **13of 17**

---

A similar approach is applied for the case of BBB projects including the Clark Railway 
Line, the Metro Manila Subway, MRT Line 7 and the extensions of Lines 1 (to Cavite) and 2 (to 
Antipolo). For projecting future PKTs, however, the estimated growth rates of rail passenger 
traffic is adopted from the JICA Roadmap 2 study to obtain values until 2051. This is possible 
given that the JICA study estimated and reported rail PKTs.

### c. Air transportation

In the case of air transportation, PKTs may be estimated directly from data comprising of 
flights (including aircraft type) and number of passengers. The complete data can be 
approximated based on the information that can be gathered from four airports. These are 
Ninoy Aquino International Airport (NAIA), Mactan Cebu International Airport (MCIA), Clark 
International Airport and Francisco Bangoy International Airport. Inbound and outbound flights 
from these airports account for most of the aircraft movements in the country including both 
domestic and international flights. Other significant airports would be Iloilo, Bacolod-Silay, 
Caticlan, Puerto Princesa, Cagayan-De Oro/Laguindingan, and Zamboanga. These also have 
unique flights including limited international services.

For this study and at this point, only Cebu and Clark had the details required to estimate 
PKTs. These include aircraft origin, destination, departure and arrival times, aircraft type and 
number of passengers. These allowed for more precise calculations of PKTs that in turn allowed 
for regression models to be used to project future PKTs. Table 15 shows the VKT and PKT 
estimates for MCIA based on statistics provided by the airport authority.

<u><strong>Table 15: Statistics,</strong></u> **and VKT and PKT Estimates for MCIA**
Aircraft Number of Passenger Passenger Distance Travelled of Domestic

| Aircraft Type | Number of Departure Flights Total | Number of Departure Flights %Share | Passenger Capacity | Passenger Number | Distance Travelled of Domestic Flights (in KM) Arrival | Distance Travelled of Domestic Flights (in KM) Departure | Distance Travelled of Domestic Flights (in KM) Total | Average VKT | Average PKT |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A321-100 | 1,521 | 4.13% | 200 | 108.84 | 761,933 | 754,644 | 1,516,577 | 496.15 | 54,000.93 |
| A320 | 15,328 | 41.64% | 180 | 97.96 | 7,712,652 | 7,784,857 | 15,497,509 | 507.88 | 49,750.35 |
| A321 | 1 | 0.00% | 200 | 108.84 | 567 | 567 | 1,134 | 566.92 | 61,703.57 |
| A321-211 | 498 | 1.35% | 200 | 108.84 | 282,326 | 282,326 | 564,652 | 566.92 | 61,703.57 |
| A321-231 | 703 | 1.91% | 200 | 108.84 | 397,004 | 395,941 | 792,946 | 563.22 | 61,300.52 |
| A330 | 54 | 0.15% | 335 | 182.31 | 30,614 | 30,614 | 61,227 | 566.92 | 103,353.48 |
| A330-300 | 394 | 1.07% | 335 | 182.31 | 222,233 | 223,366 | 445,599 | 566.92 | 103,353.48 |
| A330-343 | 399 | 1.08% | 335 | 182.31 | 225,646 | 226,201 | 451,847 | 566.92 | 103,353.48 |
| A340-300 | 275 | 0.75% | 375 | 204.08 | 155,903 | 155,903 | 311,806 | 566.92 | 115,694.20 |
| B737-200 | 241 | 0.65% | 215 | 117.00 | 159,646 | 158,332 | 317,978 | 656.98 | 76,868.63 |
| B777-300 | 7 | 0.02% | 396 | 215.50 | 2,132 | 3,625 | 5,757 | 517.80 | 111,587.56 |
| Q300 | 594 | 1.61% | 56 | 30.48 | 115,895 | 117,016 | 232,911 | 197.00 | 6,003.49 |
| Q400 | 6,520 | 17.71% | 90 | 48.98 | 1,521,544 | 1,528,289 | 3,049,832 | 234.40 | 11,480.45 |
| ATR 72 | 10,242 | 27.82% | 90 | 48.98 | 2,333,558 | 2,436,636 | 4,770,194 | 237.91 | 11,652.17 |

*Reference: Statistics from Mactan Cebu International Airport Authority*

**d. Maritimetransportation**

The Philippine Ports Authority (PPA) data generally reports on inbound and outbound 
passengers and freight at ports under their jurisdiction. Meanwhile, the MARINA has data on the 
vessels registered and operating in the country. Similar to the case of aviation, the PKTs and 
VKTs may be derived if the port origin-destination data are known together with the data on 
passengers and freight for each vessel. Unfortunately, such data are not readily available with 
the maritime agencies that only publish summaries of inbound and outbound passengers and

Page **14of 17** freight.

#### 3.7 Crash data analysis

Road crash analysis are often performed by government agencies and LGUs in order to 
assess road safety and formulate interventions to reduce, for example, the number of fatal 
crashes occurring at particular locations (i.e., black spots). Road crash data, for example, are 
compiled by several agencies such as the DPWH, DOTr, DOH, PNP, and the MMDA. LGUs 
may also have their own database for road crashes particularly those that occurred at local 
roads. Currently, there are several databases managed by government agencies. These include 
Metro Manila Accident Recording and Analysis System (MMARAS) of the MMDA and Online 
National Electronic Injury Surveillance System (ONEISS) of the DOH.

### 4. Conclusions and Recommendations

In the ideal scenario, there should be regular and strategic data collection both at the 
national and local levels geared towards the estimation of inter-regional, inter-provincial and 
even inter-town (cities and municipalities) trips.  It is recommended that agencies at least 
perform some analysis of the data concerning trips made through their facilities such as 
terminals, airports and ports. Most of the current data being collected and published are good 
enough for descriptive statistics but are difficult to use in order to obtain more substantial or indepth analysis using them.

It was also mentioned in the previous sections that transport models are quite useful in 
the evaluation of scenarios in addition to their typical use for travel demand forecasting. 
Currently, there are only the transport models for Metro Manila and Cebu City, which are the 
outcomes of foreign-funded initiatives (i.e., JICA and WB). These models were developed using 
the CUBE software though there are other software suites like VISSUM and EMME that can 
also be developed. These usually have their own microsimulation software (e.g., Dynasim for 
CUBE and VISSIM for VISSUM) that allows for what are often macroscopic transport models to 
be transformed or exported for microsimulation. Other cities also need to have transport models 
for similar purposes as the studies for Metro Manila and Cebu City. However, there is also a 
need for a macroscopic transport model that covers the entire country to account at least for 
inter-regional or inter-island flow for all transport modes for both passengers and freight. 
Transport models cannot be developed without the data required for inputs. In many cases such 
data are not collected on a regular basis but only when there is a big study being implemented 
(e.g., MMUTIS, MUCEP, etc.).

Port statistics, for example, only state total inbound and outbound passengers and 
freight (i.e., of various categories); often distinguishing only between domestic and international 
passengers or freight. It is basically unknown where passengers and freight originated or 
destined. And passenger and freight would need to be related to the vessels to determine traffic 
at the vehicular (i.e., vessels or boats in the case of maritime transport). Similar cases may also 
be found for the aviation sector where few airports report details to establish the equivalents of 
passenger-kilometers or vehicle-kilometers. Again, the most common manner of data reporting 
is in the form of summarized inbound and outbound passengers and freight. Details such as 
origin-destination pairs and their corresponding distances and aircraft types are not immediately 
available and would need to be analyzed together to obtain substantial outputs usable for tasks 
such as analyzing demand and supply or perhaps estimating emissions or energy demand.

For railways, the examples of the PNR and MRT 3 reporting on PKTs is recommended 
for adoption by Lines 1 and 2 as well as future railway lines like Line 7 and the MM subway that

Page **15of 17** are either under construction or approved for implementation. These can be derived based on 
actual passenger ticket sales or fares. Perhaps the LRTA (Line 2) and the LRMC (Line 1) 
compile and process their data but useful information such as PKT need to be included in their 
reports following the PNR summary format. Thus, the need for standardization of data 
collection, analysis and reporting becomes obvious among these entities. The example for 
railways can be replicated in other agencies as well in terms of what data needs to be reported 
and in what form. In some cases, the larger agencies like the DOTr and DPWH may be the 
ones responsible for processing the data into forms that are more accessible and ready for 
analysis. Agencies or offices under them would be required to submit data in formats that would 
facilitate their use regardless of the user.

Page **16of 17**

---

### References

Department of Public Works and Highways, Road and Traffic Data.

Department of Transportation, Statistics and Reports from allied agencies.

Japan International Cooperation Agency (2019) Roadmap 2 for Transport Infrastructure 
Development for Metro Manila and Its Surrounding Areas, Final Report.

Japan International Cooperation Agency (2014) Roadmap for Transport Infrastructure 
Development for Metro Manila and Its Surrounding Areas, Final Report.

Japan International Cooperation Agency (2014) MMUTIS Update and Capacity Enhancement 
Project (MUCEP), Final Report.

Japan International Cooperation Agency (1999) Metro Manila Urban Transportation Integration 
Study (MMUTIS), Final Report.

Land Transportation Office, Statistics on Vehicle Registration.

Land Transport Franchising and Regulatory Board, Statistics on Public Utility Vehicles.

Light Rail Transit Authority, Statistics on Line 1 and Line 2.

Mactan Cebu International Airport, Statistics on air passengers and aircraft movements.

Metro Rail Transit Corporation, Statistics on Line 3.

Regidor, J.R.F., Vergel, K.N. and Napalang, M.S.G. (2009) Environment Friendly Paratransit: 
Re-Engineering the Jeepney, Proceedings of the Eastern Asia Society for Transportation 
Studies, Vol. 7.

Philippine National Railways, Statistics on Commuter Line and Bicol Line.

Philippine Ports Authority, Statistics on Shipping, Cargo and Passengers.

World Bank (2013) Manila-Quezon Corridor Improvement Project, Detailed Technical Study, 
Final Report.

World Bank (2012) Cebu City Urban Transport Greenhouse Gas Emissions Study, Final Report.

Page **17of 17**