Source: https://www.ford.com/support/how-tos/ford-services/parts-and-service/where-can-i-get-self-repair-and-technical-information/
Title: Where can I get self-repair and technical information?
Fetched: 2026-11-11T10:13:57.475Z

![](https://wwwac.ownaem.ford.com/content/dam/own/ford/us/images/shelp/how-to-articles/search-background.jpg)

Search IconSearch Icon

Get support from Ford AI

[Ask AI](https://www.ford.com/support/how-tos/ford-services/parts-and-service/where-can-i-get-self-repair-and-technical-information/ai-mode)

Print

# Where can I get self-repair and technical information for my Ford?

The Motorcraft®\* Service website has a variety of resources for self-repair and technical information. To get started, visit the [Motorcraft Service](https://www.motorcraftservice.com/Home/Index) website and select your location.

## **Resources on the Motorcraft Service Website**

Select what repair information you are seeking from the drop-down option below to learn more about what the Motorcraft Service website offers.

Service Information

You can get a subscription that includes the following resources:

- Workshop Manual
- Wiring Diagram Manual (also referred to as EVTMs or Electrical Vacuum Troubleshooting Manuals)
- Powertrain Control/Emissions Diagnosis (PC/ED) Manual
- Technical Service Bulletins (TSBs) (1994-Present)
- Access to downloadable initialization (PATS) information
- Access to the latest calibration information for emission-related modules
- Access to vehicle-specific Information (available for the last 10 model years)
- Limited vehicle line coverage for 1994-present model years

Free Resources > Quick Guides

You can access information such as:

- Ford PowerStroke 6.0L and 6.4L Diesel Engine care.
- Easy Fuel No Cap Fuel filler usage, including the fuel filler funnel and the locking fuel plug.
- How to remove a tire for vehicles equipped with Tire Pressure Monitor Systems without damaging the system.
- The latest towing procedures for Ford, Lincoln, and Mercury passenger cars and light trucks.



**Note:** These easy-to-follow instructions and illustrations provide the correct hookups for sling belt wrecker, wheel-lift, or flatbed towing

Training

Purchase web-based technical training classes. Choose a category such as:

- Gasoline or diesel engine repair.
- Electrical systems.
- Manual and automatic transmissions.
- Brakes.
- Steering and suspension.

**Note:** To purchase a hard copy of your vehicle's workshop manual, visit the [Helm website](http://www.helminc.com/) or call [1-800-782-4356](tel:800-782-4356). These manuals are for specific models and are available for years prior to what is accessible through Motorcraft Service.

For more complex vehicle repair-related questions, contact your [Ford Dealer](https://www.ford.com/dealerships/?gnav=header-finddealer#/q/80012).

## **Additional Information**

[How do I get an Owner's Manual?](https://www.ford.com/support/how-tos/owner-resources/vehicle-documents/where-can-i-get-an-owners-manual) [Where can I purchase replacement parts?](https://www.ford.com/support/how-tos/ford-services/parts-and-service/where-can-i-purchase-ford-replacement-parts)

* * *

\*Motorcraft is a registered trademark of Ford Motor Company.

Did we answer your question?

YesNo

Back to top iconA circle containing an upwards pointing arrowWhere can I get self-repair and technical information?

![](https://fordtccchatprodsa.blob.core.windows.net/chaticons/ChatIcon_White_Callout.png)

CHAT NOW