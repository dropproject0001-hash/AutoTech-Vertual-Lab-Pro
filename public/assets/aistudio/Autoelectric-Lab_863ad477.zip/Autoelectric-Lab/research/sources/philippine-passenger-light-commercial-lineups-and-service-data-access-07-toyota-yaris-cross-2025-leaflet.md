Source: https://content.toyota.com.ph/uploads/vehicles/52/001_52_1754043705984_000.pdf
Title: Yaris Cross 2025 Leaflet
Fetched: 2026-11-11T12:55:34.127Z

# ELECTRIFY YOUR PASSIONS

# Toyota Yaris Cross
# ELECTRIFY YOUR PASSIONS
Electrified mobility within reach, providing sustainability and versatility in
one subcompact SUV. Have the power to cross through all lives you lead.

SCAN TO
LEARN MORE

Disclaimer: Toyota Motor Philippines Corporation reserves the right to change
the vehicle specifications without prior notice. Vehicle featured is Toyota Yaris Cross SE HEV CVT. Actual unit may vary.

Move your world

---

| MODEL |  | YARIS CROSS |  |  |  |
| --- | --- | --- | --- | --- | --- |
| VARIANT |  | 1.5 SE HEV CVT | 1.5 S HEV CVT | 1.5 V CVT | 1.5 G CVT |
| OVERALL DIMENSIONS |  |  |  |  |  |
| Length × Width × Height | mm | 4310 × 1770 × 1615 |  |  |  |
| Wheelbase | mm | 2620 |  |  |  |
| Minimum Ground Clearance | mm | 212 |  |  |  |
| Seating Capacity |  | 5 |  |  |  |
| ENGINE &amp; TRANSMISSIONS |  |  |  |  |  |
| Engine Code |  | 2NR-VEX |  | 2NR-VE |  |
| Engine Type |  | Hybrid 4-cylinder, In-Line, 16-Valve, Dual VVT-i |  | 4-cylinder, In-Line, 16-Valve, Dual VVT-i |  |
| Displacement | cc | 1496 |  |  |  |
| Max Output | PS/rpm | 91/5500 |  | 106/6000 |  |
| Max Torque | Nm/rpm | 121/4800 |  | 138/4200 |  |
| Motor Generator Max Output | PS | 80 |  | N/A |  |
| Total System Max Output | PS/rpm | 111 |  | N/A |  |
| Battery Type |  | LI |  | N/A |  |
| Fuel Type |  | Gasoline |  |  |  |
| Fuel Tank Capacity | L | 36 |  | 42 |  |
| Transmission |  | CVT |  |  |  |
| CHASSIS |  |  |  |  |  |
| Tires |  | 215/55 R18 Alloy |  | 215/60 R17 Alloy |  |
| Brake Type | Front | Ventilated Disc |  |  |  |
| Brake Type | Rear | Solid Disc |  |  |  |
| EXTERIOR |  |  |  |  |  |
| Headlamps |  | LED |  |  |  |
| Daytime Running Lamps |  | LED |  |  |  |
| Clearance Lamp |  | LED |  |  |  |
| Front Fog Lamps |  | LED |  |  |  |
| High Mount Stop Lamp |  | LED |  |  |  |
| Rear Combination Lamp |  | LED |  |  |  |
| Real Concentration Lamp |  | LED |  |  |  |
| Outside Rearview Mirror |  | Power Adjust, Side Turn Signal, Puddle, Autofold |  |  | Power Adjust, Side Turn Signal, Autofold |
| Windshield Wiper | Front | Intermittent, Mist, Time Adjust |  |  |  |
| Windshield Wiper | Rear | Intermittent, Reverse Linked |  |  |  |
| Body Kit |  | SE Design | - |  |  |
| Rear Spoiler |  | SE Design | With (Standard) |  |  |
| Roof Rail |  | With |  |  |  |
| Antenna |  | Fin Type |  |  |  |
| Moon Roof |  | Panoramic | - |  |  |
| INTERIORS |  |  |  |  |  |
| Seat Material |  | Synthetic Leather - FR: With Blue Stitching |  |  | Fabric - FR: With Blue Stitching |
| Front Seat Type &amp; Adjustment | Driver | 8-way Power |  |  | 6-way Manual |
| Front Seat Type &amp; Adjustment | Passenger | 4-way Manual |  |  |  |
| Rear Seat Type &amp; Adjustment |  | 60:40 Split (Fold Flat) |  |  |  |
| Inside Rearview Mirror |  | Digital Rearview Mirror | Day &amp; Night |  |  |
| FUNCTION |  |  |  |  |  |
| Paddle Shifter |  | - | With |  | - |
| Power Steering Type |  | EPS |  |  |  |
| Keyless Entry |  | Smart Entry |  |  |  |
| Ignition System |  | Push Start |  |  |  |
| Drive Modes |  | Eco, Normal, Power, EV | Eco, Normal, Power |  | - |
| Power Windows | Driver | Jam Protect |  |  |  |
| Power Windows | Passenger | With |  |  |  |
| Power Windows | Rear | With |  |  |  |
| Power Doorfocks |  | With Speed Sensing |  |  |  |
| Power Back Door |  | With Kick Sensor |  |  | - |
| Air conditioning System |  | Auto Single Zone Climate Control |  |  |  |
| Rear A/C Vent |  | Manual |  |  |  |
| Light Control System |  | With Follow Me Home, Auto Light |  |  | - |
| Audio |  | 10.1" Display Audio |  |  |  |
| Digital Signal Processor |  | With | - |  |  |
| Speakers |  | 6-Speaker Pioneer System |  | 6 |  |
| Multi Information Display (MID) |  | 7" TFT |  |  |  |
| Connectivity |  | Wireless Apple Carplay &amp; Android Auto, Bluetooth, Voice Command |  |  |  |
| USB | Front | Type A: 1, Type C: 1 |  |  |  |
| USB | Rear | Type C: 2 |  |  |  |
| 12v Socket |  | With |  |  |  |
| Wireless Charger |  | With |  |  |  |
| Steering Switches |  | Audio, Display, Voice, Telephone, Cruise Control, Lane Tracing Assist, Drive Mode, PVM |  | Audio, Display, Voice, Telephone |  |
| SAFETY |  |  |  |  |  |
| Toyota Safety Sense (TSS) | Pre-Collision System (PCS) | With |  | - |  |
| Toyota Safety Sense (TSS) | Automatic High Beam (AHB) | With |  | - |  |
| Toyota Safety Sense (TSS) | Lane Tracing Assist (LTA) | With |  | - |  |
| Toyota Safety Sense (TSS) | Lane Keeping Assist (LKA) | With |  | - |  |
| Toyota Safety Sense (TSS) | Adaptive Cruise Control (ACC) | With |  | - |  |
| Blind Spot Monitor (BSM) |  | With |  | - |  |
| Rear Cross Traffic Alert (RCTA) |  | With |  | - |  |
| SRS Airbags |  | Driver, Passenger, Side, Curtain Shield |  |  |  |
| Anti-Lock Brake System (ABS) |  | With Brake Assist |  |  |  |
| Vehicle Stability Control (VSC) |  | With |  |  |  |
| Hill-Start Assist Control (HAC) |  | With |  |  |  |
| Seatbelts | Front | 3pt. ELR Pretensioner with Force Limiter |  |  |  |
| Seatbelts | Rear | 3pt. ELR |  |  |  |
| Child Restraint System |  | With ISOFIX: 2 |  |  |  |
| Emergency Brake Signal |  | With |  |  |  |
| Toyota Vehicle Security System (TVSS) |  | Alarm, Immobilizer |  |  |  |
| Camera |  | Panoramic View Monitor |  | Back Camera |  |
| Clearance &amp; Back Sonar | Front | 2 |  |  |  |
| Clearance &amp; Back Sonar | Rear | 2 |  |  |  |
| Drive Video Recorder |  | Front &amp; Rear | Front |  |  |

| COLORS | 1.5 SE HEV CVT | 1.5 S HEV CVT | 1.5 V CVT | 1.5 G CVT |
| --- | --- | --- | --- | --- |
| Platinum White Pearl Mica / Attitude Black Mica |  |  |  |  |
| Scarlet SE / Attitude Black Mica |  |  |  |  |
| Dark Turquoise SE / Attitude Black Mica |  |  |  |  |
| Platinum White Pearl Mica |  |  |  |  |
| Greenish Gun Metal |  |  |  |  |
| Dark Turquoise SE |  |  |  |  |
| Scarlet SE |  |  |  |  |
| Attitude Black Mica |  |  |  |  |

Platinum White Pearl Mica / Attitude Black Mica

Dark Turquoise SE / Attitude Black Mica

Dark Turquoise SE

Scarlet SE

Scarlet SE / Attitude Black Mica

Platinum White Pearl Mica

Greenish Gun Metal

Attitude Black Mica

**SCAN TO EXPERIENCE**
**MORE AT myTOYOTA.**