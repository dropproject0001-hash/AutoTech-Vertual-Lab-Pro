Source: https://lto.gov.ph/wp-content/uploads/2023/11/Annual_Reports-2023.pdf
Title: 
Fetched: 2026-11-11T12:54:49.856Z

## Department of Transportation LAND TRANSPORTATION OFFICE

Office of the Assistant Secretary PLANNING STAFF

## NUMBER OF TRANSACTIONS HANDLED BY LTO Comparative, JAN.-SEPT. 2022; JAN.-SEPT. 2023

Date of Preparation: 08 November 2023

| TRANSACTIONS | ACCOMPLISHMENT JAN.-SEPT. 2022 | ACCOMPLISHMENT JAN.-SEPT. 2023 | % INC. (DEC.) 23/22 | INCREASE 23/22 |
| --- | --- | --- | --- | --- |
| MV REGISTERED | 11,089,241 | 11,748,088 | 5.94 | 658,847 |
| MV REG. TRANS. HANDLED | 17,405,434 | 16,397,017 | (5.79) | -1,008,417 |
| LIC. &amp; PERMITS ISSUED | 5,121,656 | 5,583,401 | 9.02 | 461,745 |
| LIC. &amp; PERMITS CASES HANDLED | 7,057,523 | 7,829,395 | 10.94 | 771,872 |
| REVENUE COLLECTION (P) | 21,090,823,413 | 23,713,067,339 | 12.43 | 2,622,243,925 |
| APPREHENSIONS HANDLED | 389,105 | 410,823 | 5.58 | 21,718 |

c:mydocu~1/Jan-May_2023.xls\pmct

---

Date of Preparation: 08 November 2023

| REGIONS | MOTOR VEHICLES REGISTERED JAN.-SEPT. 2022 | MOTOR VEHICLES REGISTERED JAN.-SEPT. 2023 | % INC. (DEC. '23/'22 |
| --- | --- | --- | --- |
| I | 620,026 | 628,451 | 1.36 |
| II | 476,832 | 473,410 | (0.72) |
| III | 1,156,247 | 1,205,141 | 4.23 |
| IV-A | 1,524,153 | 1,593,687 | 4.56 |
| IV-B | 199,074 | 217,550 | 9.28 |
| V | 434,458 | 461,220 | 6.16 |
| VI | 530,182 | 566,772 | 6.90 |
| VII | 865,213 | 942,536 | 8.94 |
| VIII | 286,006 | 301,308 | 5.35 |
| IX | 385,391 | 371,984 | (3.48) |
| X | 460,664 | 462,555 | 0.41 |
| XI | 572,159 | 585,933 | 2.41 |
| XII | 400,649 | 422,141 | 5.36 |
| NCR | 2,821,732 | 3,141,142 | 11.32 |
| C.A.R. | 146,801 | 170,916 | 16.43 |
| CARAGA | 209,654 | 203,158 | (3.10) |
| C.O. |  | 184 |  |
| TOTAL | 11,089,241 | 11,748,088 | 5.94 |

---

## MOTOR VEHICLES REGISTERED BY CLASSIFICATION & MODE OF REGISTRATION Comparative, Accomplishment, Jan.-Sept. 2022; 2023

Date of Preparation: 08 November 2023

| MV CLASSIFICATION | MODE OF REG. | JAN.-SEPT. 2022 | JAN.-SEPT. 2023 | %INC.'23/'22 |
| --- | --- | --- | --- | --- |
| PRIVATE | NEW | 2,109,774 | 1,830,687 | -13.23 |
| PRIVATE | RENEWAL | 8,202,998 | 9,003,636 | 9.76 |
| PRIVATE | Sub-Total | 10,312,772 | 10,834,323 | 5.06 |
| GOVERNMENT | NEW | 10,382 | 8,264 | -20.40 |
| GOVERNMENT | RENEWAL | 69,238 | 132,151 | 90.86 |
| GOVERNMENT | Sub-Total | 79,620 | 140,415 | 76.36 |
| DIPLOMATIC | NEW | 147 | 195 | 32.65 |
| DIPLOMATIC | RENEWAL | 1,467 | 2,785 | 89.84 |
| DIPLOMATIC | Sub-Total | 1,614 | 2,980 | 84.63 |
| FOR HIRE | NEW |  | 1 |  |
| FOR HIRE | RENEWAL | 694,380 | 767,325 | 10.51 |
| FOR HIRE | Sub-Total | 694,380 | 767,326 | 10.51 |
| TAX-EXEMPT | NEW | 88 | 17 | -80.68 |
| TAX-EXEMPT | RENEWAL | 767 | 3027 | 294.65 |
| TAX-EXEMPT | Sub-Total | 855 | 3044 | 256.02 |
| TOTAL L | NEW | 2,120,391 | 1,839,164 | -13.26 |
| TOTAL L | RENEWAL | 8,968,850 | 9,908,924 | 10.48 |
| GRAND TOTAL |  | 11,089,241 | 11,748,088 | 5.94 |

---

## MOTOR VEHICLES REGISTERED BY MV TYPE & MODE OF REGISTRATION Comparative, Accomplishment, JAN.-SEPT. 2022; 2023

Date of Preparation: 08 November 2023

| MV TYPE | MODE OF REG. | JAN.-SEPT. 2022 | JAN.-SEPT. 2023 | %INC.'23/'22 |
| --- | --- | --- | --- | --- |
| CARS | NEW | 66,984 | 72,027 | 7.53 |
| CARS | RENEWAL | 1,004,021 | 1,117,082 | 11.26 |
| CARS | Sub-Total | 1,071,005 | 1,189,109 | 11.03 |
| UV | NEW | 156,014 | 163,878 | 5.04 |
| UV | RENEWAL | 1,948,776 | 2,182,540 | 12.00 |
| UV | Sub-Total | 2,104,790 | 2,346,418 | 11.48 |
| SUV | NEW | 85,851 | 97,498 | 13.57 |
| SUV | RENEWAL | 701,541 | 803,314 | 14.51 |
| SUV | Sub-Total | 787,392 | 900,812 | 14.40 |
| TRUCK | NEW | 28,612 | 26,109 | -8.75 |
| TRUCK | RENEWAL | 354,648 | 370,410 | 4.44 |
| TRUCK | Sub-Total | 383,260 | 396,519 | 3.46 |
| BUSES | NEW | 1,192 | 2,028 | 70.13 |
| BUSES | RENEWAL | 25,003 | 30,671 | 22.67 |
| BUSES | Sub-Total | 26,195 | 32,699 | 24.83 |
| MC/TC/NON-CONV | NEW | 1,778,711 | 1,474,345 | -17.11 |
| MC/TC/NON-CONV | RENEWAL | 4,889,042 | 5,352,384 | 9.48 |
| MC/TC/NON-CONV | Sub-Total | 6,667,753 | 6,826,729 | 2.38 |
| TRAILER | NEW | 3,027 | 3,279 | 8.33 |
| TRAILER | RENEWAL | 45,819 | 52,523 | 14.63 |
| TRAILER | Sub-Total | 48,846 | 55,802 | 14.24 |
| SUB-TOTAL | NEW | 2,120,391 | 1,839,164 | -13.26 |
| SUB-TOTAL | RENEWAL | 8,968,850 | 9,908,924 | 10.48 |
| TOTAL |  | 11,089,241 | 11,748,088 | 5.94 |

---

# NUMBER OF MOTOR VEHICLE REGISTRATION TRANSACTIONS HANDLED

Comparative, Accomplishment, JAN.-SEPT. 2022; 2023

Date of Preparation: 08 November 2023

| REGION | MV REG. TRANS. HANDLED JAN.-SEPT. 2022 | MV REG. TRANS. HANDLED JAN.SEPT. 2023 | % INC. (DEC.) 23/22 |
| --- | --- | --- | --- |
| I | 1,155,640 | 943,381 | (18.37) |
| II | 853,890 | 735,107 | (13.91) |
| III | 1,979,794 | 1,782,364 | (9.97) |
| IV-A | 2,461,368 | 2,094,240 | (14.92) |
| IV-B | 324,084 | 313,347 | (3.31) |
| V | 825,567 | 787,885 | (4.56) |
| VI | 697,989 | 782,478 | 12.10 |
| VII | 1,066,702 | 1,071,786 | 0.48 |
| VIII | 570,264 | 537,275 | (5.78) |
| IX | 695,862 | 613,991 | (11.77) |
| X | 741,333 | 679,336 | (8.36) |
| XI | 759,503 | 742,275 | (2.27) |
| XII | 699,674 | 634,808 | (9.27) |
| NCR | 4,054,973 | 4,172,741 | 2.90 |
| C.A.R. | 234,431 | 239,259 | 2.06 |
| CARAGA | 284,360 | 266,553 | (6.26) |
| C.O. |  | 191 |  |
| TOTAL | 17,405,434 | 16,397,017 | (5.79) |

c:mydocu~1/Jan-May_2023.xls\pmct

---

## DRIVER'S LICENSES & PERMITS ISSUED Comparative, Accomplishment, JAN.-SEPT. 2022; 2023

Date of Preparation: 08 November 2023

| REGION | NO. OF DRIVER'S LICENSES &amp; PERMITS ISSUED JAN.-SEPT. 2022 | NO. OF DRIVER'S LICENSES &amp; PERMITS ISSUED JAN.-SEPT. 2023 | NO. OF DRIVER'S LICENSES &amp; PERMITS ISSUED % INC. '23/'22 |
| --- | --- | --- | --- |
| I | 272,919 | 278,864 | 2.18 |
| II | 170,874 | 204,968 | 19.95 |
| III | 669,688 | 713,437 | 6.53 |
| IV-A | 762,369 | 816,914 | 7.15 |
| IV-B | 95,751 | 127,903 | 33.58 |
| V | 219,554 | 231,899 | 5.62 |
| VI | 264,363 | 310,908 | 17.61 |
| VII | 397,802 | 433,446 | 8.96 |
| VIII | 142,325 | 151,171 | 6.22 |
| IX | 154,973 | 159,621 | 3.00 |
| X | 228,298 | 222,416 | -2.58 |
| XI | 216,500 | 229,975 | 6.22 |
| XII | 190,338 | 234,190 | 23.04 |
| NCR | 1,064,720 | 1,117,117 | 4.92 |
| C.A.R. | 85,715 | 102,325 | 19.38 |
| CARAGA | 158,159 | 197,107 | 24.63 |
| C.O | 27,308 | 51,140 | 87.27 |
| TOTAL | 5,121,656 | 5,583,401 | 9.02 |

---

# DRIVER'S LICENSES & PERMIT ISSUED BY TYPE, NEW, RENEW-CONVERSION Comparative, Accomplishment, JAN.-SEPT. 2022; 2023

Date of Preparation: 08 November 2023

| TYPE OF LICENSE | MODE OF TRANS. | JAN.-SEPT. 2022 | JAN.-SEPT. 2023 | 23/22 |
| --- | --- | --- | --- | --- |
| STUDENT PERMIT | NEW | 1,238,894 | 1,331,901 | 7.51 |
| STUDENT PERMIT | RENEWAL | 11,668 | 24,266 | 107.97 |
| STUDENT PERMIT | Sub-Total | 1,250,562 | 1,356,167 | 8.44 |
| CONDUCTOR'S PERMIT | NEW | 2,580 | 3,552 | 37.67 |
| CONDUCTOR'S PERMIT | RENEWAL | 3,009 | 3,503 | 16.42 |
| CONDUCTOR'S PERMIT | Sub-Total | 5,589 | 7,055 | 26.23 |
| DRIVER'S LICENSE | NEW | 905,519 | 1,058,815 | 16.93 |
| DRIVER'S LICENSE | RENEWAL | 2,959,986 | 3,161,364 | 6.80 |
| DRIVER'S LICENSE | Sub-Total | 3,865,505 | 4,220,179 | 9.18 |
| T O T A L | NEW | 2,146,993 | 2,394,268 | 11.52 |
| T O T A L | RENEWAL | 2,974,663 | 3,189,133 | 7.21 |
| G R A N D T O T A L |  | 5,121,656 | 5,583,401 | 9.02 |

---

# DRIVER'S LICENSES & PERMITS CASES HANDLED Comparative, Accomplishment, JAN.-SEPT. 2022; 2023

Date of Preparation: 08 November 2023

| REGION | NO. OF DRIVER'S LICENSES &amp; PERMITS CASES HANDLED JAN.-SEPT. 2022 | NO. OF DRIVER'S LICENSES &amp; PERMITS CASES HANDLED JAN.-SEPT. 2023 | NO. OF DRIVER'S LICENSES &amp; PERMITS CASES HANDLED % INC. '23/'22 |
| --- | --- | --- | --- |
| I | 377,356 | 379,406 | 0.54 |
| II | 245,611 | 289,718 | 17.96 |
| III | 875,579 | 988,308 | 12.87 |
| IV-A | 1,050,274 | 1,149,890 | 9.48 |
| IV-B | 144,007 | 183,805 | 27.64 |
| V | 320,164 | 334,329 | 4.42 |
| VI | 352,074 | 417,018 | 18.45 |
| VII | 528,211 | 589,679 | 11.64 |
| VIII | 206,339 | 218,562 | 5.92 |
| IX | 210,855 | 216,289 | 2.58 |
| X | 307,394 | 308,692 | 0.42 |
| XI | 273,202 | 284,536 | 4.15 |
| XII | 257,570 | 311,487 | 20.93 |
| NCR | 1,515,134 | 1,646,925 | 8.70 |
| C.A.R. | 115,546 | 136,809 | 18.40 |
| CARAGA | 223,154 | 280,418 | 25.66 |
| C.O | 55,053 | 93,524 | 69.88 |
| TOTAL | 7,057,523 | 7,829,395 | 10.94 |

---

# NUMBER OF APPREHENSIONS HANDLED Comparative, Accomplishment, JAN.-SEPT. 2022; 2023

Date of Preparation: 08 November 2023

| REGION | NO. OF APPREHENSIONS HANDLED JAN.-SEPT. 2022 | NO. OF APPREHENSIONS HANDLED JAN.-SEPT. 2023 | NO. OF APPREHENSIONS HANDLED % INC. '23/'22 |
| --- | --- | --- | --- |
| I | 19,803 | 19,458 | -1.74 |
| II | 33,969 | 44,838 | 32.00 |
| III | 21,876 | 28,913 | 32.17 |
| IV-A | 36,952 | 35,835 | -3.02 |
| IV-B | 4,063 | 10,434 | 156.81 |
| V | 8,806 | 14,058 | 59.64 |
| VI | 9,078 | 14,134 | 55.70 |
| VII | 19,530 | 14,746 | -24.50 |
| VIII | 12,339 | 13,051 | 5.77 |
| IX | 21,334 | 10,357 | -51.45 |
| X | 18,044 | 20,458 | 13.38 |
| XI | 64,718 | 71,704 | 10.79 |
| XII | 19,300 | 30,021 | 55.55 |
| NCR | 7,165 | 10,384 | 44.93 |
| C.A.R. | 7,419 | 8,188 | 10.37 |
| CARAGA | 13,577 | 8,407 | -38.08 |
| C.O | 71,132 | 55,837 | -21.50 |
| TOTAL | 389,105 | 410,823 | 5.58 |

---

# NUMBER OF IMPOUNDED VEHICLES BY REGION Comparative, Accomplishment, JAN.-SEPT. 2022; 2023

Date of Preparation: 08 November 2023

| REGION | NO. OF IMPOUNDED MOTOR VEHICLES JAN.-SEPT. 2022 | NO. OF IMPOUNDED MOTOR VEHICLES JAN.-SEPT.. 2023 | NO. OF IMPOUNDED MOTOR VEHICLES % INC. '23/'22 |
| --- | --- | --- | --- |
| I | 29 | 28 | -3.45 |
| II | 405 | 713 | 76.05 |
| III | 16 | 19 | 18.75 |
| IV-A | 280 | 396 | 41.43 |
| IV-B | 849 | 2,021 | 138.04 |
| V | 2,106 | 2,197 | 4.32 |
| VI | 417 | 849 | 103.60 |
| VII | 881 | 1,437 | 63.11 |
| VIII | 1,172 | 1,912 | 63.14 |
| IX | 174 | 253 | 45.40 |
| X | 718 | 453 | -36.91 |
| XI | 1,556 | 2,068 | 32.90 |
| XII | 2,243 | 4,209 | 87.65 |
| NCR | 5 | 24 | 380.00 |
| C.A.R. | 751 | 292 | -61.12 |
| CARAGA | 293 | 342 | 16.72 |
| C.O | 45 | 119 | 164.44 |
| TOTAL | 11,940 | 17,332 | 45.16 |

---

# Dept. of Transportation LAND TRANSPORTATION Planning Staff-OASSEC

# OFFICE

# FREQUENTLY COMMITTED TRAFFIC VIOLATIONS NATIONWIDE

JAN.-SEPT. 2023

Date of Preparation: 08 November 2023

| VIOLATION | FREQUENCY |
| --- | --- |
| 1. RA 8750 SEATBELT USE ACT | 89,437 |
| 2. FAILURE OF DRIVER/RIDER OR BACK RIDER TO WEAR |  |
| PRESCRIBED HELMET | 57,800 |
| 3. RECKLESS DRIVING | 46,844 |
| 4. UNREGISTERED/INVALID MV REGISTRATION | 45,375 |
| 5. DRIVING W/O D_LICENSE | 26,793 |
| 6. DIRTY/UNSANITARY/DEFECTIVE UNIT (FOR-HIRE MVs) | 24,399 |
| 7. FAILURE TO CARRY DRIVER'S LICENSE | 24,549 |
| 8. NO CR/OR ON HAND | 19,634 |
| 9. OBSTRUCTION | 17,225 |
| 10. AXLE OVERLOADING | 16,020 |

---

VIOLATIONS INVOLVING R.A. 8749 (CLEAN AIR ACT), BY REGION COMPARATIVE, Accomplishment, JAN- SEPT. 2022; 2023

Date of Preparation: 08 November 2023

| REGIONS | APPREHENSIONS JAN.-SEPT. 2022 | APPREHENSIONS JAN.-SEPT.. 2023 | % INC. (DEC.) | JAN.-SEPT. 2023 RESOLVED CASES DROPPED | JAN.-SEPT. 2023 RESOLVED CASES FINED | JAN.-SEPT. 2023 RESOLVED CASES TOTAL | JAN.-SEPT. 2023 RESOLVED CASES % RESOLVED | JAN.-SEPT. 2023 FINES COLLECTED (in pesos) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| I | 6 | 14 | 133.33 |  | 15 | 15 | 107.14 | 28,000 |
| II | 37 | 35 | -5.41 |  | 40 | 40 | 114.29 | 77,000 |
| III |  | 64 |  |  | 54 | 54 | 84.38 | 109,000 |
| IV-A |  | 4 |  | 8 | 23 | 31 | 775.00 | 20,000 |
| IV-B |  |  |  |  |  |  |  |  |
| V |  |  |  |  |  |  |  |  |
| VI |  |  |  |  |  |  |  |  |
| VII | 3 | 3 | 0.00 |  | 3 | 3 | 100.00 | 3,000 |
| VIII | 5 | 10 | 100.00 |  | 11 | 11 | 110.00 | 22,000 |
| IX |  | 11 |  |  | 11 | 11 | 100.00 | 1,000 |
| X |  | 18 |  |  | 20 | 20 | 111.11 | 42,000 |
| XI | 183 | 76 | -58.47 |  | 143 | 143 | 188.16 | 316,000 |
| XII |  | 5 |  |  | 5 | 5 | 100.00 | 10,000 |
| NCR |  |  |  |  |  |  |  |  |
| C.A.R. | 18 | 2 | -88.89 |  | 5 | 5 | 250.00 | 12,400 |
| CARAGA |  |  |  |  |  |  |  |  |
| C.O. | 602 | 883 | 46.68 |  | 943 | 943 | 106.80 | 2,547,000 |
| TOTAL | 854 | 1,125 | 31.73 | 8 | 1,273 | 1,281 | 113.87 | 3,187,400 |

---

## Department of Transportation LAND TRANSPORTATION OFFICE Planning Staff-OASSEC

VIOLATIONS INVOLVING R.A. 8750 (SEAT BELT USE ACT), BY REGION COMPARATIVE, Accomplishment, JAN.-SEPT. 2022; 2023

Date of Preparation: 08 November 2023

| REGIONS | APPREHENSIONS JAN.-SEPT. 2022 | APPREHENSIONS JAN.-SEPT. 2023 | % INC. (DEC.) | JAN.-SEPT. 2023 RESOLVED CASES DROPPED | JAN.-SEPT. 2023 RESOLVED CASES FINED | JAN.-SEPT. 2023 RESOLVED CASES TOTAL | JAN.-SEPT. 2023 RESOLVED CASES % RESOLVED | JAN.-SEPT. 2023 FINES COLLECTED (in pesos) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| I | 8,654 | 8,363 | -3.36 | 4 | 8,054 | 8,058 | 96.35 | 11,295,500 |
| II | 5,772 | 8,033 | 39.17 |  | 7,295 | 7,295 | 90.81 | 10,491,750 |
| III | 7,437 | 8,696 | 16.93 |  | 9,625 | 9,625 | 110.68 | 13,088,500 |
| IV-A | 13,338 | 12,462 | -6.57 |  | 12,963 | 12,963 | 104.02 | 16,573,250 |
| IV-B | 1,106 | 2,161 | 95.39 |  | 2,159 | 2,159 | 99.91 | 3,276,750 |
| V | 1,696 | 3,082 | 81.72 | 7 | 2,908 | 2,915 | 94.58 | 4,254,500 |
| VI | 2,110 | 4,523 | 114.36 | 5 | 4,472 | 4,477 | 98.98 | 6,104,260 |
| VII | 7,533 | 8,460 | 12.31 | 9 | 7,634 | 7,643 | 90.34 | 10,956,000 |
| VIII | 2,371 | 2,896 | 22.14 |  | 2,951 | 2,951 | 101.90 | 4,419,300 |
| IX | 5,952 | 1,312 | -77.96 |  | 771 | 771 | 58.77 | 1,956,500 |
| X | 2,592 | 2,643 | 1.97 |  | 2,579 | 2,579 | 97.58 | 3,160,750 |
| XI | 12,712 | 9,967 | -21.59 | 15 | 10,098 | 10,113 | 101.46 | 14,142,000 |
| XII | 3,762 | 3,945 | 4.86 |  | 3,610 | 3,610 | 91.51 | 4,636,000 |
| NCR | 520 | 1,580 | 203.85 | 1 | 1,590 | 1,591 | 100.70 | 2,164,250 |
| C.A.R. | 2,038 | 3,173 | 55.69 | 15 | 2,467 | 2,482 | 78.22 | 3,906,750 |
| CARAGA | 2,649 | 2,775 | 4.76 |  | 1,418 | 1,418 | 51.10 | 1,608,000 |
| C.O. | 5,693 | 5,366 | -5.74 |  | 5,264 | 5,264 | 98.10 | 8,946,500 |
| TOTAL | 85,935 | 89,437 | 4.08 | 56 | 85,858 | 85,914 | 96.06 | 120,980,560 |

c:mydocu~1/Jan-May_2023.xls\pmct

* Includes the settlement of unresolved cases for the previous years

---

# AMOUNT OF REVENUE COLLECTION (in pesos), BY REGION Comparative, Accomplishment, JAN.-SEPT. 2022; 2023

Date of Preparation: 08 November 2023

| REGION | REVENUE COLLECTION (in pesos) JAN.-SEPT. 2022 | REVENUE COLLECTION (in pesos) JAN.-SEPT. 2023 | REVENUE COLLECTION (in pesos) % INC. '23/'22 |
| --- | --- | --- | --- |
| I | 966,205,103 | 1,037,028,017 | 7.33 |
| II | 805,303,416 | 892,289,929 | 10.80 |
| III | 2,267,179,805 | 2,525,752,758 | 11.41 |
| IV-A | 2,664,478,314 | 2,865,830,209 | 7.56 |
| IV-B | 292,609,991 | 381,298,849 | 30.31 |
| V | 651,783,255 | 757,556,011 | 16.23 |
| VI | 1,044,036,323 | 1,219,335,915 | 16.79 |
| VII | 1,481,232,705 | 1,630,586,649 | 10.08 |
| VIII | 466,551,139 | 541,731,615 | 16.11 |
| IX | 560,044,592 | 604,938,798 | 8.02 |
| X | 876,212,774 | 996,622,451 | 13.74 |
| XI | 1,062,074,960 | 1,216,273,829 | 14.52 |
| XII | 796,489,673 | 913,323,397 | 14.67 |
| NCR | 6,216,314,042 | 6,897,642,641 | 10.96 |
| C.A.R. | 330,367,740 | 409,617,796 | 23.99 |
| CARAGA | 377,143,530 | 438,509,854 | 16.27 |
| C.O | 232,796,052 | 384,728,621 | 65.26 |
| TOTAL | 21,090,823,413 | 23,713,067,339 | 12.43 |

---

## AMOUNT OF REVENUE COLLECTION BY SOURCE (in pesos) Comparative, Accomplishment, JAN.-SEPT. 2022; 2023

Date of Preparation: 08 November 2023

| SOURCE OF INCOME | JAN.-SEPT. 2022 | JAN.-SEPT. 2023 | % INC. '23/'22 |
| --- | --- | --- | --- |
| MOTOR VEHICLE USER'S CHARGE (MVUC) | 14,449,507,141 | 16,192,157,478 | 12.06 |
| LICENSE FEE | 2,368,795,612 | 2,601,946,143 | 9.84 |
| FINES &amp; PENALTIES (LAW ENF.) | 964,216,878 | 1,091,227,389 | 13.17 |
| Clean Air Act (RA 8749) | 2,498,200 | 3,187,400 | 27.59 |
| Seatbelt Use Act (RA8750) | 112,889,827 | 120,983,560 | 7.17 |
| Axle Overloading (RA 8794) | 36,573,954 | 32,012,810 | (12.47) |
| Other Fines &amp; Penalties JAO 2014-01 | 812,254,896 | 935,043,619 | 15.12 |
| TRUST LIABILITIES |  |  |  |
| Legal Research Fund | 148,900,014 | 157,465,704 | 5.75 |
| Others | 4,819,099 | 10,123,158 | 110.06 |
| SCIENCE TAX | 70,535,527 | 87,028,126 | 23.38 |
| MISCELLANEOUS INCOME |  |  |  |
| Registration of MV | 1,160,450,057 | 815,365,318 | (29.74) |
| Issuance of License | 369,790,535 | 417,944,712 | 13.02 |
| Law Enforcement | 21,780,710 | 26,494,531 | 21.64 |
| Others | 92,057,551 | 97,352,805 | 5.75 |
| CAPITAL REVENUE | 535,370 | 0 |  |
| PENALTIES |  |  |  |
| Registration of MV | 1,373,411,559 | 2,114,370,222 | 53.95 |
| Beyond the Month | 1,346,552,848 | 1,880,878,761 | 39.68 |
| Beyond the Week | 26,858,711 | 233,491,461 | 769.33 |
| Issuance of License | 47,967,448 | 81,114,115 | 69.10 |
| Science Tax | 18,055,913 | 20,477,638 | 13.41 |
| TOTAL | 21,090,823,414 | 23,713,067,339 | 12.43 |