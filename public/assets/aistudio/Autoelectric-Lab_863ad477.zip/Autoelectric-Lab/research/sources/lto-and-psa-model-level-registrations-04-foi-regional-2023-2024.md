Source: https://www.foi.gov.ph/agencies/lto/motor-vehicle-registration-data-by-region-for-the-years-2023-and-2024
Title: Maintenance · eFOI
Fetched: 2026-11-11T12:54:48.991Z

eFOI Portal · Advisory ADV-2026-10-01

# Temporary Maintenance

The eFOI Portal is temporarily unavailable. Thank you for your patience.

[**Lodge an FOI request** You may continue through our interim submission mechanism at foi.gov.ph/standard-requests\\
_→_](https://foi.gov.ph/standard-requests) [**Need help?** For FOI-related concerns and assistance, contact FOI-PMO at foi.gov.ph/service-desk\\
_→_](https://foi.gov.ph/service-desk) [**Follow us on Facebook** While we get things ready, you can also drop us a message on our Facebook page, and you can also follow us for updates. facebook.com/foiph\\
_→_](https://www.facebook.com/foiph/)