Source: https://www.hino.com.ph/200-series
Title: Hino Motors Philippines
Fetched: 2026-11-11T12:54:31.818Z

![](https://www.hino.com.ph/assets/images/PerProduct/200/200SeriesProductFront.jpg)

The Hino 200 Series is the lightest truck line among the Hino commercial vehicle portfolio.
It is designed for inner city use with key advantage on GVW, payload and maneuverability.


Featuring a key model in the N1 category, this light truck can be operated with non-commercial
driver's license, aiding driver availability for businesses.


## RELIABLE ENGINE

Equipped with TOYOTA 1GD-FTV Euro 4 Diesel engine, the Hino 200 Series packs power and unmatched reliability.
Bearing a trusted name for quality, this engine is ready for the task and is capable to pull more load than the typical city movers with ease.


![](https://www.hino.com.ph/assets/images/PerProduct/200/Hino200SeriesProductPage_ReliableEngine.jpg)

![](https://www.hino.com.ph/assets/images/PerProduct/200/Icons/Piston%20Icon_No%20Text.png)

2.755LEngine Displacement

![](https://www.hino.com.ph/assets/images/PerProduct/200/Icons/Engine%20Oil%20Icon_No%20Text.png)

7.0 LEngine Oil Capacity

![](https://www.hino.com.ph/assets/images/PerProduct/200/Icons/Max%20Output%20Icon_No%20Text.png)

144 PS @ 3,400 rpmMax. Output

![](https://www.hino.com.ph/assets/images/PerProduct/200/Icons/Max%20Torque_No%20Text.png)

300 Nm @ 1,200-3,200 rpmMax. Torque

## BIG CARGO CAPACITY

The Hino 200 Series may be a small truck, but it is unmatched in handling cargo in its class.


The 315 variant has a gross vehicle weight of 3,490 kgs falling within Philippine regulations' N1 Category.
With this, even non-professional driver's license holders are allowed to operate this vehicle.
On the other hand, the 415 variant has a GVW of 3,800 kgs for heavier load requirements.


![](https://www.hino.com.ph/assets/images/PerProduct/200/Hino200SeriesProductPage_BigCargoCapacity.jpg)

## SAFE DRIVING

Surround yourself in an extensive suite of active and passive driving safety technologies
that protect not only the driver, but also the passengers, the cargo, and other road users.


The Hino 200 Series offers these relevant safety features as options.


![](https://www.hino.com.ph/assets/images/PerProduct/200/Hino200SeriesProductPage_SafeDriving.jpg)

![](https://www.hino.com.ph/assets/images/PerProduct/200/Icons/ABS_No%20Text.png)

Anti-lock Brake System (ABS)

![](https://www.hino.com.ph/assets/images/PerProduct/200/Icons/VSC_No%20Text.png)

Vehicle Stability Control (VSC)

![](https://www.hino.com.ph/assets/images/PerProduct/200/Icons/SRS%20Bag_No%20Text.png)

SRS AIRBAG (Optional)

## AGILE MANEUVERING

The Hino 200 Series’ small turning radius of 4.7 meters, makes it the ideal transport partner
for MSMEs and other start-up businesses. Built nimble and agile, it can tackle even those tight streets and corners of
the metro. Equipped with hydraulic power steering and double wishbone front suspension, new drivers will find it very comfortable to drive.


![](https://www.hino.com.ph/assets/images/PerProduct/200/Hino200SeriesProductPage_AgileManeuvering.jpg)

## HINO 200 SERIES SPECIFICATIONS

| RANGE | TYPE | LICENCE | MODEL | Drive<br>System | GVW | Power \|Torque   (ISO NET) | WHEELBASE<br>(mm) | TRANS | PDF File |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| HINO 200 Series | 315 NAC | 4 x 2 (4W) | 3,490 | 144 \| 300 | 2,545 | R451 , 5-Speed M/T with Overdrive | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/200%20Series/Hino200Series315NAC.pdf) |  |
| 315 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/200%20Series/200Series315Brochure.pdf) |  |
| 415 | 3,800 | [![](https://www.hino.com.ph/assets/images/Icon/pdf-download.png)](https://www.hino.com.ph/File/200%20Series/200Series415Brochure.pdf) |  |

## Get in touch with our team

[![](https://www.hino.com.ph/assets/images/Icon/Telephone.png)\\
\\
Call (+63)2-7368-5800](tel:(+63)2-7368-5800)

[![](https://www.hino.com.ph/assets/images/Icon/Location.png)\\
\\
Find a dealer](https://www.hino.com.ph/FindaDealer.aspx)

Disclaimers:

_†Active safety systems are an aid to assist the driver and have performance limitations. Please refer to owner’s manual for system operations and functionality._

_#Refer to specification sheet for specific wheelbase._