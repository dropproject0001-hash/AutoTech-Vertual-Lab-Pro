Source: https://www.nissan.ph/service/overview.html
Title: Servicing & Maintenance - Overview
Fetched: 2026-11-11T10:05:54.566Z

COOKIE NOTIFICATION

We use cookies on our website for identification and analysis purposes. By using this website you consent to the storing and accessing of cookies on your device. Find out more in our [Legal and Other Policies page.](https://www.nissan.ph/privacy.html)

* * *

-


Overview



Overview

  - [Overview](https://www.nissan.ph/service/overview.html)
  - [Trust Nissan](https://www.nissan.ph/service/trustnissan.html)


    - [Trust Nissan](https://www.nissan.ph/service/trustnissan.html)
    - [Total Cost of Maintenance](https://www.nissan.ph/service/trustnissan/cost-of-maintenance.html)

  - [Nissan Wear](https://www.nissan.ph/service/nissanwear.html)


    - [Nissan Wear](https://www.nissan.ph/service/nissanwear.html)
    - [Shirts](https://www.nissan.ph/service/nissanwear/shirts.html)
    - [Polo Shirts](https://www.nissan.ph/service/nissanwear/polo-shirts.html)
    - [Headwear](https://www.nissan.ph/service/nissanwear/headwear.html)
    - [Collectibles](https://www.nissan.ph/service/nissanwear/collectibles.html)
    - [Essentials](https://www.nissan.ph/service/nissanwear/essentials.html)
    - [All Products](https://www.nissan.ph/service/nissanwear/catalog.html)
    - [About](https://www.nissan.ph/service/nissanwear/about.html)

  - [Aftersales Services](https://www.nissan.ph/service/aftersales-services.html)


    - [Aftersales Services](https://www.nissan.ph/service/aftersales-services.html)
    - [Protect+](https://www.nissan.ph/service/aftersales-services/ProtectPlus.html)
    - [Advantage+](https://www.nissan.ph/service/aftersales-services/advantageplus.html)
    - [New Patrol Accessory](https://www.nissan.ph/service/aftersales-services/NewNissanPatrolAccy.html)
    - [Nissan Express Service](https://www.nissan.ph/service/aftersales-services/express-service.html)
    - [Service on Wheels](https://www.nissan.ph/service/aftersales-services/service-wheels.html)
    - [Pick-up And Drop-off](https://www.nissan.ph/service/aftersales-services/pudo.html)

  - [Euro 2 Implementation Guidelines](https://www.nissan.ph/service/euro-2.html)
  - [Customer Support](https://www.nissan.ph/service/customer-support.html)


    - [Customer Support](https://www.nissan.ph/service/customer-support.html)
    - [Contact Us](https://www.nissan.ph/service/customer-support/contact-us.html)
    - [Warranty & Campaign](https://www.nissan.ph/service/customer-support/warranty-campaign.html)
    - [24/7 Emergency Assistance](https://www.nissan.ph/service/customer-support/emergency-assistance.html)

  - [Seasonal Promos](https://www.nissan.ph/service/promos.html)


    - [Seasonal Promos](https://www.nissan.ph/service/promos.html)
    - [Nissan Aftersales Promos](https://www.nissan.ph/service/promos/aftersales-promos.html)
    - [Aftersales Change Oil Promo](https://www.nissan.ph/service/promos/aftersales-change-oil-promo.html)

  - [Tires](https://www.nissan.ph/service/tires.html)
  - Genuine Parts    - [Parts](https://www.nissan.ph/service/nissan-genuine-battery.html)
    - [Accessories](https://www.nissan.ph/service/accessories.html)

Overview

![](https://www-asia.nissan-cdn.net/content/dam/Nissan/global/sandbox/nissan-services/img_serviceBanner_2.jpg.ximg.l_full_m.smart.jpg)

# SERVICING & MAINTENANCE

No one is better qualified to look after your new vehicle. Schedule your service today and be back on the road with confidence.

[BOOK A SERVICE](https://npi-olsb-customer.otoleap.com/)

## SERVICE YOUR NISSAN IN 4 EASY STEPS

![](https://www-asia.nissan-cdn.net/content/dam/Nissan/global/sandbox/nissan-services/ic_number_1_ud.png.ximg.l_3_m.smart.png)

## SCHEDULE A SERVICE

Scheduling an appointment could not be easier. Simply complete the form and let Nissan do the rest.

[BOOK NOW](https://npi-olsb-customer.otoleap.com/ "BOOK NOW")

![](https://www-asia.nissan-cdn.net/content/dam/Nissan/global/sandbox/nissan-services/ic_number_2_ud.png.ximg.l_3_m.smart.png)

## HANDOVER YOUR VEHICLE

Once you have handed over your car, your Nissan dealer will carry out a "best in class" service on your car.

![](https://www-asia.nissan-cdn.net/content/dam/Nissan/global/sandbox/nissan-services/ic_number_3_ud.png.ximg.l_3_m.smart.png)

## REVIEW THE WORK

All services carried out is recorded. Simply review the work with confidence.

![](https://www-asia.nissan-cdn.net/content/dam/Nissan/global/sandbox/nissan-services/ic_number_4_ud.png.ximg.l_3_m.smart.png)

## COLLECT YOUR VEHICLE

Once your vehicle is ready to collect, your dealer will hand over your car for you to enjoy until it is time for the next service.

## WHY CHOOSE NISSAN SERVICE?

![](https://www-asia.nissan-cdn.net/content/dam/Nissan/global/sandbox/nissan-services/ic-technicians.png.ximg.l_3_m.smart.png)

## FACTORY-TRAINED TECHNICIANS

Accredited staff with a wealth

of knowledge and expertise.

![](https://www-asia.nissan-cdn.net/content/dam/Nissan/global/sandbox/nissan-services/ic-parts.png.ximg.l_3_m.smart.png)

## HIGH QUALITY GENUINE PARTS

Peace of mind comes as a standard when you bring your vehicle to a Nissan Dealership.

![](https://www-asia.nissan-cdn.net/content/dam/Nissan/global/sandbox/nissan-services/ic-diagnosis.png.ximg.l_3_m.smart.png)

## ADVANCED DIAGNOSIS

Our trained technicians use the latest technology to quickly and effectively identify any issues with your vehicles.

![](https://www-asia.nissan-cdn.net/content/dam/Nissan/global/sandbox/nissan-services/owners_hub/roadside%20assistance.png.ximg.l_3_m.smart.png)

## 24/7 EMERGENCY ASSISTANCE

Trust that we are always at your side with 24-hour roadside assistance and call center.

* * *

## OTHER SERVICES WE OFFER

![NISSAN EXPRESS SERVICE](https://www-asia.nissan-cdn.net/content/dam/Nissan/global/sandbox/nissan-services/img-repairs.jpg.ximg.l_6_m.smart.jpg)

## NISSAN EXPRESS SERVICE

With Nissan Express Service, you'll always know exactly where you stand. There'll be no nasty surprises, as we've fixed the price on most of our common repairs.

[FIND OUT MORE](https://www.nissan.ph/service/aftersales-services/express-service.html "FIND OUT MORE")

![NISSAN EXPRESS SERVICE](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/servicehub/serviceonwheels/WARRANTY.jpg.ximg.l_6_m.smart.jpg)

## WARRANTY

At Nissan, we want you to enjoy your new car, van, or electric vehicle with complete peace of mind. As such, we supply a Nissan Warranty for each new vehicle sold, registered, and operated in each country where authorised Nissan dealers are located.

[FIND OUT MORE](https://www.nissan.ph/service/customer-support/warranty-campaign.html "FIND OUT MORE")

![NISSAN EXPRESS SERVICE](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/servicehub/serviceonwheels/SOW_1.jpg.ximg.l_6_m.smart.jpg)

## SERVICE ON WHEELS

Get fast and reliable on-site aftersales services without leaving your home. Just contact us and our Nissan-certified techinicians will deliver light periodic maintenance services, basic repairs, emergency roadside assistance, and replacement of wearable car parts at your convenience.

[FIND OUT MORE](https://www.nissan.ph/service/aftersales-services/service-wheels.html "FIND OUT MORE")

![NISSAN EXPRESS SERVICE](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/servicehub/serviceonwheels/PICK-UP-AND-DRIVE.jpg.ximg.l_6_m.smart.jpg)

## PICK-UP AND DROP-OFF

Save time with our Nissan Pick-up and Drop-off service–we’ll pick up your car, service it, and return it back to you good as new.

[FIND OUT MORE](https://www.nissan.ph/service/aftersales-services/pudo.html "FIND OUT MORE")

## NEXT STEPS

- [Contact Us](https://www.nissan.ph/service/customer-support/contact-us.html)
- [Locate a dealer](https://www.nissan.ph/dealer-finder.html)
- [Schedule Service Now](https://npi-olsb-customer.otoleap.com/#/home)

- [Contact Us](https://nissanph-dialer.telavi.com.ph/ "Contact Us")
- [Find a Dealer](https://www.nissan.ph/dealer-finder.html "Find a Dealer")
- [Book a Test Drive](https://www.nissan.ph/test-drive.html "Book a Test Drive")