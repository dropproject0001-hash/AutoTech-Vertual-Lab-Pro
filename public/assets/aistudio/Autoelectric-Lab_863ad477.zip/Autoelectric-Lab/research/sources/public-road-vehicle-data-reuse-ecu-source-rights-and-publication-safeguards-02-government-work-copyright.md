Source: https://elibrary.judiciary.gov.ph/thebookshelf/showdocs/26/25662
Title: PRESIDENTIAL DECREE NO. 49 - DECREE ON THE PROTECTION OF INTELLECTUAL PROPERTY - Supreme Court E-Library
Fetched: 2026-11-11T12:54:26.539Z

# [Supreme Court E-Library](https://elibrary.judiciary.gov.ph/)   Information At Your Fingertips

[Toggle posts](https://elibrary.judiciary.gov.ph/thebookshelf/showdocs/26/25662#)

[A](https://elibrary.judiciary.gov.ph/thebookshelf/showdocs/26/25662#) [A+](https://elibrary.judiciary.gov.ph/thebookshelf/showdocs/26/25662#) [A++](https://elibrary.judiciary.gov.ph/thebookshelf/showdocs/26/25662#)

|     |
| --- |
| CONTACT: |
| Supreme Court of the Philippines <br> Library Services,<br> <br> Padre Faura, Ermita, Manila, Philippines 1000 |
| (632) 8524-2706 |
| libraryservices.sc@judiciary.gov.ph |

[![](https://elibrary.judiciary.gov.ph/assets/images/memorabilia/CORSeal.jpg)](https://npcregistration.privacy.gov.ph/certificate/organizationRegistration/64a7c5e47c2074390ec3ccb5)

![](https://elibrary.judiciary.gov.ph/assets/images/memorabilia/quick_links/header.png)[![Supreme Court of the Philippines](https://elibrary.judiciary.gov.ph/assets/images/memorabilia/quick_links/sc.png)](http://sc.judiciary.gov.ph/ "Supreme Court of the Philippines")[![Cour of Appeals](https://elibrary.judiciary.gov.ph/assets/images/memorabilia/quick_links/ca.png)](http://ca.judiciary.gov.ph/ "Cour of Appeals")[![Sandiganbayan](https://elibrary.judiciary.gov.ph/assets/images/memorabilia/quick_links/sb.png)](http://sb.judiciary.gov.ph/ "Sandiganbayan")[![Court of Tax Appeals](https://elibrary.judiciary.gov.ph/assets/images/memorabilia/quick_links/cta.png)](http://cta.judiciary.gov.ph/ "Court of Tax Appeals")[![Judicial and Bar Council](https://elibrary.judiciary.gov.ph/assets/images/memorabilia/quick_links/jbc.png)](http://jbc.judiciary.gov.ph/ "Judicial and Bar Council")[![Office of the Court Administrator](https://elibrary.judiciary.gov.ph/assets/images/memorabilia/quick_links/oca.png)](http://oca.judiciary.gov.ph/ "Office of the Court Administrator")[![Philippine Judicial Academy](https://elibrary.judiciary.gov.ph/assets/images/memorabilia/quick_links/philja.png)](http://philja.judiciary.gov.ph/ "Philippine Judicial Academy")

![](https://elibrary.judiciary.gov.ph/assets/images/printer.png)[View printer friendly version](https://elibrary.judiciary.gov.ph/thebookshelf/showdocsfriendly/26/25662)

## \[ PRESIDENTIAL DECREE NO. 49, November 14, 1972 \]

### DECREE ON THE PROTECTION OF INTELLECTUAL PROPERTY

WHEREAS, tremendous strides in science and technology have
made necessary the updating of the Copyright Law to give fuller
protection to intellectual property and to encourage arts and letters,
as well as stimulate scientific research and invention, at the same time
safeguard the public's right to cultural information;

**NOW, THEREFORE, I, FERDINAND E. MARCOS,** President of
the Philippines, by virtue of the powers vested in me by the
Constitution as Commander-in-Chief of all the Armed Forces of the
Philippines, and pursuant to Proclamation No. 1081, dated September 21,
1972, and General Order No. 1, dated September 22, 1972, as amended, do
hereby decree, order and make as part of the law of the land the
following measure:

CHAPTER I. — Preliminary Provisions

**SECTION 1.** This Decree shall be known as the "Decree
on Intellectual Property."

**SEC. 2.** The rights granted by This Decree shall,
from the moment of creation, subsist with respect to any of the
following classes of works:

01. Books, including composite and cyclopedic
    works, manuscripts, directories, and gazetteers;

02. Periodicals, including pamphlets and newspapers;

03. Lectures, sermons, addresses, dissertations prepared for oral
     delivery;

04. Letters;

05. Dramatic or dramatico-musical compositions; choreographic
    works and entertainments in dumb shows, the acting form of which is
    fixed in writing or otherwise;

06. Musical compositions, with or without words;

07. Works of drawing, painting, architecture, sculpture,
    engraving, lithography, and other works of art; models or designs for
    works of art;

08. Reproductions of a work of art;

09. Original ornamental designs or models for articles of
    manufacture, whether or not patentable, and other works of applied art;

10. Maps, plans, sketches, and charts;

11. Drawings or plastic works of a scientific or technical
    character;

12. Photographic works and works produced by a process analogous
    to photography; lantern slides;

13. Cinematographic works and works produced by a process
    analogous to cinematography or any process for making audio-visual
    recordings;

14. Computer programs;

15. Prints, pictorial illustrations, advertising copies, labels,
    tags, and box wraps;

16. Dramatizations, translations, adaptations, abridgements,
    arrangements and other alterations of literary, musical or artistic
    works or of works of the Philippine Government as herein defined, which
    shall be protected as _provided_ in Section 8 of this Decree;

17. Collections of literary, scholarly, or artistic works or of
    works referred to in Section 9 of this Decree which by reason of the
    selection and arrangement of their contents constitute intellectual
    creations, the same to be protected as such in accordance with Section 8
     of this Decree;

18. Other literary, scholarly, scientific and artistic works.

**SEC. 3.** The rights granted by this Decree shall not
be lost except in the manner specifically _provided_ herein.
Neither shall they be subject to levy and attachment while in the
possession of the creator or his heirs.

**SEC. 4.** Nothing in this Decree shall be deemed to
alter or in any manner impair any other right or remedy of the persons
protected by its provisions.

CHAPTER II — Copyright

ARTICLE I. — _Scope and beneficiaries of copyright_

**SEC. 5.** Copyright shall consist in the exclusive
right;

1. To print, reprint, publish, copy, distribute,
multiply, sell, and make photographs, photo-engravings, and pictorial
illustrations of the works;

2. To make any translation or other version or extracts or
arrangements or adaptations thereof; to dramatize it if it be a
non-dramatic work; to convert it into a non-dramatic work if it be a
drama; to complete or execute it if it be a model or design;

3. To exhibit, perform, represent, produce, or reproduce the
work in any manner or by any method whatever for profit or otherwise; if
    not reproduced in copies for sale, to sell any manuscripts or any
records whatsoever thereof;

4. To make any other use or disposition of the work consistent
with the laws of the land.

**SEC. 6.** The creator or his heirs or assigns shall
own the copyright in any of the works mentioned in Section 2 of this
Decree. If the works is produced by two or more persons, the copyright
shall belong to them jointly and their respective rights thereto shall
be governed by the Rules of the Civil Code on co-ownership.

If the work in which copyright subsists was made during and in the
course of the employment of the creator, the copyright shall belong to:

1. The employee, if the creation of the object of copyright is not a
part of his regular duties even if the employee uses the time,
facilities and materials of the employer.

2. The employer, if the work is the result of the performance
of his regularly assigned duties, unless there is an agreement, express
or implied to the contrary.

Where the work is commissioned by a person who is not the employer of
the creator and who pays or agrees to pay for it and the work is made
in pursuance of the commission, the person who so commissioned the work
shall have ownership of it but the copyright thereto shall belong in
joint ownership to him and the creator, unless there is a stipulation to
the contrary.

The creators of a cinematographic or analogous work are the producer,
the author of the scenario, the composer of the music, the film
director, the photographic director, and the author, of the work
adapted. However subject to contrary or other stipulation among the
creators, the producer shall exercise the copyright to an extent
required for the exhibition of the work in any manner, except for the
right to collect performing fees for the musical compositions, with or
without words, which may be incorporated into the work.

The copyright in letters shall belong to the writer, subject to the
provisions of Article 723 of the Civil Code.

**SEC. 7.** For purposes of this Decree, articles and
other writings published without the names of the authors or under
pseudonyms are considered as the property of the publishers, unless the
contrary appears.

**SEC. 8.** The works referred to in subsections (P) and
(O) of Section 2 of this Decree shall, when produced with the consent
of the creator or proprietor of the original works on which they are
based, be protected as new works; however, such new works shall not
affect the force of any subsisting copyright upon the original works
employed or any part thereof, or be construed to imply an exclusive
right to such use of the original works, or to secure or extend
copyright in such original works.

**SEC. 9.** No copy shall subsist in any work of the
Government of the Philippines. However, prior approval of the government
agency or office wherein the work is created shall be necessary for
exploitation of such work for profit. Such agency or office may, among
other things, impose as a condition the payment of royalties. No prior
approval or condition shall be required for the use for any purpose of
statutes, rules and regulations, and speeches, lectures, sermons,
addresses, and dissertations pronounced, read or rendered in courts of
justice before administrative agencies, in deliberative assemblies, and
in meetings of character.

A "Work of the Government of the Philippines" is a work created by an
officer or employee of the Philippine Government or any of its
subdivisions and instrumentalities, including government-owned or
controlled corporations as a part of his regularly prescribed official
duties.

Notwithstanding the foregoing provisions, the Government is not
precluded from receiving and holding copyrights transferred to it by
assignment, bequest or otherwise; nor shall publication or republication
by the Government in a public document of any work in which copyright
is subsisting be taken to cause any abridgement or annulment of the
copyright or to authorize any use or appropriation of such work without
the consent of the copyright proprietor.

ARTICLE II. — _Limitations on copyright_

**SEC. 10.** When a work has been lawfully made
accessible to the public, the author shall not be entitled to prohibit:

1. Its recitation or performance (A) if done privately and free of
charge; or (B) if made for strictly charitable or religious institution
or society;

2. Reproductions, translations and adaptations thereof destined
exclusively for personal and private use;

**SEC. 11.** To an extend compatible with fair practice
and justified by the scientific, critical, informatory or educational
purpose, it shall be permissible to make quotations or excerpts from a
work already lawfully made accessible to the public. Such quotations may
be utilized in their original form or translation.

News items, editorials, and articles on current political, social,
economic, scientific or religious topic may be reproduced by the press
or broadcast, unless they contain or are accompanied by a notice that
their reproduction or publication is reserved. In case of musical works,
parts of little extent may also be reproduced.

Quotations and excerpts as well as reproductions shall always be
accompanied by an acknowledgment of the source and name of the author,
if his name appears thereon.

**SEC. 12.** In reports of a current event by means of
photography, cinematography or broadcasting, literary, scientific or
artistic works which can be seen or heard in the course of said event
may be reproduced and communicated to the public to the extent necessary
for the purpose.

**SEC. 13.** Libraries, public archives and museums have
the right, subject to the conditions specified in the succeeding
paragraphs, to produce for purposes of their activities, by photographic
means, and without the consent of the creator or proprietor, copies of a
literary or artistic work.

Material forming part of the collections mentioned in the preceding
paragraph which, by reason of their fragile character or rarity, cannot
be lent to users in its original form, may be reproduced by photography
for the purpose of loans. Nevertheless, except in cases where special
reasons justify it, not more than two copies may be made.

It is equally permissible to make, by means of photography,
reproductions of isolated articles contained in composite works, as well
as brief portions of other published works, in order to supply them,
when this is considered expedient, to persons requesting their loan for
purposes of research or study, instead of lending the volumes or
booklets which contain them. Each person seeking loan may only receive
one copy of each article or each portion of a work.

When a copy of a work is found to be incomplete) the missing portions
may be reproduced by means of photography, _provided_ they only
constitute a minor portion of the total work. Nevertheless, it shall not
be permitted to produce a volume of a work published in several volumes
or to produce missing tomes or parts of magazines or similar works,
unless the volume, tome or part is out of stock with booksellers, the
printing house and the publisher.

Every library which, by law, is entitled to receive one or two copies
of a printed work shall be entitled, when special reasons so require,
to reproduce, by means of photography or process analogous to
photography, a copy of a published work, the acquisition of which is
considered necessary for the collections of the library, but which is
out of stock with booksellers, the printing house and the publisher.

A work belonging to the collections mentioned in the first paragraph
of this section which has not been disseminated may not be reproduced or
published without the consent of the creator or proprietor. However,
such work may be reproduced for purposes of preservation.

**SEC. 14.** If, after the expiration of five years from
the date of the first publication of a writing, a translation of such
writing has not been published in the national or other local language,
as the case may be, by the owner of the right of translation or with his
authorization, any citizen may obtain a non-exclusive license from the
Director of the National Library, to translate the work and publish the
work so translated in the national or other local language in which it
has not been published: _Provided_, That such citizen establishes
either that he has requested, and been denied, authorization by the
proprietor of the right to make and publish the translation, or that,
after due diligence on his part, he was unable to find the owner of the
right. A license may also be granted on the same conditions if all
previous editions of a translation in such language are out of print. In
both cases the terms and conditions of the license, including the
royalties of the author or proprietor of the original work, shall be
stated therein.

If the owner of the right of translation cannot be found, then the
applicant for a license shall send copies of his application to the
publisher whose name appears on the work and, if the nationality of the
owner of the right of translation is known, to the diplomatic or
consular representative of the state of which such owner is a national,
or to the organization which may have been designated by the government
of that state. The license shall not be granted before the expiration of
two months from the date of the dispatch of the copies of the
application. Neither shall it be granted when the author has withdrawn
from circulation all copies of the work.

The original title and the name of the author of the work shall be
printed on all copies of the published translation.

ARTICLE III. — _Transfer of work and copyright_

**SEC. 15.** The copyright may, by gift, inheritance or
otherwise, be transferred or assigned in whole or in part. Such transfer
or assignment shall entitle the transferee or assignee to all the
rights and remedies which the transferer or assignor had with respect to
the copyright.

The copyright is not deemed transferred or assigned _inter vivos_
in whole or in part, unless there is a written indication that such is
the intention.

The submission of a literary, photographic or artistic work to a
newspaper, magazine or periodical for publication shall constitute only a
license to make a single publication unless a greater right is
expressly granted.

**SEC. 16.** The copyright is distinct from the property
in the material object subject to it. Consequently, the transfer or
assignment of the copyright shall not itself constitute a transfer of
the material object. Nor shall a transfer or assignment of the sole copy
or of one or several copies of the work imply transfer or assignment of
the copyright.

**SEC. 17.** An assignment or transfer inter vivos, or a
license, must be in writing, acknowledged before a notary public or
other officer authorized to administer oaths or perform notarial acts
and certified under the hand and seal of the notary or other officer.

This section and Section 19 shall not apply to cases covered by the
last paragraph of Section 15 of this Decree.

**SEC. 18.** If two or more persons jointly own a
copyright or any part thereof, neither of the owners shall be entitled
to grant licenses without the consent of the other owner or owners.

**SEC. 19.** Every assignment, license or other
instrument relating to any right, title or interest in a copyright and
to the work subject to it shall be filed in duplicate with the National
Library upon payment of the prescribed fee for registration in books and
records kept for the purpose. Upon recording a copy of the instrument
shall be returned to the sender with a notation of the fact of record.
Notice of the record shall be published in the Official Gazette.

Such instruments shall be void as against any subsequent purchaser or
mortgagee for a valuable consideration and without notice unless it is
recorded in the library prior to the subsequent purchase or mortgage.

**SEC. 20.** When the creator of a work in which
copyright is subsisting dies, it shall be the duty of his heirs or
assigns to file with the National Library for registration a written
notice under oath of the date of the creator's death. Until this is
complied with, the limitation of remedies established in Section 26 of
this Decree shall be enforced.

ARTICLE IV. — _Duration of copyright_

**SEC. 21.** The copyright conferred by this Decree
shall endure the lifetime of the creator and for fifty years after his
death. In case of works of joint creation, the period of fifty years
shall be counted from the death of the last surviving co-creator.

**SEC. 22.** In case of anonymous and pseudonymous
works, the copyright shall last until the end of fifty years following
the date of their first publication. However, when the pseudonym adopted
by the author leaves no doubt as to his identity, or if the author of
an anonymous or pseudonymous work discloses his identity during the
period mentioned in this section, the term of the protection shall be
that fixed in the next preceding section.

**SEC. 23.** In the case of posthumous works which do
not fall within the categories of the works referred to in the next two
preceding sections, the term of protection afforded to the heirs or
assignees of the creator shall end at the expiration of fifty years
after his death.

**SEC. 24.** Irrespective of the provisions of the
foregoing sections of this article, the term shall be thirty years in
the case of: (A) periodicals and newspapers, _provided_ that
material contained therein in which an independent copyright may be
deemed to subsist shall be accorded the length of protection appropriate
to it; (B) works of applied art; (C) cinematographic or photographic
works as well as those produced by a process analogous to cinematography
or photography or any process for making audio-visual recordings.

**SEC. 25.** The term of protection subsequent to the
death of the creator _provided_ in Sections 21 and 23 and the
terms _provided_ in Sections 22 and 24 shall run from the date of
his death or of publication, but such terms shall always be deemed to
begin on the first day of January of the year following the event which
gives rise to them.

ARTICLE V. — _Deposit and notice_

**SEC. 26.** After the first public dissemination or
performance by authority of the copyright owner of a work falling under
subsections (A), (B), (C) and (D) of Section 2 of this Decree, there
shall, within three weeks, be registered and deposited with the National
Library, by personal delivery or by registered mail, two complete
copies or reproductions of the work in such form as the Director of said
library may prescribe. A certificate of registration and deposit for
which the prescribed fee shall be collected. If, within three weeks
after receipt by the copyright owner of a written demand from the
Director for such deposit, the required copies or reproductions are not
delivered and the fee is not paid, the copyright owner shall be liable
to pay a fine equivalent to the required fee per month of delay and to
pay to the National Library the amount of the retail price of the best
edition of the work.

With or without a demand from the Director, a copyright owner who has
not made such deposit shall not be entitled to recover damages in an
infringement suit and shall be limited to the other remedies specified
in Section 23 of this Decree.

**SEC. 27.** Each copy of a work published or offered
for sale shall contain a notice bearing the name of the copyright owner,
the year of its first publication, and in copies produced after the
creator's death, the year of such death.

Failure to comply with the requirements of this section shall result
in the limitation of remedies established in the next preceding section.

ARTICLE VI. — _Infringement_

**SEC. 28.** Any person infringing a copyright shall be
liable:

1. To an injunction restraining such
infringement;

2. To pay to the copyright proprietor or his assigns or heirs
such actual damages as he may have due to the infringement as well as
the profits the infringor may have made due to such infringement, and in
    proving profits the plaintiff shall be required to prove sales only and
    the defendant shall be required to prove every element of cost which he
    claims, or, in lieu of actual damages and profits, such damage which to
    the court shall appear to be just and which shall not be less than the
sum of One Thousand Pesos, and shall not be regarded as penalty;

3. To deliver under oath, for impounding during the pendency of
the action, upon such terms and conditions as the court may prescribe,
all articles alleged to infringe a copyright;

4. To deliver under oath for destruction all infringing copies or
    devices, as well as all plates, molds, or other means for making such
infringing copies as the court may order;

5. To such other terms and conditions, including the payment of
moral and exemplary damages, which the court may deem proper, wise and
equitable.

**SEC. 29.** Any person infringing any copyright secured
by this Decree or aiding or abetting such infringement shall be deemed
guilty of a crime punishable by imprisonment not exceeding one year or
by fine not less than Two Hundred Pesos nor more than Two Thousand Pesos
or both, in the discretion of the court.

**SEC. 30.** Unless authorized by the copyright
proprietor concerned, importation into the Philippines of any piratical
copies or likeness of any work in which Philippine copyright subsists is
prohibited, except when imported under the following circumstances:

> _First._ When copies of the work are not available in the
> Philippines and —

1. Not more than one copy at one time is imported
    for strictly individual use only, or

2. The importation is by authority of and for the use of the
Philippine Government; or

3. The importation, consisting of not more than three such copies
or likenesses in any one invoice, is not for sale but for the use only
of any religious, charitable, or educational society or institution duly
    incorporated or registered, or is for the encouragement of the fine
arts, or for any state school, college, university, or free public
library in the Philippines.

> _Second._ When such copies form parts of libraries and
> personal baggage belonging to persons or families arriving from foreign
> countries and arc not intended for sale _provided_ such copies do
> not exceed three.

Copies imported as allowed by this section may not lawfully be used
in any way to violate the rights of the proprietor of Philippine
copyright or annul or limit the protection secured by this Decree, and
such unlawful use shall be deemed an infringement and shall be
punishable as such without prejudice to the proprietor's right of
action.

The Commissioner of Customs, subject to the approval of the Secretary
of Finance, is hereby empowered to make rules and regulations for
preventing the importation of articles the importation of which is
prohibited under this section and for seizing and condemning and
disposing of the same in case they are discovered after they have been
imported.

CHAPTER III. — Right to Proceeds in subsequent
Transfers

**SEC. 31.** In every sale or lease of an original work
of painting or sculpture or of the original manuscript of a writer or
composer, subsequent to the first disposal thereof by the creator, the
creator or his heirs shall have an inalienable right to participate in.
the gross proceeds of the sale or lease to the extent of five per centum
(5%).

This right shall exist during the lifetime of the creator and for
fifty years after his death.

**SEC. 32.** As a condition precedent to making a claim
to the right established in the preceding section for any work mentioned
therein, the work must be registered in the National Library where a
separate register shall be kept for this purpose.

The creator or his heirs may designate a society of artists, writers
or composers as agent to claim the right in his or their behalf. In such
case, the society shall forward the proceeds to the creator or his
heirs upon their demand or at the end of every quarter of each calendar
year.

**SEC. 33.** The provisions of this Chapter shall not
apply to prints, etchings, engravings, works of applied art, or works of
similar kind wherein the creator primarily derives gain from the
proceeds of reproductions.

CHAPTER IV. Moral Rights

**SEC. 34.** Independently of the rights conferred by
Chapters II and III of this Decree or the grant of an assignment or
license with respect to any of such rights, a creator shall have the
right:

1. To make alterations of his work prior to, or
to withhold it from, publication;

2. To require that the authorship of the works be attributed to
him;

3. To object to any alteration of his work which is prejudicial to
    his reputation;

4. To restrain the use of his name with respect to any work not of
    his own creation or in a distorted version of his work.

**SEC. 35.** A creator cannot be compelled to perform
his contract to create a work or for the publication of his work already
in existence. However, he may be held liable for damages for breach of
such contract.

**SEC. 36.** A creator may assign or waive his rights
mentioned in Section 34 of this Decree by a written instrument expressly
so stating, but no such assignment shall be valid where its effect is
to permit another:

1. To use the name of the creator, or the title
of his work, or otherwise to make use of his reputation with respect to
any version or adaptation of his work which, because of alterations
therein, would substantially tend to injure the literary or artistic
reputation of the author; or

2. To use the name of the creator with respect to a work he did
not create.

**SEC. 37.** When a creator contributes to a collective
work, like a newspaper or an encyclopedia, his right to have his
contribution attributed to him is deemed waived unless he expressly
reserves it.

**SEC. 38.** In the absence of a special contract at the
time a creator licenses or permits another to use his work, the
necessary editing, arranging or adaptation of such work, for
publication, broadcast, use in a motion picture, dramatization, or
mechanical or electrical reproduction in accordance with the reasonable
and customary standards or requirements of the medium in which the work
is to be used, shall not be deemed to contravene the creator's rights
secured by this chapter. Nor shall complete destruction of a work
unconditionally transferred by the creator be deemed to violate such
rights.

**SEC. 39.** The rights of a creator under this chapter
shall be perpetual and imprescriptible. The person or persons to be
charged with the posthumous enforcement of these rights shall be named
in a writing to be filed with the National Library. In default of such
person or persons, such enforcement shall devolve upon either the
creator's heirs or the Director of the National Library acting in behalf
of the heirs.

The persons named by the creator in accordance with the foregoing
paragraph or, in their absence, the creator's heirs shall have the power
to make any assignment or license of the rights _provided_ in
this chapter which would be within the power of the creator had he
lived. If there are no heirs, the Director of the National Library shall
exercise this power.

For purposes of this section, "Person" shall mean any individual,
partnership, corporation, association, or society. The Director of the
National Library may prescribe reasonable fees to be charged for his
services in the application of provisions of this section.

**SEC. 40.** Violation of any of the rights conferred by
this chapter shall entitle those charged with their enforcement to the
same rights and remedies available to a copyright owner. In addition,
damages which may be availed of under the Civil Code may also be
recovered. Any damage recovered after the creator's death shall be held
in trust for and remitted to the heirs.

CHAPTER V. Rights of Performers, Producers of Sounds,
Recordings, and Broadcasting Organizations

ARTICLE 1.— _Definition of terms_

SEC. 41. As used in this chapter:

1. "Performers" mean actors, singers, musicians,
dancers, and other persons who act, sing, deliver, declaim, play in, or
otherwise perform literary or artistic work.

2. "Sound Recording" means any exclusively aural fixation of
sounds of a performance or of other sound,

3. "Producer of sound records" means the person who, or the legal
entity which, first fixes a performance or other sounds.

4. "Publication" means the issue or offering to the public of
copies of a sound recording in reasonable quantity.

5. "Reproduction" means the making of a copy or copies of a
recording.

6. "Broadcasting" means the transmission by wireless means for
public reception of sounds or of images and sound.

7. "Broadcasting organization" shall include a sole proprietorship
    duly authorized to engage in broadcasting.

ARTICLE II. — _Performers_

**SEC. 42.** Performers shall have the exclusive right:

1. To record or authorize the recording of their
performance on any recording-apparatus for image and/or sound.

2. To authorize the broadcasting and the communication to the
public of their performance.

3. To prohibit the reproduction of a recording of their
performance: (i) If the original recording itself was made without their
    consent; (ii) If the reproduction is made for purposes different from
those for which the performers gave their consent; or (iii) If the
original recording was made for any of the purposes mentioned in Section
    44 and the reproduction is made for a different purpose.

**SEC. 43.** Performers shall have the right to decide
whether their names will be mentioned when their performance is recorded
or broadcast. The provisions of Chapter IV shall apply to them.

**SEC. 44.** Notwithstanding the provisions of Section
43 of his Decree, performers may not object to the recording: (A) of
parts of their performance to be used in connection with the reporting
of current events, or (B) of the entirely thereof which shall be used
solely for the purpose of teaching or scientific research. The
provisions of Section 12 of this Decree shall also apply to
performances. However, the provisions of this section shall be without
prejudice to those of the next preceding section.

**SEC. 45.** For infringement of any of their rights,
performers shall be entitled to;

1. An injunction restraining such infringement;

2. To recover such damages as may be recoverable under the
Civil Code or, in lieu thereof, such damages which to the court shall
appear just and which shall riot be less than Three Hundred Pesos.

3. To the remedies _provided_ in subsections (C) and (D)
of Section 28 of this Decree but with respect only to recordings of
their performances and devices for making such recordings.

ARTICLE 111. — _Producers of Sound Recordings_

**SEC. 46.** Producers of sound recordings shall have
the exclusive right to authorize or prohibit the direct or indirect
reproduction of their recordings and the placing of these reproductions
in the market.

**SEC. 47.** When a sound recording is used with the
intention of making or enhancing profit, the producer of the recording
has the right to a fair remuneration from the user.

**SEC. 48.** The producer of a sound recording may also
forbid any use of this recording which would cause serious and
unwarranted damage to his industrial interests.

**SEC. 49.** There shall be indicated in each copy of a
sound recording the title of the work recorded, the name of the author
and, subject to Section 43 of this Decree of the principal performers
and the date of manufacture.

**SEC. 50.** Within one month after its manufacture, two
copies of a sound recording shall be deposited, by personal delivery or
by mail, with the National Library. Upon such deposit, the Director
shall issue to the producer a certificate under the seal of the library
indicating the fact and date of such deposit. This certificate shall
constitute a _prima facie_ evidence of the facts stated therein.

**SEC. 51.** No suit for violation of the rights of the
producer of a sound recording may be instituted until he has complied
with the requirements of the next two preceding sections.

ARTICLE IV. — _Broadcasting Organizations._

**SEC. 52.** Broadcasting organizations shall enjoy the
exclusive right:

1. To relay by wire or rebroadcast their
broadcasts;

2. To record in any manner, including the making of
cinematographic films or the use of video tape, their broadcasts for the
    purpose of making profit;

3. To use such records for fresh transmissions or for fresh
recording.

**SEC. 53.** The provisions of immediately preceding
section shall not include the right to prohibit recording of broadcasts
for strictly private use or solely for the purpose of teaching or
scientific research.

**SEC. 54.** A broadcasting organization, when any of
its rights secure herein is infringed, shall be entitled:

1. To have such infringement enjoined;

2. To recover such damages as may be awarded under the Civil Code;

3. The remedies _provided_ in subsections (C) and (D) of
Section 28 of this Decree but with respect only to unauthorized
recordings of its broadcasts and devices for making such recordings.

ARTICLE V.— _Term of Protection_

**SEC. 55.** The rights granted under this Chapter shall
expire after twenty years from the end of the year in which:

1. The performance took place — for performances
not incorporated in recordings;

2. The recording was made — for sound or image and sound
recordings and for performances incorporated therein;
3. The
broadcast took place — in the case of broadcasts.

**SEC. 56.** The prohibitions and penalties _provided_
in Section 29 shall apply to infringement of any of the rights granted
in this chapter.

ARTICLE VI. — _Penalty_

CHAPTER VII. Institution of Actions and Proceeding

**SEC. 57**. All actions, suits and proceedings shall,
regardless of the amount involved, be originally cognizable by Courts of
First Instance,

**SEC. 58.** No damages may be recovered under this
Decree after four years from the time the cause of action arose.

**SEC. 59**. Appeals shall be governed by the Rules of
Court.

CHAPTER VIII. Miscellaneous Provisions

**SEC. 60.** All copies deposited and instruments in
writing filed with the National Library in accordance with the
provisions of this Decree shall become the property of the Government.

**SEC. 61.** The section or division of the National
Library charged with receiving copies and instruments deposited and with
keeping records required under this Decree and everything in it shall
be opened, to public inspection subject to such safeguards and
regulations as may be prescribed by Director of the Library.

**SEC. 62.** The National Library shall collect the
following fees:

1. For the issuance of a certificate of deposit
of copies of a work, five pesos;

2. For each assignment, license, notice or other written
instrument filed, ten pesos;

3. For other services, in such amount as he may fix by regulation:
    _Provided_, That single fee shall exceed ten pesos.

CHAPTER IX. Final Provisions

**SEC. 63.** The provisions of this Decree shall apply
to works in which copyright protection obtained prior to the effectivity
of this Decree is subsisting: _Provided_, That the application
of this Decree shall not result in the diminution of such protection.

**SEC. 64.** Act No. 3134, otherwise known as the
"Copyright Law of the Philippine Islands," and all laws or provisions of
law, orders or regulations inconsistent herewith are hereby repealed.

This Decree shall take effect 15 days after publication in the
Official Gazette.

Done in the City of Manila, this 14th day of November, in the year of
Our Lord, nineteen hundred and seventy-two.

> |     |     |     |
> | --- | --- | --- |
> |  | **(Sgd.) FERDINAND E. MARCOS**<br>President <br>Republic of the Philippines |
> |  |  |
> |  | By the President: |  |
> |  |
> |  | **(Sgd.) ALEJANDRO MELCHOR** |  |
> |  |  | Executive Secretary |

© Supreme Court E-Library 2019

This website was designed and developed, and is maintained, by the E-Library Technical Staff in collaboration with the Management Information Systems Office.