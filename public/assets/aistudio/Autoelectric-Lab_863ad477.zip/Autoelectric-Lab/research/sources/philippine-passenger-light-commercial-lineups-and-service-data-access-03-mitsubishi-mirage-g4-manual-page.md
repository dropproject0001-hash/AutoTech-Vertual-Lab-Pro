Source: https://www.mitsubishi-motors.com.ph/service/owners-manual/mirage-G4-manual
Title: Owners Manual | Mitsubishi Motors Philippines
Fetched: 2026-11-11T12:54:56.859Z

# Mirage G4 Owners Manual

![Mirage G4 red](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/cars/mirage-g4/2022/exterior/New-Mirage-G4-Side.jpg?width=480&auto=webp)

## Mirage G4

2022 – 2024 Model Year

[Download PDF (44.2 MB)](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/owners-manual/22MY%20Mirage%20G4%20Owner's%20Manual.pdf)

![Mirage G4 ](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/cars/mirage-g4/2022/exterior/New-Mirage-G4-Side-white.jpg?width=480&auto=webp)

## Mirage G4

2025 Model Year

[Download PDF (17.9 MB)](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/owners-manual/25MY%20Mirage%20G4%20Owner's%20Manual.pdf)

![Mirage G4](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/cars/mirage-g4/2022/exterior/26MY%20Mirage%20G4.jpg?width=480&auto=webp)

## Mirage G4

2026 Model Year - Onwards

[Download PDF (12.7 MB)](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/owners-manual/26MY%20Mirage%20G4%20Owner's%20Manual.pdf)

![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/owners-manual/EL-L%20Radio.png?width=480&quality=70)

## Audio Manual

2022 Model Year - Onwards

[Download PDF (12.8 MB)](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/owners-manual/SDA3%20Manual%20(PHILIPPINES%E3%80%81BOTSWANA).pdf)

## Genuine Accessories

### Contact a dealership using our Dealer Locator

[Find a Dealer](https://www.mitsubishi-motors.com.ph/dealer-locator)[Download Brochure](https://www.mitsubishi-motors.com.ph/customer-tools/download-a-brochure)[Price List](https://www.mitsubishi-motors.com.ph/price-list)

- [Price List](https://www.mitsubishi-motors.com.ph/price-list)
- [Car Configurator](https://www.mitsubishi-motors.com.ph/customer-tools/configure)
- [Dealer Locator](https://www.mitsubishi-motors.com.ph/dealer-locator)
- [Test Drive](https://www.mitsubishi-motors.com.ph/sales/test-drive)
- [Get a Quote](https://www.mitsubishi-motors.com.ph/sales/quotation)
- [Brochures](https://www.mitsubishi-motors.com.ph/customer-tools/download-a-brochure)

Mitsubishi Motors Philippines Corporation (MMPC) places utmost importance and respects your right to privacy. MMPC shall handle with utmost care all personal and sensitive information that you may provide or those that we may collect from you upon your use of the website in accordance with our [Privacy Policy](https://www.mitsubishi-motors.com.ph/privacy-policy). By closing this banner, scrolling this page or clicking any part of it, you hereby acknowledge that you have read and understood our Privacy Policy and expressly consent to it.

I agree