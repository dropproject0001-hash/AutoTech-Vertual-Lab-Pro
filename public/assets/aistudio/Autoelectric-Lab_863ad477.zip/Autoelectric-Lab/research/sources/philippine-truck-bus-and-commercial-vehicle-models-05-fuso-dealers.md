Source: https://fuso.com.ph/dealers
Title: Find a FUSO Dealer - FUSO Philippines
Fetched: 2026-11-11T12:54:49.031Z

- [New F-Wing](https://fuso.com.ph/f-wing/)
- [Find A Dealer](https://fuso.com.ph/dealers/)
- [Trucks & Bus](https://fuso.com.ph/models/)  - [Electric Light Duty](https://fuso.com.ph/models/#ecanter)
  - [Light Duty](https://fuso.com.ph/models/#canter)
  - [Medium Duty](https://fuso.com.ph/models/#fi)
  - [Heavy Duty](https://fuso.com.ph/models/#fj)
  - [Modern PUV](https://fuso.com.ph/models/#modern-puv)
  - [Minibus](https://fuso.com.ph/models/#minibus)
- [Canter Built Ready](https://fuso.com.ph/built-ready/)
- [Latest Offers](https://fuso.com.ph/latest-offers/)
- [Parts & Services](https://fuso.com.ph/dealers/#)  - [Parts and Accessories](https://fuso.com.ph/parts-and-accessories/)
  - [Services](https://fuso.com.ph/services/)
- [About Us](https://fuso.com.ph/dealers/#)  - [FUSO Brand](https://fuso.com.ph/brands/)
  - [Company Profile](https://fuso.com.ph/company-profile/)
- [News](https://fuso.com.ph/news/)  - [Press Release](https://fuso.com.ph/category/press-release/)
  - [Related Links](https://fuso.com.ph/the-general-distributor-of-fuso-trucks-buses-and-modern-puvs-in-the-philippines)
  - [Canter AMT \| Duonic](https://fuso.com.ph/the-all-new-canter-amt)
  - [Global](https://www.mitsubishi-fuso.com/news)
- [Careers](https://fuso.com.ph/careers/)
- [Inquire Now](https://fuso.com.ph/contact-us/)

![](https://b.tile.openstreetmap.org/5/26/14.png)![](https://c.tile.openstreetmap.org/5/27/14.png)![](https://a.tile.openstreetmap.org/5/26/13.png)![](https://b.tile.openstreetmap.org/5/27/13.png)![](https://c.tile.openstreetmap.org/5/26/15.png)![](https://a.tile.openstreetmap.org/5/27/15.png)![](https://a.tile.openstreetmap.org/5/25/14.png)![](https://a.tile.openstreetmap.org/5/28/14.png)![](https://c.tile.openstreetmap.org/5/25/13.png)![](https://c.tile.openstreetmap.org/5/28/13.png)![](https://b.tile.openstreetmap.org/5/25/15.png)![](https://b.tile.openstreetmap.org/5/28/15.png)![](https://c.tile.openstreetmap.org/5/24/14.png)![](https://b.tile.openstreetmap.org/5/29/14.png)![](https://b.tile.openstreetmap.org/5/24/13.png)![](https://a.tile.openstreetmap.org/5/29/13.png)![](https://a.tile.openstreetmap.org/5/24/15.png)![](https://c.tile.openstreetmap.org/5/29/15.png)![](https://b.tile.openstreetmap.org/5/23/14.png)![](https://c.tile.openstreetmap.org/5/30/14.png)![](https://a.tile.openstreetmap.org/5/23/13.png)![](https://b.tile.openstreetmap.org/5/30/13.png)![](https://c.tile.openstreetmap.org/5/23/15.png)![](https://a.tile.openstreetmap.org/5/30/15.png)

![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-red-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)![Marker](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/square-map-black-fuso.png)

[+](https://fuso.com.ph/dealers/# "Zoom in") [−](https://fuso.com.ph/dealers/# "Zoom out")

[Leaflet](https://leafletjs.com/ "A JavaScript library for interactive maps") \| © [OpenStreetMap](https://www.openstreetmap.org/copyright) contributors

### All Dealers

- [Metro Manila](https://fuso.com.ph/dealers/#)
- [Luzon](https://fuso.com.ph/dealers/#)
- [Visayas](https://fuso.com.ph/dealers/#)
- [Mindanao](https://fuso.com.ph/dealers/#)

- [![CITIMOTORS, INC. – FUSO MAKATI facade](https://fuso.com.ph/wp-content/uploads/2023/07/CTM-1-scaled.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3861.890836100398!2d121.01293777985887!3d14.54823468570619!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397c91464a5bb05%3A0xdd5fa9239f021cbb!2sMitsubishi+CT+Citimotors+Inc.+Makati!5e0!3m2!1sen!2sph!4v1563862983454!5m2!1sen!2sph)





##### CITIMOTORS, INC. – FUSO MAKATI



Chino Roces Ave. corner Don Bosco St., Makati City



Sales: (02) 8892 0331 loc. 428 to 432

Service: (02) 8892 0331 loc. 455 or 456

Parts: (02) 8892 0331 loc. 444 or 445

- [![COLUMBIAN MOTOR SALES CORPORATION – FUSO PASAY facade](https://fuso.com.ph/wp-content/uploads/2024/04/CMC-1-scaled.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3862.2412578988938!2d121.0038628!3d14.528188!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397c94502eda71b%3A0x340ca05d64ac17c6!2sColumbian%20Motors%20Corporation!5e0!3m2!1sen!2sjp!4v1654673363342!5m2!1sen!2sjp)





##### COLUMBIAN MOTOR SALES CORPORATION – FUSO PASAY



CMC Bldg, Andrews Avenue, Brgy 190, Pasay City, Metro Manila, Philippines



Sales: (+63) 917 589 7852 / (+63) 998 597 8751 / (02) 8854 0843 / (02) 8552 2441

Service: (+63) 917 802 8941 / (02) 8854 3128 / (02) 8852 2448 - 49

Parts: (+63) 932 859 7839 / (+63) 917 621 5515 / (02) 8852 2440

- [![MEGAVIA MOTOR CO., INC. – FUSO OTIS facade](https://fuso.com.ph/wp-content/uploads/2022/06/MEGAVIA-3-scaled.jpg)](https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1930.561573203532!2d120.99880702683481!3d14.592057961213191!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x31c8cc18e1a52d04!2sFUSO%20Otis!5e0!3m2!1sen!2sjp!4v1657501811464!5m2!1sen!2sjp)





##### MEGAVIA MOTOR CO., INC. – FUSO OTIS



1900 Paz Mendoza Guazon St. Corner Mendiola Extension, Brgy. 832 Zone 6, Paco, Manila



(+63) 917 125 4546

- [![DIAMOND MOTOR CORPORATION – FUSO MARIKINA facade](https://fuso.com.ph/wp-content/uploads/2022/06/New-DMC.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3860.4521672421065!2d121.0995233751647!3d14.630255376349758!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b9d0a7f871d1%3A0x353e1f69af8fc453!2sFuso%20Trucks%20Diamond%20Motor!5e0!3m2!1sen!2sph!4v1758086858138!5m2!1sen!2sph)





##### DIAMOND MOTOR CORPORATION – FUSO MARIKINA



Blk 33 Lot 30 Mt. Everest Street corner G. Fernando Ave., Marikina City



Mobile Number: (+63) 917 674 4512

- [![MICROVAN INC. – FUSO BALINTAWAK* facade](https://fuso.com.ph/wp-content/uploads/2025/10/red-black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3859.9642701459697!2d121.0060440751651!3d14.657969175669427!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b70032919865%3A0xabbd9234a2e51956!2sFUSO%20Balintawak!5e0!3m2!1sen!2sph!4v1759449526272!5m2!1sen!2sph)





##### MICROVAN INC. – FUSO BALINTAWAK\*



1132 EDSA, Balintawak, Quezon City, Metro Manila, Philippines 1106



Sales

Ms. Kape Hernandez

0917 854 2941



Service

Kate Garcia

0917 707 3176



_\*Under Construction_

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2297.5832511307462!2d121.03349076642016!3d14.423760143740719!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397d1ccdf158d37%3A0x64083f7b489ef948!2sCitimotors+Alabang%2C+Incorporated!5e0!3m2!1sen!2sph!4v1563861766912!5m2!1sen!2sph)





##### CITIMOTORS, INC. – ALABANG



Westgate Business District, Alabang–Zapote Road, Muntinlupa City



Sales: (02) 8659 0118

Service: (02) 8659 3048

Parts: (02) 8659 3151

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3248.916556630886!2d120.98342737402788!3d14.448204514758693!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397cdfef7166487%3A0xcc775d410b07b881!2sCitimotors+Las+Pinas+Corp.!5e0!3m2!1sen!2sph!4v1563862408052!5m2!1sen!2sph)





##### CITIMOTORS, INC. – LAS PIÑAS



Alabang–Zapote Road corner St. Cecilia Village, Las Piñas City



Sales: (02) 8875 1704 / (02) 8875 1745

Service: (02) 8873 3959

Parts: (02) 8875 1751

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3860.4658997329084!2d120.97921037695717!3d14.62947459282169!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b5fa958892f9%3A0x1d70ab17bd440b7d!2sMitsubishi+Peak+Motors+Philippines+Inc.+J.+Abad+Santos!5e0!3m2!1sen!2sph!4v1563865798504!5m2!1sen!2sph)





##### PEAK MOTORS PHILIPPINES, INC. – JOSE ABAD SANTOS



2941-43 Jose Abad Santos Ave., Tondo, Manila



Sales: (02) 8708 2968

Service: (02) 8708 2963

Parts: (02) 8708 2967

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1931.040920241772!2d120.99233950815444!3d14.53731119379854!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397c959f47ab217%3A0xefa00b79aefefbea!2sMitsubishi+Peak+Motors+Phils.%2C+Inc.+-+Sales+Only!5e0!3m2!1sen!2sph!4v1563866295675!5m2!1sen!2sph)





##### PEAK MOTORS PHILIPPINES, INC. – MANILA BAY



EDSA corner Roxas Boulevard, Pasay City



Sales: (02) 8846 4578 or (02) 8846 4581 - 85

Service: (02) 846 4842 or (02) 846 4853

Parts: (02) 8551 7157

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1364.7075474612566!2d120.99417392310993!3d14.657312311537911!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b6848504225b%3A0xeb37eabbb1593f59!2sMitsubishi+Kalookan+Union+Motor+Corporation!5e0!3m2!1sen!2sph!4v1563867450739!5m2!1sen!2sph)





##### UNION MOTOR CORPORATION – KALOOKAN



198 EDSA corner Tandang Sora St., Kalookan City



(02) 8563 8461


- [![1DYNAMIX AUTOMOTIVE INC. – FUSO KAWIT facade](https://fuso.com.ph/wp-content/uploads/2019/07/1DAI-1-scaled.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5464.389310621892!2d120.89735377619532!3d14.432538005157207!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397d2cba790f03b%3A0x23dcda0d70249549!2sBest+Southern+Genesis+Motors%2C+Inc.!5e0!3m2!1sen!2sph!4v1563940575097!5m2!1sen!2sph)





##### 1DYNAMIX AUTOMOTIVE INC. – FUSO KAWIT



Centennial Road, Barangay Batong Dalig, Kawit, Cavite



(02) 8519 4516

(046) 439 4852

- [![ALPINE MOTORS CORPORATION – FUSO CARMONA facade](https://fuso.com.ph/wp-content/uploads/2019/07/AMC-scaled.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4597.49469424683!2d121.03783075202416!3d14.31045622575512!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397d7aa3489e4d3%3A0x36d02a3799a33292!2sAlpine+Motors+Corporation!5e0!3m2!1sen!2sph!4v1563940371797!5m2!1sen!2sph)





##### ALPINE MOTORS CORPORATION – FUSO CARMONA



Governor's Drive, Carmona, Cavite



(046) 404 6902

- [![CARWORLD, INC. – FUSO PAMPANGA facade](https://fuso.com.ph/wp-content/uploads/2019/07/CWI-scaled.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15413.998309514003!2d120.66605964004914!3d15.020459139122158!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3396f70f68146ac7%3A0xaebc5cb9f89475e1!2sFUSO+Carworld+Pampanga!5e0!3m2!1sen!2sph!4v1563940989392!5m2!1sen!2sph)





##### CARWORLD, INC. – FUSO PAMPANGA



Jose Abad Santos Avenue, Macabacle, Bacolor, Pampanga



Sales: (045) 649 4836 / (+63) 998 587 8280

Service: (+63) 998 587 8279

Parts: (+63) 998 587 8278

- [![H-MEN MOTORS – FUSO URDANETA facade](https://fuso.com.ph/wp-content/uploads/2021/11/HMEN.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63195.52178536833!2d120.38287480308225!3d15.871963123190536!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33913fdafce74f0b%3A0x84db2041b1922baf!2sFUSO%20Urdaneta!5e0!3m2!1sen!2sph!4v1636530817843!5m2!1sen!2sph)





##### H-MEN MOTORS – FUSO URDANETA



Brgy. Nancayasan, Mac Arthur Highway, Urdaneta City, Pangasinan



Sales: (+63) 917 504 4412

Service: (+63) 917 504 4413

- [![MG GATEWAY SOUTH CORPORATION – FUSO LIPA facade](https://fuso.com.ph/wp-content/uploads/2021/02/MGG.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2868.887222882407!2d121.1326531!3d13.944223899999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33bd6d75339dea13%3A0x9a550a578c320551!2sGateway%20Fuso%20Lipa!5e1!3m2!1sen!2sph!4v1787028493652!5m2!1sen!2sph)





##### MG GATEWAY SOUTH CORPORATION – FUSO LIPA



J. P. Laurel Highway, Purok 1, Lipa, Batangas



Sales : (+63) 915 352 2756

Service : (+63) 966 467 2479

- [![PEAK MOTORS PHILIPPINES, INC – FUSO CAINTA facade](https://fuso.com.ph/wp-content/uploads/2022/08/PMPI-1.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1930.5905877483867!2d121.10334389505944!3d14.588749892270709!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397c746b122a745%3A0x2739e31edb3345e2!2sFUSO%20Cainta!5e0!3m2!1sen!2sjp!4v1661495555158!5m2!1sen!2sjp)





##### PEAK MOTORS PHILIPPINES, INC – FUSO CAINTA



002 Ortigas Ave. Ext. corner St. Joseph Drive, Brgy. San Roque, Cainta, Rizal



(+63) 998 542 6146

- [![MAXIMOTORS CORPORATION – FUSO PALAWAN facade](https://fuso.com.ph/wp-content/uploads/2019/07/MXM-1-scaled.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3931.9078564026595!2d118.74627841528076!3d9.773864079567494!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33b5636e82776c15%3A0x5643cba9e2229337!2sMaximotors+Corp.+MITSUBISHI+Palawan!5e0!3m2!1sen!2sph!4v1563869796658!5m2!1sen!2sph)





##### MAXIMOTORS CORPORATION – FUSO PALAWAN



Km. 4 National Highway, Brgy. San Manuel, Puerto Princesa City, Palawan



(048) 433 0209

- [![CHRISTIAN GENERAL MOTORS, INC. – FUSO TARLAC facade](https://fuso.com.ph/wp-content/uploads/2024/02/CGMI-1-scaled.jpg)](https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d240.3108469320632!2d120.6385564!3d15.4858548!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3396c5f2365bb145%3A0x4145bd3e4a9f826b!2sTwin%208%20Fuel%20Station!5e0!3m2!1sen!2sph!4v1707890278562!5m2!1sen!2sph)





##### CHRISTIAN GENERAL MOTORS, INC. – FUSO TARLAC



San Jose, Tarlac City, Tarlac



Trunkline: (045) 206 4341

Sales: (+63) 919 062 6591 / (+63) 917 129 4292

Aftersales: (+63) 917 129 1245 / (+63) 917 142 6033

- [![GENESIS AUTO CORPORATION – FUSO CABANATUAN facade](https://fuso.com.ph/wp-content/uploads/2026/08/GAC-scaled.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3164.6407641330943!2d120.94009574945358!3d15.440191497192018!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x339727171c61c3bb%3A0xacabec385565f78c!2sFUSO%20Cabanatuan!5e0!3m2!1sen!2sph!4v1686614082814!5m2!1sen!2sph)





##### GENESIS AUTO CORPORATION – FUSO CABANATUAN



KM 108 Maharlika Highway, Brgy. Sumacab Este, Cabanatuan City, Nueva Ecija



Sales \| +639 173157296, Ms. Rachel Myles Paet

Service \| +639 173157336, Ms. Beverly Alavazo

Parts \| +639 676324368, Mr. Daniel Ernesto De Rueda



**\*NOW OPEN**

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15510.626064395066!2d123.19728856596579!3d13.617778178252543!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33a18cc772738d03%3A0x61974130147ee43!2sCaleb+Motor+Corporation!5e0!3m2!1sen!2sph!4v1563945634254!5m2!1sen!2sph)





##### CALIBRATION MOTORS, INC. – PILI



Zone 1, San Juan Palestina, Pili, Camarines Sur



(054) 871 5125

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3861.43406120293!2d121.14345614626846!3d14.57432504090244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397c768c2837d15%3A0x8dc4f0e8a22bf4b0!2sEVOLANDER+MOTOR+CORPORATION!5e0!3m2!1sen!2sph!4v1563868476176!5m2!1sen!2sph)





##### EVOLANDER MOTOR CORPORATION – TAYTAY



88-108 Manila East Road, Kaytikling, Taytay, Rizal



Sales: (02) 470 0777 loc. 109

Service: (02) 470 0777 loc. 115

Parts: (02) 470 0777 loc. 119

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3854.6950863935804!2d120.88526830261513!3d14.95407160088459!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33965550abaeedf3%3A0x38e4dcfb3b54b189!2sFreeway+Motor+Sales+Baliwag+(sales+)!5e0!3m2!1sen!2sph!4v1563868692526!5m2!1sen!2sph)





##### FREEWAY MOTOR SALES OF BALIUAG – BALIUAG



DRT Highway, Tarcan, Baliuag, Bulacan



Sales: (044) 766 4235

Service: (044) 673 4083 loc. 108

Parts: (02) 299 8247 loc. 108

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3870.5661881667584!2d121.34126671529908!3d14.04370979424451!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33bd5cb62746662f%3A0xcdf59c0a8bb3d187!2sSFM+Corporation!5e0!3m2!1sen!2sph!4v1563871150980!5m2!1sen!2sph)





##### SFM SALES CORPORATION – SAN PABLO



Km. 85.5 Maharlika Highway, Brgy. San Ignacio, San Pablo City, Laguna



Sales: (049) 562 0690 loc. 106

Service: (049) 562 0690 loc. 114

Parts: (049) 562 0690 loc. 115


- [![FAST AUTOWORLD PHILIPPINES CORPORATION – FUSO MACTAN facade](https://fuso.com.ph/wp-content/uploads/2020/11/FAPC-Cebu-1.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31407.12631548353!2d123.9703434727054!3d10.270382685990423!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33a99b0c18d7863b%3A0xe41ff6fbe6c65f72!2sFast%20Autoworld%20Philippines%20Fuso%20-%20Mactan!5e0!3m2!1sen!2sph!4v1605783167443!5m2!1sen!2sph)





##### FAST AUTOWORLD PHILIPPINES CORPORATION – FUSO MACTAN



Cadulang, Marigondon, Lapu-Lapu City



(+63) 998 999 7881

- [![MNV AUTO GROUP, INC. – FUSO ILOILO facade](https://fuso.com.ph/wp-content/uploads/2023/06/MNV-2.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1993165.4345050314!2d120.42421128436021!3d12.65447985411258!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33aefb75f429547d%3A0xf2c8db5205a963b8!2sFUSO%20Iloilo!5e0!3m2!1sen!2sph!4v1688397695842!5m2!1sen!2sph)





##### MNV AUTO GROUP, INC. – FUSO ILOILO



C1 Road, Pakiad, Oton, Iloilo City



Sales: (033) 337 4455

Service: (033) 337 6469

Parts: (033) 337 8666

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3921.030831854433!2d122.9371760152836!3d10.654712664340764!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33aed1b4c745b7d5%3A0xd8863906022ef22a!2sMITSUBISHI+MOTORS!5e0!3m2!1sen!2sph!4v1563871808131!5m2!1sen!2sph)





##### AVESCOR MOTORS OF BACOLOD



Araneta St., Singcang, Bacolod City



Sales: (034) 433 5088

Service: (034) 435 2113 to 14

Parts: (034) 433 0452

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3908.742136180163!2d122.75172571528705!3d11.570334347199921!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33a5f2eeeb9bf89d%3A0x8658cb76603eebb5!2sAvescor+Motors+Incorporated!5e0!3m2!1sen!2sph!4v1563872153408!5m2!1sen!2sph)





##### AVESCOR MOTORS, INC. – ROXAS



National Road, Brgy. Lawa-an, Roxas City



Sales: (036) 621 1676

Service and Parts: (036) 522 4586

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d24940.61969426954!2d123.64965796394233!3d10.107148651413388!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33a97d7188616789%3A0xa9149361a1342fc0!2sFast+Autoworld+Philippines+Corporation!5e0!3m2!1sen!2sph!4v1563872288674!5m2!1sen!2sph)





##### FAST AUTOWORLD PHILIPPINES CORPORATION – CEBU SOUTH



N. Bacalso Ave., Mambaling, Cebu City



Sales: (032) 261 7355 loc. 105 or 106

Service: (032) 261 7355 loc. 109 or 110

Parts: (032) 261 7355 loc. 112

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2783.8357347535634!2d123.29057179289191!3d9.338732061570797!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33ab6fbaf2b408b3%3A0x765826781cae2e49!2sMitsubishi+Motors!5e0!3m2!1sen!2sph!4v1563872586968!5m2!1sen!2sph)





##### FAST AUTOWORLD PHILIPPINES CORPORATION – DUMAGUETE



Maslog, Sibulan, Dumaguete City



Sales: (035) 419 9194 or (035) 225 1427

Service and Parts: (035) 419 9194

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1962.5087944533557!2d123.94055785381308!3d10.3404772301244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33a9985aa0fc8d99%3A0xd972faadec2e45f2!2sFast+Autoworld+Philippines+Corporation!5e0!3m2!1sen!2sph!4v1563873230976!5m2!1sen!2sph)





##### FAST AUTOWORLD PHILIPPINES CORPORATION – MANDAUE



M.C. Briones Highway, Mandaue City



(032) 345 1233

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15666.4699967823!2d124.61807698783076!3d10.992216866557248!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3307f134f10d320b%3A0x31b113e8a12dd6cd!2sMitsubishi+Motors+Ormoc+(Fast+Autoworld+Philippines+Corporation)!5e0!3m2!1sen!2sph!4v1563873837351!5m2!1sen!2sph)





##### FAST AUTOWORLD PHILIPPINES CORPORATION – ORMOC



FAPC Bldg. Brgy. Bantigue, Ormoc City, Leyte, 6541



Sales: (053) 560-8124

Service: (053) 561-2554

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3913.639769285359!2d125.00001131528559!3d11.214266254024437!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3308770fd40c1f11%3A0x75bfe00e8f2a7ac8!2sMitsubishi+Motors!5e0!3m2!1sen!2sph!4v1563872698623!5m2!1sen!2sph)





##### FAST AUTOWORLD PHILIPPINES CORPORATION – TACLOBAN



Fatima Village, Marasbaras, Tacloban City



Sales: (053) 325 3876 or (053) 323 3724

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3933.133178963889!2d123.85745331528038!3d9.66966028128667!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33aa4c6a4fce438d%3A0x1bbb5805a46866a!2sMitsubishi+Motors!5e0!3m2!1sen!2sph!4v1563872905344!5m2!1sen!2sph)





##### FAST AUTOWORLD PHILIPPINES CORPORATION – TAGBILARAN



282 C.P. Garcia North Ave., Taloto District, Tagbilaran City



Sales: (038) 412 2661

Service: (038) 412 5814

Parts: (038) 235 5492


- [![FAST AUTOWORLD PHILIPPINES CORPORATION – FUSO CAGAYAN DE ORO facade](https://fuso.com.ph/wp-content/uploads/2019/07/CDO-3-scaled.jpg)](https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2282.2608046755677!2d124.67130191023843!3d8.480052329241921!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x32fff3dd3ce3e00b%3A0xd7e1b332261eee86!2sFUSO%20Cagayan%20De%20Oro!5e0!3m2!1sen!2sjp!4v1658978221417!5m2!1sen!2sjp)





##### FAST AUTOWORLD PHILIPPINES CORPORATION – FUSO CAGAYAN DE ORO



Purok 8-A, San Pedro, Gusa, Cagayan de Oro City, 9000 Misamis Oriental



(+63) 956 582 0849

- [![MINDANAO INTEGRATED COMMERCIAL ENTERPRISES, INC. – FUSO SOUTH COTABATO facade](https://fuso.com.ph/wp-content/uploads/2019/07/MICEI-1-scaled.jpg)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d9152.774219783123!2d125.10737769244436!3d6.170153186081296!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x32f79b850775235d%3A0x722dc1fd133b5654!2sFUSO%20South%20Cotabato!5e0!3m2!1sen!2sjp!4v1658978012227!5m2!1sen!2sjp)





##### MINDANAO INTEGRATED COMMERCIAL ENTERPRISES, INC. – FUSO SOUTH COTABATO



Pan-Philippine Highway, Brgy. Silway 7, Polomolok, South Cotabato



Sales: (+63) 915 056 7623

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3941.3136306050924!2d125.51817080999906!3d8.943219710357013!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3301c0f9197ebce7%3A0x941a33be72d4133f!2sMitsubishi+Motors!5e0!3m2!1sen!2sph!4v1563874047845!5m2!1sen!2sph)





##### FAST AUTOWORLD PHILIPPINES CORPORATION – BUTUAN



Km. 2, Aquino Ave., Butuan City



Sales: (085) 341 1162 loc. 101 or (085) 342 8453 loc. 104

Service: (085) 815 1241

Parts: (085) 341 4737

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3949.2123295692436!2d123.85936531527703!3d8.181353303939044!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3255ab8d69bfffff%3A0xce245cc1c7975654!2sMitsubishi+Motors!5e0!3m2!1sen!2sph!4v1563874390511!5m2!1sen!2sph)





##### FAST AUTOWORLD PHILIPPINES CORPORATION – OZAMIZ



Purok 5, Brgy. Gango, Ozamiz City



Sales: (088) 521 2351

Service: (088) 521 2351 loc. 107 or 108

Parts: (088) 521 2351 loc. 110 or (088) 521 1115

- [![FUSO logo](https://fuso.com.ph/wp-content/themes/fuso-theme-2026/images/logo/black-find-dealers.png)](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.8492824739833!2d122.07774731527515!3d6.908618820481756!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x325041fec25406ed%3A0x9460bae1590b8981!2sZamboanga+Motors+Inc.!5e0!3m2!1sen!2sph!4v1563874914341!5m2!1sen!2sph)





##### ZAMBOANGA MOTORS, INC. – ZAMBOANGA



Gov. Camins Rd, Zamboanga, 7000 Zamboanga del Sur



(062) 991 2199


##### Products

- [Find A Dealer](https://fuso.com.ph/dealers/)
- [Models](https://fuso.com.ph/models/)
- [Latest Offers](https://fuso.com.ph/latest-offers/)

##### Parts & Services

- [Parts](https://fuso.com.ph/parts-and-accessories/)
- [Services](https://fuso.com.ph/services/)

##### About Us

- [FUSO Brand](https://fuso.com.ph/brands/)
- [Corporate Profile](https://fuso.com.ph/company-profile/)
- [Contact us](https://fuso.com.ph/contact-us/)
- [Careers](https://fuso.com.ph/careers/)

##### News

- [Press Release](https://fuso.com.ph/category/press-release/)
- [Global News](https://www.mitsubishi-fuso.com/en/news/)

##### Site Policy

- [Terms of Use](https://fuso.com.ph/terms-of-use/)
- [Privacy Policy](https://fuso.com.ph/privacy-policy/)
- [Social Media Terms of Use](https://fuso.com.ph/sns-terms-of-use/)

© 2026 Sojitz Fuso Philippines Corporation. All rights reserved.

Follow us:

- [Facebook](https://facebook.com/FusoPhilippines)
- [Instagram](https://www.instagram.com/fuso.ph/)
- [Youtube](https://youtube.com/@FUSOPhilippines)

#### Privacy Policy

By using this website, you acknowledge that you have read, understood, and agreed to our [Privacy Policy](https://fuso.com.ph/privacy-policy/), and consent to the collection, use, and processing of your personal data by us.

1794401687153

[Phone](tel:+63495301390)

[Email](mailto:inquiry@fuso.com.ph)

Open chatychaty buttons

Hide chaty