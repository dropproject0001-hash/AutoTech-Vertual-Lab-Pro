Source: https://rmi.isuzu.co.jp/faq
Title: ISUZU Repair and Maintenance Information
Fetched: 2026-11-11T10:05:48.197Z

# FAQ

|     |
| --- |
| [Q. What kind of information and manuals are available?](https://rmi.isuzu.co.jp/faq#a1) |
| [Q. What is CSS-net?](https://rmi.isuzu.co.jp/faq#a2) |
| [Q. What range of vehicle information do you have?](https://rmi.isuzu.co.jp/faq#a3) |
| [Q. How do I access the information?](https://rmi.isuzu.co.jp/faq#a4) |
| [Q. I bought a car other than a European market. Is this manual the same?](https://rmi.isuzu.co.jp/faq#a5) |
| [Q. What should I be aware of when using the information?](https://rmi.isuzu.co.jp/faq#a6) |
| [Q. What is the Privacy Policy?](https://rmi.isuzu.co.jp/faq#a7) |
| [Q. What is the Cookie Policy?](https://rmi.isuzu.co.jp/faq#a8) |
| [Q. What are the system requirements?](https://rmi.isuzu.co.jp/faq#a9) |
| [Q. What about COPYRIGHT?](https://rmi.isuzu.co.jp/faq#a10) |
| [Q. I am browsing online, can I print the information?](https://rmi.isuzu.co.jp/faq#a11) |
| [Q. How much is an online subscription?](https://rmi.isuzu.co.jp/faq#a12) |
| [Q. Can I download and resell the information?](https://rmi.isuzu.co.jp/faq#a13) |
| [Q. Can I share my account?](https://rmi.isuzu.co.jp/faq#a14) |
| [Q. I would like to inquire about Isuzu RMI website.](https://rmi.isuzu.co.jp/faq#a15) |

Q. What kind of information and manuals are available?

A. Our RMI web site has some type of information and manuals. These are described below.

Work shop manual

Diagnostic codes, inspection and repair procedures for engines, transmissions, fuel systems, transaxles, suspensions, brakes, cooling and safety systems such as seat belts and SRS airbags etc.

Electrical wiring diagram (ETM)

Schematic layout of the vehicle wiring diagram and components.

Body Workshop manual

Repair procedures for the reconstruction of damaged vehicles.

Owner's manual

This contains the same information as the manual installed in the vehicle.

Labor time guide

Working time required to repair the vehicle.

Technical service bulletin

Additional information about the service or repair that is not listed in the Work shop manual, or supplemental information in the Work shop manual.

Maintenance schedule

This provides service and maintenance requirements that determine what items need attention or replacement at specific time or distance intervals for Isuzu European vehicles.

Special services tools (SST)

These tools are designed specifically for the safety and efficiency of Isuzu vehicles. Refer to the workshop manual.

Parts catalog (EQ-HIT)

You can find the part number of genuine Isuzu parts. These part numbers are provided for reference only. We cannot supply replacement parts at this site.

Scan tool(G-IDSS)

This tool is useful for detecting DTC and changing the settings of ECUs. It is also used for ECU software updates.

Security RMI

To obtain the Security RMI, you must be registered and authorized by the Trust Center.

E-Learning

Training programs for mechanics are provided through the Isuzu E-learning System. you can use your time and improve your mechanic skills effectively by accessing Isuzu's Learning Management System from an electronic devise. To access the training program, you need to access CSS-net and get login ID/password.

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. What is CSS-net?

A. This contains Work shop manual, Owner's manual, Labor time guide, Technical service bulletin, body Workshop manual, Electrical wiring diagrams, Maintenance schedules, and other information and manuals published by Isuzu.

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. What range of vehicle information do you have?

A. Commercial Truck is available for 2014MY and later, and Pick Up Truck is available for 2012MY and later.

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. How do I access the information?

A. For information on how to access the information you want to view, see Standardized Navigation.

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. I bought a car other than a European market. Is this manual the same?

A. No, our RMI website only publishes information for European market. For vehicles imported from markets other than Europe, contact your Isuzu dealer.

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. What should I be aware of when using the information?

A. Before using the information on the Isuzu RMI Web site, do the following:

・Make sure you have the technical ability to perform the repair or procedure.

・Work in a safe manner and carry out all safety precautions.

・Read all warnings, precautions, and safety procedures.

・Use the correct tool specified.

・Consult a qualified professional if you have any questions about the repair or procedure.

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. What is the Privacy Policy?

A. See below

[https://www.isuzu.co.jp/world/privacy.html](https://www.isuzu.co.jp/world/privacy.html)

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. What is the Cookie Policy?

A. See below

[https://rmi.isuzu.co.jp/cookie](https://rmi.isuzu.co.jp/cookie)

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. What are the system requirements?

A. See below

[https://rmi.isuzu.co.jp/introduction](https://rmi.isuzu.co.jp/introduction)

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. What about COPYRIGHT?

A. All contents of these manuals are protected by copyright. The information, text, images, and graphics contained in this document may only be used personally or within the scope of your regular business.

You may not reproduce, modify, transmit, license or publish these manuals, in whole or in part, for any purpose without the prior written consent of Isuzu Motors limited.

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. I am browsing online, can I print the information?

A. Yes. You can print the information for personal use. However, see the Copyright section of these notes.

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. How much is an online subscription?

A. Subscriptions are offered on an hourly, daily, monthly, or yearly basis. Please see below for current subscription rates.

[https://rmi.isuzu.co.jp/introduction](https://rmi.isuzu.co.jp/introduction)

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. Can I download and resell the information?

A. All information on this site is protected by copyright. If you would like to resell it, please contact us below

[https://rmi.isuzu.co.jp/help](https://rmi.isuzu.co.jp/help)

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. Can I share my account?

A. No. Subscription terms are per person. Not a site license subscription. If multiple uses are detected, the account and access are terminated.

In such a case, all rights to the unexpired elements of the subscription are invalidated.

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

Q. I would like to inquire about Isuzu RMI website.

A. Please contact us below.

[https://rmi.isuzu.co.jp/help](https://rmi.isuzu.co.jp/help)

[Back to Top](https://rmi.isuzu.co.jp/faq#content)

[TOP](https://rmi.isuzu.co.jp/)