Source: https://rssocar.psa.gov.ph/content/istat-lto
Title: iSTAT LTO | Philippine Statistics Authority
Fetched: 2026-11-11T12:54:18.202Z

CTRL+F2![Accessibility Menu](<Base64-Image-Removed>)

Accessibility Toolbox✗

Keyboard Navigation![Keyboard Navigation](<Base64-Image-Removed>)Block Animations![Block Animations](<Base64-Image-Removed>)

Color Contrast![Uncolored<br>Display](<Base64-Image-Removed>)Uncolored

Display![Bright<br>Contrast](<Base64-Image-Removed>)Bright

Contrast![ניגודיות הפוכה](<Base64-Image-Removed>)Reverse

Contrast

Text Size![Increase<br>Text](<Base64-Image-Removed>)Increase

Text![Decrease<br>Text](<Base64-Image-Removed>)Decrease

Text![Readable<br>Text](<Base64-Image-Removed>)Readable

Text

Highlighting Content![Underline<br>Links](<Base64-Image-Removed>)Underline

Links![Underline<br>headers](<Base64-Image-Removed>)Underline

headers![Images<br>Titles](<Base64-Image-Removed>)Images

Titles

Zoom In![Big white<br>Cursor](<Base64-Image-Removed>)Big white

Cursor![Big black<br>Cursor](<Base64-Image-Removed>)Big black

Cursor![Zoom<br>Screen](<Base64-Image-Removed>)Zoom

Screen

[accessibility statement](https://rssocar.psa.gov.ph/content/istat-lto# "accessibility statement") [report an accessibility problem](https://rssocar.psa.gov.ph/content/istat-lto# "report an accessibility problem") Reset Settings![Reset Settings](<Base64-Image-Removed>)

learn more about [toolbox](https://mickidum.github.io/acc_toolbar/)

ITDS-KMCD-ODS

Drupal Accessibility Toolbar [toolbox](https://gitlab.com/rus-psa/accessibility-toolbar)

[Skip to main content](https://rssocar.psa.gov.ph/content/istat-lto#main-content)

Release Date :

Friday, February 14, 2020

[![](https://rssocar.psa.gov.ph/sites/default/files/iSTAT-header.png)](http://rssocar.psa.gov.ph/iSTAT)

**LAND TRANSPORTATION OFFICE**

| Producing Agency/ Statistical Series/<br> Statistics being Produced | Level of Dissagregation | Data Source | Frequency | Timelag/<br> Date of<br> Availability | Mode of<br> Dissemination | Unit to be Contacted | Remarks/<br> Availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Geographic | Other Indicator |
|  |
| Number of Motor Vehicles Registered | Provincial | by Classification, Type of Vehicle, Type of Fuel Used |  |  |  |  | Tel No: 444-7997 | Provincial data are available upon request from the Regional Office |
| Number of Driving Permits/Licenses Issued | Provincial | by Type |  |  |  |  | Tel No: 444-7997 | Provincial data are available upon request from the Regional Offices |
|  |  |  |  |  |  |  |  |  |

Tags

[iSTAT](https://rssocar.psa.gov.ph/taxonomy/term/558)

[iSTAT LTO](https://rssocar.psa.gov.ph/taxonomy/term/587)

02July 2020

### [iSTAT DILG](https://rssocar.psa.gov.ph/content/istat-dilg)

02July 2020

### [iSTAT CPDO](https://rssocar.psa.gov.ph/content/istat-cpdo)

01July 2020

### [iSTAT COA](https://rssocar.psa.gov.ph/content/istat-coa)