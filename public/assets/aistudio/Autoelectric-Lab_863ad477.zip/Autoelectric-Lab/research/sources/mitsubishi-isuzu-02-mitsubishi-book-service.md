Source: https://www.mitsubishi-motors.com.ph/service/book-a-service
Title: Book a Service | Mitsubishi Motors
Fetched: 2026-11-11T10:05:46.512Z

# Book a Service

Please complete the form below to send a service request to your local dealership.

### 1\. Your Car

WHAT CAR DO YOU OWN?\*Outlander PHEVStradaMirage G4MirageMontero SportPajeroL300XpanderOther

CAN YOU TELL US THE MODEL (OPTIONAL)

CAR REGISTRATION NUMBER\*

CURRENT MILEAGE (OPTIONAL)

### 2\. About you

First Name\*

Last Name\*

Email\*

Phone Number\*

### 3\. Appointment preferences

#### Pick a service centre

Enter postcode or location

Use Current Location

Avescor Motors, Inc. - Roxas

National Road, Barangay Lawa-an, Roxas City, Capiz, 5800

#### About your appointment

YOUR IDEAL DATE\*

![Previous](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='24' height='24' viewBox='0 0 24 24'%3E%3Cdefs%3E%3Cpath id='a' d='M12.5 13.563L6.762 8 5 9.712 12.5 17 20 9.712 18.237 8z'/%3E%3C/defs%3E%3Cuse fill-rule='evenodd' xlink:href='%23a'/%3E%3C/svg%3E)![Next](data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='24' height='24' viewBox='0 0 24 24'%3E%3Cdefs%3E%3Cpath id='a' d='M12.5 13.563L6.762 8 5 9.712 12.5 17 20 9.712 18.237 8z'/%3E%3C/defs%3E%3Cuse fill-rule='evenodd' xlink:href='%23a'/%3E%3C/svg%3E)

### November 2026

| M | T | W | T | F | S | S |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  | 1 |
| 2 | 3 | 4 | 5 | 6 | 7 | 8 |
| 9 | 10 | 11 | 12 | 13 | 14 | 15 |
| 16 | 17 | 18 | 19 | 20 | 21 | 22 |
| 23 | 24 | 25 | 26 | 27 | 28 | 29 |
| 30 |  |  |  |  |  |  |

YOUR IDEAL TIME8am-9am9am-10am10am-11am11am-12pm12pm-1pm1pm-2pm2pm-3pm3pm-4pm4pm-5pm

Additional information regarding your service

Privacy Policy\*

I agree to the Privacy Policy

We want you to feel confident that we take the privacy and security of your personal information very seriously. Tick the box to let us know you’ve read our [Privacy Policy](https://www.mitsubishi-motors.com.ph/privacy-policy) before you continue.

SUBMIT

Mitsubishi Motors Philippines Corporation (MMPC) places utmost importance and respects your right to privacy. MMPC shall handle with utmost care all personal and sensitive information that you may provide or those that we may collect from you upon your use of the website in accordance with our [Privacy Policy](https://www.mitsubishi-motors.com.ph/privacy-policy). By closing this banner, scrolling this page or clicking any part of it, you hereby acknowledge that you have read and understood our Privacy Policy and expressly consent to it.

I agree