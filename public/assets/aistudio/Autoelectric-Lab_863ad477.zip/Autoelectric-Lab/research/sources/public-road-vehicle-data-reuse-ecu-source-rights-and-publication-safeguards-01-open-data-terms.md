Source: https://data.gov.ph/index/terms-of-use
Title: Open Data Philippines
Fetched: 2026-11-11T12:54:21.414Z

#### DATA POLICY STATEMENT

1\. Application of this Data Policy

The statements in this policy apply only to datasets accessible through data.gov.ph. Nothing in this policy shall be construed as a limitation or modification of existing laws, rules, and legal precedents.

2\. Licensing

Unless otherwise indicated, datasets accessed through data.gov.ph are offered free and without restriction. However, proper attribution must be credited to the publishing government agency. Some datasets available through data.gov.ph have different governing licenses, as indicated in its corresponding metadata. In such cases, the user shall observe the terms and conditions stipulated in the license provided.

3\. Public information

Datasets accessed through data.gov.ph are confined to public information as defined by existing laws, rules, and legal precedents.

4\. Re-use

The Open Data Philippines Task Force and publishing government agencies have no control over the re-use or end-use of datasets accessed through data.gov.ph. Once datasets have been downloaded from data.gov.ph or from any agency's website, the government cannot vouch for its re-use, including derivative works and analysis results from these datasets.

5\. Feedback

In support of citizen engagement, feedback from users regarding datasets, metadata, visualizations, and other forms of content in data.gov.ph is welcomed and encouraged. Feedback on datasets will be forwarded by the Open Data Philippines Task Force to the concerned government agency.

6\. Data providers

Most of the datasets will link to the website of the source agency. In such cases when the user leaves data.gov.ph, the user is subject to the privacy and security policies of the data provider's website. As the data providers, government agencies retain management and version control of their datasets. Hence, only the publishing government agency can guarantee the quality and timeliness of its datasets.

7\. General

The statements in this policy may be revised from time to time. Data.gov.ph is the official open data portal of the Government of the Philippines and is managed by the Open Data Philippines Task Force.

[![](https://data.gov.ph/assets/logos/govph-ngp.png)](https://www.gov.ph/)

Philippine Standard Time - Wednesday, November 11, 2026, 7:54:20 AM

![](https://data.gov.ph/assets/icons/accessibility.png)

Accessibility

arrow\_drop\_down

arrow\_circle\_up