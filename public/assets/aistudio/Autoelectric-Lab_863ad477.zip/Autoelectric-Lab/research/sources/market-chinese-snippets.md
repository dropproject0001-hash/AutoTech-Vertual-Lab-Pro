# Market / service research snippet evidence

Research date: 2026-11-11. These excerpts were returned by webSearch and are preserved as snippet-only evidence (not full-page verification). Search-result publication dates are recorded only where the result supplied one.

## 1) Joint CAMPI–TMA August 2026 sales report (PDF hosted by Logistics News; underlying report is attributed to CAMPI/TMA)
- URL: https://logisticsnews.ph/wp-content/uploads/2026/09/CAMPI-TMA-MEDIA-SALES-REPORT-AUGUST-2026.pdf
- Title: JOINT CAMPI - TMA SALES REPORT AUGUST 2026 C A M P I
- Date: August 2026 report; PDF URL indicates September 2026 upload; exact publication date not available in snippet.
- Snippet: “YTD SALES (AUGUST 2026) … TOTAL VEHICLE SALES YTD SALES (AUGUST 2026) … AUG 2026 Total Vehicle Sales …”
- Limit: Snippet does not expose brand table, vehicle coverage, or fleet/retail split. This is a reposted PDF URL, not a verified CAMPI-hosted copy.

## 2) BYD Cars Philippines sales announcement (manufacturer / local distributor blog)
- URL: https://bydcarsphilippines.com/blog/byd-sales-growth-2026
- Title: BYD Cars Philippines Surpasses Full-Year 2025 Sales and Posts 99% Year-on-Year Growth
- Date: September 10, 2026.
- Snippet: “BYD Cars Philippines closed August 2026 with 4,682 units …” and headline claims it surpassed full-year 2025 sales with 99% year-on-year growth.
- Limit: Search snippet omits the full text and whether the figure is monthly or cumulative; do not compare or treat it as market-wide without reading the post and establishing the metric.

## 3) Manila Bulletin on Geely Philippine aftersales response (major publication)
- URL: https://mb.com.ph/2025/08/21/geely-philippines-tackles-past-service-issues-with-new-strategy
- Title: Geely Philippines tackles past service issues with new strategy
- Date: August 21, 2025 (snippet).
- Snippet: “Geely Philippines is addressing past criticism over parts shortages and long turnaround times by introducing a six-month stockpile of components and streamlining warranty approvals.”
- Limit: Reported corporate strategy; implementation/outcomes and technical-document access not independently established. Source is about 15 months old as of 2026-11-11, under the 18-month freshness threshold but should be treated as historical.

## 4) Autocar Philippines on Geely parts distribution
- URL: https://autocar.com.ph/geely-philippines-parts-delivery-sf-partnership
- Title: Geely Philippines promises on-time spare parts delivery
- Date: October 16, 2025 (snippet).
- Snippet: “Geely Motor Philippines (GMP) is committed to reestablishing its foothold in the local market as it continues to launch programs driven to further improve …” and result describes Geely PH and SF Philippines partnership.
- Limit: Does not establish realized parts lead times, fleet/retail sales mix, or technical-information access.

## 5) CarGuide.PH on 2026 industry brand standings (automotive publication; snippet only)
- URL: https://www.carguide.ph/2026/07/winners-and-losers-first-half-2026.html
- Title: Winners And Losers: First Half 2026 Philippine Auto Industry Report Card
- Date: July 2026 (snippet/date in search result).
- Snippet: “MG – 4,232 (4,632; -8.64%) … Geely – 2,464 (NEW) … The 17,696-unit difference could come from the big elephant in the room: BYD.” Another query result states CAMPI-TMA member sales totaled 204,557 in H1 2026 versus 230,912 in H1 2025.
- Limit: Snippet blends brand rankings and discusses a gap that “could” involve BYD; it is not primary CAMPI evidence and does not define its scope or fleet/retail split. Do not represent BYD's inferred contribution as confirmed.

## 6) CarGuide.PH report on August 2026 new-car sales (automotive publication; snippet only)
- URL: https://www.carguide.ph/2026/09/byd-climbs-to-2nd-place-in-august-2026.html
- Title: BYD Climbs To 2nd Place In August 2026 New Car Sales As Chinese Brands Now Occupy 40% Of Top 10
- Date: September 28, 2026 (another search result lists this exact date for the article).
- Snippet: “new car sales hit 34,390 units including those from non-CAMPI-TMA members. Among CAMPI-TMA members, new car sales hit just 29,611 units—an 18.1 percent drop versus Aug…”
- Limit: Brand position and “40%” headline need full report and source tables; snippet illustrates a material scope difference between member-only and industry-augmented totals.

## 7) BYD repair portal candidate (unverified third party; not an OEM source)
- URL: https://www.bydrepairmanual.com/
- Title: BYD Service Manuals & Wiring Diagrams | BYD Service Portal
- Date: Not supplied in snippet.
- Snippet: “BYD Service Portal Technical information … BYD Seal service manual and wiring diagrams … For mechanics & workshops … manuals, wiring diagrams & diagnostics, online.”
- Limit: Domain is not BYD's manufacturer domain and search result does not establish OEM authorization, document provenance, market applicability, licensing, or accuracy. It is not acceptable as an OEM pinout source; do not use it for pin-level advice.

## 8) TaT OEM resource directory (third-party; potentially licensed index)
- URL: https://www.tat.net.au/scandata/am-info/am-info-view.php?make=BYD
- Title: BYD Service & Repair Information | OEM Resource | TaT
- Date: Not supplied in snippet.
- Snippet: Describes an Automotive Technician membership and an “OEM Information Resource” page for BYD.
- Limit: Search result alone does not show what OEM data is available, country coverage, licensing terms, or access requirements.
