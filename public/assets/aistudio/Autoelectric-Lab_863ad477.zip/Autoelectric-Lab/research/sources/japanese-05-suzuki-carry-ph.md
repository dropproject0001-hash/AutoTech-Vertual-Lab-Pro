Source: https://auto.suzuki.com.ph/cars/carry
Title: Carry Philippines: Suzuki Carry Specifications and Prices in Philippines
Fetched: 2026-11-11T10:06:19.656Z

[Skip to main content](https://auto.suzuki.com.ph/cars/carry#cta-icons-modelPage)

![CORSeal](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/CORSeal.png)

This website uses cookies to enable it to perform properly, remember your browsing history and to arrange contents that will match your preferred interests more efficiently. The details of the cookies that Suzuki Philippines Incorporated (SPH) use can be found on our [Data Privacy Notice](https://auto.suzuki.com.ph/pages/Data-Privacy-Notice). By clicking the Accept button, closing this banner, scrolling this page or clicking any part of it, you agree to our use of cookies.

Accept

TOP

![Suzuki_Carry-Product-Page-Banner-768x1080_Mobilecopy_1775719423096](https://auto.suzuki.com.ph/_next/image?url=https%3A%2F%2Fd1shbjc4qnoh7j.cloudfront.net%2Fmodels%2FCA%2Fimages%2FCarry-Product-Page-Banner-768x1080_Mobilecopy_1775719423096.jpg&w=1920&q=75)

![CA](https://auto.suzuki.com.ph/_next/image?url=https%3A%2F%2Fd1shbjc4qnoh7j.cloudfront.net%2Fmodels%2FCA%2Fimages%2FCarry_1775719413167.jpg&w=1920&q=75)

Previous

![Suzuki_CarryDropside_07_1683021496589](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_CarryDropside_07_1683021505303](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Large-size cargo

Being able to load and haul large pieces of furniture requires lots of cargo space and extra-large loading capacity. More importantly, you need to have convenient access to the bed from all three sides and be able to load and unload without straining your back in the process.

![Suzuki_1672677778877_section2_desktop](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_1672677787867_section2_mobile](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Carry Dropside

The Carry is built to be tough. Plenty of protection measures against rust and corrosion prepare you for working in severe conditions, while heavy-duty features add to the all-around toughness.

![Suzuki_CarryDropside_07_1683021496589](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_CarryDropside_07_1683021505303](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Large-size cargo

Being able to load and haul large pieces of furniture requires lots of cargo space and extra-large loading capacity. More importantly, you need to have convenient access to the bed from all three sides and be able to load and unload without straining your back in the process.

![Suzuki_1672677778877_section2_desktop](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_1672677787867_section2_mobile](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Carry Dropside

The Carry is built to be tough. Plenty of protection measures against rust and corrosion prepare you for working in severe conditions, while heavy-duty features add to the all-around toughness.

![Suzuki_CarryDropside_07_1683021496589](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_CarryDropside_07_1683021505303](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Large-size cargo

Being able to load and haul large pieces of furniture requires lots of cargo space and extra-large loading capacity. More importantly, you need to have convenient access to the bed from all three sides and be able to load and unload without straining your back in the process.

Next

Previous

![Suzuki_CarryUVExterior_1683021663087](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_CarryUVExterior_1683021668259](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Rear body major features

Corrugated plate, gray painted flooring \| 50/50 split-folding bench type seat \| Sliding glass window on side \| Fixed glass window on back door \| Rubber accordion cab connector \| 70/30 split back door with heavy duty lock, vinyl trim and inner plastic handle \| Equipped with vinyl headlining \| Wood with vinyl cover front panel trim \| Assist grip on ceiling dome lamp, 2 position switch \| Equipped with step board \| Equipped with mudguard

![Suzuki_1672677931189_section3_desktop](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_1672677936594_section3_mobille](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Carry Utility Van

The Utility Van is both people and cargo carrier. It has 50/50 split-folding seat on both sides for flexibility in providing more cargo space when needed.

![Suzuki_CarryUVExterior_1683021663087](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_CarryUVExterior_1683021668259](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Rear body major features

Corrugated plate, gray painted flooring \| 50/50 split-folding bench type seat \| Sliding glass window on side \| Fixed glass window on back door \| Rubber accordion cab connector \| 70/30 split back door with heavy duty lock, vinyl trim and inner plastic handle \| Equipped with vinyl headlining \| Wood with vinyl cover front panel trim \| Assist grip on ceiling dome lamp, 2 position switch \| Equipped with step board \| Equipped with mudguard

![Suzuki_1672677931189_section3_desktop](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_1672677936594_section3_mobille](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Carry Utility Van

The Utility Van is both people and cargo carrier. It has 50/50 split-folding seat on both sides for flexibility in providing more cargo space when needed.

![Suzuki_CarryUVExterior_1683021663087](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_CarryUVExterior_1683021668259](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Rear body major features

Corrugated plate, gray painted flooring \| 50/50 split-folding bench type seat \| Sliding glass window on side \| Fixed glass window on back door \| Rubber accordion cab connector \| 70/30 split back door with heavy duty lock, vinyl trim and inner plastic handle \| Equipped with vinyl headlining \| Wood with vinyl cover front panel trim \| Assist grip on ceiling dome lamp, 2 position switch \| Equipped with step board \| Equipped with mudguard

Next

Previous

![Suzuki_CarryCVExterior_1683021799524](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_CarryCVExterior_1683021794206](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Rear body major features

Checkered plate, painted black flooring \| Aluminum rivetless exterior panel \| Marine plywood inner panel \| 50/50 split-door with full swing hinges, two cam lock with rubber sill \| Room lamp with two position switch

![Suzuki_1677565320580_section4_desktop](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_1677565332565_section4_mobile](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Carry Cargo Van

Perfect for cargo transfer requirements, perfect size to bring your cargo to the inner streets of the metro. The body is made of rivet less aluminum panel ideal for advertising signage.

![Suzuki_CarryCVExterior_1683021799524](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_CarryCVExterior_1683021794206](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Rear body major features

Checkered plate, painted black flooring \| Aluminum rivetless exterior panel \| Marine plywood inner panel \| 50/50 split-door with full swing hinges, two cam lock with rubber sill \| Room lamp with two position switch

![Suzuki_1677565320580_section4_desktop](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_1677565332565_section4_mobile](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Carry Cargo Van

Perfect for cargo transfer requirements, perfect size to bring your cargo to the inner streets of the metro. The body is made of rivet less aluminum panel ideal for advertising signage.

![Suzuki_CarryCVExterior_1683021799524](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_CarryCVExterior_1683021794206](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Rear body major features

Checkered plate, painted black flooring \| Aluminum rivetless exterior panel \| Marine plywood inner panel \| 50/50 split-door with full swing hinges, two cam lock with rubber sill \| Room lamp with two position switch

Next

![Suzuki_LVCarrywithBakcroundcopy_1775719511841](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

![Suzuki_LVCarrymobile_1775719632983](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=1920&q=75)

### Carry Lineman Vehicle

The Lineman Vehicle is suitable for business owners and companies, specifically for Cable and Telecom services.

#### SEE WHICH CARRY IS PERFECTLY RIGHT FOR YOU

## CARRY

CAB & CHASSIS MT

![select-arrow](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/select-drop-icon.svg)

![Suzuki_Carry_MT_Cab_Chassis_1759126341978](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=640&q=75)

WHITE

## CARRY

DROPSIDE MT

![select-arrow](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/select-drop-icon.svg)

![Suzuki_Carry_MT_Dropside_1759126355031](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=640&q=75)

WHITE

## CARRY

CARGO VAN MT

![select-arrow](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/select-drop-icon.svg)

![Suzuki_Carry_MT_Cargo_1759126365350](https://auto.suzuki.com.ph/_next/image?url=%2Fassets%2Fimages%2Fplaceholder-transparent.png&w=640&q=75)

WHITE

[Finance Calculator \\
![Click for Next page](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/blue-arrow.svg)](https://auto.suzuki.com.ph/cars/carry)

Test Drive
![Click for Next page](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/blue-arrow.svg)

## EXPERIENCECARRYTODAY

![Find a Dealer](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/brand-pages/experience-icons/add_location_alt.svg)

Find A Dealer

![Book a Test drive](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/brand-pages/experience-icons/directions_car.svg)
BOOK A TEST DRIVE

![Download the Brochure](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/brand-pages/experience-icons/chevron.svg)
DOWNLOAD A BROCHURE

![Finance Calculator](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/floatbar/CurrencySymbol.svg)

FINANCE CALCULATOR

## TOPICS

[![Suzuki_Suzuki-Carry_thumbnail_1701242531068](https://auto.suzuki.com.ph/_next/image?url=https%3A%2F%2Fd1shbjc4qnoh7j.cloudfront.net%2Fall-page%2Ffeature-images%2Fdesk-thumb%2FSuzuki-Carry_thumbnail_1701242531068.jpg&w=1920&q=75)](https://auto.suzuki.com.ph/pages/suzuki-carry-for-your-business)

Let’s review the features of the Suzuki Carry truck and why it’s the top choice for businesses in the urban jungle of the city.

[See Details \\
![Click for Next page](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/blue-arrow.svg)](https://auto.suzuki.com.ph/pages/suzuki-carry-for-your-business)

[![Suzuki_Carry-Topics-Page-Homepage-Thumbnail_1694866180310](https://auto.suzuki.com.ph/_next/image?url=https%3A%2F%2Fd1shbjc4qnoh7j.cloudfront.net%2Fall-page%2Ffeature-images%2Fdesk-thumb%2FCarry-Topics-Page-Homepage-Thumbnail_1694866180310.jpg&w=1920&q=75)](https://auto.suzuki.com.ph/pages/suzuki-carry-solves-logistics-ph-startups)

The Suzuki Carry is designed to address the various logistical challenges 21st-century Filipino companies face. What makes Suzuki Carry special is its range. Let’s explore what each one does best for Pinoy startups.

...Read More

[See Details \\
![Click for Next page](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/blue-arrow.svg)](https://auto.suzuki.com.ph/pages/suzuki-carry-solves-logistics-ph-startups)

[![Suzuki_SPH_Carry_SEOArticle_28JUNE24_thumbnail_1723432928859](https://auto.suzuki.com.ph/_next/image?url=https%3A%2F%2Fd1shbjc4qnoh7j.cloudfront.net%2Fcontents%2Fall-page%2Ffeature-images%2Fdesk-thumb%2FSPH_Carry_SEOArticle_28JUNE24_thumbnail_1723432928859.jpg&w=1920&q=75)](https://auto.suzuki.com.ph/pages/suzuki-carry-powers-philippine-businesses)

Discover how the Suzuki Carry, with its robust design and versatile variants, drives business success across the Philippines, from urban deliveries to rural transport.

...Read More

[See Details \\
![Click for Next page](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/blue-arrow.svg)](https://auto.suzuki.com.ph/pages/suzuki-carry-powers-philippine-businesses)

## Frequently asked questions

## 1What body variants are available for the Suzuki Carry to suit different business needs?

![Expand](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/faq-page/plusAcc.svg)

## 2What is the maximum payload capacity and bed features of the Suzuki Carry Dropside?

![Expand](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/faq-page/plusAcc.svg)

## 3What is the fuel efficiency and engine capacity of the Suzuki Carry?

![Expand](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/faq-page/plusAcc.svg)

## 4What engine and transmission power the Suzuki Carry?

![Expand](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/faq-page/plusAcc.svg)

Further Questions
![Click for Next page](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/faq-page/accordionArrow.svg)

* * *

- ![Find a Dealer](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/floatbar/findDealer.svg)

Dealers
Dealers
- ![Book a test drive](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/floatbar/testDrive.svg)

Test Drive
Test Drive
- ![Downlaod the Brochure](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/floatbar/brochure.svg)

Brochure
Brochure
- ![Submit an enquiry](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/floatbar/enquiredark.svg)

Inquire
Inquire

![CORSeal](https://d1shbjc4qnoh7j.cloudfront.net/assets/images/CORSeal.png)

This website uses cookies to enable it to perform properly, remember your browsing history and to arrange contents that will match your preferred interests more efficiently. The details of the cookies that Suzuki Philippines Incorporated (SPH) use can be found on our [Data Privacy Notice](https://auto.suzuki.com.ph/pages/Data-Privacy-Notice). By clicking the Accept button, closing this banner, scrolling this page or clicking any part of it, you agree to our use of cookies.

Accept