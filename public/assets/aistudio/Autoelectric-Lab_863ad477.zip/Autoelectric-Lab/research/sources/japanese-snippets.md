# Japanese OEM technical-information source snippets

Search date for all entries: 2026-11-11. Search snippets preserved as evidence; publication dates were not stated in the search result unless otherwise noted. Snippet-only evidence supports only claims expressed in the excerpt, not claims about technical content below the search result.

## Nissan

### Nissan Navara Owner Manual 2022 I Nissan Motor (Thailand)
URL: https://en.nissan.co.th/content/dam/Nissan/th/owners/OwnerManual-22MY/D23-A_OM21E00D23G1T_WEB_English.pdf
Publication date: title indicates model year 2022; actual publication date not stated. Search retrieved: 2026-11-11.
Snippet: “Your NISSAN dealer knows your vehicle best. When you require any service or have any questions, we will be glad to assist you with the extensive resources available for you.”

### NISSAN TERRA Owner Manual I Nissan Motor (Thailand)
URL: https://en.nissan.co.th/content/dam/Nissan/th/owners/OwnerManual-170612/Terra%20Owner%20Manual%20EN.pdf
Publication date: not stated; search retrieved 2026-11-11.
Snippet: “Your NISSAN dealer knows your vehicle best. When you require any service or have any questions, we will be glad to assist you with the extensive resources available for you.”

### Owner Manual for NISSAN ALMERA 2024
URL: https://www-asia.nissan-cdn.net/content/dam/Nissan/th/owners/tag/owner-manual/almera/en/OM23E00N18G0T.pdf
Publication date: title indicates 2024; actual publication date not stated. Search retrieved: 2026-11-11.
Snippet: “Please read through this manual before operating your vehicle.” (Official Nissan Thailand/Asia manual result; snippet establishes owner-manual lead, not Philippine trim applicability or service wiring coverage.)

## Honda

### Honda Independent Repair Website User’s Guide (American Honda Service Express)
URL: https://techinfo.honda.com/rjanisis/pubs/web/SvcExp_QS_CHE.pdf
Publication date: 2013 indicated by document identifier AJA 49496 (0513); search retrieved 2026-11-11.
Snippet: “Service Express is American Honda’s Web-based system for delivering electronic service publications to the aftermarket. In Service Express, technicians have access to the same service information available to Honda dealers.”

### HONDA_CITY_DECEMBER_BROCHURE_2024 (Honda Cars Philippines)
URL: https://www.hondaphil.com/app/default/files-module/local/car_brochures/HONDA_CITY_DECEMBER_BROCHURE_2024.pdf
Publication date: December 2024 indicated in title; search retrieved 2026-11-11.
Snippet: “Honda Cars Philippines Inc. reserves the right to change or modify equipment or specifications any time without prior notice. Details, colors, descriptions, and illustrations are for information purposes only. Specifications or equipment may vary in some countries...”

## Suzuki

### Suzuki Automobile Philippines | Book a Service
URL: https://auto.suzuki.com.ph/pages/book-a-service
Publication date: not stated; search retrieved 2026-11-11.
Snippet: “BOOK A SERVICE. Keep your Suzuki running at its best. Schedule online with our expert technicians...”

### Suzuki Philippines | Auto Service & Maintenance
URL: https://auto.suzuki.com.ph/pages/SERVICE-and-MAINTENANCE
Publication date: not stated; search retrieved 2026-11-11.
Snippet: “Services / Book Service / Basic Warranty Coverage / Service Promo / Customer Care / Shop Genuine Parts.”

### Suzuki Ertiga Service, Repair and Workshop Manuals (With Wiring Diagrams) | PDF (Scribd user upload)
URL: https://www.scribd.com/document/618463996/Suzuki-Ertiga-Service-Repair-and-Workshop-Manuals-With-Wiring-Diagrams
Publication date: not stated; search retrieved 2026-11-11.
Snippet: “The Suzuki Ertiga Service & Repair Manual provides the information needed to properly service and maintain a Suzuki Ertiga... Uploaded by Hendra Hilmawan.” This is an unattributed third-party upload and is not acceptable for pin truth or verification of OEM licensing.


### Honda Cars Philippines › FAQs
URL: https://www.hondaphil.com/faq
Publication date: not stated; search retrieved 2026-11-11.
Snippet: “It is advised that customers first call their respective dealers or Honda Cars Philippines hotline for an appointment...” (The search result excerpt discusses service appointments, not repair publications.)

### Honda Cars Philippines › Service FAQ
URL: https://www.hondaphil.com/virtual-honda/faq
Publication date: not stated; search retrieved 2026-11-11.
Snippet: “Visit our website's Recall Information page and input your vehicle's Chassis/VIN number at the Search box. It will tell you if your vehicle is affected or not.” (Search result excerpt concerns recalls, not workshop wiring access.)

### Suzuki Car Repair & Maintenance Services in the Philippines
URL: https://auto.suzuki.com.ph/service?product_id=69
Publication date: not stated; search retrieved 2026-11-11.
Snippet: “Keep your Suzuki running smoothly with expert maintenance and repairs at Suzuki service centers in the Philippines. Our authorized workshops cater to all models, including Ertiga & XL7 Hybrid, Jimny, S-etc. Book your service today!”

### Suzuki Philippines - Help Desk & Customer Service Solutions
URL: https://auto.suzuki.com.ph/pages/hotline
Publication date: not stated; search retrieved 2026-11-11.
Snippet: “SUZUKI CUSTOMER CARE HOTLINE / Connect with Suzuki Customer Care Hotline...”
