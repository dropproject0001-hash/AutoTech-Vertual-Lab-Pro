Source: https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/index.html?v=1676465645
Title: Abrites ECU Programming Tool HTML
Fetched: 2026-11-11T10:09:22.752Z

![loading...](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/loading.gif)

- ![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_40917.png)













Abrites ENGINE CONTROL UNIT Programming Tool







![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19961.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19962.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19963.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19976.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19977.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19979.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19967.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19974.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19977.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19978.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19971.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19972.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19973.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19974.png)



![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19976.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19977.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19978.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19979.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19980.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19981.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19982.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19983.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19984.png)



![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19987.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19988.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19989.png)![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19995.png)



![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19995.png)







![Polygon](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_19995.png)









User manual







version 4.2











www.abrites.com











www.abrites.com



![GraphicLine](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_40688.png)



Abrites



ENGINE CONTROL UNIT



Programming Tool







2026

- www.abrites.com







































Important notes



















Warranty











The Abrites software and hardware products are developed, designed and manufactured by Abrites Ltd. During the production process we comply to all safety and quality regulations and standards, aiming at highest production quality. The Abrites hardware and software products are designed to build a coherent ecosystem, which effectively solves a wide range of vehicle-related tasks, such as:









  - Diagnostic scanning;

  - Key programming;
  - Module replacement,
  - ECU programming;
  - Configuration and coding.

All software and hardware products by Abrites Ltd. are copyrighted. Permission is granted to copy Abrites software files for your own back-up purposes only. Should you wish to copy this manual or parts of it, you are granted permission only in case it is used with Abrites products, has “Abrites Ltd.” written on all copies, and is used for actions that comply to respective local law and regulations.

You, as a purchaser of Abrites hardware products, are entitled of a two-year warranty. If the hardware product you have purchased has been properly connected, and used according to its respective instructions, it should function correctly. In case the product does not function as expected, you are able to claim warranty within the stated terms. Abrites Ltd. is entitled to require evidence of the defect or malfunction, upon which the decision to repair or substitute the product shall be made.

There are certain conditions, upon which the warranty cannot be applied. The warranty shall not apply to damages and defects caused by natural disaster, misuse, improper use, unusual use, negligence, failure to observe the instructions for use issued by Abrites, modifications of the device, repair works performed by unauthorized persons. For example, when the damage of the hardware has occurred due to incompatible electricity supply, mechanical or water damage, as well as fire, flood or thunder storm, the warranty does not apply.

Each warranty claim is inspected individually by our team and the decision is based upon thorough case consideration.

Read the full hardware warranty terms on our [website.](http://abrites.com/)

Abrites ENGINE CONTROL UNIT Programming Tool

2026

2

- www.abrites.com











































Copyright information























Safety information











Copyright:









  - All material herein is Copyrighted ©2005-2021 Abrites, Ltd.

  - Abrites software, hardware, and firmware are also copyrighted
  - Users are given permission to copy any part of this manual provided that the copy is used with Abrites products and the “Copyright © Abrites, Ltd.” statement remains on all copies
  - “Abrites” as used in this manual synonymous with “Abrites, Ltd.” And all it’s affiliates
  - The “Abrites” logo is a registered trademark of Abrites, Ltd.

Notices:

  - The information contained in this document is subject to change without prior notice. Abrites shall not be held liable for technical/editorial errors, or omissions herein.
  - Warranties for Abrites products and services are set forth in the express written warranty statements accompanying the product. Nothing herein should be construed as constituting any additional warranty.
  - Abrites assumes no responsibility for any damage resulting from the use, misuse, or negligent use of the hardware or any software application.

The Abrites products are to be used by trained and experienced users in diagnostics and reprogramming of vehicles and equipment. The user is assumed to have a good understanding of vehicle electronic systems, as well as potential hazards while working around vehicles. There are numerous safety situations that cannot be foreseen, thus we recommend that the user read and follow all safety messages in the available manual, on all equipment they use, including vehicle manuals, as well as internal shop documents and operating procedures.

Some important points:

Block all wheels of the vehicle when testing. Be cautious when working around electricity.

  - Do not ignore the risk of shock from vehicle and building-level voltages.
  - Do not smoke, or allow sparks/flame near any part of the vehicle fuel system or batteries.
  - Always work in an adequately ventilated area, vehicle exhaust fumes should be directed towards the exit of the shop.
  - Do not use this product where fuel, fuel vapours, or other combustibles could ignite.

In case any technical difficulties occur, please contact the

Abrites Support Team by email at [support@abrites.com.](mailto:support%40abrites.com?subject=)

Abrites ENGINE CONTROL UNIT Programming Tool

2026

3

- Table of contents













www.abrites.com







![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_28382.png)













Abrites ENGINE CONTROL UNIT Programming Tool













2026









4









1\. Introduction



1.1 Latest Updates



1.2 Lienses information



2\. Using the Abrites ECU Programming Tool



2.1 Connection to the ECU using ZN151 Distribution box:



2.2 Using the CB401 cable from the ZN151 set



2.3 Using the CB403 DS-BOX Extended Cable Set



2.4 CB023



2.5 CB030



3\. DIAG



4\. Bench



4.1 Supported units for bench reading:



5\. BSL



6\. ZN051 (Distribution Box) connections



7\. Wiring diagrams



8\. ECU Connections - PIN OUT Diagrams and Boot



9\. TCU Connections



9.1 ZF 8HP



9.2 Mercedes VGSNAG3 9G-tronic



9.3 Mercedes VGSNAG2-FDCT



9.4 Mercedes Getrag 7DCT300



10\. ZF 8HP Virgin - Adapt for BMW



10.1 ZF 8HP BMW Make Virgin



10.2 ZF8HP ISN Read/Update



10.3 ZF 8HP BMW Adaptation

- Table of contents













www.abrites.com







![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_28382.png)













Abrites ENGINE CONTROL UNIT Programming Tool













2026









5









11\. DQxxx TCU On-Bench Pinout’s



12\. Appendix



12.1 Mercedes CEPC unit reading by OBDII

- www.abrites.com

























Abrites ENGINE CONTROL UNIT Programming Tool

























List of revisions



































































































































































































Date







Chapter







Description







Revision







2026









February 2019











September 2019











October 2019











October 2019











February 2020











March 2020











June/July 2020











August 2021











06.12.2022











Manual created











ECU diagrams added











Connecting ZN051











Wiring diagrams added











Boot diagrams update











Wiring diagrams update











Wiring diagrams update











Wiring diagrams update











New Sections created











ALL











ALL











3











2











2











2











ALL











ALL











1.1 & 1.2











1.0











2.0











2.1











2.2











2.3











2.4











3.4











3.9











3.9











08.02.2023











General Structural Revision











ALL











4.0











08.02.2023











MD/MG, VGSNAG2-FDCT, VGSNAG3 9G-tronic, DQ381,

ZF8HP; ZF 8HP Virgin/Adapt











4, 7, 8











4.0











21.12.2023











General updates, diagrams, CB030, CB403











ALL











4.1











12.05.2026











DQxxx On-Bench Pinout’s











11











6











4.2

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







﻿1\. Introduction









7









The Abrites Engine control unit programming tool is developed to unite all ECU reading/writing functionalities of our company under one software for cars, trucks, buses, bikes, boats, industrial and farming equipment.









Using it you will be able to read and write EEPROM (Data Flash), read/write Program flash, read/write ECM Maps, SPI Memories, and Adblue units, via DIAGNOSTICS, BOOT mode and on BENCH using a direct connection to the ECU.









The tool works in conjunction with the Abrites ZN151 distribution box, in order to assure reading and writing to the ECU (bench and boot mode).









We can easily read and write the EEPROM(DATA FLASH), internal flash/external flash (PROGRAM FLASH), ECM Maps, save them and keep them for later use. We can also easily write them to other ECUs, which makes it a helpful tool for units replacement. This is great for mechanical and electronic workshops, engine tuners and locksmiths.









FULL BOOT MODE AND BENCH SOLUTION FOR ALL AVAILABLE BRANDS.









This software works perfectly with the help of the Abrites ZN151 Distribution box.

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026









8









The ECU Programming Tool includes ECUs from the following brands:



  - BMW - BOSCH, SIEMENS
  - KIA/ HYUNDAI -BOSCH, CONTINENTAL, DELPHI, KEFICO
  - MERCEDES - BOSCH, CONTINENTAL, DELPHI
  - MINI - BOSCH
  - PORSCHE - BOSCH
  - PEUGEOT/ CITROEN - BOSCH
  - RENAULT - BOSCH
  - VAG - BOSCH
  - CHEVROLET - SIEMENS
  - FORD - CONTINENTAL, DELPHI, BOSCH
  - SSANGYUONG - SIEMENS
  - SUBARU - BOSCH
  - TOYOTA - BOSCH, DENSO
  - AGRIFAC - BOSCH
  - ARTEC - BOSCH
  - CASE - BOSCH
  - CLAAS - BOSCH
  - DEUTZ - BOSCH
  - Mercedes-Benz Trucks
  - Mercedes-Benz Buses
  - Akia Busses
  - Bell Equipment
  - Fendt
  - JCB
  - Krone
  - Magni
  - Manitou
  - Morelo Buses
  - Ponsse
  - Sterling
  - Western Star

  - Continental MCM, MCM02T, MCM2.1
  - Adblue control modules ACM, ACM2.0, ACM2.1, ACM2.2

A full list of supported ECUs could be found here:

https://abrites.com/page/ecu

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







1. Read/Program Application, Maps and SPI EEPROM of engine control units Continental

  - MCM
  - MCM02T
  - MCM2.1

2. Adblue control modules by OBDII and direct connection on bench

  - ACM
  - ACM2.0
  - ACM2.1
  - ACM2.2

3. Checksum alignment while programming

4. Option for full PFLASH/DFLASH/SPIEEPROM backup of the these modules:

  - Mercedes-Benz Trucks
  - Mercedes-Benz Buses
  - Akia Busses
  - Bell Equipment
  - Claas
  - Fendt
  - JCB
  - Krone
  - Magni
  - Manitou
  - Morelo Buses
  - Ponsse
  - Sterling
  - Western Star

5. Read/update ECU and TCU units on bench:

ECU

  - Bosch MG/MD TC2xx - use CB023 – BMW MD/MG ECU Connection Cable
  - Bosch MG1/MD1 SPC - use CB030 - Mercedes-Benz MD/MG ECU connection cable or the CB403

TCU

  - Bosch TCU ZF 8HP - use ZN079
  - MB VGSNAG2-FDCT
  - MB VAGBAG3 9G-tronic

9

﻿1.1 Latest Updates

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







EP001 \- full reading/writing/updating and checksum correction of Dflash, Internal/External Pflash and Map Files of Engine Control Units by bench (direct connection), boot mode and diagnostics (OBDII). Virtual reading of Flash, Maps and Bootloader.



Supported ECUs:



  - Bosch EDC17/MED17
  - Delphi
  - Continental/Siemens SIMxx
  - Kefico

EP003 \- full reading/writing/updating of PFlash, DFlash and Maps, as well as checksum correction of MD/MG Engine Control Units and VGS2-FDCT/ZF 8HP/DQ381 Transmission Control Units on bench.

The procedures allow exchanging these modules in a wide selection of vehicles.

Supported ECUs:

  - MD/MD1 with SPCxxx and TC2xx
  - MG/MG1 with SPCxxx and TC2xx

Supported TCUs:

  - VGSNAG3 9G-tronic
  - VGS2-FDCT
  - ZF 8HP
  - DQ381
  - Getrag 7DCT300

EP005 \- performing procedures on Engine Control Units and AdBlue modules in trucks, motorbikes, boats and industrial vehicles (heavy-duty, tractors, agricultural machines) by diagnostics (OBDII).

Main functionalities:

Reading and programming Application, Maps and SPI EEPROM of Engine Control Units and AdbBlue Control Modules by OBDII (and direct connection on bench)

Option for full reading PFLASH/DFLASH/SPI EEPROM for full backup of ECUs and ACMs

Checksum alignment while programming these modules

Supported brands (full list in Compatibility tab in Abrites Online store/EP005):

Mercedes-Benz Trucks

Mercedes-Benz Buses

Akia Busses

Artec

Atlas

Bell Equipment

Berthoud

Claas

DAF

Daewoo

10

﻿1.2 Lienses information

- www.abrites.com

























Abrites ENGINE CONTROL UNIT Programming Tool









2026









11









Detroit



Deutz



Dong Feng



Doosan



Ducati



Fendt



Ford



Freightliner



Hino



Hurlimann



Hyundai



Iveco



JCB



Claas



Kenworth



Kramer



Kubota



Krone



Magni



MAN



Manitou



Maxforce



Mitsubishi



Morelo Buses



New Holand



Peterbuilt



Ponsse



Sterling



Storti



Temsa



Tetra



Tigercat



Western Star



And many more!









Supported ECUs (full list in Compatibility tab in Abrites Online store/EP005):



Bosch



Delphi



Continental/Siemens

- www.abrites.com

































Abrites ENGINE CONTROL UNIT Programming Tool









2026







﻿2\. Using the Abrites ECU Programming Tool







The Abrites engine control unit programming tool will allow you to to read or write Electronic Control Unis (ECUs) and Transmission Control Units (TCUs), having the following options:









  - Diag - used for reading/writing the ECU via diagnostics (via OBDII or using a direct connection)


  - Bench \- used for reading/writing the ECU or TCU on bench with direct connection to the unit using the ZN151 Abrites Distribution Box.

  - BSL \- used for reading/writing the ECU via BOOT mode using the ZN151 Abrites Distribution Box


IMPORTANT: In order to use the ECU programming tool the AMS should be active and the hardware update should be performed at least once a month. For more information please open the Abrites Common User Manual.

![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_31605.jpg)

12

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50487.png)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50486.png)



﻿2.1 Connection to the ECU using ZN151 Distribution box:









1\. Connect the CB402 cable to your AVDI on the dedicated side and to your AVDI on the other.







3\. Power up the DS Box with the use of [ZN074 - ECU reading set](https://abrites.com/products/zn074) and the 2 dedicated power and tround plugs. The ZN074 set is developed and designed by the Abrites Team to aid you in ECU reading and writing procedures on bench. It is designed to work together with ZN151 Distribution Box and cannot be used individually









13





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50490.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026









14





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50491.png)



﻿2.2 Using the CB401 cable from the ZN151 set









Connect the CB401 cable to the DB15 port of your DS box and use the PIN OUT diagrams to connect the the CB401 cable to the ECU connectors as per the diagrams in this manual. Always start with connecting GND first.









Details about the connection of CB401 in section 7 Wiring Diagrams.

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







﻿2.3 Using the CB403 DS-BOX Extended Cable Set









CB403 is an improved version of the CB401, part of the ZN151 ABRITES Distribution Box. It is designed to help with modern connectors of different units, which are not covered by CB401.









The CB403 cable is developed for working on modules, for example ECUs, TCUs, and others, on bench using the ZN151 Distribution Box. It has multiple connectors for establishing direct connection with a wide range of modules in trucks, buses, heavy-duty and passenger vehicles to read, write, virginise, personalise, update them and more!









Functionalities:



Direct connection with automotive modules in passenger vehicles, trucks, buses, and heavy-duty machinery















15





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_59084.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026









16









1\. Main cable 70 cm long, which is equipped on one side with HD15 connector (with all pins wired) and round hole terminals on the other side. - 1 piece.



HD15 pinout, wire color and designation:









1 - pink - “IGN”

2 - yellow and yellow/white - “B+” (on both wires)

3 - red/blue - “K-LINE 1”

4 - purple - “BOOT 2”

5 - white - “BOOT 1”

6 - green - “T2”

7 - brown - “T1”

8 - red - “CAN H”

9 - green/white - “T3”

10 - green/brown - “T4”

11 - black - “GND”

12 - gray - “GND”

13 - yellow/brown - “B+ PERMANENT”

14 - blue - “CAN L”

15 - grey/pink - “K-LINE 7”

2\. Connectors:

Splitter adapter - 1 male to 3 female with round terminals - 4 pcs.

Note:

all the tips described below have a male round terminal on one side to connect to the main cable with the HD15 connector.

3\. Tip with gray wire and length 20 cm:

crocodile tip - 4 pcs.

small terminal tip - 2 pcs.

middle terminal tip - 2 pcs.

NO terminal - 2 pcs.

4\. Tip with a red wire and a length of 20 cm:

small terminal tip - 1 pc.

middle terminal tip - 1 pc.

5\. Tip with a blue color and a length of 20 cm:

small terminal tip - 1 pc.

middle terminal tip - 1 pc.

- www.abrites.com

























Abrites ENGINE CONTROL UNIT Programming Tool









2026









17









6\. Tip with brown wire and length 20 cm:



small terminal tip - 1 pc.



middle terminal tip - 1 pc.









7\. Tip with green wire and length 20 cm:



small terminal tip - 1 pc.



middle terminal tip - 1 pc.









8\. Tip with an orange wire and a length of 20 cm:



small terminal tip - 2 pcs.



middle terminal tip - 1 pc.









9\. Tip with a black wire and a length of 20 cm:



small terminal tip - 1 pc.



middle terminal tip - 2 pcs.



large terminal tip - 1 pc.









10\. Tip with a yellow wire and a length of 20 cm:



small terminal tip - 1 pc.



middle terminal tip - 2 pcs.



large terminal tip - 1 pc.









11\. Tip with gray color and length 30 cm:



NO terminal - 1 pc.









12\. Tip with purple color and a length of 30 cm:



NO terminal - 1 pc.

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







﻿2.4 CB023









  - CB023 – BMW MD/MG ECU Connection Cable

For direct connection on bench with the engine control units from BOSCH types MD1, MG1 in BMW vehicles used for reading and updating FLASH/DFLASH. EP003 licesnse required

18

![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_55658.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







﻿2.5 CB030









The CB030 cable is intended for bench connection with the Engine Control Units from BOSCH types MD1 and MG1 (MRD1, MRG1) in Mercedes-Benz vehicles. The cable set is use for diagnostic purposes on bench, and FLASH/DFLASH programming using the Abrites ECU Programming Tool and EP003 license.









Supported Units:



BOSCH MD1 and MG1 Engine Control Units









Connection types:



Connect CB030 directly to AVDI - connect the DB25 connector of the CB030 to the AVDI, and the DB15 connector of the CB030 to the black DB15 adapter with switch for ignition. This adapter is then connected to a 12V power supply via DC connector



Connect CB030 to AVDI and ZN151 DS Box - connect DB25 connector and DB15 connector of CB030 to DS-BOX. Power supply should be provided to the ZN151’s dedicated slots.



ZN074 can be used for providing power supply in both cases.









The CB030 has two identical connectors with different pinouts and are labled for MG and MD ECUs..









N.B. To avoid damage or malfunction to the ECU or your AVDI, make sure you use the correct type of connector for the ECU you are working with!









19





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_55657.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_59338.png)





20





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_59339.png)



Connect CB030 directly to AVDI - connect the DB25 connector of the CB030 to the AVDI, and the DB15 connector of the CB030 to the black DB15 adapter with switch for ignition. This adapter is then connected to a 12V power supply via DC connector.







Connect CB030 to AVDI and ZN151 DS Box - connect DB25 connector and DB15 connector of CB030 to DS-BOX. Power supply should be provided to the ZN151’s dedicated slots. ZN151 DS Box is connected to AVDI via CB402.

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50504.png)



The option DIAG is used to read/write the ECU via diagnostics through the OBDII port of the car.



It allows you to read and write the ECM Maps, Internal/External Flash, Data flash.



It allows you also to perform both real and virtual read of the memory.









Select Diag and the car brand you want to work on:













21













﻿3\. DIAG

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50528.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50527.jpg)



Select the ECU brand you want to work on:







Select the memory type you want to read/write followed by Info, Read or Write.













22

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50582.png)



The option Bench is used to read/write the ECU/TCU with direct connection to he unit using the Abrites ZN051 Distribution box without opening the ECU/TCU.









It allows you to read and write both Internal/External Program Flash and Data flash.









IMPORTANT: Some ECUs could be read on bench using a Distribution BOX version 2.3 and ZN065 adapter or Distribution box version 2.4 only as they require the PWMs to be powered up with 5V, instead of the usual 3.3V.



For more information please contact [sales@abrites.com](http://sales@abrites.com/).









Select Bench and select the type of unit you want to be working with:













23













﻿4\. Bench

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50600.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50599.jpg)



Select TC17xx Internal Flash, TC17xx External Flash or TC17xx data Flash, followed by Info, Read or Write. The software will automatically detect the type of the tricore processor:













24

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026









25









﻿4.1 Supported units for bench reading:









ECU



  - Bosch MEDC17 TC17xx
  - Bosch MG/MD TC2xx - use CB023 – BMW MD/MG ECU Connection Cable
  - Bosch MG1/MD1 SPC - use CB030 - Mercedes-Benz MD/MG ECU connection cable or the CB403

TCU

  - Bosch TCU ZF 8HP - use ZN079
  - MB VGSNAG2-FDCT
  - MB VAGBAG3 9G-tronic

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50614.png)



The option BSL is used to read/write the ECU via BOOT mode using the Abrites ZN151 Distribution box.



It allows you to read and write the Internal/External/Program Flash and Data flash.









Select BSL and select the ECU brand you are working on:













26













﻿5\. BSL

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50621.jpg)



NB! The ECUs until TPROT8(until 2010/2011) don’t require a connection through the Abrites ZN151 Distribution box so if you do not have one, please follow this diagram when reading/writing it:









NB! It is very important to start with wiring the GND before all other cables to the ECU. This minimises the risk of damage to the unit.







NB! It is very important to start with wiring the GND before all other cables to the ECU. This minimises the risk of damage to the unit.













27

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50637.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50636.jpg)



Select the processor type of the ECU:







Select Internal Flash/External/Program Flash or Data flash followed by Info, Read or Write:













28

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50647.jpg)



Connecting your ZN151 (Distribution Box) in order to operate the Abrites ECU PROGRAMMING software







In order for your ECU PROGRAMMING software to be fully operational it requires a ZN151 (Distribution Box). The following are the pest practice steps we recommend everyone who wants to use the Abrites ECU PROGRAMMING tool to its full potential.









1\. Please connect the distribution box to your AVDI and connect the AVDI to your personal computer where you have your AVDI software installed.



2\. Please make sure you always have the latest possible version of the software. If in doubt about what the latest version is please check the news section on the abrites.com website where the news are always up to date. The same location will give you additional instructions should there be any specific additional change to the operation of the ECU PROGRAMMING software.



3\. Once your AVDI and distribution box are connected you need to make sure what type of reading you are planning to do. Always start with connecting GND when establishing connection to the unit.The normal procedure would go in the following steps:









  - Try to read the ECU you plan on working on via the OBD. If this fails (not common):
  - Try the so called bench mode of reading, connecting to the ECU’s pins only from the outside without opening the ECU and soldering a BOOT pin. This method is described in details in section 4.

29

﻿6\. ZN051 (Distribution Box) connections

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50711.jpg)



  - Should this method also fail then you can move to boot mode reading where you will be required to open the ECU and solder a boot pin to the designated internal position as per the diagrams in this manual.

4\. Bench mode method of reading an ECU. Commonly known as “BENCH” method or table connection depending on your region.

This method is extremely popular in today’s diagnostic ecosystem. Most of our colleagues who work on engine control unit replacement and automotive tuning, as well as those who work with key programming often use this method. It is common and relatively easy to apply to ECUs on almost every contemporary ECU especially the very common EDC17 Tricore type built by Bosch. When you start using the ECU PROGRAMMING tool together with the distribution box to read an ECU via BSL mode you need to make sure that you have the DB15 splitter cable supplied with your ZN151 set connected to your distribution box.

N.B! Please note that there are two distinct types of DB15 cables (the type of ZN151 v. 2.0, 2.1 and 2.2 is different when compared to v.2.3). Please note that this instructions manual is written specifically for the type of DB15 which comes with the v.2.3 distribution box. If your distribution box has been upgraded via the Abrites return upgrade program you probably have the older type of DB15 cables.

This means that the colours in the manual do not match the cable you have. If this is the case please make sure to follow the labeling on the DB15 cable when connecting to an ECU. You can easily tell the two types apart as the picture below shows:

When reading an ECU in “Bench connection” mode please note that you can supply the distribution box with 12V from a desk type power supply or any reliable source of 12V. For this purpose your ZN151 distribution box is equipped with a set of cables which can be connected using the standard connectors on both ends. One end goes to the power source and the other - straight into the distribution box positive and negative sockets. Thus your ECU will be supplied with 12V so as to enable the ECU PROGRAMMING software to communicate with it.

30

- www.abrites.com

































Abrites ENGINE CONTROL UNIT Programming Tool









2026









31









N.B.! Please make sure to follow these steps when working on “BENCH”:









  - AVDI connected to PC
  - ZN151 connected to AVDI

N.B! Please be informed the DB15 cable that is part of the Distribution Box set needs to be disconnected from the power supply during the wiring process of the unit.

Please use the pinouts supplied in this manual to connect the DB15 to the ECU, then connect the DB15 to the distribution box and then supply the distribution box with the external 12V from your power source.

VERY IMPORTANT: The 5V supplied to the ECU by the AVDI WILL NOT be enough for the ECU to operate.

5\. BSL (bootstrap loader - [https://en.wikipedia.org/wiki/Bootstrapping](https://en.wikipedia.org/wiki/Bootstrapping)

If the above methods fail you will need to open the ECU and solder a “boot pin” to the ECU’s designated location as per the diagrams. ZN151 distribution box and the DB15 supplied in the set include a boot pin as well as a full set of resistors which will also be required. Every diagram shows the resistor requirements as well as the exact location. Please be EXTREMELY CAUTIOUS when using this method and make sure all your wiring is 100% before attempting boot reading.

- www.abrites.com

































Abrites ENGINE CONTROL UNIT Programming Tool









2026







In the Wiring Diagrams section you will find the connection methods for wiring the ECUs on bench by either using bench or boot mode. ECUs that don’t allow to be read by the bench method (this method excludes boot mode), need to be opened and read by boot mode.









CB403









1\. Main cable 70 cm long, which is equipped on one side with HD15 connector (with all pins wired) and round hole terminals on the other side. - 1 piece.



HD15 pinout, wire color and designation:









Pink - “IGN”



Yellow and Yellow/White - “B+” (on both wires)



Red/Blue - “K-LINE 1”



Purple - “BOOT 2”



White - “BOOT 1”



Green - “T2”



Brown - “T1”



Red - “CAN H”



Green/White - “T3”



Green/Brown - “T4”



Black - “GND”



Gray - “GND”



Yellow/Brown - “B+ PERMANENT”



Blue - “CAN L”



Grey/Pink - “K-LINE 7”









2\. Connectors:



Splitter adapter - 1 male to 3 female with round terminals - 4 pcs.



Note:



all the tips described below have a male round terminal on one side to connect to the main cable with the HD15 connector.









3\. Tip with gray wire and length 20 cm:



crocodile tip - 4 pcs.



small terminal tip - 2 pcs.



middle terminal tip - 2 pcs.



NO terminal - 2 pcs.









4\. Tip with a red wire and a length of 20 cm:









32









﻿7\. Wiring diagrams

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026









33









small terminal tip - 1 pc.



middle terminal tip - 1 pc.









5\. Tip with a blue color and a length of 20 cm:



small terminal tip - 1 pc.



middle terminal tip - 1 pc.









6\. Tip with brown wire and length 20 cm:



small terminal tip - 1 pc.



middle terminal tip - 1 pc.









7\. Tip with green wire and length 20 cm:



small terminal tip - 1 pc.



middle terminal tip - 1 pc.









8\. Tip with an orange wire and a length of 20 cm:



small terminal tip - 2 pcs.



middle terminal tip - 1 pc.









9\. Tip with a black wire and a length of 20 cm:



small terminal tip - 1 pc.



middle terminal tip - 2 pcs.



large terminal tip - 1 pc.









10\. Tip with a yellow wire and a length of 20 cm:



small terminal tip - 1 pc.



middle terminal tip - 2 pcs.



large terminal tip - 1 pc.









11\. Tip with gray color and length 30 cm:



NO terminal - 1 pc.









12\. Tip with purple color and a length of 30 cm:



NO terminal - 1 pc.

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026









34









CB401 DB15 cable Legend:



Power - Yellow (B+)



IGN - Orange (IGN)



GND - Black (GND)



CAN HI - Red (CAN6)



CAN LOW - Blue (CAN14)



T1 - Brown (T1)



T2 - Green (T2)



Boot - White









N.B! ZN151 Distribution Box with version 2.2 or lower has a DB15 cable that uses different colors from ZN151 v2.3 or higher. The legend for ZN151 v2.2 or lower uses the following colors found in the legend below:









Old DB15 cable Legend:



Power \- Yellow (B+)



IGN - Yellow/PINK (IGN)



GND - Black (GND)



CAN HI - Red (CAN6)



CAN LOW - Blue (CAN14)



T1 - Green/Brown (T1)



T2 - Green (T2)



Boot - White

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50771.png)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50770.jpg)









BOSCH EDC17CP01 and CR6.11 TC1796 - Mercedes-Benz:







BSL connection:













35













﻿8\. ECU Connections - PIN OUT Diagrams and Boot

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50794.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50793.jpg)



BOSCH EDC17CP02 TC1766 - BMW:







BSL connection:













36

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50820.png)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50819.png)



BOSCH EDC17CP04 TC1796 - Audi, Volkswagen:







BSL connection:













37

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50843.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50842.jpg)



BOSCH EDC17CP07 TC1766 - Toyota:







BOSCH EDC17CP09 TC1766 and TC1796 - BMW:







BOSCH EDC17CP10 TC1796 - Mercedes-Benz:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_42181.jpg)













38

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50897.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50896.jpg)



BOSCH EDC17CP11 TC1796 - Jaguar, Land Rover, Renault:







BSL connection:













39

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50918.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50917.jpg)



BOSCH EDC17CP14 TC1796 - Hyundai, Volksvagen, Linde, Jungheinrich, Skoda, Seat, Porsche, KIA, Audi







BSL connection:













40

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50940.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50939.jpg)



BOSCH EDC17CP16 TC1792 - Honda:







BSL connection:













41

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50956.jpg)



BOSCH EDC17CP18 TC1796 - GMC, Chevrolet:













42

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50979.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_50978.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_42418.jpg)



BOSCH EDC17CP20 TC1796 - Audi, Volkswagen, Hako:







BOSCH EDC17CP19 TC1766 - Renault, Saab:







BSL connection:













43

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51008.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51007.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_42585.jpg)



BOSCH EDC17CP24 TC1796 - Audi, Volkswagen:







BOSCH EDC17CP22 TC1796 - Volvo:







BSL connection:













44

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51030.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51029.jpg)



BOSCH EDC17CP37 TC1766 - Toyota:







BSL connection:













45

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51056.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51054.jpg)



BOSCH EDC17CP42 TC1797 - Dacia, Ford, Jaguar, Land Rover, Mercedes-Benz, Nissan, Renault, Renault trucks:







BSL connection:













46

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51079.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51077.jpg)



BOSCH EDC17CP44 TC1797 - Volkswagen, Audi, Porsche:







BSL connection:













47

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51093.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51092.jpg)



BOSCH EDC17CP45 TC1796 & TC1797 - BMW:







BSL connection:













48

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51157.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51156.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_42897.jpg)



BOSCH EDC17CP47 TC1797 - Opel:







BOSCH EDC17CP46 TC1797 - Meredes-Benz:







BOSCH EDC17CP48 TC1797 - Volvo



Version 1:













49

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51159.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51158.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_42988.jpg)



BOSCH EDC17CP49 TC1796 & TC1797 - BMW, Lindner:







Version 2:







BOSCH EDC17CP50 TC1797 - Honda:













50

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51177.png)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51160.jpg)



BOSCH EDC17CP52 TC1797 - Citroen, FIAT, Mitsubishi, Peugeot, Artec, Deutz, Fendt, Tecnoma, Iveco, Berthold, Claas, Merlo, Lamborghini tractors:







BSL connection:













51

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51235.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51234.jpg)



BOSCH EDC17CP54 TC1793 -



Audi, Volkswagen:







BSL connection:













52

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51237.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51236.jpg)



BOSCH EDC17CP55 TC1793 - Jaguar, Land Rover, Mahindra:







BSL connection:













53

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51239.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51238.jpg)



BOSCH EDC17CP57 TC1793 - Mercedes-Benz:







BOSCH EDC17CP58 TC1767 - Bench connection:













54

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51304.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51245.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_43298.jpg)



BOSCH EDC17CP62 TC1793 - KIA:







BOSCH EDC17CP60 TC1793 - Mercedes-Benz:







BOSCH EDC17CP65 TC1793 - Ford:













55

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51306.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51305.jpg)



BOSCH EDC17CP68 TC1797 - Volvo:







BOSCH EDC17CP74 TC1793 - Volkswagen:













56

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51308.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51307.jpg)



BOSCH EDC17CV41 TC1797 - Isuzu, Case, Claas, Doosan, JCB, Laverda, Massey Ferguson, New Holland, Tigercat, Valtra, Iveco, Sinotruck, Astra, Bredamenarini, Challenger, Conrad, Daewoo, Ford truck, Hino, Karsan, Merlo, Komatsu, Minelli, Ravo, Sor, Storti, Tata, Bravo, Dieci Agriculture, Faresin, Gleaner, Landini,



Laverda, Logset, McCormick, Steyr, Vermeer:







BOSCH EDC17CV42 TC1797 - Fendt, International, Man, Caterpillar, Man bus, Otocar, Willibald, Claas:













57

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51310.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51309.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_43489.jpg)



BOSCH EDC17CV52 TC1797 - Artec, Deutz, Fendt, Still, Tecnoma, Amazone, Berthold, Claas, Atlas, Dingo, Evrard, Hurlimann tractors, Lamborghini tractors, Landini, Manitou, McCormick, Merlo, R.M.H. Lachish, Storti:







BOSCH EDC17CV44 TC1767 - Belarus, Challenger, Komatsu, Massey Ferguson, Valtra, Gaz, Sinotruck, Dongfeng, Faw, Jac, Saic, Weichai power truck:







BOSCH EDC17CV54 TC1767 - Yanmar marine, Agco, Belarus, Challenger, Deutz, Fendt, JCB, John Deere, Komatsu, Lamborghini tractors, Laverda, Massey Fergusson, Valtra, Ashok Leyand, Mitsubishi, Yanmar, Bobcat, Bomag, Caterpillar, Dongfeng, Faw, Gehl, Hamm, Hitachi, JLG, Kalmar, Kramer, Landini, Lannen, Linde, Ljungbymaskin, manitou, Mecalac, Menzi muck, Merlo, Mustang mfg, New Holland, Nissan, OM still, renault trucks, Schaffer, Sdlg, Terex, Yanmar, Gleaner, Hubertrack, Komatsu, Laverda, Logset,













58

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51381.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51380.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_43573.jpg)



BOSCH EDC17C06 TC1766 - BMW:







BOSCH EDC17CV56 TC1767 - Claas, Deutz, Fendt, Hurlimann tractors, Lamborghini tractors, Landini, Massey Fergusson, Mccormick, Merlo, Same, Schaffer, Zetor







BSL connection:













59

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51383.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51382.jpg)



BOSCH EDC17C08 TC1766 - Hyundai, Kia:



Option 1:







Option 2:













60

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51385.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51384.jpg)



BOSCH EDC17C10 TC1796 & TC1797 (Variant 1)- Citroen, Ford, Peugeot:







BSL connection:







Important: When reading the ECU in boot mode the connection of CAN HIGH and CAN LOW for password reading is as follows:



CAN HIGH(red) - pin 38



CAN LOW(blue) - pin 50











BOSCH EDC17C10 TC1796 & TC1797 (Variant 2)- Citroen, Ford, Peugeot:









61





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_59565.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51452.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51386.jpg)



BOSCH EDC17C11 TC1766 - Nissan, Opel, Renault, Saab:







BOSCH EDC17C18 TC1766 - Opel:













62

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51453.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51452.jpg)



BOSCH EDC17C19 TC1792 - Opel, Vauxhall, Saab:







BOSCH EDC17C41 TC1797 - BMW, Mini:













63

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51455.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51454.jpg)



BOSCH EDC17C42 TC1767 - Renault, Dacia, Mercedes-Benz, Nissan, Opel, Renault trucks:







BSL connection:













64

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51457.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51456.png)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_43964.jpg)



BOSCH EDC17C45 TC1767 (BSL only) - Renault, Nissan:







BOSCH EDC17C43 TC1797 - Mercedes-Benz:













65

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51553.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51552.jpg)



BOSCH EDC17C46 TC1767 - Audi, Seat, Skoda, Volkswagen:







BSL connection:













66

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51555.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51554.jpg)



BOSCH EDC17C47 TC1782 - Toyota:







BOSCH EDC17C49 TC1797 - Aebi Schmidt, Alfa Romeo, Case, Caterpillar, Claas, Farmtrac, FIAT, Hyundai, Iveco, Jeep, John Deere, Lancia, Landini, Lindner, LS tractor, Magni, Manitou, Massey Fergusson, Mccormick, Mitshubishi, New Holland, Reform, Steyr, Suzuki, Temsa, Terex, Wacker Neuson, Weidemann:













67

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51557.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51556.jpg)



BOSCH EDC17C50 TC1797 - BMW, Mini:







BSL connection:













68

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51559.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51558.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_44218.jpg)



BOSCH EDC17C54 TC1797 - Volkswagen:







BOSCH EDC17C53 TC1767 - Claas, Deutz, Great Wall, Hyundai, JAC, Kia, Lamborghini tractors, LDV, Mahindra, Saic, Same:







BOSCH EDC17C55 TC1767 - JMC, Mahindra, Kubota, JMC:













69

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51562.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51560.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_44296.jpg)



BOSCH EDC17C57 TC1793 - Hyundai, Kia, Mercedes-Benz:







BOSCH EDC17C56 TC1797 - BMW:







BSL connection:



Option 1



Front side of the ECU:













70

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51661.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51660.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_44382.jpg)



Option 2(recommended)



Back side of the ECU:







BOSCH EDC17C59 TC1767 - Chevrolet, Opel:













71

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51663.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51662.jpg)



BOSCH EDC17C60 TC1793 - Citroen, Peugeot, Toyota:







BSL connection:













72

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51665.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51664.jpg)



BOSCH EDC17C64 TC1797 - Audi, Seat, Skoda, Volkswagen:







BSL connection:













73

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51667.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51666.jpg)



BOSCH EDC17C66 TC1793 - Mercedes-Benz:







BOSCH EDC17C69 TC1793 - Alfa Romeo, FIAT, Iveco, Jeep, Suziki:













74

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51669.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51668.jpg)



BOSCH EDC17C70 TC1793 - Ford:







BSL connection:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_44684.jpg)









75

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51765.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51764.jpg)



BOSCH EDC17C73 TC1793 - Toyota:







BSL connection:







BOSCH EDC17C74 TC1793 - Audi, Seat, Skoda, Volkswagen



Version 1:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_44739.jpg)









76

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







Version 2:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_44799.jpg)









77

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51773.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51768.jpg)



BOSCH EDC17C76 TC1793 - BMW:







BSL connection:













78

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51776.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51775.jpg)



BOSCH EDC17C79 TC1797 - Dodge, Fiat, Jeep, Maserati:







BSL connection:













79

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51841.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51777.jpg)



BOSCH EDC17C83 TC1793 - Isuzu:







BOSCH EDC17C84 TC1782 Old and new - Dacia, FIAT, Nissan, Opel, Renault:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_44991.jpg)









80

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51850.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51849.jpg)



BOSCH ME17.2 BMS-X TC1797 - BMW bike:







BOSCH ME17.2.4 TC1793 - BMW bike:







BOSCH ME17.3.0 TC1724 - Abarth, Alfa Romeo, FIAT:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_45079.jpg)









81

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51852.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51851.png)



BOSCH ME17.5.6 TC1767 - Volkswagen:







BSL connection:







BOSCH ME17.5.20 TC1767 - Sear, Skoda, Volkswagen:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_45181.jpg)









82

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51913.jpg)



BOSCH ME17.5.22 TC1724 - Seat, Skoda, Volkswagen:







BOSCH ME17.5.24 TC1724 - Seat, Skoda, Volkswagen: BSL and Bench connections:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_45266.jpg)









83

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51916.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51915.jpg)



BOSCH ME17.5.26 TC1724 - Skoda:







BOSCH ME17.7 TC1796 - Mercedes-Benz:







BOSCH ME17.8.5 TC1766 - Can-am, Sea doo:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_45353.jpg)









84

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51918.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51918.jpg)



BOSCH ME17.8.31 TC1797 - Aston Martin:







BOSCH BOSCH ME17.8.32 TC1797 - Mclaren:













85

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51988.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51919.jpg)



BOSCH ME17.9.5 and M17.8.XX TC1767 - Opel, Suzuki:







BSL connection:













86

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51990.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51989.jpg)



BOSCH ME17.9.7 TC1766 - Lada, Peugeot, Polaris, Uaz:







BOSCH ME17.9.11 TC1762 - Hyundai, Kia:







BOSCH ME17.9.20 TC1782 - Dacia, Renault, Smart:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_45549.jpg)









87

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51998.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51991.jpg)



BOSCH ME17.9.21 TC1724 - Ducati, Hyundai:







BSL connection:













88

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52000.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_51999.jpg)



BOSCH ME17.9.52 TC1782 - Toyota, Citroen, Peugeot:







BSL connection:













89

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52420.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52417.jpg)



BOSCH ME17.9.61 TC1724 - Suzuki:







BOSCH ME17.9.64 TC1724 - Suzuki:













90

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52422.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52421.jpg)



BOSCH ME17.9.71 TC1724 - Lada, Peugeot, UAZ:







BOSCH ME17.9.74 TC1762 - Polaris:







BOSCH MED17.0.1 TC1767 - Ford:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_45889.jpg)









91

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52424.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52423.jpg)



BOSCH MED17.0.7 TC1782 - Ford:







BOSCH MED17.1.1 TC1796 - Audi, Volkswagen



Version 1:







Version 2:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_45973.jpg)









92

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52426.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52425.jpg)



Version 3:







BSL connection:













93

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52482.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52481.jpg)



BOSCH MED17.1.1 TC1797 - Audi, bentley, Lamborghini, Porsche:







BOSCH MED17.1.6 TC1797 - Audi, Porsche, Volkswagen:







BOSCH MED17.1.10 TC1793 - Audi:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_46112.jpg)









94

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52484.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52483.jpg)



BOSCH MED17.1.11 TC1797 - Porsche:







BOSCH MED17.1.21 TC1793 - Audi, Volkswagen:







BOSCH MED17.1.27:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_46191.jpg)









95

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52486.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52485.jpg)



BOSCH MED17.1.61 MASTER TC1793 - Audi:







BOSCH MED17.1.62 MASTER TC1793 - Audi:







BOSCH MED17.1 TC1796 - Volkswagen, Audi:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_46280.jpg)









96

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52551.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52550.jpg)



BOSCH MED17.2 TC1796 & TC1766- Volvo, Mini, Land Rover, Jaguar, Ford:







BOSCH MED17.3.1 TC1766 - Alfa Romeo, Lancia:







BOSCH MED17.3.3 TC1793 - Alfa Romeo:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_46385.jpg)









97

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52553.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52552.jpg)



BOSCH MED17.3.4 TC1797 - Maserati:







BSL connection:













98

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52555.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52554.jpg)



BOSCH MED17.3.5 TC1793 - Maserati, Alfa Romeo, Ferrari:







BOSCH MED17.4.4 TC1793 - Citroen:













99

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52618.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52556.jpg)



BOSCH MED17.4 TC1766 & TC1767 & TC1797- Peugeot:







BSL connection (TC1766):













100

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52621.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52620.jpg)



BOSCH MED17.5.1 TC1796 & TC1766 - Volkswagen:







BSL connection:













101

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52626.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52625.jpg)



BOSCH MED17.5.2 TC1767 - Audi, Seat, Skoda, Volkswagen:







BSL connection:













102

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52628.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52627.jpg)



BOSCH MED17.5.5 TC1766 & TC1767- Audi, Seat, Skoda, Volkswagen:







BSL connection:













103

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52719.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52629.jpg)



BOSCH MED17.5.20 TC1766 - Audi, Seat, Volkswagen:







BSL connection:









104

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52721.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52720.jpg)



BOSCH MED17.5.21 TC1782 - Audi, Seat, Volkswagen, Skoda:







BOSCH MED17.5.25 TC1782 - Audi, Skoda, Seat, Volkswagen:







BSL connection:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_46862.jpg)





105

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52722.jpg)



BOSCH MED17.5 TC1766 - Volkswagen, Seat, Skoda, Audi:







BOSCH MED17.7.1 TC1797 - Mercedes-Benz:







BSL connection:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_46949.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52734.jpg)





106

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52724.jpg)



BOSCH MED17.7.2 TC1797 - Infiniti, Mercedes-Benz:







BSL connection:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52738.jpg)





107

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52725.jpg)



BOSCH MED17.7.3 & MED17.7.3.1 TC1797 - Mercedes-Benz:







BOSCH MED17.7.8 TC1797 :







BOSCH MED17.7.5 TC1793 - Mercedes-Benz:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52742.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52748.jpg)





108

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







BOSCH MED17.8.3 TC1797:







Important: When reading the ECU in boot mode the connection of CAN HIGH and CAN LOW for password reading is as follows:



CAN HIGH(red) - pin 60



CAN LOW(blue) - pin 61







BSL connection:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52760.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52768.jpg)





109

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52852.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52851.jpg)



BOSCH MED17.8.31 TC1797 - Jaguar, Land Rover:







BOSCH MED17.9.3 TC1793 - Honda:









110

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52853.jpg)



BOSCH MED17.9.7 TC1797 - Jaguar, Land Rover:







BOSCH MED17.9.63 TC1793 - Suzuki:







BOSCH MED17.9.30 TC1793:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_47308.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52873.jpg)





111

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52854.jpg)



BOSCH MEG17.9.12 TC1762 - Kia:







BOSCH MEV17.4 TC1766 - Bench connection:







BOSCH MEG17.9.21 TC1724 :



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52880.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52888.jpg)





112

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







BOSCH MEV17.2 TC1766/TC1796/ - Bench connection:







BOSCH MEV17.4 TC1766 - Bench connection:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52895.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52900.jpg)





113

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52926.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52968.jpg)



BOSCH MEVD17.2.3 TC1793 - BMW, Mini:







Important: When reading the ECU in boot mode the connection of CAN HIGH and CAN LOW for password reading is as follows:



CAN HIGH(red) - pin 28 CAN LOW(blue) - pin 13







BOSCH MEVD17.2.4 TC1797 - BMW:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52918.jpg)



BSL connection:









114

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52969.jpg)



BOSCH MEVD17.2.5 TC1797 - BMW:









115

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52971.jpg)



BOSCH MEVD17.2.6 TC1797 - BMW:







BOSCH MEVD17.2.9 TC1797 - BMW:







BOSCH MEVD17.2.8 TC1797 - BMW:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_47691.jpg)





116





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53007.jpg)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53076.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_52972.jpg)



BOSCH MEVD17.2.G TC1797 - BMW:







BSL connection:









117

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53079.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53078.jpg)



BOSCH MEVD17.2.H TC1797 - BMW:







BOSCH MEVD17.2.P TC1797 - BMW:









118

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53080.jpg)



BOSCH MEVD17.4.4 TC1793 - Peugeot:







BSL connection:







BOSCH MEDG17.9.8 and MEG17.9.8 TC1767 - Hyundai, Kia:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_47917.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53058.jpg)





119

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53082.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53081.jpg)



BOSCH MEDG17.0 TC1797 (BSL only) - FORD:









120

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53181.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53180.jpg)



BOSCH MEDC17.9 TC1793 - Jaguar, Land Rover:







BSL connection:









121

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026









122





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53182.jpg)



BOSCH MD1CP002 SPC577 (MRD1) - Mercedes:

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53184.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53183.jpg)



BOSCH MD1CP014 TC298TP ABR - Audi:







BOSCH MD1CE101 TC299 - New Holland, Case:









123

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53185.jpg)



BOSCH MD1CP032 TC299 - BMW:







BOSCH MD1CS003 TC298TP - Citroen, Opel, Peugeot, Vauxhall:







BOSCH MD1CS001 TC298TP - BMW, Mini:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_48225.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53137.jpg)







BOSCH MD1CS004 TC298TP - Audi:









124





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_48303.jpg)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_48335.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53179.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53191.jpg)



BOSCH MG1CP007 TC299TP - Porsche:







BOSCH MG1CP002 SPC577 (MRG1) - Mercedes:







BOSCH MD1CS006 TC298TP - Mercedes-Benz (Version 1):















BOSCH MD1CS006 TC298TP - Mercedes-Benz (Version 2):









125





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_59521.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Two white objects with numbers on them. AI generated content](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_60232.png)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53248.png)



BOSCH MG1CS002 TC298TP: - Audi, Bentley, Porsche:







BOSCH MG1CS016 TC275TP - Ford:







BOSCH MG1CS015 TC277TP - Ford, Lincoln:







BOSCH MG1CS003 - BMW:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_48437.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_48438.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53218.jpg)





126













BOSCH MG1CS011 - Audi,Vw, Seat, Skoda:

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53249.jpg)



BOSCH MG1CS017 TC277TP - Ford:







BOSCH MG1CS201 TC298TP - BMW, Mini:







BOSCH MG1CS042 TC298TP - Citroen, DS, Peugeot:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_48522.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53239.jpg)





127

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53316.jpg)



BOSCH EDC17U01 TC1766 - Seat, Skoda, Volksvagen:







MOTRONIC M17.8.7 TC1762 (BSL only) - KTM, Polaris, Bajaj:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_48601.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53269.jpg)





128

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53318.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53317.jpg)



CONTINENTAL SID208 TC1797 (BSL only) - Peugeot, Land Rover, Fiat, Citroen, Ford:









129

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53325.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53324.jpg)



CONTINENTAL SID209 TC1797 (BSL only) - Ford:









130

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53327.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53326.jpg)



CONTINENTAL SID305 TC1766 (BSL only) - Renault, Dacia, Mercedes-Benz:









131

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53461.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53460.jpg)



CONTINENTAL SID306 TC1766 (BSL only) - Renault, Dacia, Nissan:









132

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53540.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53539.jpg)



CONTINENTAL SID307 TC1767 (BSL only) - Dacia, Renault, Nissan, Opel, Mercedes-Benz:









133

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53542.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53541.jpg)



CONTINENTAL SID309 TC1767 (BSL only) - Renault, Nissan, Opel:









134

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53544.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53543.jpg)



CONTINENTAL SID310 TC1791 (BSL only) - Dacia, Infiniti, Opel, Mercedes-Benz:









135

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53612.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53611.jpg)



CONTINENTAL SID807 (BSL only) - Citroen, Ford, Mazda, Peugeot, Volvo:













136

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53614.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53613.jpg)



CONTINENTAL SID807 EVO (BSL only) - Citroen, Ford, Mazda, Peugeot, Volvo:









137

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53615.jpg)



CONTINENTAL EMS2208 TC1767 (BSL only) - Ford, Lincoln:







Run a cable from the “+3.3V supply” on the BACK side of the ECU to the location marked with “+3.3V” on the FRONT side of the ECU as per the photo.







Front side of the ECU:







Back side of the ECU:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_49012.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_49013.jpg)





138

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53722.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53616.jpg)



CONTINENTAL EMS24XX TC1791 (BSL only) - Shelby, Lincoln, Ford truck, Ford:









139

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53724.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53723.jpg)



CONTINENTAL EMS3155 TC1782 (BSL only) - Dacia, Nissan, Renault:









140

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53726.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53725.jpg)



CONTINENTAL SIM2K-240 TC1767 and TC1766 (BSL only) - Dodge, Hyundai, Kia:









141

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53728.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53727.jpg)



CONTINENTAL SIM2K-241 TC1767 (BSL only) - Hyundai,KIA:









142

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53730.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53729.jpg)



CONTINENTAL SIM2K-305 TC1782 (BSL only) - Hyundai,KIA:









143

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53732.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53731.jpg)



CONTINENTAL SDI3 TC1796 (BSL only) - Porsche:









144

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53790.jpg)



DELPHI CRD3.XX TC1797 and TC1793 (BSL only) - Mercedes:







TC1793:







TC1797:



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_49312.jpg)





145





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53721.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53792.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53791.jpg)



DELPHI DCM6.1 TC1797 (BSL only) - Ford:









146

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026











Simos PCR2.1:







\*This ECU should be read through the Abrites software for VAG!



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53808.jpg)





147

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







In order to read a TCU on bench, you need to use the ZN151 connection with CB401/CB403, or you can use the ZN079 directly with AVDI without the ZN151 for Bosch TCU ZF 8HP









IMPORTANT: There is a connection sequence for ZN079 that must be executed as follows:



Connect ZN079 to the TCU > connect the power supply adapter > connect the already powered-up set to AVDI > start the ECU Programming tool software. If not executed like that, the software might not work as expected.









Below you may find the connection diagrams for:



1. ZF 8HP (BMW,Audi Porsche)
2. Mercedes VGSNAG3 9G Tronic
3. Mercedes VGSNAG2 FDCT
4. Mercedes Getrag 7DCT300

﻿9.1 ZF 8HP

Below you may find the connections for ZF 8HP, using CB401/CB403. There are 3 versions of the connectior, the only difference is the positon of the CAN wires, so if you do not know what is the type you have, you can just check until you get it right. The power wires are on the same pins.

![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_57299.png)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_57305.png)

148

![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_57314.png)

ZN079 is used for all types, and automatically detects the correct CAN wires position.

CB403 has larger sockets that are able to fit at the TCU pins.

﻿9\. TCU Connections

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







﻿9.2 Mercedes VGSNAG3 9G-tronic



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_55791.png)





149





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_57265.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







﻿9.3 Mercedes VGSNAG2-FDCT









The connector of the FDCT does not have a PIN for GND, in this case you would have connect the GND black connector cable anywhere on the metal body of the TCU..



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_57280.png)





150





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_57282.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







﻿9.4 Mercedes Getrag 7DCT300









ZN151 DS Box and a CB401/CB403 is required for connection to the TCU. Once connected properly, you are able to read and write Data Flash, Program Flash and Maps of the TCU.









PIN OUT connection:



Connector B



PIN 1 - 12V+



PIN 6 - GND



PIN 19 - 12v+



PIN 33 - CAN H



PIN 34 - CAN L









151





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_59489.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026













The ECU Programming Tool has advanced functionalities for the BMW mounted units. There are cases when the BMW software is not able to make a ZF 8HP virgin, and here is the solution. With the use of EP003 license you can do the following:









  - Read/Update the unit
  - Make Virgin
  - Read/Update/Copy ISN

﻿10\. ZF 8HP Virgin - Adapt for BMW

152

![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_57576.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







﻿10.1 ZF 8HP BMW Make Virgin









1. Read the ZF 8HP unit’s Data Flash with the ECU Programmin tool and the ZN079 cable set and save the data to a file.

2. Load the file in the Dump tool
3. Press the “Virginize” button - this will creat a new file that you need to save again.
4. Go back and write the file to the unit

Now the EGS is in a virgin state, you can install it into the vehicle to proceed with adaptation.

![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_57536.png)

153

![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_57696.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







﻿10.2 ZF8HP ISN Read/Update









Once into the Dump Tool of the ECU Programmint tool, you have an option to read, copy and update the ISN of the TCU trough the dedicated “ISN” button. If you have the ISN of the original TCU, you can write it into the donor unit. You just need to manually input the ISN you need, and click save, the software would ask you to save the newly generated dump file, and you need to write it into the TCU. If you do this, you should not need to do the procedure with IGN ON and IGN OFF for adaptation, described in the next section.









154





![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_57686.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







﻿10.3 ZF 8HP BMW Adaptation









Once you have the “virgin” EGS unit installed into the vehicle, you need to complete the following steps in order to adapt it:



1. Turn IGN ON - wait for 2 min.

2. Turn IGN OFF - wait for 2 min
3. Repeat 5 times

In other words, you need to turn Ignition On for 2 minutes, than turn Ignition Off for 2 minute, than IGN ON for 2 min, IGN OFF for 2 min until you repeat ON and OFF 5 times each, which should make the procedure 20 minutes long.

![﻿11. DQxxx TCU On Bench Pinout’s](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item60252_60256.png)

To read DQ 200, DQ250, DQ381 or DQ500 transmission control modules, DSBox and CB403 cable are mandatory.

11.1 DQ200

155

![A white track with a yellow line on it. AI generated content](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_60287.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026







11.2 DQ250



![A drawing of a tube with a red, yellow, and blue circle inside. AI generated content](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_60344.png)



11.4 DQ500



![A close-up of a cable with several buttons on it. AI generated content](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_60381.png)



11.3 DQ381









156





![A white circle with a black and orange circle in the middle. AI generated content](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_60638.png)

- www.abrites.com





























Abrites ENGINE CONTROL UNIT Programming Tool









2026



![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53826.jpg)![Rectangle](https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/assets/images/item_53825.jpg)



﻿12.1 Mercedes CEPC unit reading by OBDII









In the future updates of ECU programming tool you can expext the functionality to read and write Pflash, Dflash and Program data of Mercedes CEPC units by OBD(2.20/2.3/2.4).









IMPORTANT: Writing inconsistent program data can make your device not working properly. It is strongly recommended to make first a full backup of the Pflash and Dflash.



For recovery procedure via boot mode contact [support@abrites.com](mailto:support%40abrites.com?subject=)









157













﻿12\. Appendix