Source: https://www.nissan.ph/vehicles/new.html
Title: New Vehicle Range | Nissan Philippines
Fetched: 2026-11-11T12:55:16.448Z

COOKIE NOTIFICATION

We use cookies on our website for identification and analysis purposes. By using this website you consent to the storing and accessing of cookies on your device. Find out more in our [Legal and Other Policies page.](https://www.nissan.ph/privacy.html)

# Vehicles

- [![nissan-primera-thumbnail](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/vehicles/primera-ev/thumbnail/Nissan%20Primera%20Thumbnail%20110326.png.ximg.l_4_m.smart.png)](https://www.nissan.ph/vehicles/new/primera.html)







### [Primera](https://www.nissan.ph/vehicles/new/primera.html)









  - Starting price

    ₱1,179,000


- [![Nissan Navara Pro PHEV](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/vehicles/navara-phev/thumbnail/Navara%20Pro%20PHEV%20Thumbnail%20110326.png.ximg.l_4_m.smart.png)](https://www.nissan.ph/vehicles/new/navara-pro-phev.html)







### [Navara Pro Plug-In Hybrid](https://www.nissan.ph/vehicles/new/navara-pro-phev.html)









  - Starting price

    ₱ 1,260,000


- [![X-Trail Thumbnail](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/Home/Select%20a%20Vehicle/X-Trail%20Thumbnail%202.png.ximg.l_4_m.smart.png)](https://www.nissan.ph/vehicles/new/x-trail.html)







### [X-TRAIL e-POWER](https://www.nissan.ph/vehicles/new/x-trail.html)



[𝗲-POWER Electric SUV](https://www.nissan.ph/vehicles/new/x-trail.html)









  - Starting price

    ₱3,988,000


[Explore](https://www.nissan.ph/vehicles/new/x-trail.html) [Download Brochure](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/brochures/x-trail_brochure.pdf)

- [![Nissan Kicks](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/vehicles/Kicks/new/model/Nissan-New-Kicks-e-POWER.png.ximg.l_4_m.smart.png)](https://www.nissan.ph/vehicles/new/kicks)







### [Kicks e-POWER](https://www.nissan.ph/vehicles/new/kicks)



[𝗲-POWER Electric SUV](https://www.nissan.ph/vehicles/new/kicks)









  - Starting price

    Available upon request


- [![Nissan Patrol](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/Home/Select%20a%20Vehicle/Patrol-Thumbnail.png.ximg.l_4_m.smart.png)](https://nissan.ph/vehicles/new/patrol)







### [Patrol](https://nissan.ph/vehicles/new/patrol)



[LUXURY 4X4 FULL-SIZE SUV](https://nissan.ph/vehicles/new/patrol)









  - Starting price

    ₱1,069,000



    \*Additional P20,000 for 2-Tone Color, P30,000 for Premium Color, P50,000 for Premium 2-Tone Color


- [![Nissan Navara](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/vehicles/thumbnail/thumb_navara.jpg.ximg.l_4_m.smart.jpg)](https://www.nissan.ph/vehicles/new/navara.html)







### [Navara](https://www.nissan.ph/vehicles/new/navara.html)



[Get Smarter When the Ride Gets Tougher](https://www.nissan.ph/vehicles/new/navara.html)









  - Starting price

    ₱2,798,000


[Explore](https://www.nissan.ph/vehicles/new/navara.html) [Download Brochure](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/brochures/navara_brochure.pdf)

- [![Nebula Metallic Red](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/vehicles/Terra/d23/philhd/2026/The%20New%20Nissan%20Terra%20Sport%203%201.png.ximg.l_4_m.smart.png)](https://www.nissan.ph/vehicles/new/terra)







### [Terra](https://www.nissan.ph/vehicles/new/terra)



[MID-SIZE SUV](https://www.nissan.ph/vehicles/new/terra)









  - Starting price

    ₱845,000


[Explore](https://www.nissan.ph/vehicles/new/terra) [Download Brochure](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/brochures/terra_brochure.pdf)

- [![Urvan Thumbnail](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/Home/Select%20a%20Vehicle/Urvan_Thumbnail.png.ximg.l_4_m.smart.png)](https://www.nissan.ph/vehicles/new/urvan.html)







### [Urvan](https://www.nissan.ph/vehicles/new/urvan.html)



[THE NEW URBAN STANDARD](https://www.nissan.ph/vehicles/new/urvan.html)









  - Starting price

    ₱1,749,000


[Explore](https://www.nissan.ph/vehicles/new/urvan.html) [Download Brochure](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/brochures/urvan_brochure.pdf)

- [![almera-thumb](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/vehicles/thumbnail/thumb_almera.png.ximg.l_4_m.smart.png)](https://www.nissan.ph/vehicles/new/almera-classic.html)







### [Almera](https://www.nissan.ph/vehicles/new/almera-classic.html)









  - Starting price

    ₱1,115,000


[Explore](https://www.nissan.ph/vehicles/new/almera-classic.html) [DOWNLOAD BROCHURE](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/brochures/almera_brochure.pdf)

- [![Livina Placeholder](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/Home/Select%20a%20Vehicle/Livina_Thumbnail.png.ximg.l_4_m.smart.png)](https://www.nissan.ph/vehicles/new/livina.html)







### [Livina](https://www.nissan.ph/vehicles/new/livina.html)



[7-SEATER MPV](https://www.nissan.ph/vehicles/new/livina.html)









  - Starting price

    ₱4,758,000


[EXPLORE](https://www.nissan.ph/vehicles/new/livina.html) [Download Brochure](https://www-asia.nissan-cdn.net/content/dam/Nissan/ph/brochures/livina_brochure.pdf)