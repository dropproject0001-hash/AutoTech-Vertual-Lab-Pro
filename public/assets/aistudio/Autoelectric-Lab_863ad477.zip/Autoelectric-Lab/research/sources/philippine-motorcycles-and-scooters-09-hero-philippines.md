Source: https://www.heromotocorp.com/en-ph.html
Title: Hero MotoCorp Philippines | Leading Two-Wheeler Manufacturer
Fetched: 2026-11-11T12:56:23.500Z

[![xoom-125r](https://www.heromotocorp.com/content/dam/hero-aem-website/ph/en-ph/products/xoom-125r/banner/xoom-web.jpg)![xoom-125r](https://www.heromotocorp.com/content/dam/hero-aem-website/ph/en-ph/products/xoom-125r/banner/xoom-mob.jpg)](https://www.heromotocorp.com/en-ph/products/scooter/xoom-125r.html)[![Eco Hercules 150](https://www.heromotocorp.com/content/dam/hero-aem-website/ph/en-ph/products/eco-hercules-150/banner/eco-hercules-150-desktop.jpg)![Eco Hercules 150](https://www.heromotocorp.com/content/dam/hero-aem-website/ph/en-ph/products/eco-hercules-150/banner/eco-hercules-150-mobile.jpg)](https://www.heromotocorp.com/en-ph/products/business/eco-hercules-150.html)[![](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/product/xoom-110/banner/Xoom-110-Banner-18.jpg)![](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/product/xoom-110/banner/Xoom-110_Banner-18-mob.jpg)](https://www.heromotocorp.com/en-ph/products/scooter/xoom-110.html)[![](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/np/products/xpulse-200-4v/banner/Xpulse_200_web_banner.jpg)![](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/np/products/xpulse-200-4v/banner/Xpulse_200_mobile_banner.jpg)](https://www.heromotocorp.com/en-ph/products/premium/xpulse-200-4v.html)[![](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/product/hunk/banner/hunk160r4v-banner-updated.jpg)![](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/product/hunk/banner/Hunk160R-4VMobile%20Banner.jpg)](https://www.heromotocorp.com/en-ph/products/premium/hunk.html)![](https://www.heromotocorp.com/content/dam/hero-aem-website/in/design-bd/banner-images/banners/World-Map-Banner_13th-Nov-25-1600x496-01.jpg)![](https://www.heromotocorp.com/content/dam/hero-aem-website/in/design-bd/banner-images/banners/World-Map-Banner_13th-Nov-25-360x380-02.jpg)

# The Most Trusted Two-Wheeler Company in Philippines

##### > Driven by passion, built on trust. No matter your riding requirements, there is a Hero for you. Our wide range of motorcycles and scooters cater to the mobility needs of today and tomorrow.    > Millions of customers have placed their trust in our two-wheelers, which are designed with precise engineering technologies and the most experienced automobile specialists to offer every customer the best riding experience. With an in-built DNA that drives us to break the limits of two-wheeler performance, we aim to instil excellence in every fibre of our products so you can truly experience the journey.    > At Hero MotoCorp, our goal has always been to deliver the highest quality products that offer more than the promised value over a lifetime of use. No matter what your travel needs are, you'll find the perfect solution with Hero. Get ready for your next riding adventure with the future of mobility, powered by Hero.

> Be the future of mobility

##### > With the immense credibility of a global brand and the trust of more than 125 million customers, Hero MotoCorp is riding into the future to address the personal mobility needs – traditional and electric – of a bold new world. With Innovation at its core, the company continues to expand horizons and strengthen its capabilities.

- [PREMIUM](https://www.heromotocorp.com/en-ph.html#menu2069978339)
- [SCOOTER](https://www.heromotocorp.com/en-ph.html#menu2069978340)
- [BUSINESS](https://www.heromotocorp.com/en-ph.html#menu2069978341)

![XPULSE 200 4V](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/product/x-pulse/x-pulse.png)

BORN FOR THE TOUGHEST TERRAINS

![XPULSE 200 4V](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/np/logo/Xpulse_200_4V.png)

> Be it city streets or the great outdoors, get ready for any terrain with Xpulse 200 4V

> [Variant Wise Price](https://www.heromotocorp.com/en-ph/products/premium/xpulse-200-4v.html#priceSection)

PRICE :
₱ 140,000

- Bike Power : **14.1 kW / 18.9 BHP @ 8500 rpm**
- Bike Torque : **17.35 Nm @ 6500 rpm**
- Engine type : **Oil Cooled, 4 Stroke 4 Valve Single Cylinder OHC**

REQUEST A CALL BACK [VIEW SPECIFICATIONS](https://www.heromotocorp.com/en-ph/products/premium/xpulse-200-4v.html#specifications)

![HUNK 160R 4V](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/product/hunk/banner/hunk.png)

EVERY DRAGSTER'S DREAM

![HUNK 160R 4V](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/product/hunk/banner/Hunk%20160R%204V_Logo%20resize_756x200-01.png)

> Get ready to set hearts racing and turn heads your way with a bike that sports a stylish look and demands a commanding presence

> [Variant Wise Price](https://www.heromotocorp.com/en-ph/products/premium/hunk.html#priceSection)

PRICE :
₱ 99,900

- Bike Power : **14.1 kW / 18.9 BHP @ 8500 rpm**
- Bike Torque : **17.35 Nm @ 6500 rpm**
- Engine type : **Oil Cooled, 4 Stroke 4 Valve Single Cylinder OHC**

REQUEST A CALL BACK [VIEW SPECIFICATIONS](https://www.heromotocorp.com/en-ph/products/premium/hunk.html#specifications)

![XPULSE 200 4V](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/product/x-pulse/x-pulse.png)![XPULSE 200 4V](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/product/x-pulse/x-pulse.png)

XPULSE 200 4V

![HUNK 160R 4V](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/product/hunk/banner/hunk.png)![HUNK 160R 4V](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/product/hunk/banner/hunk.png)

HUNK 160R 4V

![XOOM 110](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/np/products/xoom-110/colors-and-360/matt-abrax-orange/6.png)

EXCITING EXPLORATIONS

![XOOM 110](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/np/logo/Xoom.png)

> **Experience the new Dimension in Urban Riding with Style and Technology with XOOM XTEC**

> [Variant Wise Price](https://www.heromotocorp.com/en-ph/products/scooter/xoom-110.html#priceSection)

PRICE :
₱ 69,900

- Max Power : **6.0kW (8.05 bhp) @ 7250rpm**
- Max Torque : **8.70 Nm @ 5750rpm**
- Engine type : **Air-cooled, 4-stroke, SI engine**

REQUEST A CALL BACK [VIEW SPECIFICATIONS](https://www.heromotocorp.com/en-ph/products/scooter/xoom-110.html#specifications)

![Xoom 125R](https://www.heromotocorp.com/content/dam/hero-aem-website/ph/en-ph/products/xoom-125r/360-images/pearl-silver-white/11.png)

BUILT TO OUTPERFORM

![Xoom 125R](https://www.heromotocorp.com/content/dam/hero-aem-website/ph/en-ph/products/xoom-125r/XOOM%20125R%20Logo_Black.png)

> **Style and Performance That Makes You Stand Out**

> [Variant Wise Price](https://www.heromotocorp.com/en-ph/products/scooter/xoom-125r.html#priceSection)

PRICE :
₱ 76,900

- Max Power : **7.3 kW @ 7250 r/min**
- Max Torque : **10.4 N-m @ 6000 r/min**
- Engine type : **Air Cooled, 4 Stroke, SI Engine**

REQUEST A CALL BACK [VIEW SPECIFICATIONS](https://www.heromotocorp.com/en-ph/products/scooter/xoom-125r.html#specifications)

![XOOM 110](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/np/products/xoom-110/colors-and-360/matt-abrax-orange/6.png)![XOOM 110](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/np/products/xoom-110/colors-and-360/matt-abrax-orange/6.png)

XOOM 110

![Xoom 125R](https://www.heromotocorp.com/content/dam/hero-aem-website/ph/en-ph/products/xoom-125r/360-images/pearl-silver-white/11.png)![Xoom 125R](https://www.heromotocorp.com/content/dam/hero-aem-website/ph/en-ph/products/xoom-125r/360-images/pearl-silver-white/11.png)

Xoom 125R

![Eco Hercules 150](https://www.heromotocorp.com/content/dam/hero-aem-website/ph/en-ph/products/eco-hercules-150/360-images/candy-blazing-red/11.png)

Maximum Durability! Maximum Savings!

![Eco Hercules 150](https://www.heromotocorp.com/content/dam/hero-aem-website/ph/en-ph/products/eco-hercules-150/eco-hercules-150-Logo.png)

> A New Partner in Business

> [Variant Wise Price](https://www.heromotocorp.com/en-ph/products/business/eco-hercules-150.html#priceSection)

PRICE :
₱ 65,900

- Max Power : **10 kW (13.4 BHP) @ 8000 rpm**
- Max Torque : **12.8 N-m @ 5000 rpm**
- Engine type : **Air Cooled, 4 Stroke Engine Cylinder OHC**

REQUEST A CALL BACK [VIEW SPECIFICATIONS](https://www.heromotocorp.com/en-ph/products/business/eco-hercules-150.html#specifications)

![Eco Hercules 150](https://www.heromotocorp.com/content/dam/hero-aem-website/ph/en-ph/products/eco-hercules-150/360-images/candy-blazing-red/11.png)![Eco Hercules 150](https://www.heromotocorp.com/content/dam/hero-aem-website/ph/en-ph/products/eco-hercules-150/360-images/candy-blazing-red/11.png)

Eco Hercules 150

## LET US CALL YOU BACK

Customer Name\*Customer Name Required

City\*ALBAYAURORABACOORBIÑANBOHOLBULACANBenguetCABANATUANCAGAYANCALOOCANCAMARINES NORTECAMARINES SURCAPIZCAVITECEBUDAVAO DEL NORTEDAVAO DEL SURGMA CAVITE HERMOSA ILOCOS SURINFANTAISABELALAGUNALIPALUCENALa UnionMARIKINAMISAMIS ORIENTALMUNTINLUPAMasbateNEGROS OCCIDENTALNUEVA ECIJANUEVA VIZCAYAOCCIDENTAL MINDOROOLONGAPOORIENTAL MINDOROPAMPANGAPASAYPASIGPangasinanQUEZON CITYQUEZONRIZALSAN JOSESAN JUANSAN PABLOSARANGGANISINILOANSOUTH COTABATOSTA. CRUZTANAUANTARLACVALENZUELAZAMBALESEnter City Name

City Required

Mobile Number\*

Mobile Number RequiredMinimum 10 Digits RequiredInvalid Mobile Number

OTP Sent Successfully

Select Category\*Select Category of Bike Business,Premium,ScooterThis field is required

Vehicle Model\*Select Vehicle ModelThis field is required

Your Privacy Matters to Us

We may use your personal data to contact you via email, SMS, or phone. Your information will be handled according to the applicable privacy regulation and won't be shared outside our stakeholders

Please provide your consent for us to use your data for the following purposes:

Analytics & Personalisation

Marketing & Promotions

\*By clicking Submit, you agree to our [Terms of Use](https://www.heromotocorp.com/en-in/terms-of-use.html), [Disclaimer](https://www.heromotocorp.com/en-in/disclaimer.html) and [Privacy Policy](https://www.heromotocorp.com/en-in/privacy-policy.html). You may receive Calls / SMS / Email notifications from us.


Submit enquiry

![offers](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/np/offer-banners/xpluse_offer_banner.jpeg)

## THANK YOU

> **Our executive will get back to you shortly.**

## Oops!

Submission limit reached. Please try again tomorrow.

## Oops!

There was an error, please try again later.

Hero World


Hero means passion, passion for excellence, passion for great rides,

and we always strive to give you best


![Company News](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/hero-world/hero-card-heromotocorp.png)

[Read More](https://www.heromotosports.com/)

![Joyride](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/phillipines/hero-world/hero-technology.png)

[Know More](https://www.heromotocorp.com/en-ph/hero-technology.html)

![Company News](https://www.heromotocorp.com/content/dam/hero-aem-website/in/design-bd/hero-world/Hero%20Company%20News%20-%20Homepage%20Hero%20World.jpg)

[Read More](https://www.heromotocorp.com/en-in/company/newsroom/hero-in-the-news.html)

Manufacturing Happiness Since 1985

Leading with innovation, Hero is at the forefront of providing mobility to the aspirations of millions around the world.

53+ Countries

![](https://www.heromotocorp.com/content/dam/hero-dam-assets/global/np/home-page/Xpulse_200_4V_Nexus_Blue_1.png)

#1Two Wheeler

Manufacturer

9000+Customer

Touch Points

40+Years of

Excellent Service

125 MNSatisfied

Customers