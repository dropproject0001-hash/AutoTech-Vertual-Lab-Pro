Source: https://fuso.com.ph/
Title: Home | MITSUBISHI FUSO Authorized Distributor - FUSO Philippines
Fetched: 2026-11-11T12:54:41.669Z

- [New F-Wing](https://fuso.com.ph/f-wing/)
- [Find A Dealer](https://fuso.com.ph/dealers/)
- [Trucks & Bus](https://fuso.com.ph/models/)  - [Electric Light Duty](https://fuso.com.ph/models/#ecanter)
  - [Light Duty](https://fuso.com.ph/models/#canter)
  - [Medium Duty](https://fuso.com.ph/models/#fi)
  - [Heavy Duty](https://fuso.com.ph/models/#fj)
  - [Modern PUV](https://fuso.com.ph/models/#modern-puv)
  - [Minibus](https://fuso.com.ph/models/#minibus)
- [Canter Built Ready](https://fuso.com.ph/built-ready/)
- [Latest Offers](https://fuso.com.ph/latest-offers/)
- [Parts & Services](https://fuso.com.ph/#)  - [Parts and Accessories](https://fuso.com.ph/parts-and-accessories/)
  - [Services](https://fuso.com.ph/services/)
- [About Us](https://fuso.com.ph/#)  - [FUSO Brand](https://fuso.com.ph/brands/)
  - [Company Profile](https://fuso.com.ph/company-profile/)
- [News](https://fuso.com.ph/news/)  - [Press Release](https://fuso.com.ph/category/press-release/)
  - [Related Links](https://fuso.com.ph/the-general-distributor-of-fuso-trucks-buses-and-modern-puvs-in-the-philippines)
  - [Canter AMT \| Duonic](https://fuso.com.ph/the-all-new-canter-amt)
  - [Global](https://www.mitsubishi-fuso.com/news)
- [Careers](https://fuso.com.ph/careers/)
- [Inquire Now](https://fuso.com.ph/contact-us/)

- [Inquire Now](https://fuso.com.ph/contact-us/)

[(049) 530 1390](tel:(049) 530 1390)

Previous

![](https://fuso.com.ph/wp-content/uploads/2026/11/PITS-Home.jpg)

# MITSUBISHI FUSO Pavilion

1st Philippine International Truck Show 2026

[Learn More](https://fuso.com.ph/mitsubishi-fuso-philippines-reliable-mobility-since-the-1960s/)

![](https://fuso.com.ph/wp-content/uploads/2026/08/BPI-homepage.jpg)

## Enjoy 0% Interest for up to 48 Months

Get 0% interest for up to 48 months on select FUSO Canter trucks, with as low as 30% down payment, exclusive with BPI Auto Loan.

[Learn More](https://www.bpi.com.ph/personal/rewards-and-promotions/promos/fuso)

![](https://fuso.com.ph/wp-content/uploads/2026/10/Home-Page.jpg)

## Upgrade your Business this Holiday Season!

Up to ₱200,000 DISCOUNT on select FUSO Canter models.

[Learn More](https://fuso.com.ph/latest_offer/upgrade-your-business/)

![](https://fuso.com.ph/wp-content/uploads/2026/07/flag-hp.jpg)

## FUSO closes 2025 on the Podium

FUSO Philippines improved to third with 1,461 units, improving its performance by 8.1% from 1,351 units sold in 2024.

[Learn More](https://fuso.com.ph/fuso-philippines-caps-off-2025-with-a-podium-finish/)

![](https://fuso.com.ph/wp-content/uploads/2026/07/backdrop-homepage.jpg)

## SFP x Centro

The new F-resh Van & F-Lift Crane

[Learn More](https://fuso.com.ph/fuso-philippines-and-centro-manufacturing-corporation-launches-the-new-f-resh-van-and-f-lift-for-the-canter-series/)

![](https://fuso.com.ph/wp-content/uploads/2025/10/Home-Page-Value-Parts-Campaign_v.1.jpg)

## FUSO Value Parts

Your FUSO truck deserves only the best. With FUSO Value parts, you get the perfect balance of genuine reliability and best-value pricing.

[Learn More](https://fuso.com.ph/latest_offer/fuso-value-parts)

![](https://fuso.com.ph/wp-content/uploads/2026/07/FUSO-HEALTH-CHECK-BANNER-3dia.jpg)

## FUSO Health Check

Visit the Official Site of FUSO Trucks for a Free Inspection on all purchased FUSO commercial vehicles. Ensure your fleet is in top condition with expert care.

[Learn More](https://fuso.com.ph/latest_offer/fuso-health-check/)

![](https://fuso.com.ph/wp-content/uploads/2026/08/Homepage-3dia-banner.jpg)

## Moving With You

FUSO trucks are built with trusted quality to meet your business demands. Learn more about our commitment to excellence.

[Learn More](https://fuso.com.ph/dealers/)

![Experience unmatched efficiency with the Canter FE71. Check out for more details on its performance capabilities.](https://fuso.com.ph/wp-content/uploads/2024/06/The-All-New-Canter-Banner-1-scaled.jpg)

## The All-New Canter FE71

Experience unmatched efficiency with the Canter FE71. Check out for more details on its performance capabilities.

[Learn More](https://fuso.com.ph/the-all-new-canter-amt/)

Next
- 1
- 2
- 3
- 4
- 5
- 6
- 7
- 8
- 9

[**eCanter** \\
\\
Electric Light Duty\\
\\
GVW 5T\\
\\
![](https://fuso.com.ph/wp-content/uploads/2026/10/25_eCanter_S_D806151.jpg)](https://fuso.com.ph/models/#ecanter)

[**Canter** \\
\\
Light Duty\\
\\
GVW (4.4T - 8.5T)\\
\\
![](https://fuso.com.ph/wp-content/uploads/2019/06/TF-Canter-FE71-FB-BODY-copy-1.png)](https://fuso.com.ph/models/#canter)

[**FI** \\
\\
Medium Duty\\
\\
GVW 11.9T\\
\\
![](https://fuso.com.ph/wp-content/uploads/2019/06/Medium-Duty-2-1.jpg)](https://fuso.com.ph/models/#fi)

[**FJ** \\
\\
Heavy Duty\\
\\
GVW 18T-28T\\
\\
![](https://fuso.com.ph/wp-content/uploads/2019/06/Heavy-Duty-fj.jpg)](https://fuso.com.ph/models/#fj)

[**Canter** \\
\\
Modern PUV\\
\\
Class II and Class III\\
\\
![](https://fuso.com.ph/wp-content/uploads/2020/11/Canter-Commute-Class-II-PUV-Featured-Image.png)](https://fuso.com.ph/models/#modern-puv)

[**Cruise** \\
\\
Minibus\\
\\
Seating (36)\\
\\
![](https://fuso.com.ph/wp-content/uploads/2024/12/minibus-copy-2.jpg)](https://fuso.com.ph/models/#minibus)

Previous

[![https://fuso.com.ph/wp-content/uploads/2026/07/GGC-3dia.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/GGC-3dia.jpg)](https://fuso.com.ph/fuso-philippines-turns-over-canter-units-to-gamboa-group-of-companies/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/Imperial-Appliance-2026.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/Imperial-Appliance-2026.jpg)](https://fuso.com.ph/fuso-philippines-delivers-10-canter-units-to-vic-imperial-appliance-corporation/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/AP-Cargo-2026.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/AP-Cargo-2026.jpg)](https://fuso.com.ph/ap-cargo-adds-new-fuso-trucks-to-its-fleet/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/Red-Cross.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/Red-Cross.jpg)](https://fuso.com.ph/fuso-donates-modern-puv-to-philippine-red-cross/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/Shopee-3dia.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/Shopee-3dia.jpg)](https://fuso.com.ph/fuso-philippines-strengthens-sales-and-aftersales-tie-up-with-shopee-xpress/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/Owwa-3dia.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/Owwa-3dia.jpg)](https://fuso.com.ph/empowering-overseas-workers-fuso-philippines-turns-over-3-fj-units-to-owwa/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/PCL-3dia.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/PCL-3dia.jpg)](https://fuso.com.ph/expanding-the-fleet-fuso-turns-over-8-more-fj-units-to-pcl-inc/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/GGC-3dia.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/GGC-3dia.jpg)](https://fuso.com.ph/fuso-philippines-turns-over-canter-units-to-gamboa-group-of-companies/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/Imperial-Appliance-2026.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/Imperial-Appliance-2026.jpg)](https://fuso.com.ph/fuso-philippines-delivers-10-canter-units-to-vic-imperial-appliance-corporation/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/AP-Cargo-2026.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/AP-Cargo-2026.jpg)](https://fuso.com.ph/ap-cargo-adds-new-fuso-trucks-to-its-fleet/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/Red-Cross.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/Red-Cross.jpg)](https://fuso.com.ph/fuso-donates-modern-puv-to-philippine-red-cross/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/Shopee-3dia.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/Shopee-3dia.jpg)](https://fuso.com.ph/fuso-philippines-strengthens-sales-and-aftersales-tie-up-with-shopee-xpress/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/Owwa-3dia.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/Owwa-3dia.jpg)](https://fuso.com.ph/empowering-overseas-workers-fuso-philippines-turns-over-3-fj-units-to-owwa/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/PCL-3dia.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/PCL-3dia.jpg)](https://fuso.com.ph/expanding-the-fleet-fuso-turns-over-8-more-fj-units-to-pcl-inc/)

[![https://fuso.com.ph/wp-content/uploads/2026/07/GGC-3dia.jpg](https://fuso.com.ph/wp-content/uploads/2026/07/GGC-3dia.jpg)](https://fuso.com.ph/fuso-philippines-turns-over-canter-units-to-gamboa-group-of-companies/)

Next
- 1
- 2
- 3
- 4
- 5
- 6
- 7

### Latest News

- 10/22/26 [MITSUBISHI FUSO Philippines: Reliable Mobility since the 1960s](https://fuso.com.ph/mitsubishi-fuso-philippines-reliable-mobility-since-the-1960s/) Press Release
- 08/12/26 [FUSO Philippines and BPI Roll Out Exclusive FUSO Financing Promo](https://fuso.com.ph/fuso-philippines-and-bpi-roll-out-exclusive-fuso-financing-promo/) Press Release
- 08/07/26 [We are MITSUBISHI FUSO](https://fuso.com.ph/we-are-mitsubishi-fuso/) Press Release
- 05/19/26 [FUSO Philippines Delivers 10 Canter Units to Vic Imperial Appliance Corporation](https://fuso.com.ph/fuso-philippines-delivers-10-canter-units-to-vic-imperial-appliance-corporation/) Press Release

[See all news](https://fuso.com.ph/news/)

##### Products

- [Find A Dealer](https://fuso.com.ph/dealers/)
- [Models](https://fuso.com.ph/models/)
- [Latest Offers](https://fuso.com.ph/latest-offers/)

##### Parts & Services

- [Parts](https://fuso.com.ph/parts-and-accessories/)
- [Services](https://fuso.com.ph/services/)

##### About Us

- [FUSO Brand](https://fuso.com.ph/brands/)
- [Corporate Profile](https://fuso.com.ph/company-profile/)
- [Contact us](https://fuso.com.ph/contact-us/)
- [Careers](https://fuso.com.ph/careers/)

##### News

- [Press Release](https://fuso.com.ph/category/press-release/)
- [Global News](https://www.mitsubishi-fuso.com/en/news/)

##### Site Policy

- [Terms of Use](https://fuso.com.ph/terms-of-use/)
- [Privacy Policy](https://fuso.com.ph/privacy-policy/)
- [Social Media Terms of Use](https://fuso.com.ph/sns-terms-of-use/)

© 2026 Sojitz Fuso Philippines Corporation. All rights reserved.

Follow us:

- [Facebook](https://facebook.com/FusoPhilippines)
- [Instagram](https://www.instagram.com/fuso.ph/)
- [Youtube](https://youtube.com/@FUSOPhilippines)

#### Privacy Policy

By using this website, you acknowledge that you have read, understood, and agreed to our [Privacy Policy](https://fuso.com.ph/privacy-policy/), and consent to the collection, use, and processing of your personal data by us.

1794401679635

[Phone](tel:+63495301390)

[Email](mailto:inquiry@fuso.com.ph)

Open chatychaty buttons

Hide chaty