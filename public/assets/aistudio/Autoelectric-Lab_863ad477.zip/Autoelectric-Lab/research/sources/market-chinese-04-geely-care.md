Source: https://geelyph.com/care
Title: Geely Care+ | Always For You
Fetched: 2026-11-11T10:06:19.644Z

[Home](https://www.geelyph.com/)

Models

![](https://www.geelyph.com/svgs/fold.svg)

- [![Geely](https://www.datocms-assets.com/197696/1789973788-monjaro_emi.png?auto=format%2Ccompress%2Cenhance&q=45&w=1440)](https://www.geelyph.com/models/geely-monjaro)
[**Geely Monjaro**](https://www.geelyph.com/models/geely-monjaro)

- [![Geely](https://www.datocms-assets.com/197696/1780295867-ex5-em-i.png?auto=format%2Ccompress%2Cenhance&q=45&w=1440)](https://www.geelyph.com/models/geely-ex5-em-i)
[**GEELY EX5 EM-i**](https://www.geelyph.com/models/geely-ex5-em-i)

- [![Geely](https://www.datocms-assets.com/197696/1780295918-ex5.png?auto=format%2Ccompress%2Cenhance&q=45&w=1440)](https://www.geelyph.com/models/geely-ex5?geely-ex5=)
[**GEELY EX5**](https://www.geelyph.com/models/geely-ex5?geely-ex5=)

- [![Geely](https://www.datocms-assets.com/197696/1780296440-ex2.png?auto=format%2Ccompress%2Cenhance&q=45&w=1440)](https://www.geelyph.com/models/geely-ex2)
[**GEELY EX2**](https://www.geelyph.com/models/geely-ex2)

- [![Geely](https://www.datocms-assets.com/197696/1780296305-coolray.png?auto=format%2Ccompress%2Cenhance&q=45&w=1440)](https://www.geelyph.com/models/new-coolray)
[**Coolray**](https://www.geelyph.com/models/new-coolray)

- [![Geely](https://www.datocms-assets.com/197696/1780296016-gx3.png?auto=format%2Ccompress%2Cenhance&q=45&w=1440)](https://www.geelyph.com/models/gx3-pro)
[**GX3 Pro**](https://www.geelyph.com/models/gx3-pro)

- [![Geely](https://www.datocms-assets.com/197696/1780296042-emgrand.png?auto=format%2Ccompress%2Cenhance&q=45&w=1440)](https://www.geelyph.com/models/new-emgrand?geely-ex5=)
[**Emgrand**](https://www.geelyph.com/models/new-emgrand?geely-ex5=)

- [![Geely](https://www.datocms-assets.com/197696/1780299047-okavango-elite.png?auto=format%2Ccompress%2Cenhance&q=45&w=1440)](https://www.geelyph.com/models/okavango-elite?okavango-elite=)
[**Okavango Elite**](https://www.geelyph.com/models/okavango-elite?okavango-elite=)


[Promos](https://www.geelyph.com/promo)

![](https://www.geelyph.com/svgs/fold.svg)

[News](https://www.geelyph.com/news)

![](https://www.geelyph.com/svgs/fold.svg)

[Geely Care+](https://www.geelyph.com/care)

![](https://www.geelyph.com/svgs/fold.svg)

[Find Us](https://www.geelyph.com/find-us)

![](https://www.geelyph.com/svgs/fold.svg)

[About Us](https://www.geelyph.com/about)

![](https://www.geelyph.com/svgs/fold.svg)

[Test Drive](https://www.geelyph.com/testdrive)

![](https://www.geelyph.com/svgs/fold.svg)

# Geely Care+ \| Always For You

![Geely](https://www.datocms-assets.com/197696/1772561404-kv4-1-1.jpg?auto=format%2Ccompress%2Cenhance&q=45&w=1440)

```
ALWAYS FOR YOU
```

![Geely](https://www.datocms-assets.com/197696/1767765194-geely-care-logo-black.png?auto=format%2Ccompress%2Cenhance&q=45&w=1440)

Delivering professional service to global standards,
fulfilling promises with efficiency and reliability,
and offering friendly, genuine care.
Geely Care+ goes beyond service and expectations,
It's your dependable mobility companion.
Always For You.

![Geely](https://www.datocms-assets.com/197696/1772561217-professional-1.png?auto=format%2Ccompress%2Cenhance&q=45&w=1440)

Professional

Precision care, expert solutions. Backed by global expertise and advanced technology.

![Geely](https://www.datocms-assets.com/197696/1776163656-0-4.jpg?auto=format%2Ccompress%2Cenhance&q=45&w=1440)

Efficient

Rapid response, seamless dispatch.
Intelligent systems accelerate every action.

![Geely](https://www.datocms-assets.com/197696/1766051279-friendly.jpg?auto=format%2Ccompress%2Cenhance&q=45&w=1440)

Friendly

Warm connections, genuine care.
Respectful support that puts you at ease.

Contact us

Email

[customercare.ph@geely.com](mailto:customercare.ph@geely.com)

Business Hours

**Monday to Friday \| 8:30AM to 5:30PM**

**(Except Non-Working Holidays)**

_Note: We will respond to your email within two working days. Thank you for your patience._

When you visit our website and other platforms (“Geely Platforms”) we use cookies and other similar tracking technologies to enhance the Geely Platforms functionality, performance, measure website traffic, analyze user behavior and adjust our content and services accordingly. If you click “Accept All” you consent to us processing your personal data for such purposes. If you click “Reject All” we will only use cookies and tracking technology which are strictly necessary for the functionality of the Geely Platform. For further information or to consent to specific cookies and tracking technology please click on Cookies Settings on the below.

Accept AllReject AllCookies Settings