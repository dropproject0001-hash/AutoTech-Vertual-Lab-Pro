Source: https://www.toyota-tech.eu/faq
Title: TechDoc New Generation
Fetched: 2026-11-11T10:13:49.518Z

## Frequently Asked Questions

_expand\_more_ _expand\_less_Q. What types of information and manuals are available?

The Toyota-Tech website contains a vast amount of information. For convenience this is broken down into related information groups. These are described below:

NEW CAR FEATURES (NCF)

A description of the features, construction and function of components and technologies contained within a vehicle. Also contained is a description of how to accurately identify a vehicle by its VIN (Vehicle Identity Number or chassis number) and model code. Correct identification of a vehicle is essential for correct ordering of some service or maintenance components.

REPAIR MANUALS (RM)

A complete reference for diagnostic codes, inspection and repair procedures for engine, transmission, transaxle, Instruments, fuel systems, cooling, suspension, brakes and safety systems such as SRS airbag and seat belts. There may also be separate publications (supplements) to support additional features or technologies introduced after the original manual was printed.

ELECTRICAL WIRING DIAGRAM (EWD)

Schematic layout of the vehicle wire diagram and components

Wire harness repair manuals

Connector replacement and effective repair of wire harness.

COLLISION DAMAGED BODY REPAIR MANUALS (BRM)

Dimensional drawings and repair procedures for reconstruction of damaged vehicles.

SERVICE DATA SHEETS (SDS)

A quick reference guide to capacities and basic maintenance information

SERVICE INFORMATION LIBRARY (SIL)

A complete reference library containing all published manuals including supplements for a specific vehicle. For example, NCF RM EWD BRM SDS.

ACCESSORY INSTALLATION MANUALS (AIM)

Installation procedures for accessories.

Homologation Documents (HODO)

These are the legal conformity documents necessary to support official accessories fitted to vehicles before sale. In some cases they may be required to support the vehicle certificate of conformity if you are importing or exporting a vehicle.

TECHNICAL SERVICE BULLETINS (TSB)

Additional service or repair information that may not be contained in the repair manual or supplementing information in the repair manual. See also campaign and recall bulletins

Maintenance Schedules

This provides the Toyota/Toyota pan-European service and maintenance requirements that determine what items need attention or replacement at specific time or distance intervals. (Please note: These are generic maintenance schedules for Europe, local operational conditions may create variations to these schedules due to harsh weather or driving conditions.) For more specific information on service schedules applicable in your country, please contact the official Toyota importer. Links to Toyota and Toyota national websites are included within the general information section of this website

Parts catalogue

Here you can find the part numbers for genuine Toyota parts. Please note that these part numbers are provided for reference purposes only. We cannot supply replacement parts via this website.

Flat rate Manuals (FRM)

These manuals indicate the specific time allowances to complete repair operations. Times are primarily created and used for judgement of warranty repair cost calculation. Whilst indicative, these times should not be used as an indication of repair time or cost in a retail repair. The conditions under which the repair is conducted will almost certainly be different to the warranty repair condition.

Special service tools (SST)

SST’s are the specific Toyota service tools required to perform many repairs. Differing from general, commonly available hand tools, these tools are designed and are applicable only to Toyota vehicles and may need specialist knowledge or training. These tools are available for order via the official Toyota Authorised repairer network.

IT2 Diagnostic Tool

The IT2 diagnostic tool helps to speed up many diagnostic operations. Like SST’s it is available to order the official Toyota Authorised repairer network. Regular new vehicle updates to the operational software for this tool are available on an annual subscription basis via this website.

Environmental Information

Useful environmental information for all aspects of Toyota ownership. From simple driving tips to improve fuel consumption to dismantling manuals for end of life disposal.

Emergency data

This information is primarily intended for emergency service (Fire and Police) for safe handling of potentially dangerous items (airbags and high voltage hybrid components) in the event of a vehicle being involved in a substantial collision.

_expand\_more_ _expand\_less_Q. What is the Toyota library?

A. The Toyota-Tech library is an on-line source of information for general repair and maintenance of Toyota or Lexus vehicles. The information and technical manuals available here are all genuine Toyota publications, the same as those used by Toyota technicians.

_expand\_more_ _expand\_less_Q. What range of vehicles is information available for?

A. Toyota-Tech supports information for Toyota and Lexus vehicles imported and sold by directly by Toyota Europe. Currently available are manuals and information for the majority of European specification vehicles sold since 1997. Many older vehicles are also supported.

_expand\_more_ _expand\_less_Q. How do I get access to the information?

A. You can search the library for manuals by publication type, model, model code or language or any combination. The search result will produce a list of available publications with icons to identify the available formats. Some publication types (for example Bulletins and Accessory installation manuals) are immediately available to view “free of charge” others require you to register and purchase a subscription.

Formats

Online view (Subscription required for some types)

Book or Compact disc (Available via the webshop or print a pick list and purchase via a local Toyota or Lexus dealer)

_expand\_more_ _expand\_less_Q. I purchased my vehicle in America, are the manuals available here the same?

A. No, Toyota-Tech supports information for Toyota and Lexus vehicles imported and sold by directly by Toyota Europe. For information on vehicles imported from markets outside of Europe you should contact the Toyota distributor in your market. Manuals for vehicles produced for Japan domestic markets are usually only available in Japanese language.

_expand\_more_ _expand\_less_Q. How do I get access to the information?

A. The library is segregated into six logical groups to assist you to narrow your search. Once you have located the information type you require, you can then search the library for information by publication type, model, model code or language or combination. This will produce a list of available publications with icons to identify the available formats.

_expand\_more_ _expand\_less_Q. Premium and Free to view content

A. The Toyota-Tech website contains both payable and free to view content. You must first register to view any content. You can view free-to-view content or purchase any hardcopy items via the webshop once you are a registered user. However to view payable or premium content you will need to purchase a subscription, which only takes a few minutes. Subscriptions allow you to view any content for an amount of time from one hour up to one year.

_expand\_more_ _expand\_less_Q. Why do I need to register?

A. Registration helps us to better understand your needs and preferences and improve your experience of the website. When you log-in we will know if you have a valid subscription and provide access to all valid content immediately. Also if you wish to purchase hardcopy items through our webshop, we will pre-fill all the necessary information.

_expand\_more_ _expand\_less_Q. My Profile?

You can review and edit your registration details by clicking the “My Profile” link.

_expand\_more_ _expand\_less_Q. My Responsibilities?

Before you use any of the information contained on the Toyota-Tech website:

Be sure you are technically competent to carry out the repair or procedure.

Read all the warning, cautions and safety procedures.

Work in a safe manner and carry out all safety precautions

Use the correct tools where specified

If you are in any doubt about a repair or procedure, seek advice from a qualified professional.

Observe the copyright notices.

_expand\_more_ _expand\_less_Q. Lost password?

If you have forgotten your password, it can be retrieved automatically by following the procedure below

If you supplied a valid email address when you registered your account with Toyota/Lexus Publications, you can use this form to have your password automatically emailed to that address. Otherwise, you can send an email to **info@Toyota-tech.eu** including your Name and User ID - to request your password.

To request that your password be sent to your email address on record, please enter your **User ID** in the textbox at left.

Clicking the Submit button will process this request, and your password will be sent to your email address.

_expand\_more_ _expand\_less_Q. Your Privacy?

Please take a moment to view the Legal Notice (located at the bottom of the homepage) regarding the collection of your personal information.

_expand\_more_ _expand\_less_Q. System Requirements?

To experience the full range of features offered by this website, we recommend the following system specifications:

**Operating System Environment**

**Windows:** Windows 98, NT 4.0, 2000, XP

**Memory:** 128 MB RAM

**Disk Storage:** 10 MB available hard-drive space

**Display Resolution:** 1024 x 768 pixels (1280 x 720 recommended)

**Web Browser Support**

**Windows**: Internet Explorer 8+, Chrome, Firefox

**Required Support:** Javascript, CSS, Cookies

**Pop-Up blockers:**

This Web Site makes use of pop-up Windows to make certain information available to you. In order to get the full benefit from the Toyota-Tech Websites, please set your browser to “Allow pop-ups”. Note: Windows XP SP2 installs and enables a pop-up blocker automatically. This has to be disabled or configured to allow pop-ups from the Toyota-Tech site

**Additional Software/Plugins**

**Adobe Acrobat Reader:** Version 4.0 or later

Click the link below to download and install Acrobat Reader:

_expand\_more_ _expand\_less_Q. Pop-Up blockers?

This Web Site makes use of pop-up Windows to make certain information available to you. In order to get the full benefit from the Toyota-Tech Websites, please set your browser to “Allow pop-ups”. Note: Windows XP SP2 installs and enables a pop-up blocker automatically. This has to be disabled or configured to allow pop-ups from the Toyota-Tech site

_expand\_more_ _expand\_less_Q. COPYRIGHT Notice?

All content of these manuals is protected by copyright. You may only use the information, text, pictures or graphics contained in this manual for your personal use or within the scope of your normal business. You may not reproduce, modify, transmit, license or publish these manuals, in whole or in part, for any purpose without the prior written consent of Toyota Motor Corporation.

© 2026, Toyota Motor Corporation

All rights reserved.

_expand\_more_ _expand\_less_Q. Links to other websites?

The Toyota-Tech website contains many links to other website. Some of those sites may not be in the direct control of Toyota or its affiliate companies. Toyota Motor co. and Toyota Europe cannot be considered responsible for the content of any site outside the context of the Toyota-Tech website.

_expand\_more_ _expand\_less_Q. The publication I'm looking for is not available, what can I do now?

A. If you don’t find a publication, try reducing your search criterion to one field only and search again, for example just search for a model and leave the other fields blank.

Please also remember that the core language for all Toyota publications is English and the vast majority of Publications contained within this site are English language based. Some publications were not translated into all European languages.

If you still do not find a publication, unfortunately it may not yet be available on TechDoc.

Please use the “Contact Us ” link in the left side tool menu to inform us of the model and year information you are looking for. We continually assess the demand for information on previous generation models and continually add more models and information. Please add us to your favourites and check regularly to see if the information becomes available.

_expand\_more_ _expand\_less_Q. I found the publication I want. How can I view it online?

A. First you need to register with us and purchase an online subscription. Subscriptions can be completed within a few minutes and can be for as little as one hour or last up to one year. You will then be able to view all available Toyota and Lexus information. You do need to log-in to each site separately.

_expand\_more_ _expand\_less_Q. How much does an on-line subscription cost?

A. Subscriptions are offered in hourly, daily, weekly, monthly or yearly intervals. Current subscription costs are displayed on the Toyota-Tech subscriptions page. All costs are quoted in Euro and subject to VAT at the applicable rate for your country. All subscriptions expire at midnight, CET on the last day of your term. This means for example, that a one-day subscription may actually provide greater than 24 hours of usable access.

_expand\_more_ _expand\_less_Q. Is it safe to provide my credit card number and personal information?

A. Toyota-Tech e-Commerce uses a secure payment system. All sensitive information is encrypted in accordance with the 128-bit SSL standard in accordance with the transmission and security protocols set and certified by the financial institutions. Your credit card number is sent only to the financial body making the transaction.

Our technical specialists keep up to date with the latest developments in the field to provide you with a safe, reliable system. Our servers are protected by firewalls, access to our databases is strictly controlled, and sensitive information is encrypted. The security of your personal information and payments is our prime concern.

_expand\_more_ _expand\_less_Q. I found the manual I want. How do I purchase a copy to keep?

A. If you want book or CD copy of the manual, simply click the book or CD icon to add the manual to your order list. Chosen item delivered directly to your door. Follow the simple steps through our webshop and receive your product within a few days. You can even track the progress of your purchase through this website.

Alternatively, an order list can be printed and taken to your local Toyota or Lexus agent who will order the publication for you. This will normally be available to you within 10 to 15 working days from order.

_expand\_more_ _expand\_less_Q. I am viewing on-line Will I be able to print the information?

A. Yes. You can print information and keep it for your personal use. However please refer to the copyright section of these notes.

_expand\_more_ _expand\_less_Q. Can I download and resell the information from the TechDoc library?

A. All information in this site is protected by copyright. If you have purchased a valid subscription. You may extract and repurpose technical data for reuse in other formats.

You cannot however reproduce or republish from the current formats. You cannot reuse illustrations or verbatim text in whole or in part, for any purpose without the express written consent of Toyota Motor Europe. The Toyota and Lexus names, marks and designs are registered trademarks. The Toyota and Lexus marks and designs may not be used, downloaded, copied or distributed in any way.

Please refer to the copyright section of these notes.

_expand\_more_ _expand\_less_Q. Can I share my account?

A. No. The subscription terms are per individual - it is not a site license subscription. Your account and access will be terminated if cases of multiple usages are detected. In such cases, all rights to unexpired elements of subscriptions will be void.

_expand\_more_ _expand\_less_Q. I have a problem with my vehicle, Who can answer my technical questions?

A. Toyota-Tech does not operate a technical support helpline. Toyota-Tech provides access to the technical publications that may contain the answer to your question. If you cannot find the answer, we suggest that you make contact with the main Toyota distributor in your area and seek advice.

_expand\_more_ _expand\_less_Q. I have a problem with my vehicle the local dealer cannot fix.

A. Unfortunately we cannot assist. You should contact your local Toyota or Lexus distributor. If you contact Toyota-Tech by e-mail we will pass on your comment to the central customer relations department at Toyota Europe in Brussels, however we can not take any other direct actions.

_expand\_more_ _expand\_less_Q. I have a question about Toyota.

A. Unfortunately we cannot assist. You should contact your local Toyota or Lexus distributor. If you contact Toyota-Tech by e-mail we will pass on your comment to the central customer relations department at Toyota Europe in Brussels. However it will be quicker if you contact them direct at: cust.service@Toyota-europe.com

_expand\_more_ _expand\_less_Q. I am a student and want more technical information to support my studies.

A. Unfortunately we cannot assist. You should contact your local Toyota or Lexus distributor. If you contact Toyota-Tech by e-mail we will pass on your comment to the central customer relations department at Toyota Europe in Brussels. However it will be quicker if you contact them direct at: cust.service@Toyota-europe.com

_expand\_more_ _expand\_less_Q. I have paid my subscription but still cannot see any data?

There are two possible causes for this, the following should solve any problems.

A. Most Toyota-Tech documents are displayed in Adobe PDF format and require the Adobe Acrobat Reader Version 4.x or later to be installed for viewing. If two Acrobat viewers are installed at the same time (such as version 3.0 and 4.0), the viewer may open but show a blank page. Solution: uninstall previous versions and install Adobe© PDF Reader 5.x or later. You can download the latest version of the Adobe viewer at www.adobe.com

B. Toyota-Tech makes use of pop-up windows to make certain information available to you. In order to get the full benefit from the Toyota-Tech Websites, please set your browser to "Allow pop-ups". Note: Windows XP SP2 installs and enables a pop-up blocker automatically. This has to be disabled or configured to allow pop-ups from the Toyota-Tech site.

_expand\_more_ _expand\_less_Q. Can I turn off my security warning messages?

A. It is important to note that certain pages within Toyota-Tech are secure (or https://) to protect your account information and other library content pages are not secure to improve performance. Some browsers will detect changes from a secure mode to not secure mode and may display the security-warning message. Follow these steps to turn off the security warning message in the Internet Explorer Browser: From the Internet Explorer Browser Menu Bar, Click on View or Tools depending upon version, and Click on 'Internet Options'. A window will open, then click on the 'Advanced' Tab. Now scroll down to 'Security'. Uncheck the box under 'Security' to Warn if changing between secure and not secure mode.

_expand\_more_ _expand\_less_Q. Toyota does not fit within my browser window - why?

A. Toyota-Tech is optimized for 1024 x 768 pixels (1280 x 720 recommended). If your hardware can support it, we recommend changing your Desktop Properties Screen Area to use 1024x768 resolution. Right click on your Desktop and choose Properties, click on the Settings Tab, and adjust the screen resolution, then click OK to save the changes.

_expand\_more_ _expand\_less_Q. I wish to contact you about the Toyota site.

A. Please use the “Contact ” link at the bottom of the Toyota-Tech home page to inform us of your comments.

We have staff who are conversant with English, French, German and Dutch languages.

Critical Warning - Takata Airbag Recall and Replacement - Check your vehicle