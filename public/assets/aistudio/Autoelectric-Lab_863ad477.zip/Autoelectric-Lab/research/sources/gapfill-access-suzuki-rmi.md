Source: https://www.suzuki.ch/de/informationen-werkstatten
Title: Informationen für Werkstätten | Suzuki Schweiz AG
Fetched: 2026-11-11T10:09:05.726Z

![Suzuki, S-Cross Seitenansicht auf Strasse](https://www.suzuki.ch/assets/image/2c8df25a49444168b7e107b58486a2b6/27cd8b4faa954710a79c7f7e7842d9c2?auto=format&w=1920&h=1080&fit=crop)![Suzuki, S-Cross Seitenansicht auf Strasse](https://www.suzuki.ch/assets/image/2c8df25a49444168b7e107b58486a2b6/27cd8b4faa954710a79c7f7e7842d9c2?auto=format&w=1920&h=2560&fit=crop)

# Wartung & Pflege – Service Portal Europa

## Reparatur- und Wartungsinformationen für freie Werkstätten

Über das [Suzuki European Service Portal](https://serviceportal.suzuki.eu/isoportal/) erhalten freie Werkstätten Zugang zu den gleichen Werkstattinformationen sowie zu den gleichen Bedingungen wie unsere offiziellen Suzuki Partner. Dies beinhaltet Wartungs- und Reparaturinformationen, Service Bulletins, Diagnose-Software sowie eine Abfrage offener Service- und Rückrufaktionen. Mit diesen Informationen wird es freien Werkstätten ermöglicht, die fachgerechte Wartung und Instandsetzung von Suzuki Fahrzeugen vornehmen zu können.

Für den Zugang zum Suzuki European Service Portal werden Gebühren erhoben.

[Zum Service Portal](https://serviceportal.suzuki.eu/isoportal/)

![](https://cdn.builder.io/api/v1/pixel?apiKey=2c8df25a49444168b7e107b58486a2b6)