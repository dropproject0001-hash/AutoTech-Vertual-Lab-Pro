Source: https://www.mitsubishitechinfo.com/epacarb/home.jsp
Title: Mitsubishi Motors Service Information Retrieval
Fetched: 2026-11-11T10:13:52.871Z

Service Information Retrieval1

|     |     |
| --- | --- |
| |     |     |
| --- | --- |
| ![](https://www.mitsubishitechinfo.com/epacarb/images/mitsubishi_logo3.png) | HomeService Information <br> Special ToolsR2R & J2534 Pass-ThruVehicle SecurityTechnical TrainingGlobal SearchGlossary | |
| |     |     |
| --- | --- |
| ![](https://www.mitsubishitechinfo.com/epacarb/images/h_left_blue2.jpg) | |     |     |
| --- | --- |
| ![](https://www.mitsubishitechinfo.com/epacarb/images/h_Tsquare.jpg) | Choose Language:   English   \|  French |
| ![](https://www.mitsubishitechinfo.com/epacarb/images/home_mdl.jpg) |
| ![](https://www.mitsubishitechinfo.com/epacarb/images/h_Bsquare.jpg) | _**Welcome!**_<br>_My Account_   \|  _Logoff_ | | |

Home

| | Member Login |
| --- |
| |     |
| --- |
| User Name<br>Password<br>* * *<br>[Forget Password?](https://www.mitsubishitechinfo.com/epacarb/passwordreq.jsp)<br>Or [Forget User ID?](https://www.mitsubishitechinfo.com/epacarb/passwordreq.jsp)<br>**Click Here** to become a new member or [**Renew**](https://www.mitsubishitechinfo.com/epacarb/renewmember.jsp) your current subscription. | |

|     |
| --- |
| This web site best viewed in:

[Internet \\
Explorer 11+](https://www.microsoft.com/en-us/download/internet-explorer.aspx)

[Chrome](https://www.google.com/chrome/)

* * *

|     |
| --- |
| Minimum System Specs:<br>Pentium or equivalent<br> (2.9 ghz or higher)<br> 2GB RAM Memory |
| Recommended <br> Monitor Settings:<br>1440x900 | | | |     |     |
| --- | --- |
| |     |     |
| --- | --- |
| Starting November 14th, all users will be required to authenticate using two factor authentication (2FA). This feature will be implemented using Google Authenticator and requires a mobile device with the Google Authenticator application installed. For 2FA related support please contact the MEDIC Hotline 800-846-7575.

MITSUBISHI MOTORS NORTH AMERICA, Inc.
presents this web site to all members of the automotive repair community in the United States. Its purpose is to provide electronic access to vehicle service information to everyone from independent repair shops to Mitsubishi dealers to vehicle owners. It includes any and all Service Information related to Mitsubishi passenger cars and sport utility vehicles equipped with OBD-II (On-Board Diagnostic System).

|     |
| --- |
| **This site contains service information exclusively for**<br>**Mitsubishi passenger vehicles sold in the United States and Canada** |

|     |
| --- |
| - Service manual data, Technical Service Bulletin data, and other related materials<br>- Scan tools, reprogramming tools<br>- Technical Training materials.<br>Before becoming a member you have the option to perform a **[Global Search](https://www.mitsubishitechinfo.com/epacarb/GlobalSearchController)** to see what type of material is available for the vehicle you're servicing.<br>Please read our [**Warnings and Cautions**](https://www.mitsubishitechinfo.com/epacarb/home.jsp#) section before attempting any repair procedures |

Once you have signed in as a registered user, you will have access to all of the electronic information provided for 1995 and newer Mitsubishi vehicles, U.S. models only**.** This will allow you to view, print or purchase any service items related to**OBD-II.**[**Click Here**](https://www.mitsubishitechinfo.com/epacarb/newmember.jsp) to learn more about becoming a member.

**If you don't need a subscription and only need information regarding the ScanTool, or to purchase printed materials like Service Manuals and Technical Training Materials,** **[Click Here](https://www.mitsubishitechinfo.com/epacarb/specialtools.jsp)**

* * *

Listed below are the major components of our web site. The information is provided to assist you in repairing Mitsubishi vehicles.

[SERVICE INFORMATION OVERVIEW](https://www.mitsubishitechinfo.com/epacarb/svcoverview.jsp)

This section has Service Manuals, TSBs, Recalls, and other Technical Information.

[ELECTRIC & OTHER EMERGENCY RESPONSE GUIDES](https://www.mitsubishitechinfo.com/epacarb/electricemergencymanuals.jsp)

This section has emergency procedures information.

[ANTI-THEFT RADIO CODE RETRIEVAL](https://www.mitsubishicars.com/owners/support/radio-code)

This section provides the necessary information for resetting an anti-theft radio after it has lost power from the vehicle?s battery.

SEAT BELT INSTALLATION INSTRUCTIONS

This document has important information regarding seat belt installation, usage and maintenance.

[TECHNICAL TRAINING MATERIAL OVERVIEW](https://www.mitsubishitechinfo.com/epacarb/ttoverview.jsp)

In this section you will be able to search for any Technical Training Modules, Student Learning Guides, and Training Videos (VHS & CD)

[SCAN TOOL (MUT-III)](https://www.mitsubishitechinfo.com/epacarb/specialtools.jsp#scantool)

Multi-Use Tester III is Mitsubishi’s newest generation diagnostic tool (scan tool). You can learn more about price and availability of the tool on our Special Tools Page. As of 5/26/2014, the Scan Tool (MUT-III) software is at Version 30.

[ECU INITIALIZATION & REPROGRAMMING](https://www.mitsubishitechinfo.com/epacarb/specialtools.jsp#ecu)

ECU Reprogramming is made easy with Mitsubishi’s new Multi-Use Tester – III scan tool. Find out more about price and availability of the tool on our Special Tools Page.

[SITE MAP & SPECIAL LINKS](https://www.mitsubishitechinfo.com/epacarb/sitemap.jsp)

If you are having trouble finding the information you need, check out our Site Map.  Also included are special links to our affiliates, where you can order Service Manuals, Training Materials, Videos, etc. | |     |
| --- |
| Legacy Data |
| Mitsubishi's technical information database includes Technical Service Bulletins, Recalls, and Campaigns since 1982. The database also provides limited information for older models, such as Starion, Van, Truck, etc. Our service manual database includes all models since 1996 and even some models as far back as 1992 like Montero & 3000GT. | | | |  |
|  | |     |
| --- |
| * * *<br> © All Rights Reserved - 2026 MITSUBISHI MOTORS NORTH AMERICA, Inc.<br> <br>Mitsubishi <br>has designed this website to fully comply with [EPA](http://www.epa.gov/)<br>(Environmental Protection Agency) and [CARB](http://www.arb.ca.gov/homepage.htm) <br>(California Air Resources Board) regulations, and the [NASTF](http://www.nastf.org/) <br>(National Automotive Service Task Force) voluntary service information <br>& tool availability commitment supported by the [AAM](http://www.autoalliance.org/) <br>(Alliance of Automobile Manufacturers) and the [AIAM](http://www.aiam.org/) <br>(Association of International Automobile Manufacturers) | |  |

Service Information Retrieval

|     |
| --- |
| |     |
| --- |
| ![](https://www.mitsubishitechinfo.com/epacarb/images/btn_contact_a.gif)![](https://www.mitsubishitechinfo.com/epacarb/images/btn_member_a.gif)![](https://www.mitsubishitechinfo.com/epacarb/images/btn_sitemap_a.gif)![](https://www.mitsubishitechinfo.com/epacarb/images/btn_help_a.gif)![](https://www.mitsubishitechinfo.com/epacarb/images/btn_privacy_a.gif)![](https://www.mitsubishitechinfo.com/epacarb/images/btn_user_a.gif)[![](https://www.mitsubishitechinfo.com/epacarb/images/btn_mitsubishi_a.gif)](http://www.mitsubishicars.com/) | |


<body bgcolor="#FFFFFF" text="#000000" >
</body>