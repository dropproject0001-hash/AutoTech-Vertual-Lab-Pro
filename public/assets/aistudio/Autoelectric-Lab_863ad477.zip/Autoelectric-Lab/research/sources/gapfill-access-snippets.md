# Gap-fill access and tool-manufacturer source snippets

Search date: 2026-11-11. Snippets are search-result excerpts and support only the statements present in the excerpt. They do not establish information absent from the excerpt.

## Honda TechInfo / Service Information System

### RJAAI001_LOGON_CONTENT.htm — American Honda / Honda Canada TechInfo
URL: https://techinfo.honda.com/rjanisis/pubs/Web/RJAAI001_LOGON_CONTENT.htm
Retrieved by search: 2026-11-11. `webFetch` returned the host's “Site down for maintenance” page, not the SIS content.
Search snippet: “Service Information System (SIS) is American Honda and Honda Canada's service repair information website for independent repair shops and vehicle owners. This information covers all Honda and Acura vehicles from 1990 to current.”
Scope note: This establishes the named US/Canada service-information resource and its described vehicle coverage, not Philippine access/applicability or a formal ServiceExpress discontinuation date.

### Honda Independent Repair Website User’s Guide — American Honda
URL: https://techinfo.honda.com/rjanisis/pubs/web/SvcExp_QS_CHE.pdf
Publication identifier: AJA 49496 (0513), indicating 2013; fetched URL returned the host maintenance page.
Search snippet: “Service Express is American Honda’s Web-based system for delivering electronic service publications to the aftermarket. In Service Express, technicians have access to the same service information available to Honda dealers.”
Scope note: Historical description only. It does not prove the present state of ServiceExpress or explicitly document a replacement transition.

## Suzuki European Service Portal

### Informationen für Werkstätten — Suzuki Schweiz AG
URL: https://www.suzuki.ch/de/informationen-werkstatten
Fetched page is saved at `research/sources/gapfill-access-suzuki-rmi.md`; no separate snippet is needed for claims cited from that fetched page.

## Alientech and Abrites Toyota/Denso references

### Adapter for Denso ECU (NEC 76F00xx Board Type B) — Alientech
URL: https://www.alientech-tools.com/en/accessories/kess3-adapter-for-denso-ecu-nec-76f00xx-board-type-b/
Fetched page is saved at `research/sources/gapfill-access-alientech-denso.md`; no separate snippet is needed for claims cited from that fetched page.

### ECU Programming Tool manual — Abrites
URL: https://abrites.com/media/user_manuals/html/ecu-programming-tool-user-manual/index.html?v=1676465645
Fetched manual is saved at `research/sources/gapfill-access-abrites-manual.md`; no separate snippet is needed for claims cited from that fetched page.
