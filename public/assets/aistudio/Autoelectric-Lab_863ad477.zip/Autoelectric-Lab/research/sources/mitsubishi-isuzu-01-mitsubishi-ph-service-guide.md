Source: https://www.mitsubishi-motors.com.ph/service/service-guide
Title: Service Guide | Mitsubishi Motors Philippines
Fetched: 2026-11-11T10:05:42.443Z

![Service Guide](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/service-campaigns/service-guide/mitsubishi-repair-edited.jpg?width=1440&auto=webp&quality=70)

# GUIDE TO PERIODIC ​MAINTENANCE SERVICE

Whether your Mitsubishi is brand-new or has seen ​countless miles, we have a tailored maintenance ​plan ready to keep it running smoothly.

# Select your Mitsubishi vehicle for the specific guide

Maintain your Mitsubishi vehicles in top-notch condition with ​our comprehensive PMS guide

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/service-campaigns/service-guide/Mirage-HB-2.jpg?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/mirage-periodic-maintenance-service)

## Mirage

[Download PMS Guide](https://www.mitsubishi-motors.com.ph/service/service-guide/mirage-periodic-maintenance-service)

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/service-campaigns/service-guide/ell-gls-sport-all-models.jpg?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/G4-periodic-maintenance-service)

## Mirage G4

[Download PMS Guide](https://www.mitsubishi-motors.com.ph/service/service-guide/G4-periodic-maintenance-service)

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/service-campaigns/service-guide/XForce%20Model%20Lineup.png?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/xforce-periodic-maintenance-service)

## Xforce

[Download PMS Guide](https://www.mitsubishi-motors.com.ph/service/service-guide/xforce-periodic-maintenance-service)

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/service-campaigns/service-guide/XPANDER-NEW.jpg?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/xpander-periodic-maintenance-service)

## Xpander

[Download PMS Guide](https://www.mitsubishi-motors.com.ph/service/service-guide/xpander-periodic-maintenance-service)

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/service-campaigns/service-guide/NEW-XPANDER-Cross.jpg?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/xpander-cross-periodic-maintenance-service)

## Xpander Cross

[Download PMS Guide](https://www.mitsubishi-motors.com.ph/service/service-guide/xpander-cross-periodic-maintenance-service)

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/cars/model-lineup/Montero%20Sport.jpg?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/montero-periodic-maintenance-service)

## Montero Sport

[Download PMS Guide](https://www.mitsubishi-motors.com.ph/service/service-guide/montero-periodic-maintenance-service)

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/service-campaigns/service-guide/background.png?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/triton-periodic-maintenance-service)

## Triton

[Download PMS Guide](https://www.mitsubishi-motors.com.ph/service/service-guide/triton-periodic-maintenance-service)

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/service-campaigns/service-guide/L300%20B.jpg?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/L300-periodic-maintenance-service)

## L300

[Download PMS Guide](https://www.mitsubishi-motors.com.ph/service/service-guide/L300-periodic-maintenance-service)

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/cars/model-lineup/25MY%20Montero%20Sport.jpg?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/montero-25my-periodic-maintenance)

## Montero Sport 25MY

[Download PMS Guide](https://www.mitsubishi-motors.com.ph/service/service-guide/montero-25my-periodic-maintenance)

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/service-campaigns/service-guide/Destinator.png?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/destinator-periodic-maintenance)

## Destinator

[Download PMS Guide](https://www.mitsubishi-motors.com.ph/service/service-guide/destinator-periodic-maintenance)

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/service-campaigns/service-guide/Versa%20Van.png?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/versa-van-periodic-maintenance)

## Versa Van

[Download PMS Guide](https://www.mitsubishi-motors.com.ph/service/service-guide/versa-van-periodic-maintenance)

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/cars/model-lineup/Outlander%20PHEV.png?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/outlander-phev-periodic-maintenance)

## Outlander PHEV

[Download PMS Guide](https://www.mitsubishi-motors.com.ph/service/service-guide/outlander-phev-periodic-maintenance)

# Other Service Guidelines

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/service-campaigns/service-guide/splash%20resized%203.png?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/article-page/care-flood)

## MITSUBISHI CARE: What to do if your car has been submerged in a flood

Here's a guide on what every owner must do after their car has been submerged in a flood

[Learn how to care for your car after a flood](https://www.mitsubishi-motors.com.ph/service/service-guide/article-page/care-flood)

[![](https://www.mitsubishi-motors.com.ph/content/dam/mitsubishi-motors-ph/images/site-images/service-campaigns/service-guide/steering%20wheel%20resized%203.jpg?width=720&auto=webp&quality=70)](https://www.mitsubishi-motors.com.ph/service/service-guide/article-page/driving-manual)

## TRANSMISSION 101: Guide on How to Drive a Manual Transmission Vehicle

Here is a basic guideline to operate your manual transmission vehicle.

[Read the safe driving manual](https://www.mitsubishi-motors.com.ph/service/service-guide/article-page/driving-manual)

## Service Guide

### What would you like to do next?

[Book a Service](https://mmpc-customer.otoleap.com/)[Find a Dealer](https://www.mitsubishi-motors.com.ph/dealer-locator)

- [Price List](https://www.mitsubishi-motors.com.ph/price-list)
- [Car Configurator](https://www.mitsubishi-motors.com.ph/customer-tools/configure)
- [Dealer Locator](https://www.mitsubishi-motors.com.ph/dealer-locator)
- [Test Drive](https://www.mitsubishi-motors.com.ph/sales/test-drive)
- [Get a Quote](https://www.mitsubishi-motors.com.ph/sales/quotation)
- [Brochures](https://www.mitsubishi-motors.com.ph/customer-tools/download-a-brochure)

Mitsubishi Motors Philippines Corporation (MMPC) places utmost importance and respects your right to privacy. MMPC shall handle with utmost care all personal and sensitive information that you may provide or those that we may collect from you upon your use of the website in accordance with our [Privacy Policy](https://www.mitsubishi-motors.com.ph/privacy-policy). By closing this banner, scrolling this page or clicking any part of it, you hereby acknowledge that you have read and understood our Privacy Policy and expressly consent to it.

I agree