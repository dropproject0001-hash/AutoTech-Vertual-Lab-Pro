Source: https://mc.suzuki.com.ph/motorcycles-price-list
Title: Best Suzuki Bike Motorcycle Philippines Price List
Fetched: 2026-11-11T12:55:47.457Z

![Suzuki Motorcycles Philippines](https://mc.suzuki.com.ph/wp-content/uploads/2025/01/DPO-DPS-Image.png)

Manage Consent

This website uses cookies to enable it to perform properly, remember your browsing history and to arrange contents that will match your preferred interests more efficiently. The details of the cookies that Suzuki Philippines Incorporated (SPH) use can be found on our [**Privacy Policy**](https://mc.suzuki.com.ph/privacy-policy/) . By clicking the Accept button, closing this banner, scrolling this page or clicking any part of it, you agree to our use of cookies.

FunctionalFunctional
Always active

The technical storage or access is strictly necessary for the legitimate purpose of enabling the use of a specific service explicitly requested by the subscriber or user, or for the sole purpose of carrying out the transmission of a communication over an electronic communications network.

PreferencesPreferences

The technical storage or access is necessary for the legitimate purpose of storing preferences that are not requested by the subscriber or user.

StatisticsStatistics

The technical storage or access that is used exclusively for statistical purposes.The technical storage or access that is used exclusively for anonymous statistical purposes. Without a subpoena, voluntary compliance on the part of your Internet Service Provider, or additional records from a third party, information stored or retrieved for this purpose alone cannot usually be used to identify you.

MarketingMarketing

The technical storage or access is required to create user profiles to send advertising, or to track the user on a website or across several websites for similar marketing purposes.

[Manage options](https://mc.suzuki.com.ph/privacy-policy/#cmplz-manage-consent-container) [Manage services](https://mc.suzuki.com.ph/privacy-policy/#cmplz-cookies-overview) [Manage {vendor\_count} vendors](https://mc.suzuki.com.ph/privacy-policy/#cmplz-tcf-wrapper) [Read more about these purposes](https://cookiedatabase.org/tcf/purposes/)

ACCEPT ALLDENYVIEW PREFERENCESSAVE PREFERENCES [VIEW PREFERENCES](https://mc.suzuki.com.ph/privacy-policy/#cmplz-manage-consent-container)

[Privacy Policy](https://mc.suzuki.com.ph/privacy-policy/) [Privacy Policy](https://mc.suzuki.com.ph/privacy-policy/) [Get in Touch](https://mc.suzuki.com.ph/contact-us/)

![](https://mc.suzuki.com.ph/wp-content/uploads/2023/10/BURGMAN-WHITE-.gif)[Skip to content](https://mc.suzuki.com.ph/motorcycles-price-list/#content)

Buyer's Guide

# Take home a new motorcycle today and let it take you anywhere!

Looking for the best road partner that can take you anywhere? We offer an extensive range of motorcycles, from regular to big bikes. Check our buyer’s guide for more information.

[DOWNLOAD BUYER’S GUIDE](https://mc.suzuki.com.ph/wp-content/uploads/2026/02/Complete_Buyers_Guide_LANDSCAPE_FEB-2026-scaled.jpg)

## scooter

Ride easy, ride fun with Suzuki’s automatic motorcycles

[![](https://mc.suzuki.com.ph/wp-content/uploads/2026/06/Burgman-15-Thumb-white-300x239.png)\\
\\
**Burgman 15**\\
\\
**SRP ₱ 165,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
10.6kW @ 8,500 RPM \\
\\
14.2Nm 6,500 RPM \\
\\
FUEL TANK\\
\\
8 L \\
\\
ENGINE DISPLACEMENT\\
\\
149CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/scooter/burgman-15/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2025/10/Ride-Connect-Access.png)\\
\\
**Access Ride Connect Edition**\\
\\
**SRP ₱ 94,900**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
6.2 KW / 6,500 RPM \\
\\
10.2 NM / 5,000 RPM \\
\\
FUEL TANK\\
\\
5.3 L \\
\\
ENGINE DISPLACEMENT\\
\\
124CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/scooter/access-ride-connect/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2025/10/Access-Standard.png)\\
\\
**Access**\\
\\
**SRP ₱ 85,900**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
6.2 KW / 6,500 RPM \\
\\
10.2 NM / 5,000 RPM \\
\\
FUEL TANK\\
\\
5.3 L \\
\\
ENGINE DISPLACEMENT\\
\\
124CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/scooter/access/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2024/02/AvenisPrevFeb18-300x193.png)\\
\\
**Avenis**\\
\\
**SRP ₱ 81,400**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
6.4 kW / 7000 rpm \\
\\
10 NM / 5,500 RPM \\
\\
FUEL TANK\\
\\
5.2 L \\
\\
ENGINE DISPLACEMENT\\
\\
124CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/scooter/avenis/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2023/11/Skydrive-Sport-card-300x193.png)\\
\\
**Skydrive Sport**\\
\\
**SRP ₱ 73,900**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
6.7 KW / 8,000 RPM \\
\\
8.5 NM / 6,000 RPM \\
\\
FUEL TANK\\
\\
3.6 L \\
\\
ENGINE DISPLACEMENT\\
\\
113.0CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/scooter/skydrive-sport/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2024/02/burgman_125_ex-300x193.png)\\
\\
**Burgman Street 125 EX**\\
\\
**SRP ₱ 93,400**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
6.4 kW / 7,000 rpm \\
\\
10.2 Nm / 5,000 rpm \\
\\
FUEL TANK\\
\\
5.5 L \\
\\
ENGINE DISPLACEMENT\\
\\
124CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/scooter/burgman-street-125-ex/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2023/11/Burgman-Street-Standard-Candy-Red-300x194.png)\\
\\
**Burgman Street**\\
\\
**SRP ₱ 84,400**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
6.4 KW / 7,000 RPM \\
\\
10.2 NM / 5,000 RPM \\
\\
FUEL TANK\\
\\
5.5 L \\
\\
ENGINE DISPLACEMENT\\
\\
124CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/scooter/burgman-street/)

## underbone

Ride easy, ride fun with Suzuki’s automatic motorcycles

[![](https://mc.suzuki.com.ph/wp-content/uploads/2025/11/Raider-Blade-150-300x193.png)\\
\\
**Raider R150**\\
\\
**SRP starts at ₱ 130,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
13.5 KW / 10,000 RPM \\
\\
13.8 NM / 8,500 RPM \\
\\
FUEL TANK\\
\\
4 L \\
\\
ENGINE DISPLACEMENT\\
\\
147CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/underbone/raider-r150-blade/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2025/11/Raider-Pro-300x193.png)\\
\\
**Raider PRO**\\
\\
**SRP ₱ 146,400**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
13.5 KW / 10,000 RPM \\
\\
13.8 NM / 8,500 RPM \\
\\
FUEL TANK\\
\\
4 L \\
\\
ENGINE DISPLACEMENT\\
\\
147CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/underbone/raider-pro/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2024/02/SFIMMBPrevFeb10.png)\\
\\
**Smash Fi**\\
\\
**SRP starts at ₱ 68,400**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
6.9 KW / 7,000 RPM \\
\\
9.10 NM / 6,500 RPM \\
\\
FUEL TANK\\
\\
3.7 L \\
\\
ENGINE DISPLACEMENT\\
\\
113CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/underbone/smash-fi/)

[![Smash Carb mags thumbnail](https://mc.suzuki.com.ph/wp-content/uploads/2024/02/Smash-Carb-mags-thumbnail-3-300x245.png)\\
\\
**Smash Carb**\\
\\
**SRP starts at ₱ 64,400**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
5.6 KW / 7,000 RPM \\
\\
9.0 NM / 4,000 RPM \\
\\
FUEL TANK\\
\\
4.5 L \\
\\
ENGINE DISPLACEMENT\\
\\
109.7CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/underbone/smash-carb/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2024/02/image-7-2-300x193.png)\\
\\
**Raider J Crossover**\\
\\
**SRP ₱ 71,900**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
6.8 KW / 7,500 RPM \\
\\
9.0 NM / 6,500 RPM \\
\\
FUEL TANK\\
\\
3.7 L \\
\\
ENGINE DISPLACEMENT\\
\\
113CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/underbone/raider-j-crossover/)

## backbone

Ride easy, ride fun with Suzuki’s automatic motorcycles

[![Gn160-v2-thumbnail](https://mc.suzuki.com.ph/wp-content/uploads/2026/09/Gn160-v2-thumbnail.png)\\
\\
**GN160**\\
\\
**SRP ₱ 125,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
10.5 kW @ 8,000 rpm \\
\\
14.5 Nm 6,500 rpm \\
\\
FUEL TANK\\
\\
11L \\
\\
ENGINE DISPLACEMENT\\
\\
162 cc \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/backbone/gn160/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2026/04/Vstrom-Thumb-1.png)\\
\\
**V-STROM 160**\\
\\
**SRP ₱ 146,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
11 kW @ 8,000rpm \\
\\
14 Nm @ 6,500 rpm \\
\\
FUEL TANK\\
\\
13L \\
\\
ENGINE DISPLACEMENT\\
\\
162 cc \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/backbone/v-strom-160/)

[![DR 160 thumb](https://mc.suzuki.com.ph/wp-content/uploads/2026/04/DR-160-thumb-2-300x229.webp)\\
\\
**DR160**\\
\\
**SRP ₱ 129,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
10.5kW @ 8,000rpm \\
\\
14.5Nm 6,500 rpm \\
\\
FUEL TANK\\
\\
12.2L \\
\\
ENGINE DISPLACEMENT\\
\\
162 cc \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/backbone/dr-160/)

[![Gixxer 155 2026 New color](https://mc.suzuki.com.ph/wp-content/uploads/2024/10/GIXXER155PrevFeb6-300x193.png)\\
\\
**GIXXER 155**\\
\\
**SRP ₱ 106,400**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
10.4 KW / 8,000 RPM \\
\\
14.0 Nm / 6,000 rpm \\
\\
FUEL TANK\\
\\
12 L \\
\\
ENGINE DISPLACEMENT\\
\\
155CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/backbone/gixxer-155/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2024/10/Untitled-Catalog0779-1-768x494-1-300x193.webp)\\
\\
**GIXXER SF 155**\\
\\
**SRP ₱ 116,900**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
10.4 KW / 8,000 RPM \\
\\
14.0 NM / 6,000 RPM \\
\\
FUEL TANK\\
\\
12 L \\
\\
ENGINE DISPLACEMENT\\
\\
155CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/backbone/gixxer-sf155/)

[![V strom 250 SV Thumbnail](https://mc.suzuki.com.ph/wp-content/uploads/2023/10/V-strom-250-SV-Thumbnail-2-300x245.png)\\
\\
**V-STROM 250 SX**\\
\\
**SRP ₱ 229,900**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
19.5 KW / 9,300 RPM \\
\\
22.2 NM / 7,300 RPM \\
\\
FUEL TANK\\
\\
12 L \\
\\
ENGINE DISPLACEMENT\\
\\
249CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/backbone/v-strom-250-sx/)

[![Gixxer 250 Blue Thumbnail](https://mc.suzuki.com.ph/wp-content/uploads/2023/11/Gixxer-250-Blue-Thumbnail-300x208.png)\\
\\
**GIXXER 250**\\
\\
**SRP ₱ 182,900**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
19.49 KW / 9,300 RPM \\
\\
22.6 NM / 7,500 RPM \\
\\
FUEL TANK\\
\\
12 L \\
\\
ENGINE DISPLACEMENT\\
\\
249CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/backbone/gixxer-250/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2023/11/GSX-SF-250--300x208.png)\\
\\
**GIXXER SF 250**\\
\\
**SRP ₱ 192,900**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
19.49 KW / 9,300 RPM \\
\\
22.6 NM / 7,500 rpm \\
\\
FUEL TANK\\
\\
12 L \\
\\
ENGINE DISPLACEMENT\\
\\
249CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/backbone/gixxer-sf-250/)

## big bikes

Ride easy, ride fun with Suzuki’s automatic motorcycles

[![](https://mc.suzuki.com.ph/wp-content/uploads/2026/01/DR-Z4S-thumbnail.png)\\
\\
**DR-Z4S**\\
\\
**SRP ₱ 589,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
28 kW @ 8,000 rpm \\
\\
37 Nm @ 6,500 rpm \\
\\
FUEL TANK\\
\\
8.7 L (2.3/1.9 US/lmp gal) \\
\\
ENGINE DISPLACEMENT\\
\\
398 cm³ (24.3 cu. in.) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/dr-z4s/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2026/01/DR-Z4SM-thumbnail.png)\\
\\
**DR-Z4SM**\\
\\
**SRP ₱ 589,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
28 kW @ 8,000 rpm \\
\\
37 Nm @ 6,500 rpm \\
\\
FUEL TANK\\
\\
8.7 L (2.3/1.9 US/lmp gal) \\
\\
ENGINE DISPLACEMENT\\
\\
398 cm³ (24.3 cu. in.) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/dr-z4sm/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2025/08/8T-NO-BG-SHADOW-1-300x193.webp)\\
\\
**GSX-8T**\\
\\
**SRP ₱ 699,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
62 kW @ 8,500 rpm \\
\\
78 Nm @ 6,500 rpm \\
\\
FUEL TANK\\
\\
16.5 L (4.3/3.6 US/LMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
776 CM3 (47.4 CU. IN.) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/gsx-8t/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2025/08/8TT-NO-BG-SHADOW-300x193.webp)\\
\\
**GSX-8TT**\\
\\
**SRP ₱ 729,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
62 kW @ 8,500 rpm \\
\\
78 Nm @ 6,500 rpm \\
\\
FUEL TANK\\
\\
14 L (4.3/3.6 US/LMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
776 CM3 (47.4 CU. IN.) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/gsx-8tt/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2024/04/image-7-gsx-8r-png-300x193.png)\\
\\
**GSX-8R**\\
\\
**SRP ₱ 699,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
62 kW @ 8,500 rpm \\
\\
78 Nm @ 6,800 rpm \\
\\
FUEL TANK\\
\\
14 L (3.7/3.1 US/LMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
776CC (47.4 CU. IN) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/gsx-8r/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2024/04/image-7GSX-S1000GX-1-300x193.png)\\
\\
**GSX-S1000GX**\\
\\
**SRP ₱ 969,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
112 kW @ 11,000 rpm \\
\\
106 Nm @ 9,250 rpm \\
\\
FUEL TANK\\
\\
19 L (5.0/4.2 US/LMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
999 cm3 (61.0 cu. in.) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/gsx-s1000gx/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2023/10/1-300x208.png)\\
\\
**GSX-8S**\\
\\
**SRP ₱ 631,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
62 kW @ 8,500 rpm \\
\\
78 Nm @ 6,800 rpm \\
\\
FUEL TANK\\
\\
14 L (3.7/3.1 US/IMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
776CC (24.4 CU. IN) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/gsx-8s/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2023/10/3-2-300x218.png)\\
\\
**V-STROM 800DE**\\
\\
**SRP ₱ 759,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
62 kW @ 8,500 rpm \\
\\
78 Nm @ 6,800 rpm \\
\\
FUEL TANK\\
\\
20.0 L (5.3 US GAL / 4.4 LMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
776CC (47.4 CU. IN) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/v-strom-800-de/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2023/10/2-3-300x231.png)\\
\\
**V-STROM 1050DE**\\
\\
**SRP ₱ 939,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
79 kW @ 8,500 rpm \\
\\
100 Nm @ 6,000 rpm \\
\\
FUEL TANK\\
\\
20.0 LITER (5.3 US GAL / 4.4 IMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
1,037CC (63.3 CU IN) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/v-strom-1050-de/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2023/11/image-7-18-copy-5-300x193.png)\\
\\
**GSX-S1000GT**\\
\\
**SRP ₱ 842,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
101 kW @ 10,360 rpm \\
\\
99 Nm @ 9,190 rpm \\
\\
FUEL TANK\\
\\
19.0 L (5.0/4.2 US/LMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
999CC (61.0 CU. IN) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/gsx-s1000gt/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2023/11/B-1-300x218.png)\\
\\
**GSX-S1000**\\
\\
**SRP ₱ 806,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
112 kW @ 11,000 rpm \\
\\
106 Nm @ 9,250 rpm \\
\\
FUEL TANK\\
\\
19.0 L (5.0/4.2 US/LMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
999CC (61.0 CU. IN) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/gsx-s1000/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2023/11/A-2-300x243.png)\\
\\
**SV650**\\
\\
**SRP ₱ 449,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
54.7 kW @ 8,400 rpm \\
\\
64 Nm @ 6,400 rpm \\
\\
FUEL TANK\\
\\
14.5 L (3.8/3.2 US/LMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
645CC (39.4 CU. IN) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/sv650/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2024/02/image-7-26-300x193.png)\\
\\
**Burgman 400**\\
\\
**SRP ₱ 566,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
22.4 kW @ 6,300 rpm \\
\\
35 Nm @ 4,800 rpm \\
\\
FUEL TANK\\
\\
13.5 L (3.6/3.0 US/LMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
400CC (24.4 CU. IN) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/burgman-400/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2023/11/motosm-300x201.png)\\
\\
**Hayabusa**\\
\\
**SRP ₱ 1,235,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
139.44 kW @ 9,700 rpm \\
\\
150 Nm @ 7,000 rpm \\
\\
FUEL TANK\\
\\
20 L (5.3 US GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
1,340CC (81.8 CU. IN) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/hayabusa/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2023/11/1-6-300x193.png)\\
\\
**GSX-R1000R**\\
\\
**SRP ₱ 1,219,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
144.9 KW @ 13,200 RPM \\
\\
117 Nm @ 10,800 RPM \\
\\
FUEL TANK\\
\\
16 L (4.2/3.5 US/LMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
999.8CC (61.0 CU. IN) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/gsx-r1000r/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2023/11/gsx-r1000_2--300x193.png)\\
\\
**GSX-R1000**\\
\\
**SRP ₱ 1,099,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
144.9 KW @ 13,200 RPM \\
\\
117 Nm @ 10,800 RPM \\
\\
FUEL TANK\\
\\
16.0 L \\
\\
ENGINE DISPLACEMENT\\
\\
999CC (61.0 CU. IN) \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/gsx-r1000/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2024/02/image-7-28-300x193.png)\\
\\
**RM-Z450**\\
\\
**SRP ₱ 585,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
36.9 kW @ 8,800 RPM \\
\\
45.01 Nm @ 8,800 RPM \\
\\
FUEL TANK\\
\\
6.3 L (1.6/1.4 US/LMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
449CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/rm-z450/)

[![](https://mc.suzuki.com.ph/wp-content/uploads/2024/02/image-7-27-300x193.png)\\
\\
**RM-Z250**\\
\\
**SRP ₱ 559,000**\\
\*Subject to each dealer\\
\\
POWER / TORQUE\\
\\
27.06 kW @ 11,500 RPM \\
\\
25.2 Nm @ 9,100 RPM \\
\\
FUEL TANK\\
\\
6.3 L (1.6/1.4 US/LMP GAL) \\
\\
ENGINE DISPLACEMENT\\
\\
249CC \\
\\
COLOR VARIANTS](https://mc.suzuki.com.ph/motorcycles/big-bike/rm-z250/)

Manage consent