Source: https://www.udtrucks.com/philippines/trucks
Title: Heavy, Medium & Light Duty Trucks
Fetched: 2026-11-11T12:56:11.100Z

[Skip to main content](https://www.udtrucks.com/philippines/trucks#main-content)

We noticed that you are visiting from Norway. Would you like to go to the Global website?

[Yes](https://www.udtrucks.com/)No

- [Trucks](https://www.udtrucks.com/philippines/trucks)















Select Segments





ALL MODELS











ALL MODELS














Heavy duty










[![Quester](https://www.udtrucks.com/sites/default/files/2022-11/Quester.png)](https://www.udtrucks.com/philippines/trucks/quester)



[![Quester](https://www.udtrucks.com/sites/default/files/styles/truck_menu/public/2022-11/Quester%20-%20Trucks%20Carousel_2.png?itok=J3CbfWlA)](https://www.udtrucks.com/philippines/trucks/quester)





[Quester](https://www.udtrucks.com/philippines/trucks/quester)



[View Specs](https://www.udtrucks.com/philippines/trucks/quester/specs)
















Medium duty










[![Croner](https://www.udtrucks.com/sites/default/files/2022-11/Croner.png)](https://www.udtrucks.com/philippines/trucks/croner)



[![Croner](https://www.udtrucks.com/sites/default/files/styles/truck_menu/public/2022-11/Croner%20-%20Trucks%20Carousel_3.png?itok=mchSAK1i)](https://www.udtrucks.com/philippines/trucks/croner)





[Croner](https://www.udtrucks.com/philippines/trucks/croner)



[View Specs](https://www.udtrucks.com/philippines/trucks/croner/specs)

















Quick Link



  - [Brochure Gallery](https://www.udtrucks.com/philippines/trucks/brochure-gallery)
  - [Truck Selector](https://www.udtrucks.com/philippines/trucks/find-truck)

- [Service](https://www.udtrucks.com/philippines/service-parts)











  - SERVICE









    - [Genuine Parts](https://www.udtrucks.com/philippines/service-parts/genuine-parts)

    - [UD Connected Services](https://www.udtrucks.com/philippines/service-parts/ud-connected-services-0)

    - [Genuine Service](https://www.udtrucks.com/philippines/service-parts/genuine-service)

    - [UD Financial Services](https://www.udtrucks.com/philippines/service-parts/ud-financial-services)

    - [UD Trust](https://www.udtrucks.com/philippines/service-parts/ud-trust)

    - [Telematics](https://www.udtrucks.com/philippines/service-parts/telematics)


  - For OWNERS









    - [UD Mobile Workshop](https://www.udtrucks.com/philippines/service-parts/ud-mobile-workshop)

    - [UD Road Support](https://www.udtrucks.com/philippines/service-parts/ud-road-support)

    - [Connected Services](https://www.udtrucks.com/philippines/service-parts/connected-services)


- [News](https://www.udtrucks.com/philippines/news-and-stories)











  - NEWS AND STORY









    - [News & Stories](https://www.udtrucks.com/philippines/news-and-stories)

    - [Media Gallery](https://www.udtrucks.com/philippines/news-and-stories/mediagallery)


  - LATEST NEWS







    [![Grupo ng tao sa harap ng dalawang trak, may gusali at event banner sa likod.](https://www.udtrucks.com/sites/default/files/styles/news_article_detail_page/public/article-images/IMG_0517%20%28002%29.jpeg?itok=wu6f5cNy)\\
    \\
    UD Trucks News\\
    \\
    April 24, 2026\\
    \\
    \\
    **UD Trucks Philippines Completes Nationwide Customer Roadshow Series.**\\
    \\
    Read More](https://www.udtrucks.com/philippines/news-and-stories/news/ud-trucks-philippines-completes-nationwide-customer-roadshow-series)



    [![UD Trucks extends vehicle warranty during the COVID-19 lockdown period in Philippines ](https://www.udtrucks.com/sites/default/files/styles/news_article_detail_page/public/article-images/UD-top-mark_1440x551_21.jpg?itok=1o3NOUF2)\\
    \\
    Press release\\
    \\
    April 22, 2020\\
    \\
    \\
    **UD Trucks extends vehicle warranty during the COVID-19 lockdown period in Philippines**\\
    \\
    Read More](https://www.udtrucks.com/philippines/news-and-stories/news/ud-trucks-extends-vehicle-warranty-during-the-covid-19)



    [![ud](https://www.udtrucks.com/sites/default/files/styles/news_article_detail_page/public/article-images/UD-top-mark_1440x551_25.jpg?itok=HWue-zb4)\\
    \\
    Press release\\
    \\
    January 17, 2019\\
    \\
    \\
    **UD Trucks has launched the new Quester in South Africa**\\
    \\
    Read More](https://www.udtrucks.com/philippines/news-and-stories/news/ud-trucks-has-launched-the-new-quester-in-south-africa)


- [About UD](https://www.udtrucks.com/philippines/about-us)











  - About UD
  - Company









    - Company
    - [Company Profile](https://www.udtrucks.com/philippines/about-us/company/company-profile)

    - [UDEC](https://www.udtrucks.com/philippines/about-us/company/udec)


  - Our Purpose









    - Our Purpose
    - [Overview](https://www.udtrucks.com/philippines/about-us/our-purpose/overview)


  - Sustainability









    - Sustainability
    - [Strategy](https://www.udtrucks.com/philippines/about-us/sustainability/strategy)

    - [Logistics](https://www.udtrucks.com/philippines/about-us/sustainability/logistics)

    - [Business](https://www.udtrucks.com/philippines/about-us/sustainability/business)

    - [Planet](https://www.udtrucks.com/philippines/about-us/sustainability/the-planet)

    - [People](https://www.udtrucks.com/philippines/about-us/sustainability/people)

    - [Sustainability Report](https://www.udtrucks.com/philippines/about-us/sustainability/sustainability-report)

    - [Code of Conduct](https://www.udtrucks.com/philippines/about-us/sustainability/code-of-conduct)

    - [Policies](https://www.udtrucks.com/philippines/about-us/sustainability/policies)


  - Who we are









    - Who we are
    - [UD Values](https://www.udtrucks.com/philippines/about-us/who-we-are/ud-values)

    - [Our Culture](https://www.udtrucks.com/philippines/about-us/who-we-are/our-culture)

    - [Our People](https://www.udtrucks.com/philippines/about-us/who-we-are/our-people)

    - [Challenger Story](https://www.udtrucks.com/philippines/about-us/who-we-are/challenger-story)


  - Innovation









    - Innovation
    - [Innovation for Smart Logistic](https://www.udtrucks.com/philippines/about-us/innovation/innovation-for-smart-logistic)

    - [UDAS](https://www.udtrucks.com/philippines/about-us/innovation/udas)

    - [Product History](https://www.udtrucks.com/philippines/about-us/innovation/product-history)


  - Events









    - Events
    - [Extra Mile Challenge](https://www.udtrucks.com/philippines/about-us/events/extra-mile-challenge)

    - [UD Gemba Challenge](https://www.udtrucks.com/philippines/about-us/events/gemba-challenge)

    - [Tokyo Motor Show 2019](https://www.udtrucks.com/philippines/about-us/events/tokyo-motor-show-2019)


- [Careers](https://www.udtrucks.com/philippines/careers)


- [Find Dealer](https://www.udtrucks.com/philippines/dealers/find-dealer)

- [Philippines](https://www.udtrucks.com/philippines)


- [Contact Us](https://www.udtrucks.com/philippines/contact-us)


- Trucks

- [Overview](https://www.udtrucks.com/philippines/trucks)

- [Quester](https://www.udtrucks.com/philippines/trucks/quester)

- [Croner](https://www.udtrucks.com/philippines/trucks/croner)


- [Brochure Gallery](https://www.udtrucks.com/philippines/trucks/brochure-gallery)

- [Find Truck](https://www.udtrucks.com/philippines/trucks/find-truck)


[Contact Us](mailto: inquiry@primequest.com.ph)

- [Trucks](https://www.udtrucks.com/philippines/trucks)









Select Segments





ALL MODELS











ALL MODELS














Heavy duty










[![Quester](https://www.udtrucks.com/sites/default/files/2022-11/Quester.png)](https://www.udtrucks.com/philippines/trucks/quester)



[![Quester](https://www.udtrucks.com/sites/default/files/styles/truck_menu/public/2022-11/Quester%20-%20Trucks%20Carousel_2.png?itok=J3CbfWlA)](https://www.udtrucks.com/philippines/trucks/quester)





[Quester](https://www.udtrucks.com/philippines/trucks/quester)



[View Specs](https://www.udtrucks.com/philippines/trucks/quester/specs)
















Medium duty










[![Croner](https://www.udtrucks.com/sites/default/files/2022-11/Croner.png)](https://www.udtrucks.com/philippines/trucks/croner)



[![Croner](https://www.udtrucks.com/sites/default/files/styles/truck_menu/public/2022-11/Croner%20-%20Trucks%20Carousel_3.png?itok=mchSAK1i)](https://www.udtrucks.com/philippines/trucks/croner)





[Croner](https://www.udtrucks.com/philippines/trucks/croner)



[View Specs](https://www.udtrucks.com/philippines/trucks/croner/specs)

















Quick Link



  - [Brochure Gallery](https://www.udtrucks.com/philippines/trucks/brochure-gallery)
  - [Truck Selector](https://www.udtrucks.com/philippines/trucks/find-truck)

- [Service](https://www.udtrucks.com/philippines/service-parts)



  - SERVICE



    - [Genuine Parts](https://www.udtrucks.com/philippines/service-parts/genuine-parts)

    - [UD Connected Services](https://www.udtrucks.com/philippines/service-parts/ud-connected-services-0)

    - [Genuine Service](https://www.udtrucks.com/philippines/service-parts/genuine-service)

    - [UD Financial Services](https://www.udtrucks.com/philippines/service-parts/ud-financial-services)

    - [UD Trust](https://www.udtrucks.com/philippines/service-parts/ud-trust)

    - [Telematics](https://www.udtrucks.com/philippines/service-parts/telematics)


  - For OWNERS



    - [UD Mobile Workshop](https://www.udtrucks.com/philippines/service-parts/ud-mobile-workshop)

    - [UD Road Support](https://www.udtrucks.com/philippines/service-parts/ud-road-support)

    - [Connected Services](https://www.udtrucks.com/philippines/service-parts/connected-services)


- [News](https://www.udtrucks.com/philippines/news-and-stories)



  - NEWS AND STORY



    - [News & Stories](https://www.udtrucks.com/philippines/news-and-stories)

    - [Media Gallery](https://www.udtrucks.com/philippines/news-and-stories/mediagallery)


  - LATEST NEWS







    [![Grupo ng tao sa harap ng dalawang trak, may gusali at event banner sa likod.](https://www.udtrucks.com/sites/default/files/styles/news_article_detail_page/public/article-images/IMG_0517%20%28002%29.jpeg?itok=wu6f5cNy)\\
    \\
    UD Trucks News\\
    \\
    April 24, 2026\\
    \\
    \\
    **UD Trucks Philippines Completes Nationwide Customer Roadshow Series.**\\
    \\
    Read More](https://www.udtrucks.com/philippines/news-and-stories/news/ud-trucks-philippines-completes-nationwide-customer-roadshow-series)



    [![UD Trucks extends vehicle warranty during the COVID-19 lockdown period in Philippines ](https://www.udtrucks.com/sites/default/files/styles/news_article_detail_page/public/article-images/UD-top-mark_1440x551_21.jpg?itok=1o3NOUF2)\\
    \\
    Press release\\
    \\
    April 22, 2020\\
    \\
    \\
    **UD Trucks extends vehicle warranty during the COVID-19 lockdown period in Philippines**\\
    \\
    Read More](https://www.udtrucks.com/philippines/news-and-stories/news/ud-trucks-extends-vehicle-warranty-during-the-covid-19)



    [![ud](https://www.udtrucks.com/sites/default/files/styles/news_article_detail_page/public/article-images/UD-top-mark_1440x551_25.jpg?itok=HWue-zb4)\\
    \\
    Press release\\
    \\
    January 17, 2019\\
    \\
    \\
    **UD Trucks has launched the new Quester in South Africa**\\
    \\
    Read More](https://www.udtrucks.com/philippines/news-and-stories/news/ud-trucks-has-launched-the-new-quester-in-south-africa)


- [About UD](https://www.udtrucks.com/philippines/about-us)



  - Company



    - [Company Profile](https://www.udtrucks.com/philippines/about-us/company/company-profile)

    - [UDEC](https://www.udtrucks.com/philippines/about-us/company/udec)


  - Our Purpose



    - [Overview](https://www.udtrucks.com/philippines/about-us/our-purpose/overview)


  - Sustainability



    - [Strategy](https://www.udtrucks.com/philippines/about-us/sustainability/strategy)

    - [Logistics](https://www.udtrucks.com/philippines/about-us/sustainability/logistics)

    - [Business](https://www.udtrucks.com/philippines/about-us/sustainability/business)

    - [Planet](https://www.udtrucks.com/philippines/about-us/sustainability/the-planet)

    - [People](https://www.udtrucks.com/philippines/about-us/sustainability/people)

    - [Sustainability Report](https://www.udtrucks.com/philippines/about-us/sustainability/sustainability-report)

    - [Code of Conduct](https://www.udtrucks.com/philippines/about-us/sustainability/code-of-conduct)

    - [Policies](https://www.udtrucks.com/philippines/about-us/sustainability/policies)


  - Who we are



    - [UD Values](https://www.udtrucks.com/philippines/about-us/who-we-are/ud-values)

    - [Our Culture](https://www.udtrucks.com/philippines/about-us/who-we-are/our-culture)

    - [Our People](https://www.udtrucks.com/philippines/about-us/who-we-are/our-people)

    - [Challenger Story](https://www.udtrucks.com/philippines/about-us/who-we-are/challenger-story)


  - Innovation



    - [Innovation for Smart Logistic](https://www.udtrucks.com/philippines/about-us/innovation/innovation-for-smart-logistic)

    - [UDAS](https://www.udtrucks.com/philippines/about-us/innovation/udas)

    - [Product History](https://www.udtrucks.com/philippines/about-us/innovation/product-history)


  - Events



    - [Extra Mile Challenge](https://www.udtrucks.com/philippines/about-us/events/extra-mile-challenge)

    - [UD Gemba Challenge](https://www.udtrucks.com/philippines/about-us/events/gemba-challenge)

    - [Tokyo Motor Show 2019](https://www.udtrucks.com/philippines/about-us/events/tokyo-motor-show-2019)


- [Careers](https://www.udtrucks.com/philippines/careers)

- [Find Dealer](https://www.udtrucks.com/philippines/dealers/find-dealer)

- [Philippines](https://www.udtrucks.com/philippines)

- [Contact Us](mailto: inquiry@primequest.com.ph)


Search

Select a Market


- Global
[Global](https://www.udtrucks.com/)
- Asia Pacific
[Australia](https://www.udtrucks.com/australia) [China](https://www.udtrucks.com/china) [Hong Kong (Region of China)](https://www.udtrucks.com/hongkong) [Indonesia](https://www.udtrucks.com/indonesia) [Japan](https://www.udtrucks.com/japan) [Korea](https://www.udtrucks.com/korea) [Malaysia](https://www.udtrucks.com/malaysia) [Cambodia](https://www.udtrucks.com/cambodia) [Myanmar](https://www.udtrucks.com/myanmar) [New Zealand](https://www.udtrucks.com/newzealand) [Philippines](https://www.udtrucks.com/philippines) [Vietnam](https://www.udtrucks.com/vietnam) [Singapore](https://www.udtrucks.com/singapore) [Taiwan (Province of China)](https://www.udtrucks.com/taiwan) [Thailand](https://www.udtrucks.com/thailand) [India](https://www.udtrucks.com/india)
- Africa and Middle East
[MEENA](https://www.udtrucks.com/meena) [South Africa](https://www.udtrucks.com/southafrica) [Kenya](https://www.udtrucks.com/kenya) [Egypt](https://www.udtrucks.com/egypt)
- Americas
[Latin America](https://www.udtrucks.com/latinamerica) [United States](https://www.udtrucks.com/unitedstates)

- Global
[Global](https://www.udtrucks.com/)
- Asia Pacific
[Australia](https://www.udtrucks.com/australia) [China](https://www.udtrucks.com/china) [Hong Kong (Region of China)](https://www.udtrucks.com/hongkong) [Indonesia](https://www.udtrucks.com/indonesia) [Japan](https://www.udtrucks.com/japan) [Korea](https://www.udtrucks.com/korea) [Malaysia](https://www.udtrucks.com/malaysia) [Cambodia](https://www.udtrucks.com/cambodia) [Myanmar](https://www.udtrucks.com/myanmar) [New Zealand](https://www.udtrucks.com/newzealand) [Philippines](https://www.udtrucks.com/philippines) [Vietnam](https://www.udtrucks.com/vietnam) [Singapore](https://www.udtrucks.com/singapore) [Taiwan (Province of China)](https://www.udtrucks.com/taiwan) [Thailand](https://www.udtrucks.com/thailand) [India](https://www.udtrucks.com/india)
- Africa and Middle East
[MEENA](https://www.udtrucks.com/meena) [South Africa](https://www.udtrucks.com/southafrica) [Kenya](https://www.udtrucks.com/kenya) [Egypt](https://www.udtrucks.com/egypt)
- Americas
[Latin America](https://www.udtrucks.com/latinamerica) [United States](https://www.udtrucks.com/unitedstates)

[Return to Global](https://www.udtrucks.com/philippines)

![](https://www.udtrucks.com/sites/default/files/styles/hero_desktop_crop/public/2022-10/Trucks.jpeg?itok=kvR3gGtP)

# Trucks

Trucks

- [Overview](https://www.udtrucks.com/philippines/trucks)

- [Quester](https://www.udtrucks.com/philippines/trucks/quester)

- [Croner](https://www.udtrucks.com/philippines/trucks/croner)

- [Brochure Gallery](https://www.udtrucks.com/philippines/trucks/brochure-gallery)

- [Find Truck](https://www.udtrucks.com/philippines/trucks/find-truck)


## Experience our wide range of UD Trucks built to help you deliver greatness

UD Trucks provides a full range of heavy duty, medium duty and light duty trucks, with models optimized for mature markets and growth markets. It’s our best truck range ever. Supported by our smart service solutions, our products excel in fuel efficiency, drivability, safety, productivity and uptime.

### Heavy duty

![Quester](https://www.udtrucks.com/sites/default/files/styles/image_text_component/public/2022-11/Quester.png?itok=mRUXoOkT)

Quester

Quester

Quester focuses on the features and benefits that make your business grow. Benefits such as higher productivity, extended uptime and increased fuel-efficiency.

[Read More](https://www.udtrucks.com/philippines/trucks/quester)

### Medium duty

![Croner](https://www.udtrucks.com/sites/default/files/styles/image_text_component/public/2022-11/Croner.png?itok=5sKgKamc)

Croner

Croner

Croner, saving you the most precious resource of all: Time. Go the extra mile with the truck that makes every moment count.

[Read More](https://www.udtrucks.com/philippines/trucks/croner)

### FIND DEALER

With our extensive partner network, you are never too far from a UD Trucks dealer or service center.

[Dealer Search](https://www.udtrucks.com/philippines/dealers/find-dealer)

For Buyers

[![Truck](https://www.udtrucks.com/sites/default/files/styles/thumbnail_image_video_pc_crop/public/2022-10/truck_0.png?h=a07cc34a&itok=uZjDjksA)\\
\\
Truck Selector](https://www.udtrucks.com/philippines/trucks/find-truck)

[![Find Dealer](https://www.udtrucks.com/sites/default/files/styles/thumbnail_image_video_pc_crop/public/2022-10/Find-Dealer.png?itok=qFju95hd)\\
\\
Find Dealer](https://www.udtrucks.com/philippines/dealers/find-dealer)

[![Contact Us](https://www.udtrucks.com/sites/default/files/styles/thumbnail_image_video_pc_crop/public/2022-10/Contact-Us.png?itok=qBIA_nSX)\\
\\
Contact Us](mailto:inquiry@primequest.com.ph)

[![Brochure Gallery](https://www.udtrucks.com/sites/default/files/styles/thumbnail_image_video_pc_crop/public/2022-10/Brochure_0.png?h=97371e4a&itok=xrGkrnwd)\\
\\
Brochure Gallery](https://www.udtrucks.com/philippines/trucks/brochure-gallery)

[![Financial](https://www.udtrucks.com/sites/default/files/styles/thumbnail_image_video_pc_crop/public/2022-10/Financial_0.png?h=14b6af04&itok=60j0dPsa)\\
\\
Financial Services](https://www.udtrucks.com/philippines/service-parts/ud-financial-services)

A2A