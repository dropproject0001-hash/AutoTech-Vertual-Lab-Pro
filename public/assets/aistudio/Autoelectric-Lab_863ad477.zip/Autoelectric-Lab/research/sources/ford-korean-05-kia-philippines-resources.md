Source: https://kiaphilippines.com/owners/manual-and-resources
Title: Manual & Resources | Kia Philippines
Fetched: 2026-11-11T10:06:26.386Z

[PBV](https://kiaphilippines.com/nav-vehicle-tag/pbv)

[Sedan](https://kiaphilippines.com/nav-vehicle-tag/sedan)

[Hybrid/Electric](https://kiaphilippines.com/nav-vehicle-tag/hybrid-electric)

[SUV/Crossover/MPV](https://kiaphilippines.com/nav-vehicle-tag/suv-crossover-mpv)

[Skip to main menu](https://kiaphilippines.com/owners/manual-and-resources#main)

Use of Cookies

We collect data, including through the use of cookies and similar technology ("cookies") that enhance the online experience. By clicking “Accept" you agree to our use of cookies, agree to be bound by our Terms of Service, and acknowledge our [**Privacy Statement**](https://kiaphilippines.com/legal/privacy-policy).

[Accept & Close\\
\\
Accept & Close](https://kiaphilippines.com/owners/manual-and-resources#)

# Manuals & Guides

Download digital PDF copies of the owner's manual for your Kia model.

Kia recommends you download and/or print a copy of the Owners’ Manual if travelling to areas where internet access may be limited.

Select VehicleSelect VehiclePV5 CargoEV3SportageSonetK2500CarnivalSorentoEV5EV9Soluto

Thank you! Your submission has been received!

Oops! Something went wrong while submitting the form.

## Kia Dealer Network

Locate an authorized Kia dealer near you and get expert support for sales, service, and ownership.

[Find a Kia Dealer](https://kiaphilippines.com/shopping-tools/dealership)

![Map showing multiple Kia Motors locations in and around Manila, Philippines, including Kia Sta. Mesa, Kia Pasig, Kia Ortigas, and Kia Marikina.](https://cdn.prod.website-files.com/690ecd59178f856fe5e9d5ed/6911ae167fad8b2d6afe46da_36534d1325222764dcaa05a2104a0d07_b4d11d21a93784e28c478dbc92de25048b085019%20%281%29.avif)

### Schedule a Test Drive

Experience the performance and comfort of a Kia firsthand.

[![](https://cdn.prod.website-files.com/690ecd59178f856fe5e9d5ed/691477459e0e5885f3bc8a9f_chevron_right.svg)\\
Request a Test Drive\\
\\
Request a Test Drive](https://kiaphilippines.com/shopping-tools/request-a-test-drive-old)

![Schedule test drive at KIA Philippines](https://cdn.prod.website-files.com/690ecd59178f856fe5e9d5ed/6911aed1831f21f8cbed0f4c_c47d9bc7589d16e8e967334ed8881cb2_4a086646af78707935e0a13e5b9bd33790f9a4f8%20%281%29.avif)

## Find your Kia

Step into the Kia experience today. Explore our latest models and connect with our expert team to find the Kia that fits your lifestyle and driving needs.

[Request a Quote\\
\\
Request a Quote](https://kiaphilippines.com/shopping-tools/request-a-quote) [![](https://cdn.prod.website-files.com/690ecd59178f856fe5e9d5ed/691477459e0e5885f3bc8a9f_chevron_right.svg)\\
See Our Price List\\
\\
See Our Price List](https://kiaphilippines.com/shopping-tools/pricelist)

![KIA Vertical Slide Icon](https://cdn.prod.website-files.com/690ecd59178f856fe5e9d5ed/696117392b382bcf836580fd_Vector%208.svg)