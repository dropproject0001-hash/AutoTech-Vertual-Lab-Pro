Source: https://toyota.com.ph/service-campaign/articles/0000000034
Title:   | Toyota Motor Philippines
Fetched: 2026-11-11T12:55:13.101Z

SSC
TOYOTA SERVICE CAMPAIGN

# Special Service Campaign for Engine ECU Reprogramming on Toyota Raize Model

As part of its corporate commitment to product safety and quality, Toyota Motor Philippines (TMP) has launched a Special Service Campaign to conduct reprogramming of the Engine ECU on certain Toyota Raize model.


| Model | Involved Units | Production Period |
| --- | --- | --- |
| Raize | 28,828 | December 1, 2021 to July 15, 2024 |
| Subtotal | 28,828 |  |

The subject vehicles are equipped with a certain engine ECU. Due to improper programming of the engine ECU, under certain driving conditions, such as frequent braking operation in high altitude areas, there is a possibility that the suction pressure in the brake booster could not be maintained as designed. If this occurs, this could make the brake pedal harder to press, which means the vehicle might take longer to stop.

Involved customers will be notified by Toyota Motor Philippines through Official Notification Letter and will be invited by authorized Toyota Dealers to perform the necessary reprogramming of the Engine ECU. The remedy will be performed at **NO CHARGE** to vehicle owners. Customers may also check if the Toyota vehicle is included in any active Service Campaign at [https://toyota.com.ph/service-campaign.](https://toyota.com.ph/service-campaign)

Involved customers with vehicles included in the service campaign are highly encouraged to immediately set an appointment with any authorized Toyota dealer to perform the necessary reprogramming of the Engine ECU and prevent problems from occurring. You may also schedule the repair during your Periodic Maintenance appointment if the vehicle is already due or approaching its regular maintenance schedule.

For more information or further inquiries, Customers may contact any authorized Toyota Dealerships or Toyota’s Customer Assistance Center (CAC) hotline at [(02) 8819 2912](tel:0288192912), email us at [customerassistance@toyota.com.ph](mailto:customerassistance@toyota.com.ph) or direct message through [TMP official Facebook page](https://m.me/ToyotaMotorPhilippines), or 'Contact Support' via MyToyotaPH app.

[Find a Dealer](https://toyota.com.ph/dealer) [Check if Your Vehicle is Covered](https://toyota.com.ph/service-campaign)

![Toyota App](https://toyota.com.ph/img/mytoyotaph/download-toyota-app.png)

Download the myToyota app to book your next service.

Manage your bookings, track your service history, and get real-time updates—all in one app.


[![Google Play Button](https://toyota.com.ph/assets/images/revamp/google-play-w-btn.png)](https://play.google.com/store/apps/details?id=tmp_notifsv1_devv1.app)[![App Store Button](https://toyota.com.ph/assets/images/revamp/app-store-w-btn.png)](https://apps.apple.com/ph/app/mytoyota-ph/id1554961783)

![Footer Icon](https://content.toyota.com.ph/img/move-your-world.svg)

#### Explore Vehicles

- [New Vehicles](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-108-new-vehicles)
  - [Electrified](https://toyota.com.ph/vehicles#electrified)
  - [Hatchbacks & Sedans](https://toyota.com.ph/vehicles#hatchbacks-sedans)
  - [Crossovers & SUVs](https://toyota.com.ph/vehicles#crossovers-suvs)
  - [MPVs](https://toyota.com.ph/vehicles#mpvs)
  - [Vans & Pick-ups](https://toyota.com.ph/vehicles#vans-pick-ups)
  - [Utility Vehicles](https://toyota.com.ph/vehicles#utility-vehicles)
  - [Electrified](https://toyota.com.ph/vehicles#electrified)
  - [Gazoo Racing](https://toyota.com.ph/vehicles#gazoo-racing)

#### Buying Guide

- [Shopping Tools](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-109-shopping-tools)
  - [Latest Promos](https://toyota.com.ph/promos)
  - [Dealer Locator](https://toyota.com.ph/dealer)
  - [Price List](https://toyota.com.ph/price-list)
  - [Payment Calculator](https://toyota.com.ph/financial-calculator)
  - [Car Comparison](https://toyota.com.ph/comparison)
  - [T-Sure](https://toyota.com.ph/t-sure)
- [Financing Options](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-109-financing-options)
  - [Toyota Financing](https://www.toyotafinancial.ph/)
  - [Kinto One Leasing](https://www.toyota-mobilitysolutions.ph/kinto-one)
  - [Balloon Payment](https://www.toyotafinancial.ph/balloon-payment-plus)
- [Add-Ons](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-109-add-ons)
  - [Accessories](https://toyota.com.ph/accessories)
  - [Merchandise](https://toyota.com.ph/tgrphilippines/merchandise)

#### Care & Maintenance

- [myToyota Experience](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-110-mytoyota-experience)
  - [myToyota App](https://toyota.com.ph/mytoyota)
  - [myToyota Connect](https://toyota.com.ph/mytoyotaconnect)
  - [myToyota Wallet](https://www.toyotafinancial.ph/mytoyotawallet)
- [After-Sales](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-110-after-sales)
  - [Service Products](https://toyota.com.ph/service-packages)
  - [Service Campaigns](https://toyota.com.ph/service-campaign)
  - [Takata Airbag](https://toyota.com.ph/service-campaign#takata)
  - [5 Year Warranty](https://toyota.com.ph/5yearwarranty)
  - [T-OPT](https://toyota.com.ph/T-opt)
  - [Toyota Platinum Card](https://toyota.com.ph/toyota-platinum-card)

#### Discover Toyota

- [Media Center](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-111-media-center)
  - [Newsroom](https://toyota.com.ph/news)
  - [Stories](https://toyota.com.ph/stories)
- [Brands And Campaigns](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-111-brands-and-campaigns)
  - [Move Your World](https://toyota.com.ph/moveyourworld)
  - [The Toyota Choice](https://toyota.com.ph/toyota-choice)
  - [Asia Sports Movement](https://toyota.com.ph/startyourimpossible)
  - [Beyond Zero](https://toyota.com.ph/beyondzero)
  - [Toyota Gazoo Racing](https://toyota.com.ph/tgrphilippines)
  - [Next Generation Tamaraw](https://toyota.com.ph/next-generation-tamaraw)
  - [Mobility Solutions](https://toyota.com.ph/mobility-solutions)
  - [Electrification](https://toyota.com.ph/electrified)
- [About Toyota Motor Philippines](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-111-about-toyota-motor-philippines)
  - [Company Profile](https://toyota.com.ph/company-profile)
  - [Our Commitment](https://toyota.com.ph/our-commitment)
  - [Sustainability](https://toyota.com.ph/sustainability)
  - [Careers](https://www.careers-page.com/toyota-motor-philippines-corporation)
  - [Contact Us](https://toyota.com.ph/contactus)

* * *

© TOYOTA MOTOR PHILIPPINES CORPORATION. 2026 ALL RIGHTS RESERVED.

[Privacy Policy](https://toyota.com.ph/privacy-policy)

#### Explore Vehicles

- [New Vehicles](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-108-new-vehicles)
  - [Electrified](https://toyota.com.ph/vehicles#electrified)
  - [Hatchbacks & Sedans](https://toyota.com.ph/vehicles#hatchbacks-sedans)
  - [Crossovers & SUVs](https://toyota.com.ph/vehicles#crossovers-suvs)
  - [MPVs](https://toyota.com.ph/vehicles#mpvs)
  - [Vans & Pick-ups](https://toyota.com.ph/vehicles#vans-pick-ups)
  - [Utility Vehicles](https://toyota.com.ph/vehicles#utility-vehicles)
  - [Electrified](https://toyota.com.ph/vehicles#electrified)
  - [Gazoo Racing](https://toyota.com.ph/vehicles#gazoo-racing)

#### Buying Guide

- [Shopping Tools](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-109-shopping-tools)
  - [Latest Promos](https://toyota.com.ph/promos)
  - [Dealer Locator](https://toyota.com.ph/dealer)
  - [Price List](https://toyota.com.ph/price-list)
  - [Payment Calculator](https://toyota.com.ph/financial-calculator)
  - [Car Comparison](https://toyota.com.ph/comparison)
  - [T-Sure](https://toyota.com.ph/t-sure)
- [Financing Options](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-109-financing-options)
  - [Toyota Financing](https://www.toyotafinancial.ph/)
  - [Kinto One Leasing](https://www.toyota-mobilitysolutions.ph/kinto-one)
  - [Balloon Payment](https://www.toyotafinancial.ph/balloon-payment-plus)
- [Add-Ons](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-109-add-ons)
  - [Accessories](https://toyota.com.ph/accessories)
  - [Merchandise](https://toyota.com.ph/tgrphilippines/merchandise)

#### Care & Maintenance

- [myToyota Experience](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-110-mytoyota-experience)
  - [myToyota App](https://toyota.com.ph/mytoyota)
  - [myToyota Connect](https://toyota.com.ph/mytoyotaconnect)
  - [myToyota Wallet](https://www.toyotafinancial.ph/mytoyotawallet)
- [After-Sales](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-110-after-sales)
  - [Service Products](https://toyota.com.ph/service-packages)
  - [Service Campaigns](https://toyota.com.ph/service-campaign)
  - [Takata Airbag](https://toyota.com.ph/service-campaign#takata)
  - [5 Year Warranty](https://toyota.com.ph/5yearwarranty)
  - [T-OPT](https://toyota.com.ph/T-opt)
  - [Toyota Platinum Card](https://toyota.com.ph/toyota-platinum-card)

#### Discover Toyota

- [Media Center](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-111-media-center)
  - [Newsroom](https://toyota.com.ph/news)
  - [Stories](https://toyota.com.ph/stories)
- [Brands And Campaigns](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-111-brands-and-campaigns)
  - [Move Your World](https://toyota.com.ph/moveyourworld)
  - [The Toyota Choice](https://toyota.com.ph/toyota-choice)
  - [Asia Sports Movement](https://toyota.com.ph/startyourimpossible)
  - [Beyond Zero](https://toyota.com.ph/beyondzero)
  - [Toyota Gazoo Racing](https://toyota.com.ph/tgrphilippines)
  - [Next Generation Tamaraw](https://toyota.com.ph/next-generation-tamaraw)
  - [Mobility Solutions](https://toyota.com.ph/mobility-solutions)
  - [Electrification](https://toyota.com.ph/electrified)
- [About Toyota Motor Philippines](https://toyota.com.ph/service-campaign/articles/0000000034#footer-collapse-111-about-toyota-motor-philippines)
  - [Company Profile](https://toyota.com.ph/company-profile)
  - [Our Commitment](https://toyota.com.ph/our-commitment)
  - [Sustainability](https://toyota.com.ph/sustainability)
  - [Careers](https://www.careers-page.com/toyota-motor-philippines-corporation)
  - [Contact Us](https://toyota.com.ph/contactus)

![Footer Icon](https://content.toyota.com.ph/img/move-your-world.svg)

© TOYOTA MOTOR PHILIPPINES CORPORATION. 2026 ALL RIGHTS RESERVED

[Privacy Policy](https://toyota.com.ph/privacy-policy)

Something went wrong.

## We Use Website Cookies

We use cookies to enhance your browsing experience, provide third-party services and tools, analyze site performance, and support advertising. Keeping all cookies enabled is recommended for the best experience, but you can adjust your preferences anytime by selecting "Cookie Settings" below. Our use of cookies aligns with our
[Privacy Policy](https://toyota.com.ph/privacy-policy), ensuring your data is handled responsibly.
For more details about cookies, please check our [Cookie Policy](https://toyota.com.ph/cookie-policy).


No, take me to cookie settings

Yes, I agree


![Toyota Logo](https://content.toyota.com.ph/img/toyota-product-logo.png)

![Close Cookie Preference Center](https://content.toyota.com.ph/img/cookie-policy/close-icon.svg)

## Cookie Preference Center

We use cookies to recognize you as a unique visitor and improve our website for you. Your privacy is important to us, and you have control over which cookies you allow. While some cookies help enhance your browsing experience, others support site improvements. You can explore the different cookie categories below and adjust your preferences. However, limiting certain cookies may impact your experience of the site and the services we are able to offer.


Allow All


### Manage Your Consent Preferences

Strictly Necessary Cookies


Always Active


These essential cookies enable key features that allow the website to function properly. Without them, the site may not work as intended.


Performance Cookies



These cookies help us analyze how you interact with our website, allowing us to improve its functionality and test new features.


Functional Cookies



These cookies remember your preferences and settings to make your visit smoother, such as recalling pages you have viewed or products you have explored.


Advertising Cookies



These cookies help customize the ads you see on other platforms, making them more relevant based on your interests and browsing behavior.



Confirm My Choices