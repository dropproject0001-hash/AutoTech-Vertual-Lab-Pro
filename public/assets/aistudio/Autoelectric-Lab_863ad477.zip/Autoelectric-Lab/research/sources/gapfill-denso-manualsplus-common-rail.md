Source: https://manuals.plus/m/b82c963b8d73f6ab83a433f9aec3a53f7f0a9a8bc12a5375cbd4eaa3ab712958
Title: DENSO Common Rail System Service Manual for Toyota Hilux/Innova 1KD/2KD Engines
Fetched: 2026-11-11T10:09:03.636Z

[Skip to content](https://manuals.plus/m/b82c963b8d73f6ab83a433f9aec3a53f7f0a9a8bc12a5375cbd4eaa3ab712958#content)

**ℹ️ Document Conversion Notice:**
This page was converted from the original file for easier reading. Diagrams/images may appear only in the original PDF below.


![Document preview](https://manuals.plus/m/b82c963b8d73f6ab83a433f9aec3a53f7f0a9a8bc12a5375cbd4eaa3ab712958.png)

File info: application/pdf · 68 pages · 11.63MB

## Overview

This document is a comprehensive service manual provided by DENSO CORPORATION for the Common Rail System. It is designed to assist technicians and service personnel in understanding, diagnosing, and maintaining the fuel injection system.

## Vehicle and Engine Applications

The manual specifically covers the Common Rail System as applied to the following Toyota vehicles and engine configurations:

- Toyota Hilux
- Kijang Innova
- Innova
- Engines: 1KD-FTV and 2KD-FTV

## Key Content Areas

This service manual provides detailed information on:

- System outline and characteristics
- System configuration and component locations
- Construction and operation of main components (Supply Pump, Rail, Injectors, Engine ECU, EDU)
- Detailed descriptions of sensors and control systems
- Diagnosis procedures, including DTC (Diagnostic Trouble Code) charts and fail-safe operations
- External wiring diagrams and ECU connector information

## Purpose

The manual aims to ensure proper service and repair of the DENSO Common Rail System, contributing to optimal engine performance, fuel efficiency, and reduced emissions for the specified Toyota models.

## Ask a question about this manual

Ask about setup, troubleshooting, compatibility, parts, safety, or missing instructions. Manuals+ will review the question and use this page’s manual context to help answer it.

Posting as .

NameEmail

After a successful submission, we securely hash the supplied account or form email before sending it to Microsoft Advertising for conversion attribution. [Privacy details](https://manuals.plus/privacy-policy).

QuestionDetailsSubmit question

## Full PDF Document

68 pages · 152% zoom

−+Fit width100%View Fullscreen [Download PDF](https://manuals.plus/m/b82c963b8d73f6ab83a433f9aec3a53f7f0a9a8bc12a5375cbd4eaa3ab712958.pdf) Print PDF

×![](https://manuals.plus/m/b82c963b8d73f6ab83a433f9aec3a53f7f0a9a8bc12a5375cbd4eaa3ab712958.png)

68 pages · 152% zoom

Page 1

Page 2

Page 3

Page 4

Page 5

Page 6

Page 7

Page 8

Page 9

Page 10

Page 11

Page 12

Page 13

Page 14

Page 15

Page 16

Page 17

Page 18

Page 19

Page 20

Page 21

Page 22

Page 23

Page 24

Page 25

Page 26

Page 27

Page 28

Page 29

Page 30

Page 31

Page 32

Page 33

Page 34

Page 35

Page 36

Page 37

Page 38

Page 39

Page 40

Page 41

Page 42

Page 43

Page 44

Page 45

Page 46

Page 47

Page 48

Page 49

Page 50

Page 51

Page 52

Page 53

Page 54

Page 55

Page 56

Page 57

Page 58

Page 59

Page 60

Page 61

Page 62

Page 63

Page 64

Page 65

Page 66

Page 67

Page 68

If the inline viewer fails, it will open the original document in compatibility mode automatically. You can also [open the file directly](https://manuals.plus/m/b82c963b8d73f6ab83a433f9aec3a53f7f0a9a8bc12a5375cbd4eaa3ab712958.pdf).