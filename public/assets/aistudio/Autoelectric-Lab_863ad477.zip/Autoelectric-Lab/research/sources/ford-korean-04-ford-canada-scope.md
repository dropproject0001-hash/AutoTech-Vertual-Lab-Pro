Source: https://www.ford.ca/support/how-tos/ford-services/parts-and-service/where-can-i-get-self-repair-and-technical-information
Title: Where can I get self-repair and technical information?
Fetched: 2026-11-11T10:06:22.753Z

![](<Base64-Image-Removed>)

# **Where can I get self-repair and technical reference information?**

The Motorcraft® Service website has a variety of resources for self-repair and technical information. To get started, visit the [Motorcraft Service](https://www.motorcraftservice.com/ownerinformation) website and select your location.

## **Resources on the Motorcraft Website**

Service Info

You can get a subscription that includes the following information:

- Workshop Manual
- Wiring Diagram Manual (also referred to as EVTMs or Electrical Vacuum Troubleshooting Manuals)
- Powertrain Control/Emissions Diagnosis (PC/ED) Manual
- Technical Service Bulletins or TSBs ('94-Present)
- Access to a downloadable initialization (PATS) information
- Access to the latest calibration information for emission-related modules
- Access to vehicle-specific Information (available for last 10 model years)
- Limited vehicle line coverage for 1994-present model years

Free Resources > QuickGuides

Access information such as:

- Ford PowerStroke 6.0L and 6.4L Diesel Engine care
- Information regarding the Easy Fuel No Cap Fuel filler including use of the fuel filler funnel and the locking fuel plug
- How to remove a tire for vehicles equipped with Tire Pressure Monitor Systems without damaging the system
- View the latest towing procedures for Ford, Lincoln, and Mercury passenger cars and light trucks
  - These easy-to-follow instructions and illustrations provide the correct hookups for slingbelt wrecker, wheel-lift, or flatbed towing

Training

Purchase web-based technical training classes. Choose a category such as:

- Gasoline or diesel engine repair
- Electrical systems
- Manual and automatic transmissions
- Brakes
- Steering and suspension

**Note:** To purchase a hard copy of your vehicle's workshop manual, visit the [Helm website](http://www.helminc.com/), or call [800-782-4356](tel:800-782-4356). These manuals are for specific models and are available for years prior to what is accessible through Motorcraft Service.

For more complex vehicle repair-related questions, contact your [Ford Dealer](http://www.ford.ca/dealerships/?gnav=footer-tools#/q/L6J5E4).

## **Additional Information**

[How do I get an Owner's Manual?](https://www.ford.ca/support/how-tos/owner-resources/vehicle-documents/where-can-i-get-an-owners-manual)

[Where can purchase replacement parts?](https://www.ford.ca/support/how-tos/ford-services/parts-and-service/where-can-i-purchase-ford-replacement-parts)

[What do I do if I need a repair?](https://www.ford.ca/support/how-tos/ford-services/parts-and-service/what-do-i-do-if-i-am-having-issues-with-my-vehicle)

* * *

Motorcraft is a registered trademark of Ford Motor Company.

The Motorcraft® Service website has a variety of resources for self-repair and technical information. To get started, visit the [Motorcraft Service](https://www.motorcraftservice.com/ownerinformation) website and select your location.

## **Resources on the Motorcraft Website**

### Service Info

You can get a subscription that includes the following information:

- Workshop Manual
- Wiring Diagram Manual (also referred to as EVTMs or Electrical Vacuum Troubleshooting Manuals)
- Powertrain Control/Emissions Diagnosis (PC/ED) Manual
- Technical Service Bulletins or TSBs ('94-Present)
- Access to a downloadable initialization (PATS) information
- Access to the latest calibration information for emission-related modules
- Access to vehicle-specific Information (available for last 10 model years)
- Limited vehicle line coverage for 1994-present model years

### Free Resources > QuickGuides

Access information such as:

- Ford PowerStroke 6.0L and 6.4L Diesel Engine care
- Information regarding the Easy Fuel No Cap Fuel filler including use of the fuel filler funnel and the locking fuel plug
- How to remove a tire for vehicles equipped with Tire Pressure Monitor Systems without damaging the system
- View the latest towing procedures for Ford, Lincoln, and Mercury passenger cars and light trucks
  - These easy-to-follow instructions and illustrations provide the correct hookups for slingbelt wrecker, wheel-lift, or flatbed towing

### Training

Purchase web-based technical training classes. Choose a category such as:

- Gasoline or diesel engine repair
- Electrical systems
- Manual and automatic transmissions
- Brakes
- Steering and suspension

**Note:** To purchase a hard copy of your vehicle's workshop manual, visit the [Helm website](http://www.helminc.com/), or call [800-782-4356](tel:800-782-4356). These manuals are for specific models and are available for years prior to what is accessible through Motorcraft Service.

For more complex vehicle repair-related questions, contact your [Ford Dealer](http://www.ford.ca/dealerships/?gnav=footer-tools#/q/L6J5E4).

## **Additional Information**

[How do I get an Owner's Manual?](https://www.ford.ca/support/how-tos/owner-resources/vehicle-documents/where-can-i-get-an-owners-manual)

[Where can purchase replacement parts?](https://www.ford.ca/support/how-tos/ford-services/parts-and-service/where-can-i-purchase-ford-replacement-parts)

[What do I do if I need a repair?](https://www.ford.ca/support/how-tos/ford-services/parts-and-service/what-do-i-do-if-i-am-having-issues-with-my-vehicle)

* * *

Motorcraft is a registered trademark of Ford Motor Company.

Did we answer your question?

YesNo

To Top

## You are now being redirected to www.ford.ca/finance

You are now being redirected to www.ford.ca/finance. Ford of Canada’s privacy policy will no longer apply. Please refer to the redirected website for its privacy policy.

[Continue](https://www.ford.ca/support/#)

[Cancel](https://www.ford.ca/support/#)

## You are now being redirected to commercialsolutions.ford.ca.

You are now being redirected to commercialsolutions.ford.ca. Ford of Canada’s privacy policy will no longer apply. Please refer to the redirected website for its privacy policy.

[Continue](https://www.ford.ca/support/#)

[Cancel](https://www.ford.ca/support/#)

## You are now being redirected to ford.ca/accessories

You are now being redirected to ford.ca/accessories. Ford of Canada’s privacy policy will no longer apply. Please refer to the redirected website for its privacy policy.

[Continue](https://www.ford.ca/support/#)

[Cancel](https://www.ford.ca/support/#)

## You are now leaving www.ford.ca.

You are now leaving Ford.ca. Ford of Canada’s privacy policy will no longer apply. Please refer to the redirected website for its privacy policy.

[Continue](https://www.ford.ca/support/#)

[Cancel](https://www.ford.ca/support/#)

## You are now being redirected to fordpro.ca.

You are now being redirected to fordpro.ca. Ford of Canada’s privacy policy will no longer apply. Please refer to the redirected website for its privacy policy.

[Continue](https://www.ford.ca/support/#)

[Cancel](https://www.ford.ca/support/#)

![](https://fordtccchatprodsa.blob.core.windows.net/chaticons/ChatIcon_White_Callout.png)

LIVE CHAT