Source: https://psa.gov.ph/statistics/environment/peenra/node/1684081133
Title: | Philippine Statistics Authority
Fetched: 2026-11-11T12:54:58.242Z

CTRL+F2![Accessibility Menu](<Base64-Image-Removed>)

Accessibility Toolbox✗

Keyboard Navigation![Keyboard Navigation](<Base64-Image-Removed>)Block Animations![Block Animations](<Base64-Image-Removed>)

Color Contrast![Uncolored<br>Display](<Base64-Image-Removed>)Uncolored

Display![Bright<br>Contrast](<Base64-Image-Removed>)Bright

Contrast![ניגודיות הפוכה](<Base64-Image-Removed>)Reverse

Contrast

Text Size![Increase<br>Text](<Base64-Image-Removed>)Increase

Text![Decrease<br>Text](<Base64-Image-Removed>)Decrease

Text![Readable<br>Text](<Base64-Image-Removed>)Readable

Text

Highlighting Content![Underline<br>Links](<Base64-Image-Removed>)Underline

Links![Underline<br>headers](<Base64-Image-Removed>)Underline

headers![Images<br>Titles](<Base64-Image-Removed>)Images

Titles

Zoom In![Big white<br>Cursor](<Base64-Image-Removed>)Big white

Cursor![Big black<br>Cursor](<Base64-Image-Removed>)Big black

Cursor![Zoom<br>Screen](<Base64-Image-Removed>)Zoom

Screen

[accessibility statement](https://psa.gov.ph/statistics/environment/peenra/node/1684081133# "accessibility statement") [report an accessibility problem](https://psa.gov.ph/statistics/environment/peenra/node/1684081133# "report an accessibility problem") Reset Settings![Reset Settings](<Base64-Image-Removed>)

learn more about [toolbox](https://mickidum.github.io/acc_toolbar/)

ITDS-KMCD-ODS

Drupal Accessibility Toolbar [toolbox](https://gitlab.com/rus-psa/accessibility-toolbar)

[Skip to main content](https://psa.gov.ph/statistics/environment/peenra/node/1684081133#main-content)

### Number of Registered Electric Vehicles Increased Almost Fivefold in 2024

_Release Date: Thursday, November 13, 2025_

2025-SSO-184

The Compendium of Philippine Environment Statistics is a compilation of environment and related socioeconomic statistics collected from various government agencies and other official data sources. One of its components, Component 5 Human Settlements and Environmental Health, focuses on the statistics related to the living conditions and environmental health of the areas where humans live and work, including the access to selected basic services.

The Land Transportation Office reported the number of registered vehicles by type of fuel used and type of motor vehicle registration. The total number of registered vehicles increased to 14.56 million in 2024 from 14.27 million registered vehicles in 2023. Gasoline-powered vehicles reached 11.45 million, or 78.7 percent of the total number of registered vehicles in 2024. Meanwhile, 3.08 million registered vehicles, or 21.2 percent of the total number of registered vehicles used diesel, and the remaining 0.2 percent used either Liquified Petroleum Gas (LPG), electric, or hybrid power sources. (Figure 5.1 and Table 5.8.1)

The number of registered electric vehicles reached 6,697 in 2024, increasing almost fivefold from the 1,359 registrations recorded in 2023. Likewise, hybrid vehicle registrations reached 17,590 in 2024, representing a 185.8 percent growth from the 6,155 registrations recorded in 2023. (Table 5.8.1)

![Figure 5.1. Distribution of Registered Vehicles by Type of Fuel Used:  in percent, 2024](https://psa.gov.ph/system/files/inline-images/image_987.png)

According to the Department of Public Works and Highways, the total length of the national road network reached 35.53 thousand kilometers in 2024. This network primarily consists of paved roads, totaling 35.21 thousand kilometers, which comprises 22.03 thousand kilometers of concrete and 13.18 thousand kilometers of asphalt roads. (Figure 5.2 and Table 5.9)

![Figure 5.2. Distribution of Paved National Roads by Surface Type,  in kilometers, 2024](https://psa.gov.ph/system/files/inline-images/image_988.png)

Meanwhile, the remaining portion of the national road network, spanning 315.36 kilometers of unpaved surfaces, is composed of 282.24 kilometers of gravel roads and 33.12 kilometers of earth roads. (Figure 5.3 and Table 5.9)

![Figure 5.3. Distribution of Unpaved National Roads by Surface Type, in kilometers, 2024](https://psa.gov.ph/system/files/inline-images/image_989.png)

**DIVINA GRACIA L. DEL PRADO, PhD**

Assistant Secretary

Deputy National Statistician

Sectoral Statistics Office

| Attachment | Size |
| --- | --- |
| ![PDF](https://psa.gov.ph/sites/default/files/file_field_icons/flat/application-pdf.png)[Press Release - 2015-2024 CPES Component 5](https://psa.gov.ph/system/files/enrad/2025%20CPES%20Comp%205%20Press%20release_ao%2012%20Nov_signed.pdf "2025 CPES Comp 5 Press release_ao 12 Nov_signed.pdf") | 237.4 KB |
| ![PDF](https://psa.gov.ph/sites/default/files/file_field_icons/flat/application-pdf.png)[Highlights - 2015-2024 CPES Component 5](https://psa.gov.ph/system/files/enrad/2.%20%5BREV3%5D%202025%20CPES%20Comp%205%20Highlights_ao%2013%20Nov.pdf "2. [REV3] 2025 CPES Comp 5 Highlights_ao 13 Nov.pdf") | 256.56 KB |
| ![PDF](https://psa.gov.ph/sites/default/files/file_field_icons/flat/application-pdf.png)[Technical Notes - 2015-2024 CPES Component 5](https://psa.gov.ph/system/files/enrad/3.%202025%20CPES%20Comp%205%20Technical%20notes.pdf "3. 2025 CPES Comp 5 Technical notes.pdf") | 432.7 KB |
| ![PDF](https://psa.gov.ph/sites/default/files/file_field_icons/flat/application-pdf.png)[Infographics - 2015-2024 CPES Component 5](https://psa.gov.ph/system/files/enrad/4.%20%5BREV1%5D%202025%20CPES%20Comp%205%20Infographics_ao07Nov_signed.pdf "4. [REV1] 2025 CPES Comp 5 Infographics_ao07Nov_signed.pdf") | 10.41 MB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.1 Total Population, Urban Population and Level of Urbanization by Region, 2010, 2015, 2020 and 2024.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.1%20Total%20Population%2C%20Urban%20Population%20and%20Level%20of%20Urbanization%20by%20Region%2C%202010%2C%202015%2C%202020%20and%202024.xlsx) | 58.2 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.2 Total Population, Rural Population, and Percentage of Rural Population by Region, 2010, 2015, 2020, and 2024.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.2%20Total%20Population%2C%20Rural%20Population%2C%20and%20Percentage%20of%20Rural%20Population%20by%20Region%2C%202010%2C%202015%2C%202020%2C%20and%202024.xlsx) | 60.77 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.3.1 Proportion of Families with Access to Water Supply by Region and Level, 2019, 2020, 2022, and 2024.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.3.1%20Proportion%20of%20Families%20with%20Access%20to%20Water%20Supply%20by%20Region%20and%20Level%2C%202019%2C%202020%2C%202022%2C%20and%202024.xlsx) | 349.31 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.3.2 Proportion of Families with Access to Water Supply by Region and Level, 2021 and 2023.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.3.2%20Proportion%20of%20Families%20with%20Access%20to%20Water%20Supply%20by%20Region%20and%20Level%2C%202021%20and%202023.xlsx) | 84.63 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.4.1 Proportion of Households with Sanitation Facility by Region and Level, 2019, 2020, 2022, and 2024.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.4.1%20Proportion%20of%20Households%20with%20Sanitation%20Facility%20by%20Region%20and%20Level%2C%202019%2C%202020%2C%202022%2C%20and%202024.xlsx) | 145.92 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.4.2 Proportion of Households with Sanitation Facility by Region and Level, 2021 and 2023.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.4.2%20Proportion%20of%20Households%20with%20Sanitation%20Facility%20by%20Region%20and%20Level%2C%202021%20and%202023.xlsx) | 28.6 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.5 Population Supplied by Water Supply Industry, 2015 to 2024.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.5%20Population%20Supplied%20by%20Water%20Supply%20Industry%2C%202015%20to%202024.xlsx) | 49.35 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.6 Philippine Water Districts Average Yearly Water Rates, 2015 to 2024.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.6%20Philippine%20Water%20Districts%20Average%20Yearly%20Water%20Rates%2C%202015%20to%202024.xlsx) | 66.51 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.7 Rates of Electricity by Region, 2015 to 2024.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.7%20Rates%20of%20Electricity%20by%20Region%2C%202015%20to%202024.xlsx) | 67.26 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.8.1 Number of Registered Vehicles by Region, Type of Ownership, and Type of Fuel, 2015 to 2024.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.8.1%20Number%20of%20Registered%20Vehicles%20by%20Region%2C%20Type%20of%20Ownership%2C%20and%20Type%20of%20Fuel%2C%202015%20to%202024.xlsx) | 365.32 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.8.2 Number of Registered Vehicles by Region, Type of Motor Vehicle, and Type of Registration, 2015 to 2024.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.8.2%20Number%20of%20Registered%20Vehicles%20by%20Region%2C%20Type%20of%20Motor%20Vehicle%2C%20and%20Type%20of%20Registration%2C%202015%20to%202024.xlsx) | 210.04 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.9 Length of National Roads with Classification and Surface Type, as of 2024.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.9%20Length%20of%20National%20Roads%20with%20Classification%20and%20Surface%20Type%2C%20as%20of%202024.xlsx) | 57.17 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.10 Existence of Urban Planning and Zoning Regulations and Instruments in Main Cities, as of 2024.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.10%20Existence%20of%20Urban%20Planning%20and%20Zoning%20Regulations%20and%20Instruments%20in%20Main%20Cities%2C%20as%20of%202024.xlsx) | 54.35 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.11a.1 Airborne Diseases Cases (Measles 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.11a.1%20Airborne%20Diseases%20Cases%20%28Measles%202015-2024%29.xlsx) | 59.07 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.11a.2 Airborne Diseases Cases (Acute Lower Respiratory Tract Infection \_ Pneumonia 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.11a.2%20Airborne%20Diseases%20Cases%20%28Acute%20Lower%20Respiratory%20Tract%20Infection%20_%20Pneumonia%202015-2024%29.xlsx) | 63.98 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.11b.1 Airborne Diseases Deaths (Measles 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.11b.1%20Airborne%20Diseases%20Deaths%20%28Measles%202015-2024%29.xlsx) | 60.76 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.11b.2 Airborne Diseases Deaths (Acute Lower Respiratory Tract Infection \_ Pneumonia 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.11b.2%20Airborne%20Diseases%20Deaths%20%28Acute%20Lower%20Respiratory%20Tract%20Infection%20_%20Pneumonia%202015-2024%29.xlsx) | 64.08 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.12.5. Water Borne Diseases Cases and Deaths (Rotavirus 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.12.5.%20Water%20Borne%20Diseases%20Cases%20and%20Deaths%20%28Rotavirus%202015-2024%29.xlsx) | 66.71 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.12.6. Water Borne Diseases Cases and Deaths (Leptospirosis 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.12.6.%20Water%20Borne%20Diseases%20Cases%20and%20Deaths%20%28Leptospirosis%202015-2024%29.xlsx) | 68.7 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.12a.1. Water Borne Diseases Cases (Typhoid and Paratyphoid Fever 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.12a.1.%20Water%20Borne%20Diseases%20Cases%20%28Typhoid%20and%20Paratyphoid%20Fever%202015-2024%29.xlsx) | 62.46 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.12a.2. Water Borne Diseases Cases (Acute Bloody Diarrhea 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.12a.2.%20Water%20Borne%20Diseases%20Cases%20%28Acute%20Bloody%20Diarrhea%202015-2024%29.xlsx) | 63.04 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.12a.3. Water Borne Diseases Cases (Cholera 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.12a.3.%20Water%20Borne%20Diseases%20Cases%20%28Cholera%202015-2024%29.xlsx) | 57.96 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.12a.4. Water Borne Diseases Cases (Viral Hepatitis 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.12a.4.%20Water%20Borne%20Diseases%20Cases%20%28Viral%20Hepatitis%202015-2024%29.xlsx) | 30.17 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.12b.1. Water Borne Diseases Deaths (Typhoid and Paratyphoid Fever 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.12b.1.%20Water%20Borne%20Diseases%20Deaths%20%28Typhoid%20and%20Paratyphoid%20Fever%202015-2024%29.xlsx) | 62.75 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.12b.2. Water Borne Diseases Deaths (Acute Bloody Diarrhea 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.12b.2.%20Water%20Borne%20Diseases%20Deaths%20%28Acute%20Bloody%20Diarrhea%202015-2024%29.xlsx) | 63.2 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.12b.3. Water Borne Diseases Deaths (Cholera 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.12b.3.%20Water%20Borne%20Diseases%20Deaths%20%28Cholera%202015-2024%29.xlsx) | 58.18 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.12b.4. Water Borne Diseases Deaths (Viral Hepatitis 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.12b.4.%20Water%20Borne%20Diseases%20Deaths%20%28Viral%20Hepatitis%202015-2024%29.xlsx) | 30.57 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.13.1. Vector Borne Diseases Cases and Deaths (Dengue 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.13.1.%20Vector%20Borne%20Diseases%20Cases%20and%20Deaths%20%28Dengue%202015-2024%29.xlsx) | 91.07 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.13.2. Vector Borne Diseases Cases and Deaths (Chikungunya 2016-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.13.2.%20Vector%20Borne%20Diseases%20Cases%20and%20Deaths%20%28Chikungunya%202016-2024%29.xlsx) | 109.52 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.13a.3. Vector Borne Diseases Cases (Malaria 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.13a.3.%20Vector%20Borne%20Diseases%20Cases%20%28Malaria%202015-2024%29.xlsx) | 58.46 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.13b.3. Vector Borne Diseases Deaths (Malaria 2015-2024).xlsx](https://psa.gov.ph/system/files/enrad/Table%205.13b.3.%20Vector%20Borne%20Diseases%20Deaths%20%28Malaria%202015-2024%29.xlsx) | 58.4 KB |
| ![Excel spreadsheet](https://psa.gov.ph/sites/default/files/file_field_icons/flat/x-office-spreadsheet.png)[Table 5.14 Population Living in Informal Settlements, as of 2018\_0.xlsx](https://psa.gov.ph/system/files/enrad/Table%205.14%20Population%20Living%20in%20Informal%20Settlements%2C%20as%20of%202018_0.xlsx) | 12.95 KB |

Back to top