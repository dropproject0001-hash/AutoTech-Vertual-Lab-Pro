# Search-snippet evidence: Ford / Hyundai / Kia Philippine technical-information scope

Research date: 2026-11-11. The following are search-result snippets only (not page fetches) and are saved as the evidence actually available for these leads. Publication dates were not exposed by the search results unless noted. Snippets are not evidence of Philippines applicability unless they expressly say so. No pin-number claims are made.

## Ford leads

1. Title: Where can I get self-repair and technical information? (Ford US)
URL: https://www.ford.com/support/how-tos/ford-services/parts-and-service/where-can-i-get-self-repair-and-technical-information/
Date: Not surfaced.
Snippet: “The Motorcraft ®* Service website has a variety of resources for self-repair and technical information. To get started, visit …”

2. Title: Ford Service Info Resources (Ford UK)
URL: https://www.ford.co.uk/support/how-tos/owner-resources/vehicle-specifications/ford-service-info-resources
Date: Not surfaced.
Snippet: “The Ford Service Info website provides technical service information, diagnostic software, and training primarily for independent repair facilities and fleet owners. Individual owners should use their Ford Account dashboard for servicing, recalls, and manuals.”

3. Title: Where can I get self-repair and technical information? (Ford Canada; fetched separately as ford-korean-04)
URL: https://www.ford.ca/support/how-tos/ford-services/parts-and-service/where-can-i-get-self-repair-and-technical-information
Date: Not surfaced. Complete page saved at research/sources/ford-korean-04-ford-canada-scope.md.
Search snippet: “The Motorcraft ® Service website has a variety of resources for self-repair and technical information. To get started, visit the Motorcraft Service website and select your location.”

4. Title: Ford Philippines Service Offers
URL: https://www.ford.com.ph/owner/service-offers
Date: Not surfaced.
Snippet: “Ranger Starting at PhP 1,379,000 … Ranger Wildtrak … Quick links … Ford Philippines Service Offers …” (Search result only; prices are not relied upon.)

5. Title: Who do I contact if I am having vehicle issues? (Ford Philippines)
URL: https://www.ford.com.ph/support/how-tos/ford-services/parts-and-service/who-do-i-contact-if-i-am-having-vehicle-issues
Date: Not surfaced.
Snippet: “If you are having an issue with your Ford vehicle, there are multiple ways to get the help you need. For any questions or concerns about your vehicle, your Ford Dealership will be able to assist you.”

6. Title: Ford Philippines | FAQs
URL: https://www.ford.com.ph/owner/faqs
Date: Not surfaced.
Snippet: Search result includes Ford Philippines service/support and owner-dashboard navigation; no repair-document detail.

## Hyundai leads

1. Title: H-100 (Hyundai Motor Philippines official brochure)
URL: https://www.hyundai.com/content/dam/hyundai/ph/en/data/marketing/brochure/product/h100/H-100_FLYERv2.pdf
Date: Not surfaced.
Snippet: Identifies “Hyundai H-100 CAB & CHASSIS” and shows product dimensions; this is a product flyer, not a repair manual.

2. Title: [HYUNDAI] GDS-Smart User Manual – GIT FAQ | Asia/Pacific, Europe, Africa, Middle East (fetched as ford-korean-02)
URL: https://support.gitauto.com/hc/en-gb/articles/4403345307929--HYUNDAI-GDS-Smart-User-Manual
Date: Not surfaced. Complete page saved at research/sources/ford-korean-02-hyundai-git-scope.md.
Snippet: “A dedicated support portal for Kia vehicles and diagnostic solutions is now live. Please use the new portal for all KIA-related support.” (The page title indicates the listed regions; fetched answer did not establish country/model coverage.)

3. Title: Hyundai – Australian Automotive Service and Repair Authority
URL: https://aasra.com.au/?page_id=1037
Date: Not surfaced.
Snippet: “Hyundai Global Service Way contains service …” AASRA is an Australian genuine service/repair information gateway; snippet does not establish Philippine coverage.

4. Title: Hyundai, Genesis & Kia Buyer’s Guide (Maverick Diagnostics; third-party)
URL: https://www.maverickdiagnostics.com/guide/hyundai-genesis-kia/
Date: Not surfaced.
Snippet: “Brands Covered: Hyundai, Genesis and Kia … Vehicle Coverage: 1996 OBD Equipped Vehicles - Current … Functionality: Diagnostics, Guided Diagnostics, Security Access, Module …” Third-party lead only, not proof of PH model coverage.

5. Title: HyundaiTechInfo Service Information Subscriptions (Hyundai Motor America)
URL: https://www.hyundaitechinfo.com/external/files/HyundaiTechInfo_Service_Information_Subscriptions.pdf
Date: PDF copyright line “© 2021 Hyundai Motor America”; older than 18 months as of research date.
Snippet: “Your subscription provides you with access to all electronic information contained in the site.” US-scope subscription lead, not PH coverage.

6. Title: Hyundai H-100 PDF Workshop and Repair manuals (Carmanualshub; third-party)
URL: https://carmanualshub.com/hyundai-h-100-pdf-workshop-and-repair-manuals
Date: Not surfaced.
Snippet: Search result says a document library offers H-100 workshop/repair documents and advises checking model/year/edition; provenance/authenticity not established.

## Kia leads

1. Title: Kia Global Information System (KGIS; official, fetched as ford-korean-03)
URL: https://kiatechinfo.snapon.com/default.aspx
Date: Not surfaced. Complete page saved at research/sources/ford-korean-03-kia-kgis-us-scope.md.
Snippet: “This site contains service information exclusively applicable for Kia vehicles sold in the United States. After signing up you will have access to: - Service manual data, Technical Service Bulletin data, and other related materials …”

2. Title: Manual & Resources | Kia Philippines (fetched as ford-korean-05)
URL: https://kiaphilippines.com/owners/manual-and-resources
Date: Not surfaced. Complete page saved at research/sources/ford-korean-05-kia-philippines-resources.md.
Snippet: Search result lists owner resources; fetched answer confirms downloadable owner manuals, but not repair diagrams or procedures.

3. Title: Soluto | Sedan | Kia Philippines
URL: https://kiaphilippines.com/vehicles/soluto
Date: Not surfaced.
Snippet: Kia Philippines vehicle listing includes “Soluto” among local vehicle models; no technical repair content.

4. Title: K2500 | Best Commercial Truck | Kia Philippines
URL: https://kiaphilippines.com/vehicles/k2500
Date: Not surfaced.
Snippet: Kia Philippines vehicle listing names K2500; no technical repair content.

5. Title: K2500 (Kia Philippines official product brochure)
URL: https://cdn.prod.website-files.com/69147ff747dcd9178147f86c/692a968a40b566829cc933de_FA_K2500_2024.pdf
Date: Filename identifies 2024; no separate publication date surfaced.
Snippet: “K2500 … CHOOSE YOUR … Single Cab Utility Vehicle … Single Cab & Chassis … Single Cab Dropside … Single Cab Closed Van … Double Cab Dropside …” Product specifications only, not repair data.

6. Title: Online factory authorized manuals (U.S. only) (Kia owner manual site, model-year 2026)
URL: https://ownersmanual.kia.com/full_webhelp/MQ4a/2026/en_US/topics/t00884.html
Date: Model-year 2026 page; publication date not surfaced.
Snippet: “Online factory authorized manuals (U.S. only) … The following publications are available at www.KiaTechinfo.com: Service manual …” U.S.-limited lead, not PH vehicle evidence.

7. Title: Kia Global Information System – TSB (NHTSA-hosted document)
URL: https://static.nhtsa.gov/odi/tsbs/2020/MC-10174519-0001.pdf
Date: Search snippet not clear; TSB document record is in 2020 archive (older than 18 months).
Snippet: “Always refer to KGIS for the latest information.” Third-party/public US government-hosted TSB, not a Kia Philippines source.

8. Title: Kia Global Information System - TSB (2026 bulletin repost)
URL: https://dot.report/bulletins/MC-11028737-0001.pdf
Date: Snippet references bulletin revision 02/10/2026 and December 2025 service information; repost is not OEM-hosted.
Snippet: “publications are listed in ‘Service Releases’ and has the latest service information that has been released … 2026MY Sportage … NUMBER DATE 406 (Rev 1, 02/10/2026) December 2025.” Not relied on for Philippines.
