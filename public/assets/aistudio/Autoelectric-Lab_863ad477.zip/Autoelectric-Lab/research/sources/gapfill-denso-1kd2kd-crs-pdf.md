Source: https://sc80f9ecf73beaece.jimcontent.com/download/version/1617734502/module/13959221827/name/4.%20Denso%20Toyota%20hilux%201KD.pdf
Title: 
Fetched: 2026-11-11T10:09:29.982Z

# TOYOTA 1KD/2KD ENGINE

# COMMON RAIL SYSTEM (CRS)

Issued : September 2009

Revised : October 2009

## DENSO CORPORATION

---

**Revision History**

| Date | Revision Contents |
| --- | --- |
| 2009.10 | • Visual contents addition Visual contents are video and animation used for manual explanation. Visual contents can be viewed by clicking the appropriate button. • Items added to the visual contents The following items have been added to “Microinjection Quantity Learning Control” under “FUEL INJECTION CONTROL”. ✓ Determinations for learning conditions ✓ Single microinjection operation ✓ Detecting the change in rotational speed via injection ✓ Correcting the injection pulse width (TQ), and actual injection quantity (Q) characteristics |

**© 2009 DENSO CORPORATION**
All rights reserved. This material may not be reproduced 
or copied, in whole or in part, without the written 
permission of DENSO Corporation.

---

## Table of Contents

## Operation Section

1. PRODUCT APPLICATION INFORMATION
    1.1 OUTLINE ..... 
    1.2 Applicable Vehicles ..... 
    1.3 Applicable Product List ..... 
    1.4 System Outline ..... 

2. SUPPLY PUMP
    2.1 Change Item ..... 
    2.2 Suction Control Valve (SCV) ..... 

3. RAIL
    3.1 Change Item ..... 

4. INJECTOR
    4.1 Change Items ..... 
    4.2 Quick Response (QR) Codes ..... 

5. FUEL INJECTION CONTROL
    5.1 Change Item ..... 
    5.2 Injection Pattern.. ... 
    5.3 Microinjection Quantity Learning Control..... 
    5.4 Wide-Range Cylinder Correction Control ..... 

6. DIAGNOSTIC TROUBLE CODES (DTC)
    6.1 DTC Table ..... 

7. ENGINE ECU
    7.1 LAND CRUISER PRADO ..... 
    7.2 DYNA. ..... 
    7.3 IMV .....

1-1
1-1
1-1
1-5

1-6
1-6

1-8

1-9
1-10

1-11
1-11
1-11
1-13

1-15

1-19
1-22
1-25

---

1–1

## 1. PRODUCT APPLICATION INFORMATION

### 1.1 OUTLINE

z Minor changes have been made to the TOYOTA LAND CRUISER, PRADO, DYNA, and IMV. As a result, a
portion of the Common Rail System (CRS) equipped with the 1KD-FTV and 2KD-FTV engines has
changed. The construction, operation, and control of main CRS components (supply pump, injectors, rail)
are identical to the components described in the previously issued "Common Rail System for TOYOTA
HILUX/KIJYANG INNOVA/INNOVA 1KD/2KD (Doc ID: 00400077)". Primary changes and additions are
listed below.

• The supply pump Suction Control Valve (SCV) has been changed from the SV2 type to the SV1 type.
(refer to P1-6)

• The rail pressure limiter has been replaced with a pressure discharge valve. (refer to P1-8)

• The injectors have been changed from the G2 type to the G3 type. (refer to P1-9)

• Microinjection quantity learning control, and wide-range cylinder correction control have been added to
injector control. (refer to P1-11)

### 1.2 Applicable Vehicles

| Vehicle Name | Engine Type | Engine Displacement | Remarks |
| --- | --- | --- | --- |
| LAND CRUISER PRADO | 1KD-FTV | 3.0 L | August 2009 |
| DYNA | 1KD-FTV | 3.0 L | August 2009 |
| IMV | 1KD/2KD-FTV | 3.0 L/2.5 L | August 2009 |

### 1.3 Applicable Product List

**LAND CRUISER PRADO**

| Part Name | DENSO Part Number | Manufacturer Part Number | Remarks |
| --- | --- | --- | --- |
| Supply Pump | 294000-110# | 22100-30140 |  |
| Injector | 295050-020# | 23670-30400 |  |
| Rail | 095440-095# | 23810-30100 |  |
| Engine ECU | 275900-045# | 89661-60N10 | AT, 4WD, Europe, Australia, Euro 4 |
| Engine ECU | 275900-046# | 89661-60N30 | AT, 4WD, Middle East, General, Euro 3, 2 |
| Engine ECU | 275900-047# | 89661-60N50 | AT, 4WD, Middle East, General, Euro 0 |
| Engine ECU | 275900-048# | 89661-60N20 | MT, 4WD, Europe, Australia, Euro 4 |
| Engine ECU | 275900-049# | 89661-60N40 | MT, 4WD, Middle East, General, Euro 3, 2 |
| Engine ECU | 275900-050# | 89661-60N60 | MT, 4WD, Middle East, General, Euro 0 |
| EDU | 131000-155# | 89871-25010 |  |

---

1–2

| Part Name | DENSO Part Number | Manufacturer Part Number | Remarks |
| --- | --- | --- | --- |
| Crankshaft Position Sensor | 029600-143# | 90919-05066 |  |
| Camshaft Position Sensor | 029600-116# | 90919-05052 |  |
| Accelerator Pedal Module | 198800-742# | 78110-60030 |  |
| Manifold Absolute Pressure (MAP) Sensor | 079800-780# | 89421-20200 |  |
| Coolant Temperature Sensor | 179700-045# | 89422-33030 |  |
| Intake Air Temperature Sensor | 071500-237# | 89727-60010 |  |
| Exhaust Gas Recirculation (EGR) Valve | 101397-123# | 25800-30190 |  |

##### DYNA

| Part Name | DENSO Part Number | Manufacturer Part Number | Remarks |
| --- | --- | --- | --- |
| Supply Pump | 294000-070# | 22100-30090 | SCV: 294200-004# |
| Injector | 295050-007# | 23670-30380 | Different connector, for use with cylinders 1 and 2 |
| Injector | 295050-008# | 23670-30390 |  |
| Rail | 095440-095# | 23810-30100 |  |
| Engine ECU | 275900-053# | 89661-25290 | MT, 2WD, Europe, Euro 4 (C/D), with charging regulation when starting |
| Engine ECU | 275900-054# | 89661-25300 | MT, 2WD, Europe, Euro 4 (C/D), without charging regulation when starting |
| EDU | 101310-570# | 89870-25030 |  |
| EDU | 101310-581# | 89870-25040 |  |
| Crankshaft Position Sensor | 029600-143# | 90919-05066 |  |
| Camshaft Position Sensor | 029600-116# | 90919-05052 |  |
| Accelerator Pedal Module | 198300-302# | 89281-35020 |  |
| MAP Sensor | 079800-780# | 89421-20200 |  |
| Coolant Temperature Sensor | 179700-045# | 89422-33030 |  |
| Intake Air Temperature Sensor | 071500-237# | 89727-60010 |  |

---

1–3

| Part Name | DENSO Part Number | Manufacturer Part Number | Remarks |
| --- | --- | --- | --- |
| Throttle Position Sensor | 192300-201# | 15081-3F00B |  |
| EGR Valve | 101397-118# | 25800-30140 |  |
| EGR Valve | 101397-121# | 25800-30150 |  |

**IMV**

| Part Name | DENSO Part Number | Manufacturer Part Number | Remarks |
| --- | --- | --- | --- |
| Supply Pump | 294000-094# | 22100-30120 | 1KD, Europe, low lubrication |
| Supply Pump | 294000-070# | 22100-30090 | 1KD/2KD, Thailand |
| Supply Pump | SM294000-090# | 22100-0L060 | 1KD, Europe, Australia, Thailand |
| Supply Pump | SM294000-091# | 22100-0L070 | 1KD/2KD, Europe, Thailand, India, low lubrication |
| Injector | 295050-020# | 23670-30400 | 1KD/2KD |
| Injector | 295050-021# | 23670-30410 | 2KD |
| Injector | SM295050-018# | 23670-0L090 | 1KD/2KD |
| Injector | SM295050-019# | 23670-0L100 | 2KD |
| Rail | 095440-095# | 23810-30100 | 1KD/2KD |
| Rail | SM095440-095# | 23810-0L030 | 1KD/2KD |
| Engine ECU | MA275900-055# | 89661-0KN00 | 1KD, MT, PT-4WD, Europe, Euro 4 |
| Engine ECU | MA275900-056# | 89661-0KN20 | 1KD, MT, 2WD, Australia, Euro 4 |
| Engine ECU | MA275900-057# | 89661-0KN30 | 1KD, MT, PT-4WD, Australia, Euro 4 |
| Engine ECU | MA275900-058# | 89661-0KN40 | 1KD, AT, PT-4WD, Europe, Euro 4 |
| Engine ECU | MA275900-059# | 89661-0KN60 | 1KD, AT, PT-4WD PRE, Australia, Euro 4 |
| Engine ECU | MA275900-060# | 89661-0KN80 | 2KD, MT, 2WD, Europe, Euro 4 Class 2 |
| Engine ECU | MA275900-061# | 89661-0KP00 | 2KD, MT, 2WD, Europe, Euro 4 Class 3 |
| Engine ECU | MA275900-062# | 89661-0KP20 | 2KD, MT, PT-4WD, Europe, Euro 4 |
| Engine ECU | MA275900-063# | 89661-0KP40 | 2KD, MT, 2WD PRE, Thailand, Euro 3 |
| Engine ECU | MA275900-064# | 89661-0KP50 | 2KD, MT, PT-4WD, Thailand, Euro 3 |
| Engine ECU | RB275900-065# | 89661-0KN10 | 1KD, MT, PT-4WD, Europe, Euro 4 |
| Engine ECU | RB275900-066# | 89661-0KN50 | 1KD, AT, PT-4WD, Europe, Euro 4 |
| Engine ECU | RB275900-067# | 89661-0KN90 | 2KD, MT, 2WD, Europe, Euro 4 Class 2 |
| Engine ECU | RB275900-068# | 89661-0KP10 | 2KD, MT, 2WD, Europe, Euro 4 Class 3 |
| Engine ECU | RB275900-069# | 89661-0KP30 | 2KD, MT, PT-4WD, Europe, Euro 4 |
| Engine ECU | HA275900-070# | 89661-0KN70 | 1KD, MT, FT-4WD, India, Euro 4(W/O OBD) |
| Engine ECU | HA275900-071# | 89661-0KP60 | 2KD, MT, 2WD, India, Euro 4 (W/O OBD) |
| EDU | 101310-590# | 89870-71070 |  |
| EDU | 101310-591# | 89870-71080 |  |

---

1–4

| Part Name | DENSO Part Number | Manufacturer Part Number | Remarks |
| --- | --- | --- | --- |
| Crankshaft Position Sensor | 029600-063# | 90919-05025 |  |
| Camshaft Position Sensor | 029600-115# | 90919-05050 |  |
| MAP Sensor | 079800-913# | 89421-20200 |  |
| Coolant Temperature Sensor | 179700-045# | 89421-71030 |  |
| Intake Air Temperature Sensor | 170400-602# | 89424-12010 |  |
| EGR Valve | 101397-113# | 25800-30100 |  |
| EGR Valve | 101397-114# | 25800-30110 |  |
| EGR Valve | 101397-116# | 25800-30120 |  |

---

1–5

### 1.4 System Outline

z The CRS configuration is as per the figure below.

EGR Cooler
EGR Valve
Engine
EDU
ECU
Injector
Variable Nozzle
Turbo 
Rail
Pressure Diesel 
Discharge Throttle
Valve
Fuel Fuel
Supply Pump
Filter Cooler
Fuel Tank

Q004457E

---

1–6

## 2. SUPPLY PUMP

### 2.1 Change Item

z The supply pump Suction Control Valve (SCV) has been changed from the SV2 type to the SV1 type. (Refer
to [SCV types (SV1, SV2)] on P1-7.)

to Fuel Tank to Fuel Tank
to Rail
from 
Fuel Tank
SCV
Fuel Temperature Fuel Temperature
Sensor Sensor
Q004458E

### 2.2 Suction Control Valve (SCV)

z The supply pump is equipped with a normally closed type SCV.

z When the solenoid is energized, the needle valve is pressed upon (in the compact SCV, the cylinder is
pulled upon) by the armature, completely opening the fuel passage and supplying fuel to the plunger. (Total
quantity suctioned → Total quantity discharged)

z When power is removed from the solenoid, the return spring presses the needle valve back to the original
position, closing the fuel passage.

z The solenoid is actuated by duty ratio control. Fuel is supplied in an amount corresponding to the open
surface area of the passage, which depends on the duty ratio. The fuel is then discharged by the plungers.

Needle Valve Armature
Return Spring
Valve Body Solenoid

---

1–7

Feed Pump
Plunger
Cylinder
Supply Pump
SCV
Q002505E

Operational Concept Diagram

Short Duty ON
→ Small Valve Opening
→ Minimum Intake Quantity

Long Duty ON
→ Large Valve Opening
→ Maximum Intake Quantity

Cylinder
Small Opening

Cylinder
Large Opening

Operation

#### (1) SCV types (SV1, SV2)

• The SCV is available in the SV1 type and SV2 type. The SV2 is a compact SCV, while the SV1 is a bit
larger than the SV2.

SV2 Type SCV

SV1 Type SCV

---

1–8

## 3. RAIL

### 3.1 Change Item

z Beginning from August 2006 model vehicles, a pressure discharge valve is used in place of the rail pressure
limiter. The engine ECU control and an actuation circuit (EDU) control the pressure discharge valve.

Rail Pressure Sensor

Pressure Discharge Valve

Q004461E

---

1–9

## 4. INJECTOR

### 4.1 Change Items

z The injectors used with the 1KD-FTV and 2KD-FTV engines have been changed from the G2 type to the
G3 type. In comparison to the G2 type injector, the G3 type injector has the following characteristics:

• The nozzle shape, and shape of the high-pressure seal service have been changed, resulting in a more
high-pressure resistant structure.

• The G3 injector is more highly responsive due to changes to the nozzle and solenoid valve.

z In consideration of the mounting measurements,  the overall length for the 295050-008# injector (for use
with cylinders 1 and 2 in the DYNA) has been made shorter by 5.5 mm.

295050-007# SM295050-018#
295050-020# SM295050-019#
295050-021#

295050-008#

---

1–10

### 4.2 Quick Response (QR) Codes

z QR codes are used to improve the accuracy of the injector injection quantity. The code from the vehicle
assembly line is read, then entered into the engine ECU. Similar to the assembly line process, when
performing service, the ID code is read by a diagnostic tool, and entered into the engine ECU.

QR Codes ( 9.9 mm)

ID Codes (30 Base-16 Characters)
Base-16 characters noting fuel injection
quantity correction information for market
service use.

295050-007# SM295050-018#
295050-020# SM295050-019#
295050-021#

QR Codes ( 9.9 mm)

ID Codes (30 Base-16 Characters)
Base-S16 characters noting fuel injection
quantity correction information for market
service use.

Q004463E

295050-008#

Q004463E

z The injection quantity correction points contained in the injector QR code are shown in the figure below.

180 MPa
 140 MPa
 100 MPa
Correction
12 Points
 64 MPa
 32 MPa
Injection Quantity Q

Actuating Pulse Width TQ

Q004464E

---

1–11

## 5. FUEL INJECTION CONTROL

### 5.1 Change Item

z Microinjection quantity learning control, and wide-range cylinder correction control have been added to the
CRS equipped with the 1KD-FTV and 2KD-FTV engines.

### 5.2 Injection Pattern

z In this CRS system, injection occurs a maximum of three times. under normal operations, fuel injection
control is performed with a pilot injection and a main injection. However, an additional pilot injection is added
when the engine is started at cold temperatures, as well as when the engine is operating in the lowtemperature, low-rotation speed range.

Main Injection 
TDC
Pilot Injection 1 Pilot Injection 2
Note) TOYOTA terminology is used in this figure.
 Q004465E

### 5.3 Microinjection Quantity Learning Control

#### (1) Outline

• In microinjection quantity learning control, the actual injector injection quantity is estimated from the
change in engine rotational speed that accompanies a very small injection. The difference between the
estimated actual injection quantity, and the injection quantity command value at that time are learned by
the engine ECU. This difference is then used to correct the actual injection quantity.

#### (2) Goal

• Microinjection quantity learning control is used to accomplish the following: 1) to minimize injection
quantity deviations due to injector deterioration over time, and 2) to prevent both engine running noise
due to misfires and exhaust smoke.

#### (3) Control outline

• Microinjection quantity learning control is automatically performed approximately every 2000 km of
normal vehicle operation, and is completed after the vehicle has traveled approximately 500 km. Actual
learning takes place during the following processes.

---

##### Determination for learning conditions

9 Microinjection quantity learning control is performed when the following two engine operations are
established: 1) a reduction in vehicle speed, and 2) injection is cut off. In the determination process, the
engine ECU then judges whether or not the conditions for learning have been met. The figure below
shows the specific details for learning determinations.

Determination Content

Non-injection determination

Deceleration determination

Clutch position determination  
*For manual transmission vehicles

Engine Rotational Speed
Injection
Quantity Q
Q = 0
Determination
Time
Q002593E

##### Single microinjection operation

9 Under the single microinjection operation process, microinjection is performed once the following items
are set: 1) the cylinder for which learning will be performed, and 2) the injection quantity. The figure
below shows the specific settings and controls for a single microinjection.

Settings, Control, Injection

Injection cylinder setting

Command injection quantity setting

Injection timing setting

Injection pressure (rail pressure) setting, control

Fuel injection

Rail Pressure
Injection 
Quantity Q
Q = 0
Injection Time

##### Detecting the change in rotational speed via injection

9 In this process, the change in rotational speed can be detected using the set microinjection. The figure
below shows the processing for calculating changes in rotational speed.

Processing

Rotational speed change detection

Rotational speed change processing

Engine Rotational Speed
DDetection etection
Injection 
Quantity Q
Q = 0
Injection Time

---

1–13

##### Correcting the injection pulse width (TQ), and actual injection quantity (Q) characteristics

9 In this process, the actual injection quantity is estimated from the set microinjection, and the change in
rotational speed. The actual injection quantity is then corrected such that the value equals the target
injection quantity. The figure below shows the processing for the aforementioned corrections.

Processing

Estimation of correction quantity from each
detected value

Reflection of correction quantity

| Injection Pulse Width (TQ) | Map Value (Q) | Actual Injection Quantity (Q) |
| --- | --- | --- |
| unlabelled 1 | 0 | 0 |
| unlabelled 2 | 0 | 0 |
| unlabelled 3 | 10 | 5 |
| unlabelled 4 | 20 | 15 |
| unlabelled 5 | 30 | 25 |
| unlabelled 6 | 40 | 35 |

##### [ REFERENCE ]

Learning must be performed manually when either an injector (or injectors), or the engine ECU is replaced.
As per the figure below, diagnostic tools are used to perform learning while the engine is operating.

No Load 3000 - 4000 rpm
Non-Injection Learning
(Approximately 10 Single Injections)
Rail Pressure Adjusting 
Idle During this Interval Injection Recovery        Idle
Approximately
1 sec. Approximately 3 sec. 2 sec. 1 sec.
Unit Cycle Approximately 7 sec.
Q002597E

### 5.4 Wide-Range Cylinder Correction Control

#### (1) Outline

• In wide-range cylinder correction control, the combustion state for each cylinder is detected based on the
crankshaft position sensor (NE) signal. The injection quantity across all the cylinders can then be
averaged by correcting the injection quantity for each injector. Wide-range cylinder correction control
corrects the conventional FCCB control (idle speed stabilization control) performed at idle speed in all
regions of rotation.

---

#### (2) Control outline

• The difference between the final injection quantity and the actual injection quantity are learned based on
the loop in the figure below. Next, the following two items are compared: 1) the results of the actual
injection quantity estimate based on the ideal state for NE input, and 2) the results of the actual injection
quantity estimate based on the actual NE input (detected value.)

Difference Between Both Values Learned
Command Actual Injection Actual Rotational
Command Output 
Injection Quantity Quantity Speed
Wide-Range Injection Rotational
Quantity Learning Speed Output

• Finally, the optimal emission state is found as shown in the figure below.

Includes Error from Compatible Vehicle
Actual
Actual Rotational
Optimal Command Optimal Emissions
Command Output Injection Speed
Injection Quantity (Optimal Exhaust Gas)
Quantity
Ideal Rotational Rotational Speed 
Speed Detection 
Target Value 
Q002599E

• The correction below shows pilot injection 2 and main injection.

Main Injection
Pilot Injection 1 Pilot Injection 2
The total deviation in injection quantity is learned via wide-range injection quantity learning.
: Reflected in the main injection quantity

---

1–15

## 6. DIAGNOSTIC TROUBLE CODES (DTC)

### 6.1 DTC Table

| DTC SAE Code | DTC Malfunction Indicator Lamp (MIL) | Detection Item |
| --- | --- | --- |
| P00AF | Yes | Variable Nozzle Turbo (VNT) Driver Abnormality, Position Request Signal Abnormality |
| P0046 | Yes | VNT Nozzle Sliding Abnormality |
| P0047 | Yes | VNT Motor Circuit Open |
| P0048 | Yes | VNT Motor Circuit Short |
| P0069 | Yes | Pressure Difference Abnormality Between Boost Pressure and Atmospheric Pressure |
| P0087 | Yes | Rail Pressure Sensor Abnormality |
| P0088 | Yes | Pressure Discharge Valve Abnormality |
| P0093 | Yes | Fuel Leak |
| P0095 | Yes | Intake Air Temperature Sensor System Abnormality |
| P0097 | Yes | Intake Air Temperature Sensor Low |
| P0098 | Yes | Intake Air Temperature Sensor High |
| P0101 | Yes | Mass Air Flow (MAF) Meter Out of Range |
| P0102 | Yes | MAF Meter Low |
| P0103 | Yes | MAF Meter High |
| P0105 | Yes | Manifold Absolute Pressure (MAP) Sensor System Abnormality |
| P0106 | Yes | MAP Sensor Out of Range |
| P0107 | Yes | MAP Sensor Low |
| P0108 | Yes | MAP Sensor High |
| P0110 | Yes | Intake Air Temperature Sensor System Abnormality |
| P0112 | Yes | Intake Air Temperature Sensor Low |
| P0113 | Yes | Intake Air Temperature Sensor High |
| P0115 | Yes | Coolant Temperature Sensor System Abnormality |
| P0116 | Yes | Coolant Temperature Sensor Circuit Range/Performance |
| P0117 | Yes | Coolant Temperature Sensor Low |
| P0118 | Yes | Coolant Temperature Sensor High |
| P0122 | Yes | Diesel Throttle Position Sensor Low |
| P0123 | Yes | Diesel Throttle Position Sensor High |
| P0168 | Yes | High Fuel Temperature Abnormality |
| P0180 | Yes | Fuel Temperature Sensor System Abnormality |

---

1–16

| DTC SAE Code | DTC Malfunction Indicator Lamp (MIL) | Detection Item |
| --- | --- | --- |
| P0182 | Yes | Fuel Temperature Sensor Low |
| P0183 | Yes | Fuel Temperature Sensor High |
| P0190 | Yes | Rail Pressure Sensor System Abnormality |
| P0191 | Yes | Rail Pressure Sensor Characteristics Abnormality |
| P0192 | Yes | Rail Pressure Sensor Low |
| P0193 | Yes | Rail Pressure Sensor High |
| P0200 | Yes | EDU Circuit Abnormality |
| P0299 | Yes | VNT Closed Abnormality |
| P0335 | Yes | Crankshaft Position Sensor Abnormality |
| P0339 | No | Crankshaft Position Sensor Power Flicker |
| P0340 | Yes | Camshaft Position Sensor Open Circuit |
| P0400 | Yes | Exhaust Gas Recirculation (EGR) Flow Volume Abnormality |
| P0405 | Yes | EGR Lift Sensor Low |
| P0406 | Yes | EGR Lift Sensor High |
| P0488 | Yes | EGR Throttle Motor System Abnormality |
| P0489 | Yes | EGR E-VRV Low |
| P0490 | Yes | EGR E-VRV High |
| P0500 | Yes | Vehicle Speed Sensor System Abnormality |
| P0503 | — | Vehicle Speed Sensor Power Flicker Noise |
| P0504 | No | Stop Lamp Switch System Abnormality |
| P0516 | — | Battery Temperature Sensor Low |
| P0517 | — | Battery Temperature Sensor High |
| P0560 | Yes | Battery Abnormality |
| P0571 | — | Stop Lamp Switch (Open, Short) |
| P0575 | — | Cruise Cancel Circuit Abnormality |
| P0606 | Yes | Engine ECU Internal Abnormality |
| P0607 | Yes | Control Module Performance |
| P060A | Yes | Engine ECU Monitor CPU Abnormality |
| P060B | Yes | Engine ECU Peripheral Circuit Abnormality |
| P0617 | Yes | Starter Circuit High |
| P0627 | Yes | Supply Pump SCV Abnormality (Open, Short\(\mathring{A}\)) |
| P0724 | Yes | Stop Lamp Switch Abnormality |
| P1229 | Yes | Supply Pump Abnormality (Overfeed) |
| P1238 | Yes | Injector Injection Abnormality |
| P1251 | Yes | VNT Abnormality (Power Flicker) |
| P1264 | Yes | VNT Driver Abnormality |

---

1–17

| DTC SAE Code | DTC Malfunction Indicator Lamp (MIL) | Detection Item |
| --- | --- | --- |
| P1271 | Yes | Pressure Discharge Valve System Abnormality |
| P1272 | Yes | Pressure Discharge Valve (Stuck Closed) |
| P1496 | Yes | Intake Air Temperature Sensor Low |
| P1497 | Yes | Intake Air Temperature Sensor High |
| P1550 | — | Battery Current Sensor Abnormality |
| P1551 | — | Battery Current Sensor Low |
| P1552 | — | Battery Current Sensor High |
| P1570 | — | Laser Sensor Abnormality |
| P1572 | — | Laser Sensor Optical Axis Misalignment |
| P1575 | — | Warning Buzzer Abnormality |
| P1578 | — | Brake System Abnormality |
| P1601 | Yes | Injector ID Code Abnormality, Unregistered |
| P1602 | — | Battery Low Voltage |
| P1604 | No | Poor Start Judgment |
| P1605 | No | Unstable Idle |
| P1607 | Yes | Cruise Control CPU Abnormality |
| P1611 | Yes | Internal IC Abnormality |
| P1615 | — | DSS1 ECU Communication Abnormality |
| P1616 | — | Vehicle Control ECU Communication Abnormality |
| P1617 | — | Vehicle Control ECU Abnormality |
| P1630 | — | VSC ↔ ENG Communication Abnormality (VSC → ENG) |
| P1631 | — | VSC ↔ ENG Communication Abnormality (ENG → VSC) |
| P2006 | Yes | Swirl Control Valve Stuck Fully Closed Abnormality |
| P2009 | Yes | Swirl Control Valve VSV Abnormality - Low |
| P2010 | Yes | Swirl Control Valve VSV Abnormality - High |
| P2120 | Yes | Accelerator Position Sensor No. 1 (Open) |
| P2121 | Yes | Accelerator Position Sensor (Out of Range) |
| P2122 | Yes | Accelerator Position Sensor No. 1 (Open) Low |
| P2123 | Yes | Accelerator Position Sensor No. 1 (Open) High |
| P2125 | Yes | Accelerator Position Sensor No. 2 (Open) |
| P2127 | Yes | Accelerator Position Sensor No. 2 (Open) Low |
| P2128 | Yes | Accelerator Position Sensor No. 2 (Open) High |
| P2138 | Yes | Accelerator Position Sensor No. 1/ No. 2 Open |
| P2226 | Yes | Atmospheric Pressure Sensor (Open) |
| P2228 | Yes | Atmospheric Pressure Sensor Low |
| P2229 | Yes | Atmospheric Pressure Sensor High |

---

1–18

| DTC SAE Code | DTC Malfunction Indicator Lamp (MIL) | Detection Item |
| --- | --- | --- |
| P245C | Yes | EGR Cooler Bypass Actuation VSV Low |
| P245D | Yes | EGR Cooler Bypass Actuation VSV High |
| P2501 | — | Alternator Abnormality |
| P2563 | Yes | VNT Position Sensor Characteristics Discrepancy |
| P2564 | Yes | VNT Position Sensor 1 Open |
| P2565 | Yes | VNT Position Sensor 1 Short |
| P2588 | Yes | VNT Position Sensor 2 Open |
| P2589 | Yes | VNT Position Sensor 2 Short |
| U0100 | — | Vehicle Control ECU Communication Abnormality |
| U0101 | Yes | TCM ECU CAN Communication Abnormality |
| U0122 | — | VSC ↔ ENG Communication Abnormality (VSC → ENG) |
| U0123 | — | Yaw Rate Sensor Communication Abnormality |
| U0126 | — | Steering Sensor Communication Abnormality |
| U0235 | — | Laser Sensor Communication Abnormality (Sensor → Vehicle ECU) |
| U1102 | — | Laser Sensor Communication Abnormality (Vehicle ECU → Sensor) |
| U1104 | — | DSS1 ECU Communication Abnormality |

---

1–19

## 7. ENGINE ECU

### 7.1 LAND CRUISER PRADO

| Node | Component |
| --- | --- |
| 15A | Fuse-EFI |
| MREL | Main Relay |
| 140 | +B |
| 143 | +B2 |
| 139 | BATT |
| 13 | E1 |
| 2 | E01 |
| 3 | E02 |
| 9 | ME01 |
| 109 | WFSE |
| 135 | VCPA |
| 137 | VPA |
| 134 | EPA |
| 133 | VCP2 |
| 136 | VPA2 |
| 132 | EPA2 |
| 65 | VNC |
| 83 | VNA |
| 64 | VNE2 |
| 44 | VCEG |
| 81 | EGLS |
| 45 | EEGL |
| 66 | VCPM |
| 82 | PIM |
| 47 | EPIM |
| 62 | VCVL |
| 80 | VLU1 |
| 63 | EVLU |
| 51 | VCS1 |
| 53 | PCR1 |
| 52 | E2S1 |
| 50 | VCS2 |
| 85 | PCR2 |
| 68 | E2S2 |
| 54 | VG |
| 55 | E2G |
| 86 | THIA |
| 69 | ETHI |
| 87 | THF |
| 70 | ETHF |
| 88 | THW |
| 71 | ETHW |
| 89 | THA |
| 72 | ETHA |
| 6 | PCV+ |
| 12 | PCV- |
| 41 | LUSL |
| 31 | ALT |
| 105 | W |
| 127 | IREL |
| 27 | GREL |
| 114 | ACT |
| 125 | AC1 |
| 129 | FC |
| 126 | MREL |
| 38 | #4 |
| 37 | #3 |
| 36 | #2 |
| 35 | #1 |
| 33 | PRD |
| 130 | NEO |
| 14 | SCV |
| 15 | SCV2 |
| 16 | ECBV |
| 10 | EGR |
| 58 | EGRC |
| 144 | ACM |

Engine ECU External Wiring Diagrams (1)

---

1–20

| Node | Description |
| --- | --- |
| 113 | CCS |
| 124 | CCHG |
| 56 | NE+ |
| 39 | G+ |
| 57 | NE- |
| 40 | G- |
| 121 | ST1- |
| 120 | STP |
| 111 | IGSW |
| 19 | CAN+ |
| 22 | CAN- |
| 48 | R |
| 46 | CLSW |
| 94 | CANH |
| 95 | CANL |
| 96 | CANP |
| 97 | CANN |
| 101 | IMI |
| 102 | IMO |
| 98 | L4 |
| 100 | LGND |
| 34 | INJ1 |
| 103 | SPD |
| 21 | NSW |
| 128 | STA |
| 110 | TC |
| 104 | TACH |
| 7 | VNM+ |
| 8 | VNM- |
| 11 | GND |
| 24 | PSW |
| 145 | EC |
| 118 | EOM |
| 138 | FANL |

Engine ECU External Wiring Diagrams (2)

---

1–21

|  | 1 | 2 | 3 | 4 | 5 | 6 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33 | 34 | 35 | 36 | 37 | 38 | 90 | 91 | 92 | 93 | 94 | 95 | 96 | 97 | 138 | 139 | 140 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 7 | 8 | 9 | 10 | 11 | 12 | 39 | 40 | 41 | 42 | 43 | 44 | 45 | 46 | 47 | 48 | 49 | 50 | 51 | 52 | 53 | 54 | 55 | 114 | 115 | 116 | 117 | 118 | 119 | 120 | 121 | 144 | 145 | 146 |  |  |  |
|  | 13 | 14 | 15 | 16 | 17 | 18 | 56 | 57 | 58 | 59 | 60 | 61 | 62 | 63 | 64 | 65 | 66 | 67 | 68 | 69 | 70 | 71 | 72 | 122 | 123 | 124 | 125 | 126 | 127 | 128 | 129 |  |  |  |  |  |  |

Engine ECU Connector Terminal Layout

---

1–22

### 7.2 DYNA

**Main Relay**

| Node | Terminal |
| --- | --- |
| Main Relay | 140 |
| Fuse-EFI | 139 |
| BATT | 13 |
| E1 | 2 |
| E01 | 3 |
| E02 | 109 |
| WFSE | 135 |
| VCPA | 137 |
| VPA | 134 |
| EPA | 133 |
| VCP2 | 136 |
| VPA2 | 132 |
| EPA2 | 44 |
| VC | 82 |
| PIM | 47 |
| EPIM | 53 |
| PCR1 | 50 |
| VCS2 | 85 |
| PCR2 | 68 |
| E2S2 | 54 |
| VG | 89 |
| THA | 55 |
| E2G | 80 |
| VLU1 | 81 |
| EGLS | 86 |
| THIA | 88 |
| THW | 84 |
| THB | 87 |
| THF | 45 |
| E2 | 6 |
| PCV+ | 12 |
| PCV- | 41 |
| LUSL | 25 |
| VNTO | 26 |
| VNTI | 31 |
| ALT | 30 |
| RLO | 105 |
| W | 106 |
| MIL | 116 |
| GIND | 127 |
| Glow Indicator | 27 |
| LOUT | 126 |
| LED | 91 |
| IREL | 27 |
| EDU Relay | 126 |
| GREL | 126 |
| Glow Plug Relay | 126 |
| MREL | 91 |
| Main Relay | 126 |
| OILM | 91 |
| Meter ECU | 91 |

Engine ECU External Wiring Diagrams (1)

---

1–23

| Node | Description |
| --- | --- |
| 46 | CLSW |
| 56 | NE+ |
| 39 | G+ |
| 57 | NE- |
| 40 | G- |
| 111 | IGSW |
| 121 | ST1- |
| 120 | STP |
| 104 | TACH |
| 38 | #4 |
| 37 | #3 |
| 36 | #2 |
| 35 | #1 |
| 33 | PRD |
| 14 | SCV |
| 16 | ECBV |
| 10 | EGR |
| 58 | EGRC |
| 108 | HSW |
| 125 | AC1 |
| 117 | THWO |
| 34 | INJ1 |
| 103 | SPD |
| 128 | STA |
| 110 | TC |
| 114 | ACT |
| 94 | CANH |
| 95 | CANL |
| 145 | EC |
| 118 | EOM |

Engine ECU External Wiring Diagrams (2)

---

1–24

|  | 1 | 2 | 3 | 4 | 5 | 6 | 12 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33 | 34 | 35 | 36 | 37 | 38 | 90 | 91 | 92 | 93 | 94 | 95 | 96 | 97 | 138 | 139 | 140 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 7 | 8 | 9 | 10 | 11 | 12 | 18 | 39 | 40 | 41 | 42 | 43 | 44 | 45 | 46 | 47 | 48 | 49 | 50 | 51 | 52 | 53 | 54 | 55 | 114 | 115 | 116 | 117 | 118 | 119 | 120 | 121 | 144 | 145 | 146 |  |  |  |
|  | 13 | 14 | 15 | 16 | 17 | 18 | 56 | 57 | 58 | 59 | 60 | 61 | 62 | 63 | 64 | 65 | 66 | 67 | 68 | 69 | 70 | 71 | 72 | 122 | 123 | 124 | 125 | 126 | 127 | 128 | 129 |  |  |  |  |  |  |  |

Q002653

Engine ECU Connector Terminal Layout

---

1–25

### 7.3 IMV

Main Relay 111
15A +B PCV+ 6 PCV (Suction Control Valve) (2.1   )
Fuse-EFI 121 MREL
PCV-7
(111   ) 74 BATT PRD 30
12V
EDU
35 E1
1 E01
DM 109
2 E02 Multi Display
Engine Earth
LUSL 38
128 WFSE Diesel Throttle Drive IC
OBDII Check With MA275900-059#
Without MA275900-060#, -061#
Connector 129 SIL
RB275900-067#, -068#
HA275900-071#
With MA275900-058#, -059#
RB275900 -066# VNTO 15
91 CAN+ VNT
ECT 92 CAN-Drive
VNTI 8
135 VCPA
134 VCP2
Without MA275900-059# 
+B 27 VC
CANH 89
69 PIM
MAP Sensor VSC
40 VCS CANL 90
MAF
Meter Rail Pressure Sensor 19 PCR1
(Main)
125 VPA
29 PCR2 With MA275900-055#, -056#, -057#, -058#, -059#
Rail Pressure Sensor
(Sub) RB275900-065#, -066#
Accelerator Position Sensor (Main) 124 VPA2
PI 73 Cruise Indicator
IG2
Intake Air Temperature Sensor 25 THIA
Coolant Temperature Sensor 26 THW
57 VG
W 117 MIL
Accelerator Position Sensor (Sub) 68 VLU IG2
Diesel Throttle Position Sensor GIND 115 Glow Indicator
64 EGLS
(111   )
Fuel Temperature Sensor 33 THF IREL 119
+B
Air Temperature Sensor 31 THA EDU Relay
EGR Lift Sensor
EGR 52
With MA275900-055#, -056#, -057#, -058# +B
MA275900-059#,RB275900-065#, -066# E-VRV (12    at 20    
126 CCS
Cruise Control Switch
41 E2S (194   )
GREL 114
34 E2
65 EVG Glow Plug Relay
132 EPA2
133 EPA
Q004471E

Engine ECU External Wiring Diagrams (1)

---

1–26

18 NE+
+B
Crankshaft Position 58 G-
Sensor ECBV 42
28 NE-EGR Cooler Bypass VSV
Camshaft Position
66 G+ (29.7 at 20   )
Sensor
EGRC 43
120 IGSW
IG2 IGSW EGR Cut VSV (36 at 20   )
Brake Switch
78 ST1-TACH 108
METER
77 STP
BATT #4 24
EDU
#3 23
EDU
With MA275900-058#, -059# #2 22
RB275900-066# EDU
#1 21
82 D EDU
+B
IG1
D Switch
SCV 10
Without MA275900-058#, -059#
Swirl Control Valve
RB275900-066#
(29 at 20   )
82 CLSW
With MA275900-055#, -056#, -057#, -058#, -059#
IG1
Clutch Switch RB275900-065#, -066#
HA275900-070#
With MA275900-058#, -059# SCV2 11
RB275900-066# 
Swirl Control Valve 2
(29 at 20   )
106 NSW
Neutral Start Switch
EDU
INJF 20
76 HSW
A/C Amplifier
95 AC1
A/C Amplifier
Vehicle Speed Sensor
110 THWO SPD 96
A/C Amplifier
94 ACT
A/C Amplifier
101 OILM
Oil Monitor
TC 118 Check Connector
102 IMI
Immobilizer
EOM 113
103 IMO
Immobilizer
EC 70
79 VCH
Viscous Amplifier
72 VCT Body Earth
Viscous Amplifier
17 ALT
Alternator
Starter Relay 105 STA
Q004472E

Engine ECU External Wiring Diagrams (2)

---

1–27

| 1 | 2 | 3 | 4 | 5 | 6 | 7 |
| --- | --- | --- | --- | --- | --- | --- |
| 8 | 9 | 10 | 11 | 12 | 13 | 14 |
| 18 | 19 | 20 | 21 | 22 | 23 | 24 |
| 28 | 29 |  |  | 30 | 31 | 32 |

| 35 | 36 | 37 | 38 | 39 | 40 | 41 |
| --- | --- | --- | --- | --- | --- | --- |
| 42 | 43 | 44 | 45 | 46 | 47 | 48 |
| 54 | 55 |  | 56 | 57 |  | 58 |
| 62 | 63 |  | 64 | 65 |  | 66 |

| 70 | 71 |  |  | 72 | 73 | 74 | 75 |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 76 | 77 | 78 | 79 | 80 | 81 | 82 | 83 | 84 |
| 86 | 87 | 88 | 89 | 90 | 91 | 92 | 93 | 94 |
| 97 | 98 | 99 | 100 | 101 |  |  | 102 | 103 |

| 105 | 106 | 107 | 108 | 109 | 110 | 111 |
| --- | --- | --- | --- | --- | --- | --- |
| 112 | 113 | 114 | 115 | 116 | 117 | 118 |
| 122 | 123 |  | 124 | 125 | 126 | 127 |
| 130 | 131 |  | 132 | 133 |  | 134 |

Q004470E

Engine ECU Connector Terminal Layout

---

Service Department DENSO CORPORATION
1-1, Showa-cho, Kariya-shi, Aichi-ken, 448-8661, Japan