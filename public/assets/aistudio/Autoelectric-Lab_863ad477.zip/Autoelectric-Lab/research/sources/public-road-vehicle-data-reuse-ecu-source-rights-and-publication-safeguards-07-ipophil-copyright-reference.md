Source: https://ilaw.ipophil.gov.ph/pluginfile.php/150/mod_resource/content/2/Copyright%20Reference%20Book%202021.pdf
Title: A9dos040_43e87u_7hs.tmp
Fetched: 2026-11-11T12:56:03.383Z
Truncated: continue from startIndex 250000

Rising. Shining. Beckoning.

**Copyright Reference Book PHILIPPINES**

| Category | Number of copyrighted works |
| --- | --- |
| 2019 | 100 |
| 2020 | 100 |
| 2021 | 100 |
| 2022 | 100 |
| 2023 | 100 |

## Copyright Reference Book PHILIPPINES

---

## COPYRIGHT REFERENCE BOOK PHILIPPINES

### INTELLECTUAL PROPERTY OFFICE OF THE PHILIPPINES

### Bureau of Copyright and Related Rights

**April, 2021**

---

**Publication Notice (2021).**  This is a government work.  No part of this publication may be 
reproduced for profit without the written permission of the Intellectual Property Office of the 
Philippines through its Bureau of Copyright and Related Rights. You may reach the Bureau at 
the following address: <u>copyright@ipophil.gov.ph</u>.

---

### ABOUT THIS BOOK

This reference book intends to serve as a simple yet comprehensive reference on 
the copyright legal system in the Philippines. The work is divided into three parts. The 
first part covers the Philippine Copyright Law as expressed in Republic Act (R.A.) 8293 
or the Intellectual Property (IP) Code of the Philippines. Relevant amendments to some 
provisions of R.A. 8293, specifically those introduced in R.A. 10372, were already 
incorporated into the main text of the IP Code, for easy reference and convenience. The 
second part includes various issuances by the Intellectual Property Office of the 
Philippines (IPOPHL) on copyright and related rights. The third part, meanwhile, 
includes various international copyright treaties, conventions, and agreements, almost all 
of which the Philippines has acceded to.

We fervently hope for this book to be one of the many ways to promote and protect 
copyright and other related rights. We also hope to keep the creative sector informed of 
the latest and relevant developments in copyright and related rights, here and abroad, so 
as to get greater participation and involvement from the creatives in registering and 
protecting their works.

**_Bureau of Copyright and Related Rights Staff_**

---

### TABLE OF CONTENTS

**The Law on Copyright**        1 
Preliminary Provisions        2 
Original Works         4 
Derivative Works        5 
Works not Protected        5 
Economic Rights        6 
Ownership of Copyright       7 
Transfer, Assignment and Licensing 
 of Copyright         8 
Limitations on Copyright       9 
Deposit and Notice       13 
Moral Rights        14 
Rights to Proceeds in Subsequent Transfers    16 
Rights of Performers, Producers of Sound Recordings 
 And Broadcasting Organizations     16 
Producers of Sound Recordings     19 
Broadcasting Organizations      20 
Limitations on Protection      20 
Term of Protection       20 
Infringement        22 
Scope of Application       26 
Institution of Actions       28 
Miscellaneous Provisions      28 
II. **IPOPHL Issuances on Copyright**      29 
IPOPHL Memorandum Circular No. 2019-025  
Philippine Regulations Implementing the Marrakesh 
 Treaty to Facilitate Access to Published Works for Persons 
 Who Are Blind, Visually Impaired or Otherwise Print 
 Disabled         30

---

IPOPHL Memorandum Circular No. 2020-022 
Revised Rules and Regulations on the Resolution of 
 Disputes Relating to the Terms of a License Involving 
 the Author’s Right to Public Performance or Other 
 Communication of His Work      40 
IPOPHL Memorandum Circular No. 2020-023 
Implementing Rules and Regulations on Resale Rights   45 
IPOPHL Memorandum Circular No. 2020-024 
Copyright Rules and Regulations for the Government   52 
IPOPHL Memorandum Circular No. 2020-025 
Revised Rules and Regulations on Copyright Registration 
 And Recordation of Transfer, Assignment and License 
 of Copyright         58 
IPOPHL Memorandum Circular No. 2020-026 
Revised Rules and Regulations on Accreditation of 
 Collective Management Organizations and Similar  
 Entities         68 
III. **International Copyright Treaties, Conventions, and Agreements** 77 
Berne Convention for the Protection of Literary and 
 Artistic Works (Berne Convention)     78 
International Convention for the Protection of  
 Performers, Producers of Phonograms and Broadcasting 
 Organizations (Rome Convention)     122 
Convention Relating to the Distribution of  
Programme-Carrying Signals Transmitted by Satellite                                     
(Brussels Convention)       137 
WIPO Copyright Treaty (WCT)      142 
WIPO Performances and Phonograms Treaty (WPPT)   153

---

Beijing Treaty on Audiovisual Performance (BTAP)   168 
Marrakesh Treaty to Facilitate Access to Published 
 Works for Persons Who Are Blind, Visually Impaired, 
 Or Otherwise Print Disabled (Marrakesh VIP Treaty)   182 
World Trade Organization (WTO) Agreement on 
 Trade-Related Aspects of Intellectual Property Rights 
 (TRIPS Agreement)        196 
Agreement Between the World Intellectual Property 
 Organization and the World Trade Organization   233

---

## THE LAW ON COPYRIGHT

Republic Act (R.A.) 8293 or the Intellectual Property Code of the Philippines was 
enacted into law on June 6, 1997. The law took effect on the 1st of January, 1998. This part 
presents the Law on Copyright which is Part IV of the IP Code. Various amendments to 
RA 8293, specifically those introduced in 2013 under R.A. 10372, have been incorporated 
into the main text of this work for easy reference.

---

### PART IV

### THE LAW ON COPYRIGHT

### CHAPTER I

### PRELIMINARY PROVISIONS

**_SEC. 171. Definitions._** -

For the purpose of this Act, the following terms have the following meaning:

171.1. "Author" is the natural person who has created the work;

171.2. A "collective work" is a work which has been created by two (2) or more natural 
persons at the initiative and under the direction of another with the understanding that it 
will be disclosed by the latter under his own name and that contributing natural persons 
will not be identified;

171.3. "Communication to the public" or "communicate to the public" means any 
communication to the public, including broadcasting, rebroadcasting, retransmitting by 
cable, broadcasting and retransmitting by satellite, and includes the making of a work 
available to the public by wire or wireless means in such a way that members of the public 
may access these works from a place and time individually chosen by them;

171.4. A "computer" is an electronic or similar device having information-processing 
capabilities, and a "computer program" is a set of instructions expressed in words, codes, 
schemes or in any other form, which is capable when incorporated in a medium that the 
computer can read, or causing the computer to perform or achieve a particular task or result;

171.5. "Public lending" is the transfer of possession of the original or a copy of a work or 
sound recording for a limited period, for non-profit purposes, by an institution the services 
of which are available to the public, such as public library or archive;

171.6. "Public performance," in the case of a work other than an audiovisual work, is the 
recitation, playing, dancing, acting or otherwise performing the work, either directly or by 
means of any device or process; in the case of an audiovisual work, the showing of its images 
in sequence and the making of the sounds accompanying it audible; and, in the case of a 
sound recording, **making** the recorded sounds audible at a place or at places where persons 
outside the normal circle of a family and that family’s closest social acquaintances are or can

2 | Copyright Reference Book Philippines (2021)

---

be present, irrespective of whether they are or can be present at the same place and at the 
same time, or at different places and/or at different times, and where the performance can 
be perceived without the need for communication within the meaning of Subsection 171.3;

171.7. "Published works" means works, which, with the consent of the authors, are made 
available to the public by wire or wireless means in such a way that members of the public 
may access these works from a place and time individually chosen by them: Provided, that 
availability of such copies has been such, as to satisfy the reasonable requirements of the 
public, having regard to the nature of the work;

171.8. "Rental" is the transfer of the possession of the original or a copy of a work or a 
sound recording for a limited period of time, for profit-making purposes;

171.9. "Reproduction" is the making of one (1) or more copies, temporary or permanent, 
in whole or in part, of a work or a sound recording in any manner or form without prejudice 
to the provisions of Section 185 of this Act (Sec. 41 [E], P.D. No. 49a);

171.10. A "work of applied art" is an artistic creation with utilitarian functions or 
incorporated in a useful article, whether made by hand or produced on an industrial scale;

171.11. A "work of the Government of the Philippines" is a work created by an officer or 
employee of the Philippine Government or any of its subdivisions and instrumentalities, 
including government-owned or controlled corporations as part of his regularly prescribed 
official duties.

171.12. “Technological measure” means any technology, device or component that, in 
the normal course of its operation, restricts acts in respect of a work, performances or sound 
recording, which are not authorized by the authors, performers or producers of sound 
recordings concerned or permitted by law;

171.13. “Rights management information” means information which identifies the 
work, sound recording or performance; the author of the work, producer of the sound 
recording or performer of the performance, the owner of any right in the work, sound 
recording or performance; or information about the terms and conditions of the use of the 
work, sound recording or performance; and any number or code that represent such 
information, when any of these items is attached to a copy of a work, sound recording or 
fixation of performance or appears in conjunction with the communication to the public of 
a work, sound recording or performance;

---

### CHAPTER II

### ORIGINAL WORKS

**_SEC. 172. Literary and Artistic Works._** –

172.1 Literary and artistic works, hereinafter referred to as "works", are original 
intellectual creations in the literary and artistic domain protected from the moment of their 
creation and shall include in particular

(a) Books, pamphlets, articles and other writings;

(b) Periodicals and newspapers;

(c) Lectures, sermons, addresses, dissertations prepared for oral delivery, whether or not 
reduced in writing or other material form;

(d) Letters;

(e) Dramatic or dramatico-musical compositions; choreographic works or entertainment 
in dumb shows;

(f) Musical compositions, with or without words;

(g) Works of drawing, painting, architecture, sculpture, engraving, lithography or other 
works of art; models or designs for works of art;

(h) Original ornamental designs or models for articles of manufacture, whether or not 
registrable as an industrial design, and other works of applied art;

(i) Illustrations, maps, plans, sketches, charts and three-dimensional works relative to 
geography, topography, architecture or science;

(j) Drawings or plastic works of a scientific or technical character;

(k) Photographic works including works produced by a process analogous to 
photography; lantern slides;

(l) Audiovisual works and cinematographic works and works produced by a process 
analogous to cinematography or any process for making audio-visual recordings;

(m) Pictorial illustrations and advertisements;

(n) Computer programs; and

(o) Other literary, scholarly, scientific and artistic works.

172.2. Works are protected by the sole fact of their creation, irrespective of their mode or 
form of expression, as well as of their content, quality and purpose. (Sec. 2, P.D. No. 49a)

---

### CHAPTER III

### DERIVATIVE WORKS

**_SEC. 173. Derivative Works._** -

173.1. The following derivative works shall also be protected by copyright:

(a) Dramatizations, translations, adaptations, abridgments, arrangements, and other 
alterations of literary or artistic works; and

(b) Collections of literary, scholarly or artistic works, and compilations of data and 
other materials which are original by reason of the selection or coordination or 
arrangement of their contents. (Sec. 2, [P] and [Q], P.D. No. 49)

173.2. The works referred to in paragraphs (a) and (b) of Subsection 173.1 shall be 
protected as a new works: *Provided however,* that such new work shall not affect the force of 
any subsisting copyright upon the original works employed or any part thereof, or be 
construed to imply any right to such use of the original works, or to secure or extend 
copyright in such original works. (Sec. 8, P.D. 49; Art. 10, TRIPS)

### <em>SEC. 174. Published Edition of Work.</em> -

In addition to the right to publish granted by the author, his heirs or assigns, the 
publisher shall have a copy right consisting merely of the right of reproduction of the 
typographical arrangement of the published edition of the work. (n).

### CHAPTER IV

### WORKS NOT PROTECTED

### <em>SEC. 175. Unprotected Subject Matter.</em> -

Notwithstanding the provisions of Section 172 and 173, no protection shall extend, under 
this law, to any idea, procedure, system method or operation, concept, principle, discovery 
or mere data as such, even if they are expressed, explained, illustrated or embodied in a 
work; news of the day and other miscellaneous facts having the character of mere items of 
press information; or any official text of a legislative, administrative or legal nature, as well 
as any official translation thereof. (n)

### <em>SEC. 176. Works of the Government.</em> -

176.1. No copyright shall subsist in any work of the Government of the Philippines. 
However, prior approval of the government agency or office wherein the work is created shall be necessary for exploitation of such work for profit. Such agency or office may, among 
other things, impose as a condition the payment of royalties. No prior approval or conditions 
shall be required for the use of any purpose of statutes, rules and regulations, and speeches, 
lectures, sermons, addresses, and dissertations, pronounced, read or rendered in courts of 
justice, before administrative agencies, in deliberative assemblies and in meetings of public 
character. (Sec. 9, first par., P.D. No. 49)

176.2. The Author of speeches, lectures, sermons, addresses, and dissertations 
mentioned in the preceding paragraphs shall have the exclusive right of making a collection 
of his works. (n)

176.3. Notwithstanding the foregoing provisions, the Government is not precluded from 
receiving and holding copyrights transferred to it by assignment, bequest or otherwise; nor 
shall publication or republication by the government in a public document of any work in 
which copy right is subsisting be taken to cause any abridgment or annulment of the 
copyright or to authorize any use or appropriation of such work without the consent of the 
copyright owners. (Sec. 9, third par., P.D. No. 49)

### CHAPTER V

### COPYRIGHT OR ECONOMIC RIGHTS

### <em>SEC. 177. Copy or Economic Rights.</em> -

Subject to the provisions of Chapter VIII, copyright or economic rights shall consist of 
the exclusive right to carry out, authorize or prevent the following acts:

177.1. Reproduction of the work or substantial portion of the work;

177.2 Dramatization, translation, adaptation, abridgment, arrangement or other 
transformation of the work;

177.3. The first public distribution of the original and each copy of the work by sale or 
other forms of transfer of ownership;

177.4. Rental of the original or a copy of an audiovisual or cinematographic work, a work 
embodied in a sound recording, a computer program, a compilation of data and other 
materials or a musical work in graphic form, irrespective of the ownership of the original or 
the copy which is the subject of the rental; (n)

---

177.5. Public display of the original or a copy of the work;

177.6. Public performance of the work; and

177.7. Other communication to the public of the work (Sec. 5, P.D. No. 49a)

### CHAPTER VI

### OWNERSHIP OF COPYRIGHT

### <em>SEC. 178. Rules on Copyright Ownership.</em> -

Copyright ownership shall be governed by the following rules:

178.1. Subject to the provisions of this section, in the case of original literary and artistic 
works, copyright shall belong to the author of the work;

178.2. In the case of works of joint authorship, the co-authors shall be the original owners 
of the copyright and in the absence of agreement, their rights shall be governed by the rules 
on co-ownership. If, however, a work of joint authorship consists of parts that can be used 
separately and the author of each part can be identified, the author of each part shall be the 
original owner of the copyright in the part that he has created;

178.3. In the case of work created by an author during and in the course of his 
employment, the copyright shall belong to:

(a) The employee, if the creation of the object of copyright is not a part of his regular 
duties even if the employee uses the time, facilities and materials of the employer.

(b) The employer, if the work is the result of the performance of his regularly-assigned 
duties, unless there is an agreement, express or implied, to the contrary.

178.4. In the case of a work-commissioned by a person other than an employer of the 
author and who pays for it and the work is made in pursuance of the commission, the person 
who so commissioned the work shall have ownership of work, but the copyright thereto 
shall remain with the creator, unless there is a written stipulation to the contrary;

---

178.5. In the case of audiovisual work, the copyright shall belong to the producer, the 
author of the scenario, the composer of the music, the film director, and the author of the 
work so adapted. However, subject to contrary or other stipulations among the creators, the 
producers shall exercise the copyright to an extent required for the exhibition of the work in 
any manner, except for the right to collect performing license fees for the performance of 
musical compositions, with or without words, which are incorporated into the work; and

178.6. In respect of letters, the copyright shall belong to the writer subject to the 
provisions of Article 723 of the Civil Code. (Sec. 6, P.D. No. 49a)

### <em>SEC. 179. Anonymous and Pseudonymous Works.</em> –

For purposes of this Act, the publishers shall be deemed to represent the authors of 
articles and other writings published without the names of the authors or under 
pseudonyms, unless the contrary appears, or the pseudonyms or adopted name leaves no 
doubts as to the author’s identity, or if the author of the anonymous works discloses his 
identity. (Sec. 7, P.D. 49)

### CHAPTER VII

### TRANSFER, ASSIGNMENT AND LICENSING OF COPYRIGHT

### <em>SEC. 180. Rights of Assignee or Licensee.</em> -

180.1. The copyright may be assigned or licensed in whole or in part. Within the scope 
of the assignment or license, the assignee or licensee is entitled to all the rights and remedies 
which the assignor or licensor had with respect to the copyright.

180.2. The copyright is not deemed assigned or licensed *inter vivos,* in whole or in part, 
unless there is a written indication of such intention.

180.3. The submission of a literary, photographic or artistic work to a newspaper, 
magazine or periodical for publication shall constitute only a license to make a single 
publication unless a greater right is expressly granted. If two (2) or more persons jointly own 
a copyright or any part thereof, neither of the owners shall be entitled to grant licenses 
without the prior written consent of the other owner or owners. (Sec. 15, P.D. No. 49a)

180.4. Any exclusivity in the economic rights in a work may be exclusively licensed. 
Within the scope of the exclusive license, the licensee is entitled to all the rights and remedies 
which the licensor had with respect to the copyright.

---

180.5. The copyright owner has the right to regular statements of accounts from the 
assigned or the licensee with regard to assigned or licensed work.

### <em>SEC. 181. Copyright and Material Object.</em> -

The copyright is distinct from the property in the material object subject to it. 
Consequently, the transfer, assignment or licensing of the copyright shall not itself constitute 
a transfer of the material object. Nor shall a transfer or assignment of the sole copy or of one 
or several copies of the work imply transfer, assignment or licensing of the copyright. (Sec. 
16, P.D. No. 49)

### <em>SEC. 182. Filing of Assignment of License.</em> -

An assignment or exclusive license may be filed in duplicate with the National Library 
upon payment of the prescribed fee for registration in books and records kept for the 
purpose. Upon recording, a copy of the instrument shall be, returned to the sender with a 
notation of the fact of record. Notice of the record shall be published in the IPO Gazette. (Sec. 
19, P.D. No. 49a)

### <em>SEC 183. Designation of Society.</em> -

The owners of copyright and related rights or their heirs may designate a society of 
artists, writers, composers and other right-holders to collectively manage their economic or 
moral rights on their behalf. For the said societies to enforce the rights of their members, 
they shall first secure the necessary accreditation from the Intellectual Property Office (Sec. 
32, P.D. No. 49a)

### CHAPTER VIII

### LIMITATIONS ON COPYRIGHT

### <em>SEC. 184. Limitations on Copyright.</em> -

184.1. Notwithstanding the provisions of Chapter V, the following acts shall not 
constitute infringement of copyright:

(a) The recitation or performance of a work, once it has been lawfully made accessible to 
the public, if done privately and free of charge or if made strictly for a charitable or 
religious institution or society; (Sec. 10(1), P.D. No.49)

(b) The making of quotations from a published work if they are compatible with fair use 
and only to the extent justified for the purpose, including quotations from newspaper 
articles and periodicals in the form of press summaries: *Provided,* That the source and the name of the author, if appearing on the work, are mentioned; (Sec. 11, third par., 
P.D. No. 49)

(c) The reproduction or communication to the public by mass media of articles on current 
political, social, economic, scientific or religious topic, lectures, addresses and other 
works of the same nature, which are delivered in public if such use is for information 
purposes and has not been expressly reserved: *Provided,* That the source is clearly 
indicated; (Sec. 11, P.D. No. 49)

(d) The reproduction and communication to the public of literary, scientific or artistic works 
as part of reports of current events by means of photography, cinematography or 
broadcasting to the extent necessary for the purpose; (Sec. 12, P.D. No. 49)

(e) The inclusion of a work in a publication, broadcast, or other communication to the 
public, sound recording or film, if such inclusion is made by way of illustration for 
teaching purposes and is compatible with fair use: *Provided,* that the source and of the 
name of the author, if appearing in the work, are mentioned;

(f) The recording made in schools, universities, or educational institutions of a work 
included in a broadcast for the use of such schools, universities or educational 
institutions: *Provided,* that such recording must be deleted within a reasonable period 
after they were first broadcast: *Provided, further,* that such recording may not be made 
from audiovisual works which are part of the general cinema repertoire of feature films 
except for brief excerpts of the work;

(g) The making of ephemeral recordings by a broadcasting organization by means of its 
own facilities and for use in its own broadcast;

(h) The use made of a work by or under the direction or control of the Government, by the 
National Library or by educational, scientific or professional institutions where such use 
is in the public interest and is compatible with fair use;

(i) The public performance or the communication to the public of a work, in a place where 
no admission fee is charged in respect of such public performance or communication, 
by a club or institution for charitable or educational purpose only, whose aim is not 
profit making, subject to such other limitations as may be provided in the Regulations; 
(n)

(j) Public display of the original or a copy of the work not made by means of a film, slide, 
television image or otherwise on screen or by means of any other device or process: 
*Provided,* that either the work has been published, or, that original or the copy displayed 
has been sold, given away or otherwise transferred to another person by the author or 
his successor in title; and

(k) Any use made of a work for the purpose of any judicial proceedings or for the giving of 
professional advice by a legal practitioner.

(l) The reproduction or distribution of published articles or materials in a specialized 
format exclusively for the use of the blind, visually- and reading-impaired persons:

---

*Provided,* that such copies and distribution shall be made on a nonprofit basis and shall 
indicate the copyright owner and the date of the original publication.

184.2. The provisions of this section shall be interpreted in such a way as to allow the 
work to be used in a manner which does not conflict with the normal exploitation of the 
work and does not unreasonably prejudice the right holder's legitimate interest.

### <em>SEC. 185. Fair Use of a Copyrighted Work.</em> -

185.1. The fair use of a copyrighted work for criticism, comment, news reporting, 
teaching including limited number of copies for classroom use, scholarship, research, and 
similar purposes is not an infringement of copyright. Decompilation, which is understood 
here to be the reproduction of the code and translation of the forms of a computer program 
to achieve the interoperability of an independently created computer program with other 
programs may also constitute fair use under the criteria established by this section, to the 
extent that such decompilation is done for the purpose of obtaining the information 
necessary to achieve such interoperability. In determining whether the use made of a work 
in any particular case is fair use, the factors to be considered shall include:

(a) The purpose and character of the use, including whether such use is of a commercial 
nature or is for non-profit educational purposes;

(b) The nature of the copyrighted work;

(c) The amount and substantiality of the portion used in relation to the copyrighted work 
as a whole; and

(d) The effect of the use upon the potential market for or value of the copyrighted work.

185.2. The fact that a work is unpublished shall not by itself bar a finding of fair use if 
such finding is made upon consideration of all the above factors.

### <em>SEC. 186. Work of Architecture.</em> -

Copyright in a work of architecture shall include the right to control the erection of any 
building which reproduces the whole or a substantial part of the work either in its original 
form or in any form recognizably derived from the original; *Provided,* That the copyright in 
any such work shall not include the right to control the reconstruction or rehabilitation in 
the same style as the original of a building to which the copyright relates. (n)

### <em>SEC. 187. Reproduction of Published Work.</em> -

187.1. Notwithstanding the provision of Section 177, and subject to the provisions of 
Subsection 187.2, the private reproduction of a published work in a single copy, where the 
reproduction is made by a natural person exclusively for research and private study, shall 
be permitted, without the authorization of the owner of copyright in the work.

---

187.2. The permission granted under Subsection 187.1 shall not extend to the 
reproduction of:

(a) A work of architecture in form of building or other construction;

(b) An entire book, or a substantial past thereof, or of a musical work in which graphics 
form by reprographic means;

(c) A compilation of data and other materials;

(d) A computer program except as provided in Section 189; and

(e) Any work in cases where reproduction would unreasonably conflict with a normal 
exploitation of the work or would otherwise unreasonably prejudice the legitimate 
interests of the author. (n)

### <em>SEC. 188. Reprographic Reproduction by Libraries.</em> -

188.1. Notwithstanding the provisions of Subsection 177.1, any library or archive whose 
activities are not for profit may, without the authorization of the author or copyright owner, 
make a limited number of copies of the work, as may be necessary for such institutions to 
fulfill their mandate, by reprographic reproduction:

(a) Where the work by reason of its fragile character or rarity cannot be lent to user in its 
original form;

(b) Where the works are isolated articles contained in composite works or brief portions of 
other published works and the reproduction is necessary to supply them; when this is 
considered expedient, to person requesting their loan for purposes of research or study 
instead of lending the volumes or booklets which contain them; and

(c) Where the making of such limited copies is in order to preserve and, if necessary, in the 
event that it is lost, destroyed or rendered unusable, replace a copy, or to replace, in the 
permanent collection of another similar library or archive, a copy which has been lost, 
destroyed or rendered unusable and copies are not available with the publisher.

188.2. Notwithstanding the above provisions, it shall not be permissible to produce a 
volume of a work published in several volumes or to produce missing tomes or pages of 
magazines or similar works, unless the volume, tome or part is out of stock; *Provided,* That 
every library which, by law, is entitled to receive copies of a printed work, shall be entitled, 
when special reasons so require, to reproduce a copy of a published work which is 
considered necessary for the collection of the library but which is out of stock. (Sec. 13, P.D. 
49a)

---

**_SEC. 189. Reproduction of Computer Program._** -

189.1. Notwithstanding the provisions of Section 177, the reproduction in one (1) backup copy or adaptation of a computer program shall be permitted, without the authorization 
of the author of, or other owner of copyright in, a computer program, by the lawful owner 
of that computer program: *Provided,* That the copy or adaptation is necessary for:

(a) The use of the computer program in conjunction with a computer for the purpose, and 
to the extent, for which the computer program has been obtained; and

(b) Archival purposes, and, for the replacement of the lawfully owned copy of the computer 
program in the event that the lawfully obtained copy of the computer program is lost, 
destroyed or rendered unusable.

189.2. No copy or adaptation mentioned in this Section shall be used for any purpose 
other than the ones determined in this Section, and any such copy or adaptation shall be 
destroyed in the event that continued possession of the copy of the computer program ceases 
to be lawful.

189.3. This provision shall be without prejudice to the application of Section 185 
whenever appropriate. (n)

**_SEC. 190. Importation and Exportation of Infringing Materials._** -

Subject to the approval of the Secretary of Finance, the Commissioner of Customs is 
hereby empowered to make rules and regulations for preventing the importation or 
exportation of infringing articles prohibited under Part IV of this Act and under relevant 
treaties and conventions to which the Philippines may be a party and for seizing and 
condemning and disposing of the same in case they are discovered after they have been 
imported or before they are exported. (Sec. 30, P.D. No. 49)

### CHAPTER IX

### DEPOSIT AND NOTICE

### <em>SEC. 191. Deposit and Notice of Deposit with the National Library and the Supreme Court Library.</em> -

At any time during the subsistence of the copyright, the owner of the copyright or of 
any exclusive right in the work may, for the purpose of completing the records of the 
National Library and the Supreme Court Library, register and deposit with them, by 
personal delivery or by registered mail, two (2) complete copies or reproductions of the 
work in such form as the Directors of the said libraries may prescribe in accordance with regulations: *Provided,* That only works in the field of law shall be deposited with the 
Supreme Court Library. Such registration and deposit is not a condition of copyright 
protection.

### <em>SEC. 192. Notice of Copyright.</em> -

Each copy of a work published or offered for sale may contain a notice bearing the name 
of the copyright owner, and the year of its first publication, and, in copies produced after 
the creator’s death, the year of such death. (Sec. 27, P.D. No. 49a)

### CHAPTER X

### MORAL RIGHTS

### <em>SEC. 193. Scope of Moral Rights.</em> -

The author of a work shall, independently of the economic rights in Section 177 or the 
grant of an assignment or license with respect to such right, have the right:

193.1. To require that the authorship of the works be attributed to him, in particular, the 
right that his name, as far as practicable, be indicated in a prominent way on the copies, and 
in connection with the public use of his work;

193.2. To make any alterations of his work prior to, or to withhold it from publication;

193.3. To object to any distortion, mutilation or other modification of, or other 
derogatory action in relation to, his work which would be prejudicial to his honor or 
reputation; and

193.4. To restrain the use of his name with respect to any work not of his own creation 
or in a distorted version of his work. (Sec. 34, P.D. No. 49)

### <em>SEC. 194. Breach of Contract.</em> -

An author cannot be compelled to perform his contract to create a work or for the 
publication of his work already in existence. However, he may be held liable for damages 
for breach of such contract. (Sec. 35, P.D. No. 49)

### <em>SEC. 195. Waiver of Moral Rights.</em> -

An author may waive his rights mentioned in Section 193 by a written instrument, but 
no such waiver shall be valid where its effects is to permit another:

---

195.1. To use the name of the author, or the title of his work, or otherwise to make use 
of his reputation with respect to any version or adaptation of his work which, because of 
alterations therein, would substantially tend to injure the literary or artistic reputation of 
another author; or

195.2. To use the name of the author with respect to a work he did not create. (Sec. 36, 
P.D. No. 49)

### <em>SEC. 196. Contribution to Collective Work.</em> -

When an author contributes to a collective work, his right to have his contribution 
attributed to him is deemed waived unless he expressly reserves it. (Sec. 37. P.D. No. 49)

### <em>SEC. 197. Editing, Arranging and Adaptation of Work.</em> -

In the absence of a contrary stipulation at the time an author licenses or permits another 
to use his work, the necessary editing, arranging or adaptation of such work, for publication, 
broadcast, use in a motion picture, dramatization, or mechanical or electrical reproduction 
in accordance with the reasonable and customary standards or requirements of the medium 
in which the work is to be used, shall not be deemed to contravene the author's rights 
secured by this chapter. Nor shall complete destruction of a work unconditionally 
transferred by the author be deemed to violate such rights. (Sec. 38, P.D. No. 49)

### <em>SEC. 198. Term of Moral Rights.</em> -

198.1. The rights of an author under Section 193.1. shall last during the lifetime of the 
author and in perpetuity after his death while the rights under Sections 193.2.  193.3. and 
193.4. shall be coterminous with the economic rights, the moral rights shall not be assignable 
or subject to license. The person or persons to be charged with the posthumous enforcement 
of these rights shall be named in a written instrument which shall be filed with the National 
Library. In default of such person or persons, such enforcement shall devolve upon either 
the author’s heirs, and in default of the heirs, the Director of the National Library.

198.2. For purposes of this Section, "Person" shall mean any individual, partnership, 
corporation, association, or society. The Director of the National Library may prescribe 
reasonable fees to be charged for his services in the application of provisions of this Section. 
(Sec. 39, P.D. No. 49)

### <em>SEC. 199. Enforcement Remedies.</em> -

Violation of any of the rights conferred by this Chapter shall entitle those charged with 
their enforcement to the same rights and remedies available to a copyright owner. In 
addition, damages which may be availed of under the Civil Code may also be recovered.

---

Any damage recovered after the creator's death shall be held in trust for and remitted to his 
heirs, and in default of the heirs, shall belong to the government. (Sec. 40, P.D. No. 49)

### CHAPTER XI

### RIGHTS TO PROCEEDS IN SUBSEQUENT TRANSFERS

**_SEC. 200. Sale or Lease of Work._** -

In every sale or lease of an original work of painting or sculpture or of the original 
manuscript of a writer or composer, subsequent to the first disposition thereof by the author, 
the author or his heirs shall have an inalienable right to participate in the gross proceeds of 
the sale or lease to the extent of five percent (5%). This right shall exist during the lifetime of 
the author and for fifty (50) years after his death. (Sec. 31, P.D. No. 49)   
**_SEC. 201. Works Not Covered._** -

The provisions of this Chapter shall not apply to prints, etchings, engravings, works of 
applied art, or works of similar kind wherein the author primarily derives gain from the 
proceeds of reproductions. (Sec. 33, P.D. No. 49)

### CHAPTER XII

### RIGHTS OF PERFORMERS, PRODUCERS OF SOUND RECORDINGS AND BROADCASTING ORGANIZATIONS

**_SEC. 202. Definitions._** -

For the purpose of this Act, the following terms shall have the following meanings:

202.1. "Performers" are actors, singers, musicians, dancers, and other persons who act, 
sing, declaim, play in, interpret, or otherwise perform literary and artistic work;

202.2. "Sound recording" means the fixation of the sounds of a performance or of other 
sounds, or representation of sound, other than in the form of a fixation incorporated in a 
cinematographic or other audiovisual work;

202.3. An "audiovisual work or fixation" is a work that consists of a series of related 
images which impart the impression of motion, with or without accompanying sounds, 
susceptible of being made visible and, where accompanied by sounds, susceptible of being 
made audible;

---

202.4. "Fixation" means the embodiment of sounds, or of the representations thereof, 
from which they can be perceived, reproduced or communicated through a device;

202.5. "Producer of a sound recording" means the person, or the legal entity, who or 
which takes the initiative and has the responsibility for the first fixation of the sounds of a 
performance or other sounds, or the representation of sounds;

202.6. "Publication of a fixed performance or a sound recording" means the offering of 
copies of the fixed performance or the sound recording to the public, with the consent of the 
right holder: Provided, that copies are offered to the public in reasonable quality;

202.7. "Broadcasting" means the transmission by wireless means for the public reception 
of sounds or of images or of representations thereof; such transmission by satellite is also 
"broadcasting" where the means for decrypting are provided to the public by the 
broadcasting organization or with its consent;

202.8. "Broadcasting organization" shall include a natural person or a juridical entity 
duly authorized to engage in broadcasting; and

202.9. "Communication to the public of a performance or a sound recording" means the 
transmission to the public, by any medium, otherwise than by broadcasting, of sounds of a 
performance or the representations of sounds fixed in a sound recording. For purposes of 
Section 209, "communication to the public" includes making the sounds or representations 
of sounds fixed in a sound recording audible to the public.

### <em>SEC. 203. Scope of Performers&#39; Rights.</em> -

## SEC. 203. Scope of Performers' Rights. -

Subject to the provisions of Section 212, performers shall enjoy the following exclusive 
rights:

203.1. As regards their performances, the right of authorizing:

(a) The broadcasting and other communication to the public of their performance; 
and

(b) The fixation of their unfixed performance.

203.2. The right of authorizing the direct or indirect reproduction of their performances 
fixed in sound recordings or audiovisual works or fixations in any manner or form;

203.3. Subject to the provisions of Section 206, the right of authorizing the first public 
distribution of the original and copies of their performance fixed in the sound recordings or audiovisual works or fixations through sale or rental or other forms of transfer of 
ownership;

203.4. The right of authorizing the commercial rental to the public of the original and 
copies of their performances fixed in sound recordings or audiovisual works or fixations, 
even after distribution of them by, or pursuant to the authorization by the performer; and

203.5. The right of authorizing the making available to the public of their performances 
fixed in sound recordings or audiovisual works or fixations, by wire or wireless means, in 
such a way that members of the public may access them from a place and time individually 
chosen by them. (Sec. 42, P.D. No. 49a)

### <em>SEC. 204. Moral Rights of Performers.</em> -

204.1. Independently of a performer's economic rights, the performer, shall, as regards 
his live aural performances or performances fixed in sound recordings or in audiovisual 
works or fixations, have the right to claim to be identified as the performer of his 
performances, except where the omission is dictated by the manner of the use of the 
performance, and to object to any distortion, mutilation or other modification of his 
performances that would be prejudicial to his reputation.

204.2. The rights granted to a performer in accordance with Subsection 203.1 shall be 
maintained and exercised fifty (50) years after his death, by his heirs, and in default of heirs, 
the government, where protection is claimed. (Sec. 43, P.D. no. 49)

### <em>SEC. 205. Limitation on Right.</em> -

205.1. Subject to the provisions of Section 206, once the performer has authorized the 
broadcasting or fixation of his performance, the provisions of Sections 203 shall have no 
further application.

205.2. The provisions of Section 184 and Section 185 shall apply mutatis mutandis to 
performers. (n)

### <em>SEC.</em> 206. Additional Remuneration for Subsequent Communications or Broadcasts. -

Unless otherwise provided in the contract, in every communication to the public or 
broadcast of a performance subsequent to the first communication or broadcast thereof by 
the broadcasting organization, the performer shall be entitled to an additional remuneration 
equivalent to at least five percent (5%) of the original compensation he or she received for 
the first communication or broadcast. (n)

---

### <em>SEC. 207. Contract Terms.</em> -

Nothing in this Chapter shall be construed to deprive performers of the right to agree 
by contracts on terms and conditions more favorable for them in respect of any use of their 
performance. (n)

### CHAPTER XIII

### PRODUCERS OF SOUND RECORDINGS

### <em>SEC. 208. Scope of Right.</em> -

Subject to the provisions of Section 212, producers of sound recordings shall enjoy the 
following exclusive rights:

208.1. The right to authorize the direct or indirect reproduction of their sound 
recordings, in any manner or form; the placing of these reproductions in the market and the 
right of rental or lending;

208.2. The right to authorize the first public distribution of the original and copies of 
their sound recordings through sale or rental or other forms of transferring ownership; and

208.3. The right to authorize the commercial rental to the public of the original and copies 
of their sound recordings, even after distribution by them by or pursuant to authorization 
by the producer. (Sec. 46, P.D. No. 49a)

208.4. The right to authorize the making available to the public of their sound recordings 
in such a way that members of the public may access the sound recording from a place and 
at a time individually chosen or selected by them, as well as other transmissions of a sound 
recording with like effect.

### <em>SEC. 209. Communication to the Public.</em> -

If a sound recording published for commercial purposes, or a reproduction of such 
sound recording, is used directly for broadcasting or for other communication to the public, 
or is publicly performed with the intention of making and enhancing profit, a single 
equitable remuneration for the performer or performers, and the producer of the sound 
recording shall be paid by the user to both the performers and the producer, who, in the 
absence of any agreement shall share equally. (Sec. 47, P.D. No. 49a)

### <em>SEC. 210. Limitation of Right.</em> -

Sections 184 and 185 shall apply *mutatis mutandis* to the producer of sound recordings. 
(Sec. 48, P.D. No. 49a)

---

### CHAPTER XIV BROADCASTING ORGANIZATIONS

**_SEC. 211. Scope of Right._** -

Subject to the provisions of Section 212, broadcasting organizations shall enjoy the 
exclusive right to carry out, authorize or prevent any of the following acts:

211.1. The rebroadcasting of their broadcasts;

211.2. The recording in any manner, including the making of films or the use of video 
tape, of their broadcasts for the purpose of communication to the public of television 
broadcasts of the same; and

211.3. The use of such records for fresh transmissions or for fresh recording. (Sec. 52, 
P.D. No. 49)

### CHAPTER XV

### LIMITATIONS ON PROTECTION

**_Sec. 212. Limitations on Rights._** -

The provisions of Chapter VIII shall apply *mutatis mutandis* to the rights of 
performers, producers of sound recordings and broadcasting organizations.

### CHAPTER XVI

### TERM OF PROTECTION

**_SEC. 213. Term of Protection._** -

213.1. Subject to the provisions of Subsections 213.2 to 213.5, the copyright in works 
under Sections 172 and 173 shall be protected during the life of the author and for fifty (50) 
years after his death. This rule also applies to posthumous works. (Sec. 21, first sentence, 
P.D. No. 49a)

---

213.2. In case of works of joint authorship, the economic rights shall be protected during 
the life of the last surviving author and for fifty (50) years after his death. (Sec. 21, second 
sentence, P.D. no. 49)

213.3. In case of anonymous or pseudonymous works, the copyright shall be protected 
for fifty (50) years from the date on which the work was first lawfully published: *Provided,* 
That where, before the expiration of the said period, the author's identity is revealed or is no 
longer in doubt, the provisions of Subsections 213.1 and 213.2 shall apply, as the case may 
be: *Provided, further,* That such works if not published before shall be protected for fifty (50) 
years counted from the making of the work. (Sec. 23, P.D. No. 49)

213.4. In case of works of applied art the protection shall be for a period of twenty-five 
(25) years from the date of making. (Sec. 24(B), P.D. No. 49a)

213.5. In case of photographic works, the protection shall be for fifty (50) years from 
publication of the work and, if unpublished, fifty (50) years from the making. (Sec. 24(C), 
P.D. 49a)

213.6. In case of audio-visual works including those produced by process analogous to 
photography or any process for making audio-visual recordings, the term shall be fifty (50) 
years from date of publication and, if unpublished, from the date of making. (Sec. 24(C), P.D. 
No. 49a)

### <em>SEC. 214. Calculation of Term.</em> -

The term of protection subsequent to the death of the author provided in the preceding 
Section shall run from the date of his death or of publication, but such terms shall always be 
deemed to begin on the first day of January of the year following the event which gave rise 
to them. (Sec. 25, P.D. No. 49)

### <em>SEC. 215. Term of Protection for Performers, Producers and Broadcasting Organizations.</em> -

215.1. The rights granted to performers and producers of sound recordings under this 
law shall expire:

(a) For performances not incorporated in recordings, fifty (50) years from the end of the 
year in which the performance took place; and

(b) For sound or image and sound recordings and for performances incorporated therein, 
fifty (50) years from the end of the year in which the recording took place.

---

215.2. In case of broadcasts, the term shall be twenty (20) years from the date the 
broadcast took place. The extended term shall be applied only to old works with subsisting 
protection under the prior law. (Sec. 55, P.D. No. 49a)

### CHAPTER XVII

### INFRINGEMENT

### <em>SEC.</em> 216. Infringement. -

## SEC. 216. Infringement. -

Any person infringes a right protected under this Act when one:

(a) Directly commits an infringement;

(b) Benefits from the infringing activity of another person who commits an infringement if 
the person benefiting has been given notice of the infringing activity and has the right 
and ability to control the activities of the other person;

(c) With knowledge of infringing activity, induces, causes or materially contributes to the 
infringing conduct of another.

(d) 216.1 Remedies for Infringement

(e) Any person infringing a right protected under this law shall be liable:

(f) To an injunction restraining such infringement. The court may also order the defendant 
to desist from an infringement, among others, to prevent the entry into the channels of 
commerce of imported goods that involve an infringement, immediately after customs 
clearance of such goods.

(g) To pay to the copyright proprietor or his assigns or heirs such actual damages, including 
legal costs and other expenses, as he may have incurred due to the infringement as well 
as the profits the infringer may have made due to such infringement, and in proving 
profits the plaintiff shall be required to prove sales only and the defendant shall be 
required to prove every element of cost which he claims, or, in lieu of actual damages 
and profits, such damages which to the court shall appear to be just and shall not be 
regarded as penalty: *Provided,* That the amount of damages to be awarded shall be 
doubled against any person who:

(h) Circumvents effective technological measures; or

(i) Having reasonable grounds to know that it will induce, enable, facilitate or conceal the 
infringement, remove or alter any electronic rights management information from a 
copy of a work, sound recording, or fixation of a performance, or distribute, import for 
distribution, broadcast, or communicate to the public works or copies of works without authority, knowing that electronic rights management information has been removed 
or altered without authority.

(j) Deliver under oath, for impounding during the pendency of the action, upon such terms 
and conditions as the court may prescribe, sales invoices and other documents 
evidencing sales, all articles and their packaging alleged to infringe a copyright and 
implements for making them.

(k) Deliver under oath for destruction without any compensation all infringing copies or 
devices, as well as all plates, molds, or other means for making such infringing copies 
as the court may order.

(l) Such other terms and conditions, including the payment of moral and exemplary 
damages, which the court may deem proper, wise and equitable and the destruction of 
infringing copies of the work even in the event of acquittal in a criminal case.

The copyright owner may elect, at any time before final judgment is rendered, to recover 
instead of actual damages and profits, an award of statutory damages for all infringements 
involved in an action in a sum equivalent to the filing fee of the infringement action but not 
less than Fifty thousand pesos (Php50,000.00). In awarding statutory damages, the court 
may consider the following factors:

(1) The nature and purpose of the infringing act;

(2) The flagrancy of the infringement;

(3) Whether the defendant acted in bad faith;

(4) The need for deterrence;

(5) Any loss that the plaintiff has suffered or is likely to suffer by reason of the infringement; 
and

(6) Any benefit shown to have accrued to the defendant by reason of the infringement.

In case the infringer was not aware and had no reason to believe that his acts constitute 
and infringement of copyright, the court in its discretion may reduce the award of statutory 
damages to a sum of not more than Ten thousand pesos (Php10,000.00): *Provided,* That the 
amount of damages to be awarded shall be doubled against any person who:

(i) Circumvents effective technological measures; or

(ii) Having reasonable grounds to know that it will induce, enable, facilitate or conceal the 
infringement, remove or alter any electronic rights management information from a 
copy of a work, sound recording, or fixation of a performance, or distribute, import for 
distribution, broadcast, or communicate to the public works or copies of works without authority, knowing that electronic rights management information has been removed 
or altered without authority.

216.2.  In an infringement action, the court shall also have the power to order the seizure 
and impounding of any article which may serve as evidence in the court proceedings, in 
accordance with the rules on search and seizure involving violations of intellectual property 
rights issued by the Supreme Court. (Sec.28, P.D. No. 49a)

The foregoing shall not preclude an independent suit for relief by the injured party by 
way of damages, injunction, accounts or otherwise.

### SEC. 217. Criminal Penalties

217.1. Any person infringing any right secured by provisions of Part IV of this Act or 
aiding or abetting such infringement shall be guilty of a crime punishable by:

(a) Imprisonment of one (1) year to three (3) years plus a fine ranging from Fifty thousand 
pesos (P50,000) to One hundred fifty thousand pesos (P150,000) for the first offense.

(b) Imprisonment of three (3) years and one (1) day to six (6) years plus a fine ranging from 
One hundred fifty thousand pesos (P150,000) to Five hundred thousand pesos 
(P500,000) for the second offense.

(c) Imprisonment of six (6) years and one (1) day to nine (9) years plus a fine ranging from 
Five hundred thousand pesos (P500,000) to One million five hundred thousand pesos 
(P1,500,000) for the third and subsequent offenses.

(d) In all cases, subsidiary imprisonment in cases of insolvency.

217.2.  In determining the number of years of imprisonment and the amount of fine, the 
court shall consider the value of the infringing materials that the defendant has produced or 
manufactured and the damage that the copyright owner has suffered by reason of the 
infringement: *Provided,* That the respective maximum penalty stated in Section 217.1. (a), (b) 
and (c) herein for the first, second, third and subsequent offense, shall be imposed when the 
infringement is committed by:

(a) The circumvention of effective technological measures;

(b) The removal or alteration of any electronic rights management information from a copy 
of a work, sound recording, or fixation of a performance, by a person, knowingly and 
without authority; or

(c) The distribution, importation for distribution, broadcast, or communication to the 
public of works or copies of works, by a person without authority, knowing that 
electronic rights management information has been removed or altered without 
authority.

---

217.3. Any person who at the time when copyright subsists in a work has in his 
possession an article which he knows, or ought to know, to be an infringing copy of the work 
for the purpose of:

(a) Selling, letting for hire, or by way of trade offering or exposing for sale, or hire, the 
article;

(b) Distributing the article for purpose of trade, or for any other purpose to an extent that 
will prejudice the rights of the copyright owner in the work; or

(c) Trade exhibit of the article in public, shall be guilty of an offense and shall be liable on 
conviction to imprisonment and fine as above mentioned. (Sec. 29, P.D. No. 49a)

### <em>SEC. 218. Affidavit Evidence.</em> -

218.1.   In an action under this Chapter, an affidavit made before a notary public by or 
on behalf of the owner of the copyright in any work or other subject matter and stating that:

(a) At the time specified therein, copyright subsisted in the work or other subject matter;

(b) He or the person named therein is the owner of the copyright; and

(c) The copy of the work or other subject matter annexed thereto is a true copy thereof.

The affidavit shall be admitted in evidence in any proceedings under this Chapter and 
shall be *prima facie* proof of the matters therein stated until the contrary is proved, and the 
court before which such affidavit is produced shall assume that the affidavit was made by 
or on behalf of the owner of the copyright.

### 218.2. In an action under this Chapter

(a) Copyright shall be presumed to subsist in the work or other subject matter to which the 
action relates if the defendant does not put in issue the question whether copyright 
subsists in the work or other subject matter; and

(b) Where the subsistence of the copyright is established, the plaintiff shall be presumed to 
be the owner of the copyright if he claims to be the owner of the copyright and the 
defendant does not put in issue the question of his ownership.

(c) Where the defendant, without good faith, puts in issue the questions of whether copyright 
subsists in a work or other subject matter to which the action relates, or the ownership of 
copyright in such work or subject matter, thereby occasioning unnecessary costs or delay 
in the proceedings, the court may direct that any costs to the defendant in respect of the 
action shall not be allowed by him and that any costs occasioned by the defendant to other 
parties shall be paid by him to such other parties. (n)

---

### <em>SEC. 219. Presumption of Authorship.</em> -

219.1. The natural person whose name is indicated on a work in the usual manner as the 
author shall, in the absence of proof to the contrary, be presumed to be the author of the 
work. This provision shall be applicable even if the name is a pseudonym, where the 
pseudonym leaves no doubt as to the identity of the author.

219.2. The person or body, corporate whose name appears on an audio-visual work in 
the usual manner shall, in the absence of proof to the contrary, be presumed to be the maker 
of said work. (n)

### <em>SEC. 220. International Registration of Works.</em> -

A statement concerning a work, recorded in an international register in accordance with 
an international treaty to which the Philippines is or may become a party, shall be construed 
as true until the contrary is proved except:

220.1. Where the statement cannot be valid under this Act or any other law concerning 
intellectual property.

220.2. Where the statement is contradicted by another statement recorded in the 
international register. (n)

### <em>SEC. 220A. Disclosure of Information.</em> -

Where any article or its packaging or an implement for making it is seized or detained 
under a valid search and seizure under this Act is, or is reasonably suspected to be, by an 
authorized enforcement officer, in violation of this Act, the said officer shall, wherever 
reasonably practicable, notify the owner of the copyright in question or his authorized agent 
of the seizure or detention, as the case may be.

### CHAPTER XVIII

### SCOPE OF APPLICATION

### <em>SEC. 221. Points of Attachment for Works under Sections 172 and 173.</em> -

221.1. The protection afforded by this Act to copyrightable works under Sections 172 
and 173 shall apply to:

(a) Works of authors who are nationals of, or have their habitual residence in the 
Philippines;

---

(b) Audio-visual works the producer of which has his headquarters or habitual residence 
in the Philippines;

(c) Works of architecture erected in the Philippines or other artistic works incorporated in 
a building or other structure located in the Philippines;

(d) Works first published in the Philippines; and

(e) Works first published in another country but also published in the Philippines within 
thirty days, irrespective of the nationality or residence of the authors.

221.2. The provisions of this Act shall also apply to works that are to be protected by 
virtue of and in accordance with any international convention or other international 
agreement to which the Philippines is a party. (n)

### <em>SEC. 222. Points of Attachment for Performers.</em> -

The provisions of this Act on the protection of performers shall apply to:

222.1. Performers who are nationals of the Philippines;

222.2. Performers who are not nationals of the Philippines but whose performances:

(a)Take place in the Philippines; or

(b) Are incorporated in sound recordings that are protected under this Act; or

(c)Which has not been fixed in sound recording but are carried by broadcast qualifying 
for protection under this Act. (n)

### <em>SEC. 223. Points of Attachment for Sound Recordings.</em> -

The provisions of this Act on the protection of sound recordings shall apply to:

223.1. sound recordings the producers of which are nationals of the Philippines; and

223.2. Sound recordings that were first published in the Philippines. (n)

### <em>SEC. 224. Points of Attachment for Broadcasts.</em> -

224.1. The provisions of this Act on the protection of broadcasts shall apply to:

(a) Broadcasts of broadcasting organizations the headquarters of which are situated in 
the Philippines; and

(b) Broadcasts transmitted from transmitters situated in the Philippines.

224.2. The provisions of this Act shall also apply to performers who, and to producers 
of sound recordings and broadcasting organizations which, are to be protected by virtue of 
and in accordance with any international convention or other international agreement to 
which the Philippines is a party. (n)

---

### CHAPTER XIX INSTITUTION OF ACTIONS

### <em>SEC. 225. Jurisdiction.</em> -

Without prejudice to the provisions of Subsection 7.1(c), actions under this Act shall be 
cognizable by the courts with appropriate jurisdiction under existing law. (Sec. 57, P.D. 
No.49a)

### <em>SEC. 226. Damages.</em> -

No damages may be recovered under this Act after the lapse of four (4) years from the 
time the cause of action arose. (Sec. 58, P.D. No. 49)

### CHAPTER XX MISCELLANEOUS PROVISIONS

### <em>SEC. 227. Ownership of Deposit and Instruments.</em> -

All copies deposited and instruments in writing filed with the National Library and the 
Supreme Court Library in accordance with the provisions of this Act shall become the 
property of the Government. (Sec. 60,P.D. No. 49)

### <em>SEC. 228. Public Records.</em> -

The section or division of the National Library and the Supreme Court Library charged 
with receiving copies and instruments deposited and with keeping records required under 
this Act and everything in it shall be opened to public inspection. The Director of the 
National Library is empowered to issue such safeguards and regulations as may be 
necessary to implement this Section and other provisions of this Act. (Sec. 61, P.D. No. 49)

### <em>SEC. 229. Copyright Division Fees.</em> -

The Copyright Section of the National Library shall be classified as a Division upon the 
effectivity of this Act. The National Library shall have the power to collect, for the discharge 
of its services under this Act, such fees as may be promulgated by it from time to time subject 
to the approval of the Department Head. (Sec. 62, P.D. 49a)

### <em>SEC. 230. Adoption of Intellectual Property (IP) Policies.</em> -

Schools and universities shall adopt intellectual property policies that would govern the 
use and creation of intellectual property with the purpose of safeguarding the intellectual 
creations of the learning institution and its employees, and adopting locally-established 
industry practice fair use guidelines. These policies may be developed in relation to licensing 
agreements entered into by the learning institution with a collective licensing organization.

---

## INTELLECTUAL PROPERTY OFFICE OF THE PHILIPPINES (IPOPHL) ISSUANCES ON COPYRIGHT AND RELATED RIGHTS

The IPOPHL Director General, pursuant to Section 7.1(a) of the IP Code which 
grants the power to promulgate rules and guidelines to implement the objectives,
policies, plans, programs, and projects of IPOPHL, has issued the following circulars on 
copyright and related rights.

---

**IPOPHL MEMORANDUM CIRCULAR NO. 2019-025** 
**Series of 2019**

### SUBJECT: PHILIPPINE REGULATIONS IMPLEMENTING THE MARRAKESH TREATY TO FACILITATE ACCESS TO PUBLISHED WORKS FOR PERSONS WHO ARE BLIND, VISUALLY IMPAIRED OR OTHERWISE PRINT DISABLED ---------------------------------------------------------------------------------------------------------------------

**Whereas,** Section 1, Article XIV of the Philippine Constitution provides that: 
The State shall protect and promote the right of all citizens to quality education at all 
levels and shall take appropriate steps to make such education accessible to all.

**Whereas,** the Intellectual Property Office of the Philippines (IPOPHL) is mandated to 
administer and implement the state policies declared in Republic Act No. 8293, the Intellectual 
Property Code of the Philippines (IP Code), as amended by Republic Act No. 10372;

**Whereas,** Sec. 2 of the IP Code, as amended, states that:

The use of intellectual property bears a social function. To this end, the State shall 
promote the diffusion of knowledge and information for the promotion of national 
development and progress and the common good.

**Whereas,** Sec. 184.1(I) of the IP Code, as amended, provides, as one of the limitations on 
copyright:

The reproduction or distribution of published articles or materials in specialized 
format exclusively for the use of the blind, visually- and reading-impaired persons: 
Provided, that such copies and distribution shall be made on a nonprofit basis and 
shall indicate the copyright owner and the date of the original publication.

**Whereas,** as State Party to the UN Convention on the Rights of Persons with Disabilities, 
government entities commit to implement all of the provisions thereof, particularly Articles 24.3, 
30.1 and 30.3, which state, to wit:

24.3. States Parties shall enable persons with disabilities to learn life and social 
development skills to facilitate their full and equal participation in education and as 
members of the community. To this end, States Parties shall take appropriate 
measures, including:

(a) Facilitating the learning of Braille, alternative script, augmentative and alternative 
modes, means and formats of communication and orientation and mobility skills, and 
facilitating peer support and mentoring;

---

(b) Facilitating the learning of sign language and the promotion of the linguistic 
identity of the deaf community;

(c) Ensuring that the education of persons, and in particular children, who are blind, 
deaf or deafblind, is delivered in the most appropriate languages and modes and 
means of communication for the individual, and in environments which maximize 
academic and social development.

30.1 States Parties recognize the right of persons with disabilities to take part on an 
equal basis with others in cultural life, and shall take all appropriate measures to 
ensure that persons with disabilities: (a) enjoy access to cultural materials in accessible 
formats;

30.2 States Parties shall take all appropriate steps, in accordance with international 
law, to ensure that laws protecting intellectual property rights do not constitute an 
unreasonable or discriminatory barrier to access by persons with disabilities to 
cultural materials.

**Whereas,** Republic Act No. 7277, as amended, or the Magna Carta for Persons with 
Disabilities, declares that:

The State shall take into consideration the special requirements of persons 
with disability in the formulation of educational policies and programs. It shall 
encourage learning institutions to take into account the special needs of 
persons with disability with respect to the use of school facilities, class 
schedules, physical education requirements, and other pertinent 
consideration.

**Whereas,** on November 12, 2018, the President of the Republic of the Philippines, 
had signed the Instrument of Accession to the "Marrakesh Treaty to Facilitate Access to 
Published Works for Persons Who Are Blind, Visually Impaired, or Otherwise Print 
Disabled" (MVT);

**Whereas,** the Instrument of Accession was deposited with the Director General of 
the World Intellectual Property Organization (WIPO), in Geneva, Switzerland, on 
December 18, 2018, and consequently, per Article 19 (b) of the MVT, the said treaty had 
been in effect in the Philippines on March 18, 2019;

**Whereas,** there is a need to establish regulations that would properly and 
effectively implement the provisions of Sec. 184.1 of the IP Code and of the MVT, taking 
into consideration the balancing of rights inherent in the intellectual property system;

---

**NOW, THEREFORE,** pursuant to the authority of the Director General under Section 
7.1(a) of the IP Code that grants the power to manage and direct all functions and activities of the 
IPOPHL including the promulgation of rules and guidelines to implement the objectives, policies, 
plans, programs, and projects of the Office, the following Rules are hereby adopted and 
promulgated, as follows:

#### RULE I

#### GENERAL PROVISIONS

**Section 1.**  
Regulations".

**_Short Title._** – These regulations shall be known as the "Philippine Marrakesh

**Section 2.  _Coverage._** – These rules shall apply to facilitating access to certain published 
works without the authorization of the right holder, exclusively for the benefit of persons who 
are blind, visually impaired or otherwise print-disabled and under conditions provided below.

#### Section 3. <em>Definitions.</em> –

## Section 3. Definitions . –

a. Accessible format copy - a copy of a work in an alternative or specialized manner or form, 
including Braille, audio books and other existing formats or ones that may be developed in 
the future, which gives a beneficiary person access to the work, including to permit the person 
to have access as feasibly and comfortably as a person without visual impairment or other 
print disability.

#### b. Authorized entity - an entity that refers to

(i) Organizations that are explicitly recognized or approved by the government to make and 
share accessible format copies. This includes for profit entities authorized or recognized by 
the government to provide education, instructional training, adaptive reading or information 
access to print-disabled individuals. This may also include entities receiving financial 
support from the government to provide the said activities on a non-profit basis; or

(ii) A government institution or non-profit organization that provides the same services to 
beneficiary persons as one of its primary activities or institutional obligations.

c. Beneficiary person - a person who is, regardless of any other disabilities:

(i) blind;

(ii) visually impaired or has a perceptual or reading disability which cannot be improved to give 
visual function substantially equivalent to that of a person who has no such impairment or disability and so is unable to read printed works to substantially the same degree as a person 
without an impairment or disability; or

(iii) otherwise unable, through physical disability, to hold or manipulate a book or to focus or 
move the eyes to the extent that would be normally acceptable for reading.

d. Bureau or BCRR – Bureau of Copyright and Related Rights

e. Director – Director of the Bureau of Copyright and Other Related Rights.

f. Right holder – owner of copyright over works.

g. Works – literary and artistic works within the meaning of Sec. 172.1 (original intellectual 
creations) and 173.1 (derivative works) of the IP Code, in the form of text, notation and/or 
related illustrations, whether published or otherwise made publicly available in any media, 
including in audio form.

#### RULE II

#### AUTHORIZATION OF ENTITIES

**Section 1. Authorizing Government Agency.** –The IPOPHL, through the BCRR, is 
mandated to authorize and recognize entities defined in Sec. 3 (b) of Rule I above. A 
nonrefundable application fee, plus 1% legal research fee, shall be paid by the applicant 
entity to cover expenses of the proceedings and administrative costs.

**Section 2.   _Authorization of For-Profit Entities_** – For-profit entities shall request the 
BCRR for recognition as authorized entity by submitting the following documents:

a. Formal letter request for authorization;

b. Latest reportorial requirements or documents submitted to, duly stamped “received,” or 
issued by the Securities and Exchange Commission (SEC), including:

● Certificate of Incorporation;

● Articles of Incorporation and By-Laws;

● General Information Sheet (GIS); and

● Audited Financial Statements.

c. Organizational structure;

d. List of activities for the benefit of visually impaired persons within the last year;

---

e. List of reproduced works in the accessible format copy, if any;

f. Statement under oath that –

● activities to be undertaken in connection with the request shall be for nonprofit purposes; and

● the documents submitted are true and faithful reproductions of the original, 
and that the material information or data contained in the request are likewise 
true and faithful representations of the facts.

**Section 3.  _Authorization of Non-Profit Organizations._** – Non-profit organizations shall 
request the BCCR for recognition as authorized entity by submitting the following 
documents:

a. Formal letter request for authorization;

b. Latest reportorial requirements or documents submitted to, duly stamped “received” or 
issued by the Securities and Exchange Commission (SEC), including:

● Certificate of Incorporation;

● Articles of Incorporation and By-Laws;

● General Information Sheet (GIS); and

● Audited Financial Statements.

c. Organizational structure;

d. List of activities for the benefit of visually impaired persons within the last year;

e. List of reproduced works in the accessible format copy, if any; and

f. Statement under oath that the documents submitted are true and faithful reproductions of 
the original, and that the material information or data contained in the request are likewise 
true and faithful representations of the facts.

**Section 4. _Authorization of Government Agencies._** – Government agencies that provide 
education, instructional training, adaptive reading or information access to print-disabled 
individuals pursuant to their mandates shall submit a letter addressed to the BCRR, 
informing the latter of its intention to avail of the rights granted under the Marrakesh Treaty 
and of Sec. 184.1(1) of the IP Code.

**Section 5.  _Authorized Beneficiary Person._** – Notwithstanding the authorization of entities, 
a beneficiary person/s, or someone acting on his or her or their behalf, including a primary 
caretaker, trusted caregiver or personal assistant, is/are authorized to make an accessible 
format copy of a work for personal use of the beneficiary person or otherwise may assist the beneficiary person to make and use accessible format copies where the beneficiary person 
has lawful access to that work or a copy of that work.

**Section 6.   _Third Party Observation._** – Within three (3) days from filing, the letter request 
for authorization shall be published in the IPOPHL website. Any interested party may 
submit written observations thereon to the BCRR within fifteen (15) days from said 
publication. Within three (3) days from submission of any written observation, the BCRR 
shall communicate the observations to the applicant entity who may comment on them 
within ten (10) days from receipt of said communication. The BCRR shall acknowledge and 
consider the observations and comments in making its decision.

**Section 7.    _Decision of the Director._** – The Director shall examine the merits of the request 
for authorization within thirty (30) days from receipt of the last observation or comment of 
the parties. Thereafter, the Director shall render a decision granting or denying 
authorization. The corresponding certificate shall be issued within one (1) week from date 
of the decision.

**Section 8.    _Denial of Authorization or of Renewal._** – Authorization or renewal thereof may 
be denied on the following grounds:

(a) Non-compliance with the provisions of Sections 2 or 3 above;

(b) The information supporting the application and/or the third-party observation reveal 
that the entity cannot effectively perform the duties and responsibilities of an authorized 
entity as enumerated in Sec. 11 below; and

(c) Misrepresentation and other analogous circumstances.

**Section 9.    _Effectivity of Authorization._** – The authorization shall be effective for a period 
of three (3) years starting from the date of issuance of the decision granting the authorization.

**Section 10.  _Duties and Responsibilities of Authorized Entities._** – Authorized entities shall 
have the following duties and responsibilities:

a. Establish that the persons they serve are beneficiary persons;

b. Limit to beneficiary persons and/or authorized entities its distribution and making 
available of works in accessible format copies;

c. Prevent the reproduction, distribution and making available of unauthorized copies;

---

d. Maintain due care in, and records of, its handling of copies of works, while respecting 
the privacy of beneficiary persons in accordance with Republic Act No. 10173, the Data 
Privacy Act of 2012; and

e. Provide the following information in an accessible way, on request, to beneficiary 
persons, other authorized entities or right holders:

(i) the list of works or other subject matter for which it has accessible format copies 
and the available formats; and

(ii) the name and contact details of the authorized entities with which it has engaged 
in the exchange of accessible format copies pursuant to Rule IV below.

f. Assist the BCRR in information dissemination on the MVT, Section 184.1 of the IP Code, 
and these rules to beneficiary persons, potential authorized entities and the general 
public.

**Section 11. _Reportorial Requirement._** – Authorized entities shall submit the information 
required under Section 11(e) to BCRR on or before the anniversary of its authorization or 
manifestation of authorized status.

**Section 12.   _Renewal of Authorization._** – An authorized entity may apply for renewal of 
its authorization at least thirty (30) days before the expiration of the term, and submitting 
any updates on the requirements in Sections 2 and 3 above.

**Section 13.  _Publication upon Approval or Renewal of Authorization._** – BCRR shall 
publish, in the IPOPHL website, the list of authorized entities, their contact details and their 
corresponding certificates, as may be allowed under Republic Act No. 10173, or the Data 
Privacy Act of 2012.

**Section 14.  _Suspension and Cancellation of Authorization._** – The BCRR Director shall 
suspend, *motu proprio* or at the instance of the beneficiary person/s, or an interested party, 
after giving the concerned entity due notice and opportunity to be heard, the authorization 
of an entity, for any of the following grounds:

a. Perjury, false representation, falsification, forgery and misrepresentation of 
documents, material information or data contained in the documents submitted under 
Sections 2 or 3 as may be determined by the BCRR;

---

b. Failure to engage in any of the activities under Section 1, Rule III within one (1) year 
after authorization. In this connection, an authorized entity may be allowed to 
surrender its certificate or authorization should, in its assessment, it will not be able to 
perform any of the said activities; and

c. Failure to submit the reportorial requirements as contained in Section 12.

Except in the case of (a) which shall be a ground for permanent cancellation, compliance or 
non-compliance with the requirements of (b) within six (6) months and (c) within three (3) 
months, from the date of suspension shall trigger the issuance of a compliance order or 
permanent cancellation order, as the case may be.

**Section 15.  _New Application._** – The entity whose authorization has been cancelled may 
file a new application for authorization within six (6) months, subject to the same 
requirements and procedure as the previous application.

**Section 16.  _Appeal to the Director General._** – The decision of the Director denying 
authorization or renewal thereof, or suspending the authorization, shall be appealable to the 
Director General, subject to the IPOPHL Uniform Rules on Appeal, as amended.

### RULE III

### AUTHORIZED ACTIVITIES

**Section 1.  _Authorized Activities._** – Authorized entities are permitted, without the 
consent of the right holder, to do the following authorized activities:

a. Make an accessible format copy of a work;

b. Obtain from another authorized entity an accessible format copy, and supply those 
copies to beneficiary persons by any means, including non-commercial lending or by 
electronic communication by wire or wireless means; and

c. Undertake any intermediate steps necessary and indispensable to the above activities.

**Section 2.**

by contract.

**_Relation to Contract_** – The authorized activities above cannot be overridden

**Section 3.  _Conditions for the Making of Accessible Format Copies of a Work._** -

Authorized entities shall be permitted to make accessible format copies of a work, subject to 
<u>the following conditions:</u> a. The authorized entity must have lawful access to the work or a copy of the work. This 
means that the authorize must have a legitimate and original copy of the work to be 
converted;

b. The work is converted to an accessible format copy, which may include any means 
needed to navigate information in the accessible format, but does not introduce 
changes other than those needed to make the work accessible to the beneficiary person;

c. The accessible format copy shall indicate the copyright owner and date of the original 
publication;

d. Such accessible format copies are supplied exclusively to be used by beneficiary 
persons; and

e. The conversion is undertaken on a non-profit basis and does not unreasonably 
prejudice the legitimate interests of the right holder.

**Section 4.  _Reasonable Fees_** – Nothing in this rule precludes an authorized entity from 
charging a reasonable fee for making or sharing accessible format copies in order to cover 
its expenses.

### RULE IV

### CROSS-BORDER EXCHANGE OF ACCESSIBLE FORMAT COPIES

**Section 1. *Exchange through* an _Authorized Entity._** – Authorized entities are permitted, 
without the authorization of the right holder, to import, distribute or make available for the 
exclusive use of beneficiary persons accessible format copies from an authorized entity in 
another Contracting Party to the MVT, or to export to an authorized entity in such Party.

**Section 2.  *Exchange through* a _Beneficiary Person._** – Authorized entities are permitted, 
without the authorization of the right holder, to import, distribute or make available for the
exclusive use of beneficiary persons accessible format copies from a beneficiary person in
another Contracting Party to the MVT, or to export to a beneficiary person in such Party.

**Section 3.   _Importation for Personal Use._** – A beneficiary person, someone acting on his or 
her behalf, or an authorized entity, is permitted, without the authorization of the right 
holder, to import an accessible format copy for the personal use of such person.

---

**Section 4.  _Voluntary Sharing of Information._** – Authorized entities are encouraged to 
voluntarily share information that would assist them in identifying one another and in 
ascertaining policies and practices, to interested parties and members of the public, as may 
be allowed under Republic Act No. 10173 or the Data Privacy Act of 2012.

### RULE V FINAL PROVISIONS

**Section 1.  _Construction in Favor of Beneficiaries._** – These Implementing Rules and 
Regulations shall be liberally construed to promote access to, and use of works, by the herein 
beneficiary persons. All doubts in the implementation and interpretation of these Rules shall 
be resolved in favor of the beneficiary persons, consistent with the spirit and letter of the 
Marrakesh Treaty and Section 2 in relation to Sec. 184.1 of the Intellectual Property Code.

**Section 2.   *Without Prejudice* to _Other Limitations and Exceptions._** – Nothing in these rules 
shall affect any provisions which promote access to and use of works by beneficiary persons, 
which may be contained in national law and international treaties in force in the 
Philippines.

**Section 3. _Information Dissemination._** – The BCRR, with the assistance of concerned 
government agencies and authorized entities, shall make the MVT, Section 184.1 of the IP
Code, and these rules widely known, through active and appropriate means and formats, to
beneficiary persons, potential authorized entities and the general public.

**Section 4.   _Separability Clause._** – If any section or provision of these Rules shall be held to 
be invalid, the remaining provisions shall remain in full force and effect as completely as if 
the part held invalid has not been included therein.

**Section 5.   _Effectivity._** – These Rules shall take effect after fifteen (15) days from publication 
in a newspaper of general circulation.

**Section 6.   *Furnishing* of _Certified Copies._** – Certified copies of this Memorandum Circular 
shall be filed with the University of the Philippines Law Center, the Department of Trade 
and Industry, the Senate of the Philippines, the House of Representatives, the Supreme 
Court of the Philippines and the National Library.

Done this 20<sup>th</sup> day of December 2019, at Taguig City, Philippines.

(Sgd.) **JOSEPHINE R. SANTIAGO, LL.M.** 
      Director General

---

**IPOPHL MEMORANDUM CIRCULAR NO. 2020-022**

### SUBJECT: REVISED RULES AND REGULATIONS ON THE RESOLUTION OF DISPUTES RELATING TO THE TERMS OF A LICENSE INVOLVING THE AUTHOR’S RIGHT TO PUBLIC PERFORMANCE OR OTHER <u>COMMUNICATION OF HIS WORK</u>

WHEREAS, Section 13, Article XIV of the 1987 Constitution declares that “[t]he State shall 
protect and secure the exclusive rights of scientists, inventors, artists, and other gifted citizens to 
their intellectual property and creations, particularly when beneficial to the people, for such period 
as may be provided by law”;

WHEREAS, the State enacted Republic Act No. 8293, the Intellectual Property Code of the 
Philippines (IP Code), as amended, in pursuit of the above policy;

WHEREAS, Part IV of the IP Code refers to the Law on Copyright, which provides for the 
rights of creators of literary and artistic works as well as the protection and enforcement of such 
rights.

WHEREAS, in the proper implementation of the Law on Copyright, there is a need to clarify 
the provisions thereof for the guidance of the general public and thus promote awareness and respect 
of copyright as an intellectual property;

WHEREAS, there is a need to revise and update the existing Revised Rules and 
Regulations on Resolution of Disputes Relating to the Terms of a License Involving the 
Author’s Right to Public Performance or Other Communication of His Work, as contained 
in Intellectual Property Office of the Philippines (IPOPHL) Office Order No. 13-169 (2013), 
in order to better realize the objectives thereof as well as to properly address the concerns of 
all stakeholders;

NOW, THEREFORE, pursuant to the foregoing, the following rules and regulations are hereby 
adopted:

**Section 1. _Short Title._** – These Rules and Regulations shall be referred to as the “Revised Rules on 
the Resolution of Public Performance Disputes.”

**Section 2. _Scope._** – These Rules shall govern the procedure to be observed in the resolution of 
disputes involving the author’s right to public performance or other communication of his work.

**Section 3. _Definition of Terms._** – Unless otherwise specified, the following terms shall have the 
meaning herein provided:

---

(a) *“Author”* or *“Creator”* – the natural person who created a work.

(b) *“Bureau”* or *“BCRR”* – the Bureau of Copyright and Other Related Rights of the Intellectual 
Property Office of the Philippines.

(c) *“Communication to the public”* or *“communicate to the public”* – any communication to the public, 
including broadcasting, rebroadcasting, retransmitting by cable, broadcasting and retransmitting 
by satellite, and includes the making of a work available to the public by wire or wireless means 
in such a way that members of the public may access these works from a place and time 
individually chosen by them.

(d) *“Director General”* – the head of the Intellectual Property Office of the Philippines.

(e) *“Director”* – the Director of the Bureau of Copyright and Other Related Rights.

(f) *“Alternative Dispute Resolution Service”* – the department or unit of the Intellectual Property 
Office primarily in charge of mediation proceedings.

(g) *“Mediator”* – any officer designated by the Alternative Dispute Resolution Service to amicably 
resolve disputes.

(h) *“Office”* – refers to the Intellectual Property Office of the Philippines.

(i) *“Public performance”* – (1) the showing of images in sequence and the making of the sounds 
accompanying it audible in the case of an audiovisual work; (2) the act of making the recorded 
sounds audible, in the case of a sound recording; (3) the recitation, playing, dancing, acting or 
otherwise performing, either directly or by means of any device or process, in the case of a work 
other than an audiovisual work.

Public performance as defined above must be made in a place or places where persons outside 
the normal circle of a family and that family’s closest social acquaintances are or can be present, 
irrespective of whether they are or can be present at the same place and at the same time, or at 
different places and/or at different times, and where the performance can be perceived without 
the need for communication within the meaning of ‘communication to the public’ or 
‘communicate to the public’.

**Section 4. _Jurisdiction of the Director._** – The Director of the Bureau of Copyright and Other
Related Rights shall exercise original jurisdiction to resolve disputes relating to the terms of 
a license involving the author’s right to public performance or other communication of his 
work.

---

**Section 5. _Jurisdiction of the Director General._** – The Director General shall exercise 
exclusive appellate jurisdiction over decisions or final orders of the Director of the Bureau 
of Copyright and Other Related Rights in the latter’s exercise of his original jurisdiction.

**Section 6. _Who may File a Complaint._** – Any person affected by the terms of a license 
involving the author’s right to public performance or other communication of his work may 
file a complaint with the Director.

**Section 7. _How Complaint is Filed._** – A person aggrieved by the terms of a license involving 
the author’s right to public performance or other communication of his work shall file a 
Complaint Affidavit with the Director, copy furnished the respondent.

Proof of service of a copy of the Complaint Affidavit to the respondent shall be attached to 
the Complaint Affidavit. Proof of payment of the prescribed filing fee shall likewise be 
attached.

**Section 8.  _Period to File Complaint._** – Any complaint must be filed with the Office of the 
Director within four (4) years from the time the cause of action arose.

**Section 9. _Contents of the Complaint Affidavit._** – The Complaint Affidavit shall state the 
following:

(a) Name and address of the complainant and the name and address of the respondent;

(b) Brief statement of the nature of the complaint;

(c) The demands or reliefs sought;

(d) Verification and certification of non-forum shopping.

**Section 10.  _Notice to Answer._** – Within three (3) days from receipt of the Complaint 
Affidavit, the Director shall issue a Notice to Answer addressed to the respondent. The 
Notice to Answer shall be served upon the respondent by mail or personal service.

**Section 11. _Answer._** – The respondent shall file the answer to the Complaint Affidavit 
within ten (10) days from receipt of the Notice to Answer. The Answer shall state the 
respondent’s defenses, specifically denying the material allegations of the complaint. The 
Answer may also contain affirmative defenses.

**Section 12.  _Motion to Dismiss._** – No motion to dismiss shall be allowed.

**Section 13. _Mediation Process._** – Within three (3) days from receipt of the Answer, the 
Director shall refer the case to the Alternative Dispute Resolution Service for mediation. The

---

Rules on Alternative Dispute Resolution Service of the Office shall apply during the 
mediation period until the case is referred back to the Bureau.

**Section 14. _Judgment on Compromise._** – In case of a successful mediation, the Director shall 
render a judgment based on compromise within five (5) days from the time the case is 
referred back to the Bureau.

**Section 15.  _Order to Submit Memoranda._** – In case of an unsuccessful mediation, the 
Director shall issue an order addressed to the parties to submit their respective memoranda 
within five (5) days from the time the case is referred back to the Bureau.

**Section 16. _Memoranda._** – The parties shall submit their respective memoranda within ten 
(10) days from receipt of the order mentioned in the immediately preceding section. The 
memoranda of the parties shall be supported by evidence.

**Section 17. _Clarificatory Hearing._** – Within ten (10) days from receipt of the last 
memorandum, the Director may call the parties to a clarificatory hearing, if he deems 
necessary.

**Section 18. _Decision of the Director._** – Within twenty (20) days from receipt of the last 
memorandum or after a clarificatory hearing, the Director shall render a Decision.

Before rendering a Decision, the Director may seek the assistance of acknowledged experts 
in their relevant field, whether in the government service or in the private sector.

**Section 19. _Service of Copy of the Decision._** – The Decision of the Director shall be served 
to each of the parties through personal service or, if not practicable, through registered mail.

**Section 20.  _Finality of the Decision of the Director._** – Unless a motion for reconsideration 
is filed or an appeal is taken, the Decision of the Director shall become final and executory 
within thirty (30) days from receipt of a copy thereof by the parties.

**Section 21.  _Motion for Reconsideration._** – Any party aggrieved may file a motion for 
reconsideration within thirty (30) days from receipt of the decision of the Director. Only one 
motion for reconsideration shall be allowed.

**Section 22.  _Appeal before the Office of the Director General._** – The parties may file an appeal 
before the Office of the Director General in accordance with the IPOPHL Uniform Rules on 
Appeal.

---

**Section 23. _Escrow._** – Any party may elect to avail of the provisions of the Civil Code of the 
Philippines on consignation with respect to the royalty or any sum of money that may be 
involved in disputes covered by these Rules. The complainant shall submit a certified true 
copy of the Contract of Escrow to the Director.

**Section 24. _Suppletory Application of the Rules of Court._** – In the absence of any applicable 
provision in these Rules, the pertinent provisions of the Rules of Court in the Philippines 
shall be applicable by analogy or in suppletory character and effect.

**Section 25. _Amendment._** – All rules and regulations, office orders, memoranda, circulars 
and memorandum circulars or parts thereof, and other issuances of the Office inconsistent 
with these Rules are hereby deemed repealed or amended accordingly.

**Section 26. _Separability._** – If any provision in these Rules and Regulations or application of 
such provision to any circumstance is held invalid, the remainder thereof shall not be 
affected thereby.

**Section 27. _Furnishing of Certified Copies._** – The IPOPHL Administrative, Financial and 
Human Resource Development Service Bureau is hereby directed to immediately file three 
(3) certified copies of these rules with the Office of the National Administrative Register of 
the University of the Philippines Law Center.

**Section 28. _Effectivity._** – These Rules and Regulations shall take effect fifteen (15) days after 
publication in a newspaper of general circulation.

Done this 3rd day of July, 2020, at Taguig City, Philippines.

(Sgd.) **ROWEL S. BARBA** 
 Director General

---

### IPOPHL MEMORANDUM CIRCULAR NO. 2020-023

### SUBJECT: IMPLEMENTING RULES AND REGULATIONS ON RESALE RIGHTS ________________________________________________________________________________

WHEREAS, Section 13, Article XIV of the 1987 Constitution declares that “[t]he State shall 
protect and secure the exclusive rights of scientists, inventors, artists, and other gifted 
citizens to their intellectual property and creations, particularly when beneficial to the 
people, for such period as may be provided by law”;

WHEREAS, the State enacted Republic Act No. 8293, the Intellectual Property Code of the 
Philippines (IP Code), as amended, in pursuit of the above policy;

WHEREAS, Sec. 200 of the IP Code provides for a right to proceeds in subsequent transfers, 
or resale right, for artists;

WHEREAS, there is a need to establish implementing rules and regulations pertaining to the 
rights to proceeds in subsequent transfers with the view of protecting copyright owners and 
contribute significantly to the resolution of disputes arising from the interpretation of Sec. 
200;

WHEREAS, Sec. 7.1(a) of the IP Code grants the Director General the power to manage and 
direct all functions and activities of the IPOPHL including the promulgation of rules and 
guidelines to implement the objectives, policies, plans, programs and projects of the Office;

NOW, THEREFORE, in view of the foregoing, the following Rules are hereby adopted and 
promulgated.

#### RULE I GENERAL PROVISIONS

**Section 1. _Short Title._** – These Rules and Regulations shall be known and referred to as the “Rules 
on Resale Rights.”

**Section 2. _Definition of Terms._** — For purposes of these Rules, the following terms shall have the 
meanings provided below:

---

(*a)“Accredited collective management organization”* – a collective management organization 
duly recognized by IPOPHL/Bureau after successfully undergoing the accreditation 
process laid out in the Rules on the Accreditation of Collective Management 
Organizations;

(*b)“Author”* or *“Creator”* – the natural person who has created the work;

(*c)“Art Market Professional”* – someone acting in the course of a business of dealing in 
works of art. The term is used interchangeably with “professional party” or 
“intermediary” as defined below;

(d) *“Bureau”* – refers to the Bureau of Copyright and Other Related Rights of IPOPHL;

(*e)“Collective management organization”* – a group of artists or copyright/related rights 
holders whose primary purpose is to collectively manage copyright and/or related 
rights, including any combination or all of the following activities:

(i) Negotiation with and grant of licenses to users of protected literary, scholarly, 
scientific and artistic works, derivative works, performances, sound recordings 
and broadcasts;

(ii) Collection of royalties and other forms of remuneration for the use of the 
abovementioned; or

(iii)  Distribution of the said collection to the rights holders;

(f) *“First disposition”* – the first transfer of ownership of a work with or without 
consideration. In commissioned works, the transfer of ownership from the author to the 
person who commissioned the work shall be considered the first disposition;

(*g)“Gross proceeds of the sale or lease”* – the consideration stated in the sales document or 
the total amount of money or its equivalent which the purchaser pays or is obligated to 
pay to the seller in consideration of the sale, excluding value added tax (VAT). It means 
the same as “gross selling price”;

(h) *“Lease”* – a contract whereby one of the parties binds himself to give to another the 
enjoyment or use of a thing for a price certain, and for a period which may be definite or 
indefinite;

---

(i) *“Professional party"* or *“intermediary"* — refers to auction houses, art galleries, art 
salesrooms, or any dealer in works of art;

(j) *“Public Museum”* – an institution with a permanent collection, governed by an elected 
or appointed board, founded by civically minded people, existing for the stewardship 
of its collection and the education of the public.

(*k)“Resale”* – the sale of a work subsequent to the first disposition thereof by the author;

(l) *“Resale right”* – the right of artists or their heirs to receive royalty from the resale of 
their work. It also means their right to participate or share in the proceeds of the 
subsequent sale or lease of their work. It is also called *“droit de suite.”*

(m) *“Resale royalty”* – the remuneration given to the author or his heirs ensuing from the resale 
right;

(n) *“Seller”* – a person who owns a work by virtue of a first or subsequent disposition;

(o) *“Work”* – an original work of painting or sculpture or of the original manuscript of 
a writer or composer; and

(p) *“Work of joint authorship”* – a work created by two or more authors.

**Section 3.  _Coverage._** – **These Rules shall apply to** the sale or lease of an author’s original works of 
painting, sculpture or manuscript subsequent to the first disposition thereof by the author, and 
notwithstanding that the works sold may have been made before the effectivity of these Rules.

### Section 4. <em>Works not Covered.</em> – These Rules shall not apply to the following:

a. Prints, etchings, engravings, works of applied art, and works of a similar kind wherein the 
author primarily derives gain from the proceeds of reproductions; and

b. Subsequent sales that are:

i. Made directly between private individuals without the participation of an art market 
professional; or

ii. Made by individuals to public museums.

---

**Section 5. _Authors Covered._** – These Rules cover authors who are citizens of the Philippines 
and of other member states of the Berne Convention with resale rights provisions in their 
national copyright legislation.

#### RULE II RESALE RIGHT AS A SPECIAL ECONOMIC RIGHT

### Section 6. <em>Ownership of Resale Right.</em> —

## Section 6. Ownership of Resale Right. —

6.1 The author of a work, whether done independently or pursuant to employment or 
commission, is entitled to resale rights. Upon the author’s death, such right is 
transmissible to his/her heir(s).

6.2 In the case of a work of joint authorship, the right shall belong to the authors as coowners. They shall hold it in equal shares or as may be agreed upon in writing signed 
by or on behalf of each party.

**Section 7. _Term of Protection._** — The resale right subsists during the lifetime of the author plus fifty 
(50) years after his death. In case of works of joint authorship, the resale right shall be reckoned from 
the moment of creation plus fifty (50) years after the death of the last surviving author.

**Section 8. _Royalty Rate._** —The resale royalty shall be to the extent of five percent (5%) of the gross 
proceeds of the subsequent sale or lease, computed based on Section 14.1 below.

**Section 9. _Presumption of Authorship._** — Where a name purporting to be that of the author appears 
on a work at the time of its creation, the person whose name appears thereon shall, unless the 
contrary is proved, be presumed to be the author of the work.

### Section 10. <em>lnalienability of Resale Right.</em> —

## Section 10. lnalienability of Resale Right. —

10.1 Resale right can neither be taken away from nor given away by the author except in the case 
of succession or other circumstances as may be provided by law.

10.2 Resale right can neither be sold nor waived.

10.3 Any charge or encumbrance on, or assignment or waiver of, or agreement to share or repay, 
the resale right is void.

---

#### RULE III MECHANICS OF RESALE

#### Section 11. <em>Mechanics of Resale.</em> —

## Section 11. Mechanics of Resale. —

11.1 The sale of an original work of art, even if the first transfer of ownership was not made for 
any consideration, money or otherwise, shall be regarded as a resale provided:

a) The subsequent sale involves a professional party or intermediary. In case of lease, the 
same must be for a period longer than one (1) year and covered by a written contract.

b) The work is enrolled and registered in the Registry established in Rule IV hereof.

11.2 “First transfer of ownership" shall include in particular:

a) Transmission of the work from the author by testamentary disposition, or in 
accordance with the rules of intestate succession;

b) Disposal of the work by the author's personal representatives for the purposes of 
administration of his estate;

c) Disposal of the work by an official receiver or a trustee in bankruptcy, for the purposes 
of the realization of the author’s estate.

### Section 12. <em>Liability to Pay Resale Royalty.</em> —

## Section 12. Liability to Pay Resale Royalty. —

12.1 Payment of resale royalty shall be made by the seller to the author or his heirs within sixty 
(60) days from the date of the sale or lease of a work.

12.2 The seller may withhold payment from a person claiming resale rights until sufficient 
evidence of entitlement thereto is produced.

12.3 In case of joint authorship, payment by the seller of the total amount of resale royalty to one 
of the authors shall discharge the former from paying resale royalty to the other author/s. 
The co-author who received the payment shall have the obligation to ensure that the other 
co-authors, their heirs or assigns, shall receive their respective royalty share.

### Section 13. <em>Management of Resale Right.</em> —

## Section 13. Management of Resale Right. —

13.1 *Collective Management.* — The resale right may be exercised through an accredited collective 
management organization by virtue of an authorization allowing management of the right. 
The management of resale right is the collection of resale royalty on behalf of the holder of 
<u>the right in return for a commission, a fixed fee or a percentage of the royalty.</u>

---

13.2 *Individual management.* — Where the holder of the right has not transferred its management 
to a collective management organization, the former alone shall be responsible for 
monitoring and collecting the resale royalty.

### Section 14. <em>Calculation of Resale Royalty.</em> —

## Section 14. Calculation of Resale Royalty. —

14.1 Subject to the limit established in Section 200 of the IP Code, the resale royalty payable 
on the subsequent transfer of a work shall be the sum of the following amounts, being 
percentage amounts of consecutive portions of the sale price:

| Gross Selling Price (PhP) | Percentage amount |
| --- | --- |
| Up to 150,000.00 | 5% |
| 150,000.01 – 350,000.00 | 4% |
| 350,000.01 – 600,000.00 | 3% |
| 600,000.01 – 1,000,000.00 | 2% |
| 1,000,000.01 – 2,000,000.00 | 1.5% |
| 2,000,000.01 – above | 1% |

14.2 If the sale price is not in Philippine Peso, the price shall be converted into Philippine Peso 
at the *Bangko Sentral ng Pilipinas* reference rate prevailing on the contract date.

#### RULE IV CREATION OF A REGISTRY OF QUALIFIED WORKS

**Section 15. _Creation of a Registry of Qualified Works._** – There is hereby created a National 
Registry of Qualified Works to be maintained by the Bureau. This Registry shall provide the 
means for the enrollment and registration of works that qualify for the application of resale 
right. It shall also serve as the repository of information on the author of the work for 
purposes of remittance on the resale royalty.

**Section 16. _Collection of Fees._** – The Bureau shall collect appropriate fees for this service.

---

### RULE V

### DISPUTE RESOLUTION

**Section 17. _Filing of Claim_** – All claims or disputes arising from the application of this 
Implementing Rules and Regulations shall be filed within one (1) year from the time cause 
of the action arose. Such claim shall be considered filed upon payment of the requisite filing 
fee.

**Section 18. _Original Jurisdiction_** – All claims or disputes arising from the application of this 
Implementing Rules and Regulations shall be brought before the Office of the Director of the 
Bureau of Copyright.

**Section 19. _Appellate Jurisdiction_** – Parties aggrieved by the decision of the Director of the 
Bureau of Copyright and Other Related Rights may file an appeal before the Director 
General of the Intellectual Property Office of the Philippines within 30 days from receipt of 
the decision of the Director of the Bureau. The decision of the Director General shall be final.

#### RULE VI FINAL PROVISIONS

**Section 20. _Amendment._** – All rules and regulations, office orders, memoranda, circulars 
and memorandum circulars or parts thereof, and other issuances of the Office 
inconsistent with these Rules are hereby deemed repealed or amended accordingly.

**Section 21. _Separability._** — If any section or provision in these Rules shall be held invalid, 
the remaining provisions shall remain in full force and effect as completely as if the part 
held invalid had not been included therein.

**Section 22. _Furnishing of Certified Copies._** — The IPOPHL Administrative, Financial and 
Human Resource Development Service Bureau is hereby directed to immediately file 
three (3) certified copies of these rules with the Office of the National Administrative 
Register of the University of the Philippines Law Center.

**Section 23. _Effectivity._** – These Rules shall take effect fifteen (15) days after publication 
in a newspaper of general circulation.

Done this 3rd day of July 2020 at Taguig City, Philippines.

(Sgd.)  **ROWEL S. BARBA**
             <u>Director General</u>

---

### IPOPHL MEMORANDUM CIRCULAR NO. 2020-024

### SUBJECT: COPYRIGHT RULES AND REGULATIONS FOR THE GOVERNMENT

WHEREAS, Section 13, Article XIV of the 1987 Constitution declares that “[t]he State 
shall protect and secure the exclusive rights of scientists, inventors, artists, and other gifted 
citizens to their intellectual property and creations, particularly when beneficial to the 
people, for such period as may be provided by law”;

WHEREAS, the State enacted Republic Act No. 8293, the Intellectual Property Code 
of the Philippines (IP Code), as amended, in pursuit the above policy;

WHEREAS, the government itself, through its branches, agencies and 
instrumentalities, is a creator of works which, although not copyright-protected, enjoy 
certain protections pursuant to Section 176 of the IP Code under the concept of “works of 
the government”;

WHEREAS, government, through its branches, agencies and instrumentalities, also 
utilizes works belonging to other agencies, entities and individuals, both public and private;

WHEREAS, there is a need to clarify the rights and duties of government in relation 
to the creation, utilization and protection of works protected under the IP Code;

WHEREAS, Sec. 7.1(a) of the IP Code grants the Director General the power to 
manage and direct all functions and activities of the IPOPHL including the promulgation of 
rules and guidelines to implement the objectives, policies, plans, programs and projects of 
the Office;

NOW, THEREFORE, in view of the foregoing, the following rules and regulations are 
hereby adopted and promulgated.

#### RULE I

#### PRELIMINARY PROVISIONS

**Section 1. _Short Title._** – These Rules and Regulations shall be known and referred to as the 
“Copyright Rules for the Government.”

---

**Section 2. _Scope._** — These Rules shall apply to all works created or used by the 
Government of the Philippines as defined herein, but excludes works covered by Republic 
Act No.10055, otherwise known as the “Technology Transfer Act of 2009.”

**Section 3. _Definitions._** — For purposes of these Rules, the following terms shall have the 
meanings provided below:

a. “Fair Use” – the use of a copyrighted work for criticism, comment, news reporting, 
teaching including multiple copies for classroom use, scholarship, research, and 
similar purposes. In determining whether the use made of a work in any particular 
case is fair use, the factors to be considered shall include: (i) The purpose and 
character of the use, including whether such use is of a commercial nature or is for 
non-profit educational purposes; (ii) The nature of the copyrighted work; (iii) The 
amount and substantiality of the portion used in relation to the copyrighted work as 
a whole; and (iv) The effect of the use upon the potential market for or value of the 
copyrighted work.

b. *“Government”* — refers to those offices within the scope of the Civil Service, 
particularly the legislative, executive, and judicial branches, and the subdivisions, 
instrumentalities, and agencies of the Government of the Philippines, including 
government-owned or controlled corporations with original charters, the Armed 
Forces of the Philippines, and the Civil Service Commission, Commission on 
Elections, and Commission on Audit, as well as other offices and bodies created by 
the Constitution, other chartered institutions including state universities and 
colleges, and local/community colleges;

c. *“Moral Rights”* – refers to the rights of an author: (i) To require that the authorship of 
the works be attributed to him, in particular, the right that his name, as far as 
practicable, be indicated in a prominent way on the copies, and in connection with 
the public use of his work; (ii) To make any alterations of his work prior to, or to 
withhold it from publication; (iii) To object to any distortion, mutilation or other 
modification of, or other derogatory action in relation to, his work which would be 
prejudicial to his honor or reputation; and (iv) To restrain the use of his name with 
respect to any work not of his own creation or in a distorted version of his work.

d. *“Officer of the Government”* — refers to a person holding office in the Philippine 
Government, either in the career or non-career service, by direct provision of law, 
popular election, or appointment by a competent authority under a permanent, 
temporary, substitute, co-terminus, fixed-term, contractual, or casual employment 
status. It is used herein as synonymous to the term “government employee”;

---

e. *“Regularly prescribed official duties"* — refers to the duties and responsibilities stated in 
an employee’s or officer's Civil Service Commission Memorandum Circular (CSC 
MC) Form No. 1, otherwise known as the “Position Description Form," including 
functions related thereto.

f. *“Work of the Government”* — a work created by an officer or employee of the Philippine 
Government or any of its subdivisions and instrumentalities, including governmentowned or controlled corporations, as a part of the officer or employee‘s regularly 
prescribed official duties;

### RULE II

### THE GOVERNMENT AS CREATOR AND USER OF WORKS

**Section 4. _The Government as Creator of Works._** – The Government, through its 
branches, agencies and instrumentalities, may be a creator of works.

**4.1** *No copyright on works of the Government.* — No copyright shall subsist in any work of 
the Government created by an officer or employee thereof as a part of his or her 
regularly prescribed official duties, as defined above. However, this does not create 
the requirement that such work be made publicly available without restrictions nor 
does this preclude the Government or any of its agencies from asserting protection in 
countries where copyright is provided for government works.

While the government does not own the copyright to a work of any of its officers or 
employees when such work was created as a part of the regularly prescribed official 
duties of the latter, the government is not precluded from exercising proprietary 
rights over the work against any party.

**4.2** *Works created by a government employee or for the Government by a non-government 
employee.* —

a. Notwithstanding the immediately preceding Subsection, copyright subsists in the 
following works which, due to the nature and circumstances of their creation, are 
not considered works of the Government:

1. Works that are not part of the regularly prescribed official duties of a 
government employee; or

---

2. Works made for the Government by an author who is not a government 
employee. This includes works created by a consultant.

b. Unless the author of the works mentioned in Sec. 4.2 (a) paragraphs 1 and 2 above 
transfers the copyright over the work to the Government in accordance with the 
provisions of Section 180 of the IP Code, the author remains as the owner of the 
copyright.

**4.3** *Use and Exploitation of Works of the Government.* — Any natural or juridical person, 
association, entity, or institution may use and exploit the works of the Philippine 
government; *Provided,* that prior approval is obtained in the following instances:

a. From the government agency or office wherein the work is created, for 
exploitation of such work for profit. The agency or office may impose as a 
condition the payment of reasonable fees akin to royalties;

b. From both the government agency and the private author in case of works of joint 
authorship if such work will be exploited for profit;

c. From the government agency or office where the government is the transferee of 
copyright through assignment, bequest or otherwise; and

d. From the authors of speeches, lectures, sermons, addresses, and dissertations, 
pronounced, read or rendered in courts of justice, before administrative agencies, 
in deliberative assemblies and in meetings of public character, for the purpose of 
making a collection thereof.

**_4.4_** *When Prior Approval Not Needed.* — Except for the specific and limited purpose of 
making a collection thereof, as mentioned in Section 4.3.d above, no prior approval or 
conditions shall be required for the use of statutes, rules and regulations, and speeches, 
lectures, sermons, addresses, and dissertations, pronounced, read or rendered in courts 
of justice, before administrative agencies, in deliberative assemblies and in meetings of 
public character.

**Section 5. _The Government as User of Works._** – The Government, may be a user of 
works belonging to other agencies, entities and individuals, both public and private.

**5.1** *Prior Permission.* – If copyright subsists over a work that is to be used by the 
Government, permission shall first be sought by the latter from the owner or assignee of the copyright. Likewise, prior permission shall be obtained for the use by a 
government agency of a work belonging to another agency.

**5.2** *Statutory Fair Use.* — The use of a work by the Government or under its direction or 
control is considered as statutory fair use and does not constitute copyright 
infringement under the following conditions:

a. When the use is in the interest of the public; and

b. When the use is compatible with fair use.

**5.3** *Moral rights.* — In the use by the Government of works, the moral rights of authors as 
provided in Sec. 193 of the IP Code shall be respected.

#### RULE III THE GOVERNMENT AS ASSIGNEE OF COPYRIGHT

**Section 6. _The Government as Assignee or Holder of Copyright._** — The Government is not 
precluded from receiving and holding copyright transferred to it by assignment, bequest or 
otherwise, in accordance with the provisions of Chapter VII of the IP Code. This Rule also 
contemplates the assignment of works mentioned in Section 4.2 (b) hereof.

**6.1** *Rights of Government over Assigned Copyright.* — Within the scope of the assignment 
or license, the Government is entitled to all the rights and remedies which the assignor 
or licensor had with respect to the copyright, including the right to sue in its own name.

**Section 7. _No abridgment of copyright on work upon publication or republication by the_** 
**_Government._** — Publication or republication by the Government in a public document of 
any work in which copyright is subsisting shall not be taken to cause any abridgment or 
annulment of the copyright or to authorize any use or appropriation of such work without 
the consent of the copyright owner.

#### RULE IV FINAL PROVISIONS

**Section 8. _Amendment._** – All rules and regulations, office orders, memoranda, circulars and 
memorandum circulars or parts thereof, and other issuances of the Office inconsistent with 
these Rules are hereby deemed repealed or amended accordingly.

---

**Section 9. _Separability_** — If any section or provision in these Rules shall be held invalid, the 
remaining provisions shall remain in full force and effect as completely as if the part held 
invalid had not been included therein.

**Section 10. _Furnishing of Certified Copies._** — The IPOPHL Administrative, Financial and 
Human Resource Development Service Bureau is hereby directed to immediately file three 
(3) certified copies of these rules with the Office of the National Administrative Register of 
the University of the Philippines Law Center.

**Section 11. _Effectivity._** – These Rules shall take effect fifteen (15) days after publication in a 
newspaper of general circulation.

Done this 3rd day of July 2020 at Taguig City, Philippines.

(Sgd.) **ROWEL S. BARBA**
 Director General

---

### IPOPHL MEMORANDUM CIRCULAR NO. 2020-025

### SUBJECT: REVISED RULES AND REGULATIONS ON COPYRIGHT REGISTRATION AND RECORDATION OF TRANSFER, ASSIGNMENT AND LICENSE OF COPYRIGHT

## SUBJECT: REVISED RULES AND REGULATIONS ON COPYRIGHT
## REGISTRATION AND RECORDATION OF TRANSFER,

WHEREAS, Section 13, Article XIV of the 1987 Constitution declares that “[t]he 
State shall protect and secure the exclusive rights of scientists, inventors, artists, and other 
gifted citizens to their intellectual property and creations, particularly when beneficial to 
the people, for such period as may be provided by law”;

WHEREAS, the State enacted Republic Act No. 8293, the Intellectual Property 
Code of the Philippines (IP Code), as amended, in pursuit of the above policy;

WHEREAS, Sec. 191 of the IP Code, as amended by Sec. 16 of Republic Act No. 
10372, provides for the registration and deposit of works with the National Library and 
the Supreme Court Library at any time during the subsistence of the copyright

WHEREAS, in a Memorandum of Agreement (MOA) signed on January 25, 2011, 
the National Library of the Philippines (NLP) deputized the IPOPHL as a receiving office 
for the registration and deposit of copyrighted works as well as documents pertaining to 
deeds of assignment or transfer;

WHEREAS, there is a need to revise and update the existing Rules and Regulations 
on Copyright Registration and Deposit as contained in Office Order No. 13-171 (2013) in 
order to streamline and facilitate the registration of works;

NOW, THEREFORE, pursuant to the foregoing, the following rules and 
regulations are hereby adopted:

#### RULE I GENERAL PROVISIONS

**Section 1. _Short Title._** – These Rules and Regulations shall be referred to as the “Revised 
Rules on Copyright Registration.”

---

**Section 2. _Scope._** – These Rules and Regulations shall apply to manual and online 
registration of copyrighted works and the recordation of deeds of assignment, transfer 
and exclusive license of copyright, before the IPOPHL. They may be adapted *mutatis 
mutandis* by the National Library of the Philippines (NLP). This rule shall not affect the 
system of deposit of works in the field of law maintained by the Supreme Court Library.

**Section 3. _Definition of Terms._** – The following terms as used in this Rule are defined as 
follows:

**3.1** *“Assignee”* – the person or entity to which the author or copyright holder has assigned 
the copyright in whole or in part. Within the scope of the assignment, the assignee is 
entitled to all the rights and remedies which the assignor had with respect to the 
copyright;

**3.2** *“Assignment”* or *“Transfer”* – the transfer, in whole or in part, by the author or copyright 
owner of his economic right over a literary, artistic or scientific work. Assignment or 
transfer involves a transfer of copyright ownership;

**3.3** *“Author” or “Creator”* – the natural person who has created the work;

**3.4** *“Bureau”* or *“BCRR”* – the Bureau of Copyright and Other Related Rights of the 
Intellectual Property Office of the Philippines;

**3.5** *“Copyright”* – the right granted by a statute to the proprietor of a literary, artistic or 
scientific work to its exclusive use and enjoyment to the extent specified in the statute;

**3.6** *“Deposit”* – the act of submitting original or copies of a work to the Bureau;

**3.7** *“Director”* – the Director of the Bureau of Copyright and Other Related Rights of the 
Intellectual Property Office of the Philippines;

**3.8** *“Director General”* – the head of the Intellectual Property Office of the Philippines;

**3.9** *“Heir”* – the person called to the succession either by the provision of a will or by 
operation of law;

**3.10** *“License”* – a contract by which a copyright owner allows the use and exploitation of 
his work for a fee, without transferring ownership of the copyright thereof to another 
person called the licensee;

**3.11** *“Office”* – the Intellectual Property Office of the Philippines;

---

**3.12** *“Recordation”* – the act of putting into the official records of the Bureau of the transfer 
or assignment of or the exclusive license over a work without depositing the work itself;

**3.13** *“Registration”* – the process by which an author or creator submits a claim over a work 
by filing the required documents and by depositing the work itself with the Bureau;

**3.14** *“Storage Medium”* – a device that serves as container of electronic data including, but 
not limited to, universal serial bus (USB) flash drives, optical discs, magnetic tapes or 
such other device that may be developed in the future;

#### RULE II REQUIREMENTS FOR COPYRIGHT REGISTRATION

**Section 1. _Who may Apply._** – The author or creator of the work may apply for a certificate 
of copyright registration. In case of death of, or assignment by, the author or creator, the heir 
or the assignee, as the case may be, may apply for a certificate of registration.

**Section 2. _How Application is Made._** – The application for registration and the payment of 
the filing fee therefor, shall be made in person or online, by the author, heir, or assignee as 
the case may be, or through his duly authorized representative to the IPOPHL.

In case the applicant for registration is a non-resident, application may be made by a duly 
authorized resident agent.

### Section 3. <em>Registration Form.</em> –

## Section 3. Registration Form. –

**3.1** Single Registration – All applicants for copyright registration shall accomplish and file 
the prescribed Registration Form (RF). The RF shall be filed in three (3) copies for each 
work sought to be registered.

**3.2** Bulk Registration – Authors may apply for the registration of their works in bulk 
provided all of the conditions below are satisfied. A certificate of registration shall be 
issued for each work and will be charged the applicable registration fee for each work.

a. The works to be registered must not be less than ten (10);

b. All the works must fall under the same category; and

c. All the works must be created by the same author or the same joint authors.

**Section 4. _Additional Documentary Requirements._** – In addition to the RF, applicants other than the 
author or creator shall also submit the original or certified true copy of the following documents:

4.1.1 *For Heirs* – Documents establishing the heir’s right of succession:

---

a. The death certificate of the author or creator;

b. Applicant’s birth certificate, marriage certificate, or other documents establishing 
applicant’s relationship to the deceased author or creator;

c. Will or any document evidencing designation as heir, if applicable.

#### 4.1.2 <em>For Assignees</em> – Documents establishing assignment of rights:

a. The Deed of Assignment;

b. The author or creator’s waiver of ownership of copyright; and

c. Other documents evidencing transfer of ownership to the assignee.

4.1.3 *For Representatives* – Documents establishing the fact that applicant is authorized by 
the author, heir or assignee to file an application for copyright registration and deposit 
of the work:

a. A special power of attorney, if representing a natural person;

b. A Board Resolution or a Secretary’s Certificate, if representing a juridical person.

##### 4.2 Identification documents

4.2.1 *For natural persons* – any competent evidence of identity, which refers to the 
identification of an individual based on:

a.  One (1) valid identification card bearing the photograph and signature of the 
individual; or

b.  Oath or affirmation of one credible witness not privy to the instrument, document or 
transaction who is personally known to the notary public and who personally knows 
the individual, or of two credible witnesses neither of whom is privy to the 
instrument, document or transaction who each personally knows the individual and 
shows to the notary public documentary identification.

4.2.2  *For juridical persons* – certificate of registration issued by the Securities and Exchange 
Commission (for partnerships or corporations) or business name registration issued by 
the Department of Trade and Industry (for single proprietorships and only if the author 
is other than the owner of the single proprietorship).

In the case of foreign juridical persons, certificate of registration issued by the Securities 
and Exchange Commission or equivalent government agency in the foreign jurisdiction 
in charge of registration of proprietorships, partnerships and corporations. The 
certificate must be duly authenticated or apostilled.

---

**4.3**  Official receipt of the filing fee.

**4.4**  Work to be deposited in the manner provided in Section 5 hereof.

#### Section 5. <em>Manner of Depositing</em> <em>.</em> – The works shall be deposited in the following manner:

#### 5.1 Two (2) originals or an electronic copy submitted in a storage medium for the following works:

a. Books, pamphlets, articles, e-books, audio books, comics, novels, and other writings;

b. Periodicals, newspapers, journals, diaries, magazines, e-zines;

c. Lectures, sermons, addresses, speeches, dissertations prepared for oral delivery;

d. Letters, circulars, encyclicals, e-mail and other electronic messages;

e. Dramatic or dramatico-musical compositions, plays, operas, choreographic works, 
pantomimes, magic routines and other novelty acts;

f. Musical compositions with or without lyrics;

g. Audio-visual works and cinematographic works and works produced by a process 
analogous to cinematography or any process for making audio-visual recordings;

h. Computer programs/software/e-games/applications;

i. Other literary, scholarly, scientific and artistic works, including reports, studies, 
researches, theses, and other academic papers, examinations, online course materials, 
and presentations;

j. Sound recordings; and

k. Broadcast recordings.

**5.2** Two (2) 5R photographs, or two (2) copies of the work, or an electronic copy submitted 
in a storage medium:

a. Drawings, paintings, architectural works, sculpture, engraving, prints, lithography or 
other works of art, models or designs for works of art;

b. Ornamental designs or models for articles of manufacture and industrial objects, and 
other works of applied art;

c. Illustrations, maps, plans, sketches, charts and three-dimensional works relative to 
geography, topography, architecture or science;

d. Drawings or plastic works of a scientific or technical character;

e. Photographic works including works produced by a process analogous to 
photography, lantern slides; and

f. Pictorial illustrations and advertisements.

---

### RULE III PROCEDURE FOR MANUAL REGISTRATION

**Section 1. _Review of RF._** – After submission of the prescribed RF and other required 
documents, as provided under Rule II above, the application shall be reviewed for:

**1.1** Proper categorization of the work;

**1.2** Completeness of the documents submitted; and

**1.3** Correctness and consistency of the entries in the RF and the supporting documents.

**Section 2. _Issuance of Statement of Account._** – Upon a finding that all the requirements for 
copyright registration are in order, the applicant shall be issued a Statement of Account 
(SOA) and shall be directed to pay the prescribed filing fee with the cashier.

**Section 3. _Encoding, Scanning and Uploading of Application._** –

**3.1** Upon showing of the proof of payment of filing fee, an RF number shall be generated, 
indicating the date of filing thereof;

**3.2** After generating the RF number, the bibliographic entry of the work shall be encoded in 
the copyright database;

**3.3** Scanned copies of the required documents, including the SOA and the official receipt 
shall also be included in the database;

**3.4** The encoded data shall be reviewed for quality control.

**Section 4. _Release of Certificate._** – The Certificate of Registration shall be released to the 
applicant within seven (7) working days from filing of the RF with complete documents.

**Section 5. _Allowable Amendments/Corrections._** – All information written in the RF 
concerning the ownership of copyright, authorship and title of the work shall be deemed 
final and shall be reflected in the certificate.

No correction shall be made in the RF and the certificate of registration unless:

**5.1** The correction sought is substantial in nature;

**5.2** A written request is filed; and

**5.3** The prescribed filing fee is paid.

---

**Section 6. _Contents of the Certificate._** – The Certificate of Registration shall contain the 
following:

**6.1** Name of the applicant or copyright holder

**6.2** Title of the work

**6.3** Name of the author

**6.4** Category where the work belongs

**6.5** Date of creation

**6.6** Period of protection

**6.7** Signature of the Director of the Bureau of Copyright

**6.8** Statement that the registration and deposit is made for the purpose of completing the 
records of the National Library.

### RULE IV

### DENIAL OF APPLICATION AND REMEDIES

**Section 1. _Denial of application._** – An application for copyright registration may be denied 
by the Bureau Director if:

**1.1**  The work does not fit the statutorily defined categories of works under the 
copyright law; and

**1.2**  The work is the subject of a prior registration.

**Section 2. _Appeal._** – The decision of the Bureau Director shall be appealable to the Director 
General following the IPOPHL Uniform Rules on Appeal.

### RULE V

### POST-REGISTRATION

**Section 1. _Transmittal of Deposited Works to the National Library of the Philippines (NLP)_**

– The Bureau shall have temporary custody of all the deposited works and shall transmit 
the same to the NLP on a semi-annual basis.

**Section 2. _Cancellation of Certificate._** – The Bureau Director may, upon written request by 
an interested party and upon payment of applicable fee equivalent to the application fee, cancel the Certificate of Copyright Registration covering a specific work on the following 
grounds:

**2.1** Upon a final court decision ordering the cancellation of the certificate;

**2.2** By final order of the Director of the Bureau of Legal Affairs of the IPOPHL in copyright 
infringement cases; or

**2.3** Upon recordation of the assignment or transfer as provided under Rule VII hereof or 
under the rules of the NLP;

**Section 3. _Certified True Copy (CTC) of the Certificate._** – A certified true copy of the 
Certificate of Copyright Registration may be issued by the BCRR upon written request of 
the copyright owner or any interested party, and upon payment of the applicable fee.

**Section 4. _Reissuance of the Certificate._** – The Certificate of Copyright Registration may be 
reissued by the BCRR upon written request of the copyright owner and upon payment of 
the applicable fee. A duly notarized affidavit of loss shall be attached to the written request 
for reissuance of the certificate.

**Section 5. _Request for Certifications other than CTC and Reissuance._** – Upon written 
request by any interested party, a certification on the existence or non-existence of Copyright 
Registration under the name of a specific person or entity shall be issued upon payment of 
the applicable fee.

**Section 6. _Administration of Copyright Registration Database._** – The NLP and IPOPHL 
shall jointly administer the copyright registration database.

### RULE VI COPYRIGHT ONLINE REGISTRATION AND DEPOSIT SYSTEM (CORDS)

**Section 1. _Online Accomplishment of Forms._** – The copyright holder shall fill-out the RF in 
the IPOPHL website: www.ipophil.gov.ph.

**Section 2. _Submission of Supporting Documents._** – The applicant shall upload a digital copy 
of the work and other supporting documents as required under Rule II, Section 4 above.

**Section 3. _Payment of Applicable Fees._** –The IPOPHL website will prompt the copyright 
<u>holder or his/her representative to pay the filing fee online using acceptable payment</u> methods. An electronic receipt will be delivered through the copyright holder’s registered 
electronic mail after the payment is processed.

**Section 4. _Release of Certificate._** – The Bureau will cause the preparation of the electronic 
certificate and send to the copyright holder through his official email address on record. The 
Bureau shall employ technological protection measures to safeguard the integrity and 
authenticity of the electronic certificate.

**Section 5. _Transmittal of Deposited Works to NLP._** - The Bureau shall transmit the 
deposited works electronically to the NLP on a semi-annual basis.

### RULE VII RECORDATION OF COPYRIGHT TRANSFER, ASSIGNMENT AND LICENSE

**Section 1. _Who may Apply._** – The author or creator of the work, his transferee, assignee or 
licensee may apply for the recordation of copyright transfer, assignment or exclusive license. 
The heirs, in case of death of any the interested parties mentioned, may apply for copyright 
recordation.

**Section 2. _How Application is Made._** – The author, heir, assignee, transferee or the exclusive 
licensee as the case may be, or through his duly authorized representative to the IPOPHL, 
may file the application for copyright recordation either manually or by electronic means.

In cases of manual application where the applicant for recordation is a non-resident, 
application may be made by a duly authorized resident agent.

**Section 3. _Required documents._** –

**3.1** Copyright Recordation Form

3.1.1 Single Recordation – All applicants for recordation of copyright transfer, 
assignment or exclusive license shall accomplish and file the prescribed Copyright 
Recordation Form (CRF).

3.1.2 Bulk Recordation – Interested parties may apply for the copyright recordation of 
the transfer, assignment or exclusive license of their works in bulk provided all 
the following the conditions are satisfied:

a. The deeds to be recorded must not be less than 10; and b. The transferee, assignee or exclusive licensee must be the same person.

**3.2** Three (3) copies of the notarized Deed of Assignment, Transfer or Exclusive License. 
**Section 4. _Notation._** – Upon recording, a copy of the instrument shall be returned to the 
party concerned with a notation of the fact of record.

**Section 5. _Publication of Recordation._** – Notice of the record shall be published in the 
IPOPHL E-Gazette.

### RULE VIII FINAL PROVISIONS

**Section 1. _Amendment._** – All rules and regulations, office orders, memoranda, circulars and 
memorandum circulars or parts thereof, and other issuances of the Office inconsistent 
with these rules are hereby deemed repealed or amended accordingly.

**Section 2. _Separability._** – If any provision in these Regulations or application of such 
provision to any circumstance is held invalid, the remainder of these Regulations 
shall not be affected thereby.

**Section 3. _Furnishing of Certified Copies._** – The IPOPHL Administrative, Financial and 
Human Resource Development Service Bureau is hereby directed to immediately file 
three (3) certified copies of these rules with the Office of the National Administrative 
Register of the University of the Philippines Law Center.

**Section 4. _Effectivity._** – These rules and regulations shall take effect fifteen (15) days after 
publication in a newspaper of general circulation. However, Rule VI of this IRR shall 
take effect after fifteen (15) days from the issuance of a notice by this Office that the 
Copyright Online Registration and Deposit System (CORDS) is operational.

Done this 3rd day of July, 2020, at Taguig City, Philippines.

(Sgd.) **ROWEL S. BARBA**

---

### IPOPHL MEMORANDUM CIRCULAR NO. 2020-026

### SUBJECT: REVISED RULES AND REGULATIONS ON ACCREDITATION OF COLLECTIVE MANAGEMENT ORGANIZATIONS AND SIMILAR ENTITIES

## SUBJECT: REVISED RULES AND REGULATIONS ON ACCREDITATION OF

WHEREAS, Section 13, Article XIV of the 1987 Constitution declares that “[t]he State 
shall protect and secure the exclusive rights of scientists, inventors, artists, and other gifted 
citizens to their intellectual property and creations, particularly when beneficial to the 
people, for such period as may be provided by law”;

WHEREAS, the State enacted Republic Act No. 8293, the Intellectual Property Code 
of the Philippines (IP Code), as amended, in pursuit of the above policy;

WHEREAS, the IP Code as amended by Republic Act No. 10372 mandates the 
Intellectual Property Office of the Philippines (IPOPHL) to administer and implement State 
policies relating to intellectual property;

WHEREAS, Sec. 183 of the IP Code as amended, allows the owners of copyright and 
related rights or their heirs to designate a society of artists, writers, composers and other 
rights-holders, to collectively exercise their economic rights on their behalf, provided that 
these societies first secure the necessary accreditation from IPOPHL;

WHEREAS, there is a need to revise and update the existing Rules on Accreditation 
of CMOs as contained in IPOPHL Office Order No. 13-173 (2013) in order to better realize 
the objectives thereof as well as to properly address the concerns of all stakeholders;

NOW, THEREFORE, pursuant to the foregoing, the following rules and regulations 
are hereby adopted:

### RULE I GENERAL PROVISIONS

**Section 1. _Short Title._** These Rules and Regulations shall be known as the "Revised Rules on 
Accreditation of Collective Management Organizations."

---

**Section 2. _Definitions._** – For purposes of these Rules, the following terms shall have the 
meanings provided below:

a. *“Author” or “Creator”* – the natural person who has created the work;

b. *“Bureau”* – refers to the Bureau of Copyright and Other Related Rights of IPOPHL;

c. *“Collective Management Organization”* or *“CMO”* – a non-stock, non-profit 
organization, local or foreign, duly accredited by IPOPHL, which has for its sole 
and principal purpose the exercise of copyright or related rights on behalf of more 
than one right holder, for the collective benefit of the said right-holders;

d. *“Director”* – refers to the Director of the Bureau of Copyright and Other Related 
Rights;

e. *“Director General”* – refers to the head of the Intellectual Property Office of the 
Philippines;

f. *“License”* – refers to the permissions to use of a work while the copyright and 
ownership of the work remains with the author or creator;

g. *“Royalty” – remuneration given to the author or his heirs;*

h. *“Similar entities”* – entities other than a Collective Management Organization 
engaged in any of the functions of a CMO.

**Section 3. _Scope._** These Rules and Regulations shall apply to:

a. Entities which shall apply for accreditation as a CMO;

b. Any CMO established before the effectivity of these Rules and is already engaged 
in any or all of the functions of an accredited CMO provided that such CMO shall, 
within three (3) months from effectivity hereof, apply for accreditation, if not yet 
accredited by the IPOPHL; and

c. Similar entities who, upon determination by the Bureau, engage in any of the 
functions of a CMO enumerated under these Rules. Such entities shall be required 
to apply for accreditation within three (3) months from the Bureau’s 
determination that they engage in the functions of a CMO. Refusal to apply for accreditation shall cause the Office to institute the proper legal remedies against 
such entities.

### RULE II PROCEDURE FOR ACCREDITATION

**Section 1. _Pre-Qualification Requirements._** Only CMOs or similar entities meeting all the 
following pre-qualification requirements during initial screening may apply for 
accreditation with IPOPHL:

a. Registration as a non-stock, non-profit corporation;

b. Membership is composed of right-holders belonging to the sector whose rights 
shall be managed;

c. The General Manager or Executive Director, as well as the heads of 
Documentation, Licensing, Distribution and Finance, as may be applicable, shall:

i. Be free of direct or indirect conflicts of interests both with the users of 
works and other subject matter, and members of the CMO;

ii. Have the required management or technical skill and expertise to perform 
their duties;

iii. Have at least sixteen (16) hours of training on copyright or any related 
topics relevant to the particular sector obtained from IPOPHL or other 
institutions offering IP courses or seminars, both local and abroad;

d. The CMO shall have a supervisory Board that has the duty to oversee the 
management of the CMO. The Members of the Board shall have at least eight (8) 
hours of training on good governance, taken not earlier than there (3) years from 
the date of application; provided, however, that elected Board Members shall 
have a grace period of one (1) year from the accreditation to comply with the 
required hours of training on good governance.

e. Managerial, material and administrative capability of enforcing the rights of its 
members and to distribute collected revenues as closely as possibly according to 
actual use and in line with best practice in each relevant sector.

---

f. Existence or establishment of an internal dispute resolution or any similar system 
providing for an effective and workable process of settling disputes and 
grievances between or among members of the CMO and its members, related to 
the membership agreement or the application of the CMO distribution rules, and 
of settling disputes between the CMO’s members related to the registration of 
works or other subject matter.

g. Compliance with any other reasonable requirement/s the IPOPHL may impose 
from time to time pursuant to its rule-making power and in accordance with due 
process.

**Section 2. _Documentary Requirements._** In addition to the pre-qualification requirements in 
the immediately preceding Section, a duly accomplished application form shall be 
submitted in duplicate to the Bureau, along with the following documents:

a. Articles of Incorporation and By-Laws;

b. Bureau of Internal Revenue Registration, business permits and/or relevant 
government licenses or registrations;

c. Organizational structure;

d. List of Board members and officers, with respective biodata;

e. List of members;

f. List of current licensees (if applicable);

g. List of authorized collecting agents, with respective contracts of agency;

h. Business/Operations Manual (including published tariffs/rates per category and 
distribution rules);

i. Documents used in business:

(i) Membership Agreement/Deed of Assignment;

(ii) Reciprocal agreements, if any;

(iii) Licensing Agreement;

---

j. Audited Financial Statements, if already in operation.

**Section 3. _Application Fee._** Upon submission of the duly-accomplished application form 
and required documents, a non-refundable application fee in such amount as approved by 
the Secretary of Trade and Industry shall be paid by the applicant to cover expenses of the 
proceedings and administrative costs.

**Section 4. _Third Party Observation._** Within seven (7) days from filing, the application shall 
be published in the IPOPHL Website. Any interested party may submit written observations 
thereon to the Bureau of Copyright and Other Related Rights within thirty (30) days from 
the date of such publication. The observations shall forthwith be communicated within three 
(3) days from receipt thereof to the applicant, who may comment on them within ten (10) 
days from receipt of said communication. The Bureau shall acknowledge and consider the 
observations and comment in making its decision, and include the same in the file of the 
application to which it relates.

**Section 5. _Clarificatory hearing and assistance of experts._** If necessary, the Director may, 
within ten (10) days from receipt of the last observation, call the parties to a clarificatory 
hearing. Furthermore, the Director may obtain the assistance of persons in the government 
and/or private sector who are acknowledged experts in their relevant field, of proven 
integrity and probity, when necessary, to resolve the matter.

**Section 6. _Decision of the Director._** The Director shall render a decision granting or denying 
the application within twenty (20) days from the lapse of the period for filing third party 
observations or from the receipt of the last observation or comment.

**Section 7. _Issuance of the Certificate of Accreditation._** The corresponding certificate of 
accreditation shall be issued within seven (7) days after the decision granting the same.

**Section 8. _Denial of Accreditation._** Accreditation may be denied if:

a. The applicant does not comply with the provisions of Sections 1 and 2 of Rule II 
above;

b. The applicant committed fraud or willful misrepresentation in the compliance 
with the documentary requirements under Section 2 of Rule II above; and

**c.** Such other grounds that would merit denial of the application for accreditation.

---

**Section 9. _Remedies._** The decision of the Director denying accreditation shall become final 
and executory thirty (30) days after receipt of a copy thereof by the applicant unless within 
the same period, a motion for reconsideration is filed with the Director or an appeal to the 
Director General has been perfected by filing a notice of appeal and payment of the required 
fee in accordance with the IPOPHL Uniform Rules on Appeal.

Only one motion for reconsideration of the decision of the Director shall be allowed. If the 
motion is denied, the movant shall file his appeal within the balance of the period prescribed 
above to which he was entitled at the time of serving his motion.

**Section 10. _Term of Accreditation._** The accreditation shall be effective for a period of five (5) 
years from the date stated in the order granting the accreditation.

**Section 11. _Publication upon Approval of Accreditation._** IPOPHL shall publish, in the 
IPOPHL Website, the accreditation certificates, articles of incorporation and by-laws, 
organizational structure, rates for collecting licensing fees, and distribution rates and 
mechanism of the accredited CMO.

### RULE III EFFECTS OF ACCREDITATION

### Section 1. <em>Rights of an Accredited CMO.</em> An accredited CMO has the right to:

a. Administer any or all of the economic rights for which it has been accredited.

b. Negotiate with and grant licenses to users of protected literary, scholarly, 
scientific and artistic works, derivative works, performances, sound recordings, 
and broadcasts;

c. Collect royalties and other forms of remuneration, including proceeds in 
subsequent transfers, additional remuneration for subsequent communication or 
broadcast of a performance, and single equitable remuneration for the broadcast, 
other communication to the public or public performance of a sound recording or 
of an audiovisual fixation, as applicable;

d. Distribute the said collection to their members;

e. Sue and enforce administered rights, on behalf of its members, in its own name.

---

**Section 2. _Duties of an Accredited CMO._** The accredited CMO shall:

a. Ensure the faithful discharge of their obligations as well as compliance with 
applicable laws and regulations;

b. Submit annual audited financial statements on or before April 30 of each year and 
allow the same to be posted in the IPOPHL website;

c. Have an annual general meeting, which shall approve the CMO’s accounts and 
annual report and such other matters provided in the organization’s articles of 
incorporation and by-laws.

d. Notify and invite an IPOPHL representative to its general membership meetings;

e. Submit to IPOPHL documents and/or information involving the CMO and its 
stakeholders as may be requested by IPOPHL;

f. Comply with these Rules and the orders of IPOPHL issued from time to time.

**Section 3. _Reporting of Changes._** An accredited CMO, which has amended its articles of 
incorporation and by-laws or has undergone any change relative to its business (including 
changes in authorized collecting agents, if any), shall notify the IPOPHL thereof by 
submitting the amendments made or a summary of the changes within thirty (30) days from 
effectivity thereof or the occurrence of the change, as the case may be. If such change shall 
necessitate the amendment of the accreditation certificate, an amendment fee shall be paid.

### RULE IV POST-ACCREDITATION

**Section 1. _Re-application for Accreditation._** After the expiration of the period for 
accreditation, a CMO may re-apply for accreditation by updating the documents it originally 
submitted pursuant to Section 2, Rule II, above, and by paying the application fee as 
required in Section 3, Rule II. The Director shall consider the performance of the CMO in its 
previous accreditation and shall issue a resolution within fifteen (15) days from filing of the 
application.

---

**Section 2. _Suspension of Accreditation._** The Director may suspend, either totally or partially, 
the accreditation of a CMO, after giving the latter an opportunity to be heard, if any one of 
the following circumstances are found after accreditation:

a. The CMO tolerated or abetted any of its Board members or officers in violating 
any related law, rules and regulations issued by IPOPHL.

b. Any of the documents or material information/data therein submitted by the 
CMO has been found to be false or untrue.

c. Failure to maintain its compliance with the provisions of Section 1 of Rule II 
above.

d. Failure to engage in any of the activities under Section 1 of Rule III within one 
year after accreditation.

e. Failure to observe the parameters for collection and distribution of royalties and 
other forms of remuneration.

f. Malicious breach of contract or fiduciary duty against any of its members, 
regarding the primary activities and the duties of an accredited CMO as set out in 
these Rules and/or the principles of transparency, efficiency and good 
governance, including the fair and proportionate representation of members in 
the CMO's governing bodies.

g. Failure to give proper accounting to IPOPHL or to its members.

h. Failure to comply with the mandatory submissions under Sec. 2(b) of Rule III 
hereof.

**Section 3. _Motion to Lift Suspension Order._** The CMO may file a Motion to Lift Suspension 
with the Director within thirty (30) days from receipt of the order of suspension, provided, 
that the ground/s for denial or suspension has/have ceased to exist and it has complied with 
the pre-qualification and documentary requirements under Sections 1 and 2 of Rule II above.

**Section 4. _Cancellation of Accreditation._** If the CMO whose accreditation is suspended fails 
to comply with the condition/s for the lifting thereof within six (6) months from the date of 
suspension as provided in the immediately preceding Section, an order cancelling its 
accreditation shall be issued. Upon complaint by any interested party, the Director may also 
cancel the accreditation of the CMO, based on the grounds enumerated in section 2 of this 
<u>Rule.</u>

---

**Section 5. _Effect of Non-accreditation, Denial, Total or Partial Suspension and_** 
**_Cancellation of Accreditation._** A CMO who has not applied for accreditation after the 
effectivity of these Rules, or whose application has been denied, or its accreditation totally 
suspended or cancelled, cannot, under any circumstance, engage in any of the activities 
enumerated in Section 1 of Rule III. In case of partial suspension, the CMO may still engage 
in the activities enumerated in the same section with respect to the rights they are allowed 
to manage. Furthermore, CMO shall be banned from re-applying for accreditation for the 
remaining balance of the term of its original accreditation in case its certification of 
accreditation is cancelled.

**Section 6. _Notice to the Public._** Any change in the status of accreditation of a CMO resulting 
from the above actions shall be notified to the public through the IPOPHL Website.

### RULE V

### FINAL PROVISIONS

**Section 1. _Retroactive Application; Exception._** These Rules shall apply to cases pending 
before the Bureau or the Office of the Director General. Except for Section 10, Rule II, these 
Rules shall also apply to CMOs duly accredited before its effectivity.

**Section 2. _Separability Clause._** If any section or provision of these Rules shall be held to be 
invalid, the remaining provisions shall remain in full force and effect as completely as if the 
part held invalid had not been included therein.

**Section 3. _Furnishing of Certified Copies._** The IPOPHL Administrative, Financial and 
Human Resource Development Service Bureau is hereby directed to immediately file three 
(3) certified copies of these rules with the Office of the National Administrative Register of 
the University of the Philippines Law Center.

**Section 4. _Effectivity._** These Rules shall take effect after fifteen (15) days from publication in 
a newspaper of general circulation.

Done this 3rd day of July, 2020, at Taguig City, Philippines.

(Sgd.) **ROWEL S. BARBA**

---

# INTERNATIONAL COPYRIGHT TREATIES AND CONVENTIONS

This part contains accepted international norms that are manifested in international 
copyright treaties, conventions, and agreements. These international treaties have bearing on 
enforcement and management of rights.  Moreover, national legislations are harmonized with 
these treaties, conventions, and agreements. Major international treaties on copyright<sup>1</sup> and related 
rights included in this book are:

● Berne Convention for the Protection of Literary and Artistic Works (Berne 
Convention)

● Agreement on Trade-Related Aspects of Intellectual Property Rights (TRIPS 
Agreement)

● The World Intellectual Property Organization (WIPO) Copyright Treaty (WCT)

The Berne Convention and WCT are administered by the (WIPO).  The TRIPS Agreement, 
on the other hand, is administered by the World Trade Organization (WTO) and covers not only 
copyright, but all intellectual property rights as well.

There are also treaties in the field of related rights<sup>1</sup> that are included in this book and these 
are:

● International Convention for the Protection of Performers, Producers of Phonograms 
and Broadcasting Organizations (the Rome Convention)

● The WIPO Performances and Phonograms Treaty (WPPT)

● Beijing Treaty on Audiovisual Performances (BTAP)

● Marrakesh Treaty to Facilitate Access to Published Works for Persons Who are Blind, 
Visually Impaired or Otherwise Print Disabled

The Rome Convention is administered by three international bodies, namely: 
International Labour Organization (ILO), the United Nations Educational, Scientific and Cultural 
Organization (UNESCO), and WIPO. The WPPT and BTAP are administered by WIPO<sup>1</sup>.

International copyright treaties have been agreed to and revised as a response to evolving 
technologies, starting from the Berne Convention in 1886 with the latest revision in 1971. The 
Rome Convention was a response to the needs of artists as well as sound recording and 
broadcasting industries in 1961. The TRIPS Agreement tackled international trade aspects in 1994.  
Meanwhile, the WCT and WPPT from 1996 and BTAP from 2012 are characterized as “internet 
treaties”. They contain new elements that are necessary for the delivery of protected works and 
other objects of protection through the Internet<sup>1</sup>. 
_____________________

<sup>1</sup>Main International Treaties for Copyright and Related Rights are identified by WIPO and sources of information for 
these are contained in their learning materials.

---

# Berne Convention for the Protection of Literary and Artistic Works

**of September 9, 1886,** 
**completed at PARIS on May 4, 1896,** 
**revised at BERLIN on November 13, 1908,** 
**completed at BERNE on March 20, 1914,** 
**revised at ROME on June 2, 1928,** 
**at BRUSSELS on June 26, 1948,** 
**at STOCKHOLM on July 14, 1967,** 
**and at PARIS on July 24, 1971,** 
**and amended on September 28, 1979**

### 1 TABLE OF CONTENTS

## TABLE OF CONTENTS 1

Article 1: Establishment of a Union

Article 2: Protected Works: *1. “Literary and artistic works”; 2. Possible requirement of 
fixation; 3. Derivative works; 4. Official texts; 5. Collections; 6. Obligation to 
protect; beneficiaries of protection; 7. Works of applied art and industrial designs;* 
*8. News*

Article *2bis:* Possible Limitation of Protection of Certain Works: *1. Certain speeches;* 
*2. Certain uses of lectures and addresses; 3. Right to make collections of such 
works*

Article 3: Criteria of Eligibility for Protection: *1. Nationality of author; place of 
publication of work; 2. Residence of author; 3. “Published” works; 4.* 
*“Simultaneously published” works*

Article 4: Criteria of Eligibility for Protection of Cinematographic Works, Works of 
Architecture and Certain Artistic Works

Article 5: Rights Guaranteed: *1. and 2. Outside the country of origin; 3. In the country of 
origin; 4. “Country of origin”*

Article 6: Possible Restriction of Protection in Respect of Certain Works of Nationals 
of Certain Countries Outside the Union: *1. In the country of the first 
publication and in other countries; 2. No retroactivity; 3. Notice*

Article *6bis:* Moral Rights: *1. To claim authorship; to object to certain modifications and other 
derogatory actions; 2. After the author's death; 3. Means of redress*

Article 7: Term of Protection: *1. Generally; 2. For cinematographic works; 3. For 
anonymous and pseudonymous works; 4. For photographic works and works of 
applied art; 5. Starting date of computation; 6. Longer terms; 7. Shorter terms; 8.* 
*Applicable law; “comparison” of terms*

---

Article *7bis:* Term of Protection for Works of Joint Authorship 
Article 8: Right of Translation

Right of Reproduction: *1. Generally; 2. Possible exceptions; 3. Sound and visual* 
Article 9: 
*recordings*

Certain Free Uses of Works: *1. Quotations; 2. Illustrations for teaching;* 
Article 10: 
*3. Indication of source and author*

Further Possible Free Uses of Works: *1. Of certain articles and broadcast* 
Article *10bis:* 
*works; 2. Of works seen or heard in connection with current events*
Certain Rights in Dramatic and Musical Works: *1. Right of public*

Article 11: *performance and of communication to the public of a performance; 2. In respect of 
translations*
Broadcasting and Related Rights: *1. Broadcasting and other wireless*

*communications, public communication of broadcast by wire or rebroadcast,* 
Article *11bis:* 
*public communication of broadcast by loudspeaker or analogous instruments; 2.* 
*Compulsory licenses; 3. Recording; ephemeral recordings*
Certain Rights in Literary Works: *1. Right of public recitation and of* 
Article *11ter:* 
*communication to the public of a recitation; 2. In respect of translations*
Article 12: Right of Adaptation, Arrangement and Other Alteration 
Possible Limitation of the Right of Recording of Musical Works and Any 
Article 13: Words Pertaining Thereto: *1. Compulsory licenses; 2. Transitory measures; 3.* 
*Seizure on importation of copies made without the author's permission*
Cinematographic and Related Rights: *1. Cinematographic adaptation and*

*reproduction; distribution; public performance and public communication by wire* 
Article 14: 
*of works thus adapted or reproduced; 2. Adaptation of cinematographic 
productions; 3. No compulsory licenses*

Special Provisions Concerning Cinematographic Works: *1. Assimilation to* 
Article *14bis: “original” works; 2. Ownership; limitation of certain rights of certain 
contributors; 3. Certain other contributors*

“Droit de suite” in Works of Art and Manuscripts: *1. Right to an interest in* 
Article *14ter:* 
*resales; 2. Applicable law; 3. Procedure*

Right to Enforce Protected Rights: *1. Where author's name is indicated or 
where pseudonym leaves no doubt as to author's identity; 2. In the case of* 
Article 15: 
*cinematographic works; 3. In the case of anonymous or pseudonymous works; 4.* 
*In the case of certain unpublished works of unknown authorship*

Article 16: Infringing Copies: *1. Seizure; 2. Seizure on importation; 3. Applicable law*

Article 17: Possibility of Control of Circulation, Presentation and Exhibition of Works 
Works Existing on Convention's Entry Into Force: *1. Protectable where 
protection not yet expired in country of origin; 2. Non-protectable where* 
Article 18: 
*protection already expired in country where it is claimed; 3. Application of these 
principles; 4. Special cases*

<u>Article 19: Protection Greater than Resulting from Convention</u>

---

| Article 20: | Special Agreements Among Countries of the Union |
| --- | --- |
| Article 21: | Special Provisions Regarding Developing Countries: 1. Reference to Appendix; 2. Appendix part of Act |
| Article 22: | Assembly: 1. Constitution and composition; 2. Tasks; 3. Quorum, voting, observers; 4. Convocation; 5. Rules of procedure |
| Article 23: | Executive Committee: 1. Constitution; 2. Composition; 3. Number of members; 4. Geographical distribution; special agreements; 5. Term, limits of re-eligibility, rules of election; 6. Tasks; 7. Convocation; 8. Quorum, voting; 9. Observers; 10. Rules of procedure International Bureau: 1. Tasks in general, Director General; 2. General information; 3. Periodical; 4. Information to countries; 5. Studies and services; 6. Participation in meetings; 7. Conferences of revision; 8. Other tasks |
| Article 24: | Finances: 1. Budget; 2. Coordination with other Unions; 3. Resources; 4. Contributions; possible extension of previous budget; 5. Fees and charges; 6. Working capital fund; 7. Advances by host Government; 8. Auditing of accounts |
| Article 25: | Working capital fund; 7. Advances by host Government; 8. Auditing of accounts |
| Article 26: | Amendments: 1. Provisions susceptible of amendment by the Assembly; proposals 2. Adoption; 3. Entry into force |
| Article 27: | Revision: 1. Objective; 2. Conferences; 3. Adoption |
| Article 28: | Acceptance and Entry Into Force of Act for Countries of the Union: 1. Ratification, accession; possibility of excluding certain provisions; withdrawal of exclusion; 2. Entry into force of Articles 1 to 21 and Appendix; 3. Entry into force of Articles 22 to 38 |
| Article 29: | Acceptance and Entry Into Force for Countries Outside the Union: 1. Accession; 2. Entry into force |
| Article 29bis: | Effect of Acceptance of Act for the Purposes of Article 14(2) of the WIPO Convention |
| Article 30: | Reservations: 1. Limits of possibility of making reservations; 2. Earlier reservations; reservation as to the right of translation; withdrawal of reservation |
| Article 31: | Applicability to Certain Territories: 1. Declaration; 2. Withdrawal of declaration; 3. Effective date; 4. Acceptance of factual situations not implied |
| Article 32: | Applicability of this Act and of Earlier Acts: 1. As between countries already members of the Union; 2. As between a country becoming a member of the Union and other countries members of the Union; 3. Applicability of the Appendix in Certain Relations |
| Article 33: | Disputes: 1. Jurisdiction of the International Court of Justice; 2. Reservation as to such jurisdiction; 3. Withdrawal of reservation |
| Article 34: | Closing of Certain Earlier Provisions: 1. Of earlier Acts; 2. Of the Protocol to the Stockholm Act |

---

Duration of the Convention; Denunciation: *1. Unlimited duration;*

Article 35:

*2. Possibility of denunciation; 3. Effective date of denunciation; 4. Moratorium on 
denunciation*

Article 36:

Application of the Convention: *1. Obligation to adopt the necessary measures;* 
*2. Time from which obligation exists*

Article 37:

Final Clauses: *1. Languages of the Act; 2. Signature; 3. Certified copies;* 
*4. Registration; 5. Notifications*

Article 38: Transitory Provisions: *1. Exercise of the “five-year privilege”; 2. Bureau of the* 
*Union, Director of the Bureau; 3. Succession of Bureau of the Union*

### APPENDIX

### SPECIAL PROVISIONS REGARDING DEVELOPING COUNTRIES

Faculties Open to Developing Countries:

*1. Availability of certain faculties; declaration; 2. Duration of effect of* 
Article I:   
*declaration; 3. Cessation of developing country status; 4. Existing stocks of 
copies; 5. Declarations concerning certain territories; 6. Limits of reciprocity*
Limitations on the Right of Translation: 
*1. Licenses grantable by competent authority; 2 to 4. Conditions allowing the*

Article II:   *grant of such licenses; 5. Purposes for which licenses may be granted; 6.* 
*Termination of licenses; 7. Works composed mainly of illustrations; 8. Works 
withdrawn from circulation; 9. Licenses for broadcasting organizations*
Limitation on the Right of Reproduction:

*1. Licenses grantable by competent authority; 2 to 5. Conditions allowing the* 
Article III:   
*grant of such licenses; 6. Termination of licenses. 7. Works to which this* 
*Article applies*
Provisions Common to Licenses Under Articles II and III:

Article IV:  *1 and 2. Procedure; 3. Indication of author and title of work; 4. Exportation 
of copies; 5. Notice; 6. Compensation*
Alternative Possibility for Limitation of the Rights of Translation:

*1. Regime provided for under the 1886 and 1896 Acts; 2. No possibility of* 
Article V: 
*change to regime under Article II; 3. Time limit for choosing the alternative 
possibility*
Possibilities of applying, or admitting the application of, certain

Article VI:  provisions of the Appendix before becoming bound by it: 
*1. Declaration; Depository and effective date of declaration*

---

The countries of the Union, being equally animated by the desire to protect, in as effective 
and uniform a manner as possible, the rights of authors in their literary and artistic works,

Recognizing the importance of the work of the Revision Conference held at Stockholm in 
1967,

Have resolved to revise the Act adopted by the Stockholm Conference, while maintaining 
without change Articles 1 to 20 and 22 to 26 of that Act.

Consequently, the undersigned Plenipotentiaries, having presented their full powers, 
recognized as in good and due form, have agreed as follows:

#### Article 1

#### 2 Establishment of a Union

## Establishment of a Union 2

The countries to which this Convention applies constitute a Union for the protection of 
the rights of authors in their literary and artistic works.

#### Article 2

#### Protected Works:

**_1. “Literary and artistic works”; 2. Possible requirement of fixation; 3. Derivative works; 4._** 
**_Official texts; 5. Collections; 6. Obligation to protect; beneficiaries of protection; 7. Works of 
applied art and industrial designs; 8. News_**

(1) The expression “literary and artistic works” shall include every production in the literary, 
scientific and artistic domain, whatever may be the mode or form of its expression, such as books, 
pamphlets and other writings; lectures, addresses, sermons and other works of the same nature; 
dramatic or dramatico-musical works; choreographic works and entertainments in dumb show; 
musical compositions with or without words; cinematographic works to which are assimilated 
works expressed by a process analogous to cinematography; works of drawing, painting, 
architecture, sculpture, engraving and lithography; photographic works to which are assimilated 
works expressed by a process analogous to photography; works of applied art; illustrations, 
maps, plans, sketches and three-dimensional works relative to geography, topography, 
architecture or science.

(2) It shall, however, be a matter for legislation in the countries of the Union to prescribe that 
works in general or any specified categories of works shall not be protected unless they have been 
fixed in some material form.

(3) Translations, adaptations, arrangements of music and other alterations of a literary or 
artistic work shall be protected as original works without prejudice to the copyright in the original 
work.

---

(4) It shall be a matter for legislation in the countries of the Union to determine the protection 
to be granted to official texts of a legislative, administrative and legal nature, and to official 
translations of such texts.

(5) Collections of literary or artistic works such as encyclopedias and anthologies which, by 
reason of the selection and arrangement of their contents, constitute intellectual creations shall be 
protected as such, without prejudice to the copyright in each of the works forming part of such 
collections.

(6) The works mentioned in this Article shall enjoy protection in all countries of the Union. 
This protection shall operate for the benefit of the author and his successors in title.

(7) Subject to the provisions of Article 7(4) of this Convention, it shall be a matter for legislation 
in the countries of the Union to determine the extent of the application of their laws to works of 
applied art and industrial designs and models, as well as the conditions under which such works, 
designs and models shall be protected. Works protected in the country of origin solely as designs 
and models shall be entitled in another country of the Union only to such special protection as is 
granted in that country to designs and models; however, if no such special protection is granted 
in that country, such works shall be protected as artistic works.

(8) The protection of this Convention shall not apply to news of the day or to miscellaneous 
facts having the character of mere items of press information.

#### Article 2bis

#### Possible Limitation of Protection of Certain Works:

#### 1. Certain speeches; 2. Certain uses of lectures and addresses; 3. Right to make collections of such works

(1) It shall be a matter for legislation in the countries of the Union to exclude, wholly or in 
part, from the protection provided by the preceding Article political speeches and speeches 
delivered in the course of legal proceedings.

(2) It shall also be a matter for legislation in the countries of the Union to determine the 
conditions under which lectures, addresses and other works of the same nature which are 
delivered in public may be reproduced by the press, broadcast, communicated to the public by 
wire and made the subject of public communication as envisaged in Article 11bis (1) of this 
Convention, when such use is justified by the informatory purpose.

(3) Nevertheless, the author shall enjoy the exclusive right of making a collection of his works 
mentioned in the preceding paragraphs.

---

#### Article 3

#### Criteria of Eligibility for Protection:

#### 1. Nationality of author; place of publication of work; 2. Residence of author; 3: “Published” works; 4. “Simultaneously published” works

(1) The protection of this Convention shall apply to:

(a) authors who are nationals of one of the countries of the Union, for their works, 
whether published or not;

(b) authors who are not nationals of one of the countries of the Union, for their works first 
published in one of t hose countries, or simultaneously in a country outside the Union and in 
a country of the Union.

(2) Authors who are not nationals of one of the countries of the Union but who have their 
habitual residence in one of them shall, for the purposes of this Convention, be assimilated to 
nationals of that country.

(3) The expression “published works” means works published with the consent of their 
authors, whatever may be the means of manufacture of the copies, provided that the availability 
of such copies has been such as to satisfy the reasonable requirements of the public, having regard 
to the nature of the work. The performance of a dramatic, dramatico-musical, cinematographic 
or musical work, the public recitation of a literary work, the communication by wire or the 
broadcasting of literary or artistic works, the exhibition of a work of art and the construction of a 
work of architecture shall not constitute publication.

(4) A work shall be considered as having been published simultaneously in several countries 
if it has been published in two or more countries within thirty days of its first publication.

#### Article 4

#### Criteria of Eligibility for Protection of Cinematographic Works, Works of Architecture and Certain Artistic Works

The protection of this Convention shall apply, even if the conditions of Article 3 are not 
fulfilled, to:

(a) authors of cinematographic works the maker of which has his headquarters or 
habitual residence in one of the countries of the Union;

(b) authors of works of architecture erected in a country of the Union or of other artistic 
works incorporated in a building or other structure located in a country of the Union.

---

#### Article 5

#### Rights Guaranteed:

#### 1. and 2. Outside the country of origin; 3. In the country of origin; 4. “Country of origin”

(1) Authors shall enjoy, in respect of works for which they are protected under this 
Convention, in countries of the Union other than the country of origin, the rights which their 
respective laws do now or may hereafter grant to their nationals, as well as the rights specially 
granted by this Convention.

(2) The enjoyment and the exercise of these rights shall not be subject to any formality; such 
enjoyment and such exercise shall be independent of the existence of protection in the country of 
origin of the work. Consequently, apart from the provisions of this Convention, the extent of 
protection, as well as the means of redress afforded to the author to protect his rights, shall be 
governed exclusively by the laws of the country where protection is claimed.

(3) Protection in the country of origin is governed by domestic law. However, when the author 
is not a national of the country of origin of the work for which he is protected under this 
Convention, he shall enjoy in that country the same rights as national authors.

(4) The country of origin shall be considered to be:

(a) in the case of works first published in a country of the Union, that country; in the case 
of works published simultaneously in several countries of the Union which grant different 
terms of protection, the country whose legislation grants the shortest term of protection;

(b) in the case of works published simultaneously in a country outside the Union and in a 
country of the Union, the latter country;

(c) in the case of unpublished works or of works first published in a country outside the 
Union, without simultaneous publication in a country of the Union, the country of the 
Union of which the author is a national, provided that:

(i) when these are cinematographic works the maker of which has his headquarters 
or his habitual residence in a country of the Union, the country of origin shall be 
that country, and

(ii) when these are works of architecture erected in a country of the Union or other 
artistic works incorporated in a building or other structure located in a country of 
the Union, the country of origin shall be that country.

---

#### Article 6

#### Possible Restriction of Protection in Respect of Certain Works of Nationals of Certain Countries Outside the Union:

**_1. In the country of the first publication and in other countries; 2. No retroactivity; 3. Notice_**

(1) Where any country outside the Union fails to protect in an adequate manner the works of 
authors who are nationals of one of the countries of the Union, the latter country may restrict the 
protection given to the works of authors who are, at the date of the first publication thereof, 
nationals of the other country and are not habitually resident in one of the countries of the Union. 
If the country of first publication avails itself of this right, the other countries of the Union shall 
not be required to grant to works thus subjected to special treatment a wider protection than that 
granted to them in the country of first publication.

(2) No restrictions introduced by virtue of the preceding paragraph shall affect the rights 
which an author may have acquired in respect of a work published in a country of the Union 
before such restrictions were put into force.

(3) The countries of the Union which restrict the grant of copyright in accordance with this 
Article shall give notice thereof to the Director General of the World Intellectual Property 
Organization (hereinafter designated as “the Director General”) by a written declaration 
specifying the countries in regard to which protection is restricted, and the restrictions to which 
rights of authors who are nationals of those countries are subjected. The Director General shall 
immediately communicate this declaration to all the countries of the Union.

#### Article 6bis

#### Moral Rights:

#### 1. To claim authorship; to object to certain modifications and other derogatory actions; 2. After the author's death; 3. Means of redress

(1) Independently of the author's economic rights, and even after the transfer of the said 
rights, the author shall have the right to claim authorship of the work and to object to any 
distortion, mutilation or other modification of, or other derogatory action in relation to, the said 
work, which would be prejudicial to his honor or reputation.

(2) The rights granted to the author in accordance with the preceding paragraph shall, after 
his death, be maintained, at least until the expiry of the economic rights, and shall be exercisable 
by the persons or institutions authorized by the legislation of the country where protection is 
claimed. However, those countries whose legislation, at the moment of their ratification of or 
accession to this Act, does not provide for the protection after the death of the author of all the 
rights set out in the preceding paragraph may provide that some of these rights may, after his 
death, cease to be maintained.

---

(3) The means of redress for safeguarding the rights granted by this Article shall be governed 
by the legislation of the country where protection is claimed.

#### Article 7

#### Term of Protection:

**_1. Generally; 2. For cinematographic works; 3. For anonymous and pseudonymous works; 4. For 
photographic works and works of applied art; 5. Starting date of computation; 6. Longer terms;_** 
**_7. Shorter terms; 8. Applicable law; “comparison” of terms_**

(1) The term of protection granted by this Convention shall be the life of the author and fifty 
years after his death.

(2) However, in the case of cinematographic works, the countries of the Union may provide 
that the term of protection shall expire fifty years after the work has been made available to the 
public with the consent of the author, or, failing such an event within fifty years from the making 
of such a work, fifty years after the making.

(3) In the case of anonymous or pseudonymous works, the term of protection granted by this 
Convention shall expire fifty years after the work has been lawfully made available to the public. 
However, when the pseudonym adopted by the author leaves no doubt as to his identity, the 
term of protection shall be that provided in paragraph (1). If the author of an anonymous or 
pseudonymous work discloses his identity during the above-mentioned period, the term of 
protection applicable shall be that provided in paragraph (1). The countries of the Union shall not 
be required to protect anonymous or pseudonymous works in respect of which it is reasonable 
to presume that their author has been dead for fifty years.

(4) It shall be a matter for legislation in the countries of the Union to determine the term of 
protection of photographic works and that of works of applied art in so far as they are protected 
as artistic works; however, this term shall last at least until the end of a period of twenty-five 
years from the making of such a work.

(5) The term of protection subsequent to the death of the author and the terms provided by 
paragraphs (2), (3) and (4) shall run from the date of death or of the event referred to in those 
paragraphs, but such terms shall always be deemed to begin on the first of January of the year 
following the death or such event.

(6) The countries of the Union may grant a term of protection in excess of those provided by 
the preceding paragraphs.

(7) Those countries of the Union bound by the Rome Act of this Convention which grant, in 
their national legislation in force at the time of signature of the present Act, shorter terms of protection than those provided for in the preceding paragraphs shall have the right to maintain 
such terms when ratifying or acceding to the present Act.

(8) In any case, the term shall be governed by the legislation of the country where protection 
is claimed; however, unless the legislation of that country otherwise provides, the term shall not 
exceed the term fixed in the country of origin of the work.

#### Article 7bis

#### Term of Protection for Works of Joint Authorship

The provisions of the preceding Article shall also apply in the case of a work of joint 
authorship, provided that the terms measured from the death of the author shall be calculated 
from the death of the last surviving author.

#### Article 8

#### Right of Translation

Authors of literary and artistic works protected by this Convention shall enjoy the 
exclusive right of making and of authorizing the translation of their works throughout the term 
of protection of their rights in the original works.

#### Article 9

#### Right of Reproduction:

#### 1. Generally; 2. Possible exceptions; 3. Sound and visual recordings

(1) Authors of literary and artistic works protected by this Convention shall have the exclusive 
right of authorizing the reproduction of these works, in any manner or form.

(2) It shall be a matter for legislation in the countries of the Union to permit the reproduction 
of such works in certain special cases, provided that such reproduction does not conflict with a 
normal exploitation of the work and does not unreasonably prejudice the legitimate interests of 
the author.

(3) Any sound or visual recording shall be considered as a reproduction for the purposes of 
this Convention.

---

#### Article 10

#### Certain Free Uses of Works:

#### 1. Quotations; 2. Illustrations for teaching; 3. Indication of source and author

(1) It shall be permissible to make quotations from a work which has already been lawfully 
made available to the public, provided that their making is compatible with fair practice, and 
their extent does not exceed that justified by the purpose, including quotations from newspaper 
articles and periodicals in the form of press summaries.

(2) It shall be a matter for legislation in the countries of the Union, and for special agreements 
existing or to be concluded between them, to permit the utilization, to the extent justified by the 
purpose, of literary or artistic works by way of illustration in publications, broadcasts or sound 
or visual recordings for teaching, provided such utilization is compatible with fair practice.

(3) Where use is made of works in accordance with the preceding paragraphs of this Article, 
mention shall be made of the source, and of the name of the author if it appears thereon.

#### Article 10bis

#### Further Possible Free Uses of Works:

**_1. Of certain articles and broadcast works; 2. Of works seen or heard in connection with current 
events_**

(1) It shall be a matter for legislation in the countries of the Union to permit the reproduction 
by the press, the broadcasting or the communication to the public by wire of articles published in 
newspapers or periodicals on current economic, political or religious topics, and of broadcast 
works of the same character, in cases in which the reproduction, broadcasting or such 
communication thereof is not expressly reserved. Nevertheless, the source must always be clearly 
indicated; the legal consequences of a breach of this obligation shall be determined by the 
legislation of the country where protection is claimed.

(2) It shall also be a matter for legislation in the countries of the Union to determine the 
conditions under which, for the purpose of reporting current events by means of photography, 
cinematography, broadcasting or communication to the public by wire, literary or artistic works 
seen or heard in the course of the event may, to the extent justified by the informatory purpose, 
be reproduced and made available to the public.

#### Article 11

#### Certain Rights in Dramatic and Musical Works:

**_1. Right of public performance and of communication to the public of a performance; 2. In 
respect of translations_**

(1) Authors of dramatic, dramatico-musical and musical works shall enjoy the exclusive right 
<u>of authorizing:</u>

---

(i) the public performance of their works, including such public performance by any means 
or process;

(ii) any communication to the public of the performance of their works.

(2) Authors of dramatic or dramatico-musical works shall enjoy, during the full term of their 
rights in the original works, the same rights with respect to translations thereof.

#### Article 11bis

#### Broadcasting and Related Rights:

**_1. Broadcasting and other wireless communications, public communication of broadcast by 
wire or rebroadcast, public communication of broadcast by loudspeaker or analogous 
instruments; 2. Compulsory licenses; 3. Recording; ephemeral recordings_**

(1) Authors of literary and artistic works shall enjoy the exclusive right of authorizing:

(i) the broadcasting of their works or the communication thereof to the public by any other 
means of wireless diffusion of signs, sounds or images;

(ii) any communication to the public by wire or by rebroadcasting of the broadcast of the 
work, when this communication is made by an organization other than the original one;

(iii) the public communication by loudspeaker or any other analogous instrument 
transmitting, by signs, sounds or images, the broadcast of the work.

(2) It shall be a matter for legislation in the countries of the Union to determine the conditions 
under which the rights mentioned in the preceding paragraph may be exercised, but these 
conditions shall apply only in the countries where they have been prescribed. They shall not in 
any circumstances be prejudicial to the moral rights of the author, nor to his right to obtain 
equitable remuneration which, in the absence of agreement, shall be fixed by competent 
authority.

(3) In the absence of any contrary stipulation, permission granted in accordance with 
paragraph (1) of this Article shall not imply permission to record, by means of instruments 
recording sounds or images, the work broadcast. It shall, however, be a matter for legislation in 
the countries of the Union to determine the regulations for ephemeral recordings made by a 
broadcasting organization by means of its own facilities and used for its own broadcasts. The 
preservation of these recordings in official archives may, on the ground of their exceptional 
documentary character, be authorized by such legislation.

---

#### Article 11ter Certain Rights in Literary Works:

**_1. Right of public recitation and of communication to the public of a recitation; 2. In respect of 
translations_**

(1) Authors of literary works shall enjoy the exclusive right of authorizing: 
(i) the public recitation of their works, including such public recitation by any means or 
process;

(ii) any communication to the public of the recitation of their works.

(2) Authors of literary works shall enjoy, during the full term of their rights in the original 
works, the same rights with respect to translations thereof.

#### Article 12

#### Right of Adaptation, Arrangement and Other Alteration

Authors of literary or artistic works shall enjoy the exclusive right of authorizing 
adaptations, arrangements and other alterations of their works.

#### Article 13

#### Possible Limitation of the Right of Recording of Musical Works and Any Words Pertaining Thereto:

**_1. Compulsory licenses; 2. Transitory measures; 3. Seizure on importation of copies made 
without the author's permission_**

(1) Each country of the Union may impose for itself reservations and conditions on the 
exclusive right granted to the author of a musical work and to the author of any words, the 
recording of which together with the musical work has already been authorized by the latter, to 
authorize the sound recording of that musical work, together with such words, if any; but all such 
reservations and conditions shall apply only in the countries which have imposed them and shall 
not, in any circumstances, be prejudicial to the rights of these authors to obtain equitable 
remuneration which, in the absence of agreement, shall be fixed by competent authority.

(2) Recordings of musical works made in a country of the Union in accordance with Article 
13(3) of the Conventions signed at Rome on June 2, 1928, and at Brussels on June 26, 1948, may 
be reproduced in that country without the permission of the author of the musical work until a 
date two years after that country becomes bound by this Act.

---

(3) Recordings made in accordance with paragraphs (1) and (2) of this Article and imported 
without permission from the parties concerned into a country where they are treated as infringing 
recordings shall be liable to seizure.

#### Article 14

#### Cinematographic and Related Rights:

#### 1. Cinematographic adaptation and reproduction; distribution;

**_public performance and public communication by wire of works thus adapted or reproduced; 2._** 
**_Adaptation of cinematographic productions; 3. No compulsory licenses_**

(1) Authors of literary or artistic works shall have the exclusive right of authorizing:

(i) the cinematographic adaptation and reproduction of these works, and the distribution 
of the works thus adapted or reproduced;

(ii) the public performance and communication to the public by wire of the works thus 
adapted or reproduced.

(2) The adaptation into any other artistic form of a cinematographic production derived from 
literary or artistic works shall, without prejudice to the authorization of the author of the 
cinematographic production, remain subject to the authorization of the authors of the original 
works.

(3) The provisions of Article 13(1) shall not apply.

#### Article 14bis

#### Special Provisions Concerning Cinematographic Works:

#### 1. Assimilation to “original” works; 2. Ownership; limitation of certain rights of certain contributors; 3. Certain other contributors

(1) Without prejudice to the copyright in any work which may have been adapted or 
reproduced, a cinematographic work shall be protected as an original work. The owner of 
copyright in a cinematographic work shall enjoy the same rights as the author of an original work, 
including the rights referred to in the preceding Article.

(2)

(a) Ownership of copyright in a cinematographic work shall be a matter for legislation in 
the country where protection is claimed.

(b) However, in the countries of the Union which, by legislation, include among the 
owners of copyright in a cinematographic work authors who have brought contributions 
to the making of the work, such authors, if they have undertaken to bring such 
<u>contributions, may not, in the absence of any contrary or special stipulation, object to the</u> reproduction, distribution, public performance, communication to the public by wire, 
broadcasting or any other communication to the public, or to the subtitling or dubbing of 
texts, of the work.

(c) The question whether or not the form of the undertaking referred to above should, for 
the application of the preceding subparagraph (b), be in a written agreement or a written 
act of the same effect shall be a matter for the legislation of the country where the maker 
of the cinematographic work has his headquarters or habitual residence. However, it shall 
be a matter for the legislation of the country of the Union where protection is claimed to 
provide that the said undertaking shall be in a written agreement or a written act of the 
same effect. The countries whose legislation so provides shall notify the Director General 
by means of a written declaration, which will be immediately communicated by him to 
all the other countries of the Union.

(d) By “contrary or special stipulation” is meant any restrictive condition which is relevant 
to the aforesaid undertaking.

(3) Unless the national legislation provides to the contrary, the provisions of paragraph (2)(b) 
above shall not be applicable to authors of scenarios, dialogues and musical works created for the 
making of the cinematographic work, or to the principal director thereof. However, those 
countries of the Union whose legislation does not contain rules providing for the application of 
the said paragraph (2)(b) to such director shall notify the Director General by means of a written 
declaration, which will be immediately communicated by him to all the other countries of the 
Union.

#### Article 14ter

#### “Droit de suite” in Works of Art and Manuscripts:

#### 1. Right to an interest in resales; 2. Applicable law; 3. Procedure

(1) The author, or after his death the persons or institutions authorized by national legislation, 
shall, with respect to original works of art and original manuscripts of writers and composers, 
enjoy the inalienable right to an interest in any sale of the work subsequent to the first transfer by 
the author of the work.

(2) The protection provided by the preceding paragraph may be claimed in a country of the 
Union only if legislation in the country to which the author belongs so permits, and to the extent 
permitted by the country where this protection is claimed.

(3) The procedure for collection and the amounts shall be matters for determination by national 
legislation.

---

#### Article 15

#### Right to Enforce Protected Rights:

**_1. Where author's name is indicated or where pseudonym leaves no doubt as to author's 
identity; 2. In the case of cinematographic works; 3. In the case of anonymous and 
pseudonymous works; 4. In the case of certain unpublished works of unknown authorship_**

(1) In order that the author of a literary or artistic work protected by this Convention shall, in 
the absence of proof to the contrary, be regarded as such, and consequently be entitled to institute 
infringement proceedings in the countries of the Union, it shall be sufficient for his name to 
appear on the work in the usual manner. This paragraph shall be applicable even if this name is 
a pseudonym, where the pseudonym adopted by the author leaves no doubt as to his identity.

(2) The person or body corporate whose name appears on a cinematographic work in the usual 
manner shall, in the absence of proof to the contrary, be presumed to be the maker of the said 
work.

(3) In the case of anonymous and pseudonymous works, other than those referred to in 
paragraph (1) above, the publisher whose name appears on the work shall, in the absence of proof 
to the contrary, be deemed to represent the author, and in this capacity he shall be entitled to 
protect and enforce the author's rights. The provisions of this paragraph shall cease to apply when 
the author reveals his identity and establishes his claim to authorship of the work.

(4)

(a) In the case of unpublished works where the identity of the author is unknown, but 
where there is every ground to presume that he is a national of a country of the Union, it 
shall be a matter for legislation in that country to designate the competent authority which 
shall represent the author and shall be entitled to protect and enforce his rights in the 
countries of the Union.

(b) Countries of the Union which make such designation under the terms of this provision 
shall notify the Director General by means of a written declaration giving full information 
concerning the authority thus designated. The Director General shall at once 
communicate this declaration to all other countries of the Union.

#### Article 16

#### Infringing Copies:

#### 1. Seizure; 2. Seizure on importation; 3. Applicable law

(1) Infringing copies of a work shall be liable to seizure in any country of the Union where the 
work enjoys legal protection.

---

(2) The provisions of the preceding paragraph shall also apply to reproductions coming from 
a country where the work is not protected, or has ceased to be protected.

(3) The seizure shall take place in accordance with the legislation of each country.

#### Article 17

#### Possibility of Control of Circulation, Presentation and Exhibition of Works

The provisions of this Convention cannot in any way affect the right of the Government 
of each country of the Union to permit, to control, or to prohibit, by legislation or regulation, the 
circulation, presentation, or exhibition of any work or production in regard to which the 
competent authority may find it necessary to exercise that right.

#### Article 18

#### Works Existing on Convention's Entry Into Force:

#### 1. Protectable where protection not yet expired in country of origin;

#### 2. Non-protectable where protection already expired in country where it is claimed; 3. Application of these principles; 4. Special cases

(1) This Convention shall apply to all works which, at the moment of its coming into force, 
have not yet fallen into the public domain in the country of origin through the expiry of the term 
of protection.

(2) If, however, through the expiry of the term of protection which was previously granted, a 
work has fallen into the public domain of the country where protection is claimed, that work shall 
not be protected anew.

(3) The application of this principle shall be subject to any provisions contained in special 
conventions to that effect existing or to be concluded between countries of the Union. In the 
absence of such provisions, the respective countries shall determine, each in so far as it is 
concerned, the conditions of application of this principle.

(4) The preceding provisions shall also apply in the case of new accessions to the Union and to 
cases in which protection is extended by the application of Article 7 or by the abandonment of 
reservations.

#### Article 19

#### Protection Greater than Resulting from Convention

The provisions of this Convention shall not preclude the making of a claim to the benefit 
of any greater protection which may be granted by legislation in a country of the Union.

---

#### Article 20 Special Agreements Among Countries of the Union

The Governments of the countries of the Union reserve the right to enter into special 
agreements among themselves, in so far as such agreements grant to authors more extensive 
rights than those granted by the Convention, or contain other provisions not contrary to this 
Convention. The provisions of existing agreements which satisfy these conditions shall remain 
applicable.

#### Article 21

#### Special Provisions Regarding Developing Countries:

#### 1. Reference to Appendix; 2. Appendix part of Act

(1) Special provisions regarding developing countries are included in the Appendix.

(2) Subject to the provisions of Article 28(1)(b), the Appendix forms an integral part of this Act.

#### Article 22

#### Assembly:

**_1. Constitution and composition; 2. Tasks; 3. Quorum, voting, observers; 4. Convocation; 5._** 
**_Rules of procedure_**

(1)

(a) The Union shall have an Assembly consisting of those countries of the Union which 
are bound by Articles 22 to 26.

(b) The Government of each country shall be represented by one delegate, who may be 
assisted by alternate delegates, advisors, and experts.

(c) The expenses of each delegation shall be borne by the Government which has 
appointed it.

(2)

(a) The Assembly shall:

(i)  deal with all matters concerning the maintenance and development of the Union 
and the implementation of this Convention;

(ii) give directions concerning the preparation for conferences of revision to the 
International Bureau of Intellectual Property (hereinafter designated as “the 
International Bureau”) referred to in the Convention Establishing the World 
Intellectual Property Organization (hereinafter designated as “the Organization”), due account being taken of any comments made by those countries of the Union 
which are not bound by Articles 22 to 26;

(iii) review and approve the reports and activities of the Director General of the 
Organization concerning the Union, and give him all necessary instructions 
concerning matters within the competence of the Union;

(iv) elect the members of the Executive Committee of the Assembly;

(v)  review and approve the reports and activities of its Executive Committee, and 
give instructions to such Committee;

(vi) determine the program and adopt the biennial budget of the Union, and approve 
its final accounts;

(vii) adopt the financial regulations of the Union;

(viii) establish such committees of experts and working groups as may be necessary 
for the work of the Union;

(ix) determine which countries not members of the Union and which 
intergovernmental      and international non-governmental organizations shall be 
admitted to its meetings as observers;

(x) adopt amendments to Articles 22 to 26;

(xi) take any other appropriate action designed to further the objectives of 
        the Union;

(xii) exercise such other functions as are appropriate under this Convention;

(xiii) subject to its acceptance, exercise such rights as are given to it in the 
        Convention establishing the Organization.

(b) With respect to matters which are of interest also to other Unions administered by the    
Organization, the Assembly shall make its decisions after having heard the advice of the 
Coordination Committee of the Organization.

**(3)**

(a) Each country member of the Assembly shall have one vote.

(b) One-half of the countries members of the Assembly shall constitute a quorum.

---

(c) Notwithstanding the provisions of subparagraph (b), if, in any session, the number of 
countries represented is less than one-half but equal to or more than one-third of the 
countries members of the Assembly, the Assembly may make decisions but, with the 
exception of decisions concerning its own procedure, all such decisions shall take effect 
only if the following conditions are fulfilled. The International Bureau shall communicate 
the said decisions to the countries members of the Assembly which were not represented 
and shall invite them to express in writing their vote or abstention within a period of three 
months from the date of the communication. If, at the expiration of this period, the number 
of countries having thus expressed their vote or abstention attains the number of countries 
which was lacking for attaining the quorum in the session itself, such decisions shall take 
effect provided that at the same time the required majority still obtains.

(d)  Subject to the provisions of Article 26(2), the decisions of the Assembly shall require 
two-thirds of the votes cast.

(e) Abstentions shall not be considered as votes.

(f)  A delegate may represent, and vote in the name of, one country only.

(g) Countries of the Union not members of the Assembly shall be admitted to its meetings 
as observers.

**(4)**

(a) The Assembly shall meet once in every second calendar year in ordinary session upon 
convocation by the Director General and, in the absence of exceptional circumstances, 
during the same period and at the same place as the General Assembly of the 
Organization.

(b) The Assembly shall meet in extraordinary session upon convocation by the Director 
General, at the request of the Executive Committee or at the request of one-fourth of the 
countries members of the Assembly.

(5) The Assembly shall adopt its own rules of procedure.

#### Article 23

#### Executive Committee:

**_1. Constitution; 2. Composition; 3. Number of members; 4. Geographical distribution; special 
agreements; 5. Term, limits of re-eligibility, rules of election; 6. Tasks; 7. Convocation; 8._** 
**_Quorum, voting; 9. Observers; 10. Rules of procedure_**

(1) The Assembly shall have an Executive Committee.

---

(2)

(a) The Executive Committee shall consist of countries elected by the Assembly from 
among countries members of the Assembly. Furthermore, the country on whose territory 
the Organization has its headquarters shall, subject to the provisions of Article 25(7)(b), 
have an ex officio seat on the Committee.

(b) The Government of each country member of the Executive Committee shall be 
represented by one delegate, who may be assisted by alternate delegates, advisors, and 
experts.

(c) The expenses of each delegation shall be borne by the Government which has 
appointed it.

(3) The number of countries members of the Executive Committee shall correspond to one 
fourth of the number of countries members of the Assembly. In establishing the number of seats 
to be filled, remainders after division by four shall be disregarded.

(4) In electing the members of the Executive Committee, the Assembly shall have due regard 
to an equitable geographical distribution and to the need for countries party to the Special 
Agreements which might be established in relation with the Union to be among the countries 
constituting the Executive Committee.

(5)

(a) Each member of the Executive Committee shall serve from the close of the session of 
the Assembly which elected it to the close of the next ordinary session of the Assembly.

(b) Members of the Executive Committee may be re-elected, but not more than two-thirds 
of them.

(c) The Assembly shall establish the details of the rules governing the election and possible 
re-election of the members of the Executive Committee.

(6)

(a) The Executive Committee shall:

(i) prepare the draft agenda of the Assembly;

(ii) submit proposals to the Assembly respecting the draft program  
                     and biennial budget of the Union prepared by the Director General;

(iii) [deleted]

<u>(iv) submit, with appropriate comments, to the Assembly the periodical</u> reports of the Director General and the yearly audit reports on the accounts;

(v) in accordance with the decisions of the Assembly and having regard to  
 circumstances arising between two ordinary sessions of the   
 Assembly, take all necessary measures to ensure the execution of the  
 program of the Union by the Director General;

(vi) perform such other functions as are allocated to it under this Convention.

(b) With respect to matters which are of interest also to other Unions administered by the   
Organization, the Executive Committee shall make its decisions after having heard the 
advice of the Coordination Committee of the Organization.

(7)

(a) The Executive Committee shall meet once a year in ordinary session upon convocation 
by the Director General, preferably during the same period and at the same place as the 
Coordination Committee of the Organization.

(b) The Executive Committee shall meet in extraordinary session upon convocation by the 
Director General, either on his own initiative, or at the request of its Chairman or onefourth of its members.

(8)

(a) Each country member of the Executive Committee shall have one vote.

(b) One-half of the members of the Executive Committee shall constitute a quorum.

(c) Decisions shall be made by a simple majority of the votes cast.

(d) Abstentions shall not be considered as votes.

(e) A delegate may represent, and vote in the name of, one country only.

(9) Countries of the Union not members of the Executive Committee shall be admitted to its 
meetings as observers.

(10) The Executive Committee shall adopt its own rules of procedure.

---

#### Article 24 International Bureau:

**_1. Tasks in general, Director General; 2. General information; 3. Periodical;_** 
**_4. Information to countries; 5. Studies and services; 6. Participation in meetings;_** 
**_7. Conferences of revision; 8. Other tasks_**

(1)

(a) The administrative tasks with respect to the Union shall be performed by the 
International Bureau, which is a continuation of the Bureau of the Union united with the 
Bureau of the Union established by the International Convention for the Protection of 
Industrial Property.

(b) In particular, the International Bureau shall provide the secretariat of the various 
organs of the Union.

(c) The Director General of the Organization shall be the chief executive of the Union and 
shall represent the Union.

(2) The International Bureau shall assemble and publish information concerning the protection 
of copyright. Each country of the Union shall promptly communicate to the International 
Bureau all new laws and official texts concerning the protection of copyright.

(3) The International Bureau shall publish a monthly periodical.

(4) The International Bureau shall, on request, furnish information to any country of the Union 
on matters concerning the protection of copyright.

(5) The International Bureau shall conduct studies, and shall provide services, designed to 
facilitate the protection of copyright.

(6) The Director General and any staff member designated by him shall participate, without 
the right to vote, in all meetings of the Assembly, the Executive Committee and any other 
committee of experts or working group. The Director General, or a staff member designated by 
him, shall be ex officio secretary of these bodies.

(7)

(a) The International Bureau shall, in accordance with the directions of the Assembly and 
in cooperation with the Executive Committee, make the preparations for the conferences 
of revision of the provisions of the Convention other than Articles 22 to 26.

(b) The International Bureau may consult with intergovernmental and international nongovernmental organizations concerning preparations for conferences of revision.

---

(c) The Director General and persons designated by him shall take part, without the right 
to vote, in the discussions at these conferences.

(8) The International Bureau shall carry out any other tasks assigned to it.

#### Article 25

#### Finances:

**_1. Budget; 2. Coordination with other Unions; 3. Resources;_**

**_4. Contributions; possible extension of previous budget; 5. Fees and charges;_**

**_6. Working capital fund; 7. Advances by host Government; 8. Auditing of accounts_**

(1)

(a) The Union shall have a budget.

(b) The budget of the Union shall include the income and expenses proper to the Union, 
its contribution to the budget of expenses common to the Unions, and, where applicable, 
the sum made available to the budget of the Conference of the Organization.

(c) Expenses not attributable exclusively to the Union but also to one or more other Unions 
administered by the Organization shall be considered as expenses common to the Unions. 
The share of the Union in such common expenses shall be in proportion to the interest the 
Union has in them.

(2) The budget of the Union shall be established with due regard to the requirements of 
coordination with the budgets of the other Unions administered by the Organization.

(3) The budget of the Union shall be financed from the following sources:

(i) contributions of the countries of the Union;

(ii) fees and charges due for services performed by the International Bureau in relation to 
the Union;

(iii) sale of, or royalties on, the publications of the International Bureau concerning the 
Union;

(iv) gifts, bequests, and subventions;

(v) rents, interests, and other miscellaneous income.

---

(4)

(a) For the purpose of establishing its contribution towards the budget, each country of 
the Union shall belong to a class, and shall pay its annual contributions on the basis of a 
number of units fixed as follows 3:

Class I ...................... 25 
Class II ..................... 20 
Class III .................... 15 
Class IV .................... 10 
Class V ....................... 5 
Class VI ...................... 3 
Class VII ..................... 1

(b) Unless it has already done so, each country shall indicate, concurrently with depositing 
its instrument of ratification or accession, the class to which it wishes to belong. Any 
country may change class. If it chooses a lower class, the country must announce it to the 
Assembly at one of its ordinary sessions. Any such change shall take effect at the 
beginning of the calendar year following the session.

(c) The annual contribution of each country shall be an amount in the same proportion to 
the total sum to be contributed to the annual budget of the Union by all countries as the 
number of its units is to the total of the units of all contributing countries.

(d) Contributions shall become due on the first of January of each year.

(e) A country which is in arrears in the payment of its contributions shall have no vote in 
any of the organs of the Union of which it is a member if the amount of its arrears equals 
or exceeds the amount of the contributions due from it for the preceding two full years. 
However, any organ of the Union may allow such a country to continue to exercise its 
vote in that organ if, and as long as, it is satisfied that the delay in payment is due to 
exceptional and unavoidable circumstances.

(f) If the budget is not adopted before the beginning of a new financial period, it shall be 
at the same level as the budget of the previous year, in accordance with the financial 
regulations.

---

(5) The amount of the fees and charges due for services rendered by the International Bureau 
in relation to the Union shall be established, and shall be reported to the Assembly and the 
Executive Committee, by the Director General.

(6)

(a) The Union shall have a working capital fund which shall be constituted by a single 
payment made by each country of the Union. If the fund becomes insufficient, an increase 
shall be decided by the Assembly.

(b) The amount of the initial payment of each country to the said fund or of its 
participation in the increase thereof shall be a proportion of the contribution of that 
country for the year in which the fund is established or the increase decided.

(c) The proportion and the terms of payment shall be fixed by the Assembly on the 
proposal of the Director General and after it has heard the advice of the Coordination 
Committee of the Organization.

(7)

(a) In the headquarters agreement concluded with the country on the territory of which 
the Organization has its headquarters, it shall be provided that, whenever the working 
capital fund is insufficient, such country shall grant advances. The amount of these 
advances and the conditions on which they are granted shall be the subject of separate 
agreements, in each case, between such country and the Organization. As long as it 
remains under the obligation to grant advances, such country shall have an ex officio seat 
on the Executive Committee.

(b) The country referred to in subparagraph (a) and the Organization shall each have the 
right to denounce the obligation to grant advances, by written notification. Denunciation 
shall take effect three years after the end of the year in which it has been notified.

(8) The auditing of the accounts shall be effected by one or more of the countries of the Union 
or by external auditors, as provided in the financial regulations. They shall be designated, with 
their agreement, by the Assembly.

#### Article 26

#### Amendments:

#### 1. Provisions susceptible of amendment by the Assembly; proposals; 2. Adoption; 3. Entry into force

(1) Proposals for the amendment of Articles 22, 23, 24, 25, and the present Article, may be 
initiated by any country member of the Assembly, by the Executive Committee, or by the Director 
General. Such proposals shall be communicated by the Director General to the member countries 
<u>of the Assembly at least six months in advance of their consideration by the Assembly.</u>

---

(2) Amendments to the Articles referred to in paragraph (1) shall be adopted by the Assembly. 
Adoption shall require three-fourths of the votes cast, provided that any amendment of Article 
22, and of the present paragraph, shall require four-fifths of the votes cast.

(3) Any amendment to the Articles referred to in paragraph (1) shall enter into force one month 
after written notifications of acceptance, effected in accordance with their respective 
constitutional processes, have been received by the Director General from three-fourths of the 
countries members of the Assembly at the time it adopted the amendment. Any amendment to 
the said Articles thus accepted shall bind all the countries which are members of the Assembly at 
the time the amendment enters into force, or which become members thereof at a subsequent 
date, provided that any amendment increasing the financial obligations of countries of the Union 
shall bind only those countries which have notified their acceptance of such amendment.

#### Article 27

#### Revision:

#### 1. Objective; 2. Conferences; 3. Adoption

(1) This Convention shall be submitted to revision with a view to the introduction of 
amendments designed to improve the system of the Union.

(2) For this purpose, conferences shall be held successively in one of the countries of the Union 
among the delegates of the said countries.

(3) Subject to the provisions of Article 26 which apply to the amendment of Articles 22 to 26, 
any revision of this Act, including the Appendix, shall require the unanimity of the votes cast.

#### Article 28

#### Acceptance and Entry Into Force of Act for Countries of the Union:

**_1. Ratification, accession; possibility of excluding certain provisions; withdrawal of exclusion;_** 
**_2. Entry into force of Articles 1 to 21 and Appendix; 3. Entry into force of Articles 22 to 38_**

(1)

(a) Any country of the Union which has signed this Act may ratify it, and, if it has not 
signed it, may accede to it. Instruments of ratification or accession shall be deposited with 
the Director General.

(b) Any country of the Union may declare in its instrument of ratification or accession that 
its ratification or accession shall not apply to Articles 1 to 21 and the Appendix, provided 
that, if such country has previously made a declaration under Article VI(1) of the 
Appendix, then it may declare in the said instrument only that its ratification or accession 
<u>shall not apply to Articles 1 to 20.</u>

---

(c) Any country of the Union which, in accordance with subparagraph (b), has excluded 
provisions therein referred to from the effects of its ratification or accession may at any 
later time declare that it extends the effects of its ratification or accession to those 
provisions. Such declaration shall be deposited with the Director General.

(2)

(a) Articles 1 to 21 and the Appendix shall enter into force three months after both of the 
following two conditions are fulfilled:

(i) at least five countries of the Union have ratified or acceded to this Act without 
making a declaration under paragraph (1)(b),

(ii) France, Spain, the United Kingdom of Great Britain and Northern Ireland, and 
the United States of America, have become bound by the Universal Copyright 
Convention as revised at Paris on July 24, 1971.

(b) The entry into force referred to in subparagraph (a) shall apply to those countries of 
the Union which, at least three months before the said entry into force, have deposited 
instruments of ratification or accession not containing a declaration under paragraph 
(1)(b).

(c) With respect to any country of the Union not covered by subparagraph (b) and which 
ratifies or accedes to this Act without making a declaration under paragraph (1)(b), 
Articles 1 to 21 and the Appendix shall enter into force three months after the date on 
which the Director General has notified the deposit of the relevant instrument of 
ratification or accession, unless a subsequent date has been indicated in the instrument 
deposited. In the latter case, Articles 1 to 21 and the Appendix shall enter into force with 
respect to that country on the date thus indicated.

(d) The provisions of subparagraphs (a) to (c) do not affect the application of Article VI of 
the Appendix.

(3) With respect to any country of the Union which ratifies or accedes to this Act with or 
without a declaration made under paragraph (1)(b), Articles 22 to 38 shall enter into force three 
months after the date on which the Director General has notified the deposit of the relevant 
instrument of ratification or accession, unless a subsequent date has been indicated in the 
instrument deposited. In the latter case, Articles 22 to 38 shall enter into force with respect to that 
country on the date thus indicated.

---

#### Article 29

#### Acceptance and Entry Into Force for Countries Outside the Union: <em>1. Accession; 2. Entry into force</em>

(1) Any country outside the Union may accede to this Act and thereby become party to this 
Convention and a member of the Union. Instruments of accession shall be deposited with the 
Director General.

(2)

(a) Subject to subparagraph (b), this Convention shall enter into force with

respect to any country outside the Union three months after the date on which the Director   
General has notified the deposit of its instrument of accession, unless a subsequent date 
has been indicated in the instrument deposited. In the latter case, this Convention shall 
enter into force with respect to that country on the date thus indicated.

(b) If the entry into force according to subparagraph (a) precedes the entry into force of 
Articles 1 to 21 and the Appendix according to Article 28(2)(a), the said country shall, in 
the meantime, be bound, instead of by Articles 1 to 21 and the Appendix, by Articles 1 to 
20 of the Brussels Act of this Convention.

#### Article 29bis

#### Effect of Acceptance of Act for the Purposes of Article 14(2) of the WIPO Convention

Ratification of or accession to this Act by any country not bound by Articles 22 to of the 
Stockholm Act of this Convention shall, for the sole purposes of Article 14(2) of the Convention 
establishing the Organization, amount to ratification of or accession to the said Stockholm Act 
with the limitation set forth in Article 28(1)(b)(i) thereof.

#### Article 30

#### Reservations:

#### 1. Limits of possibility of making reservations;

#### 2. Earlier reservations; reservation as to the right of translation; withdrawal of reservation

(1) Subject to the exceptions permitted by paragraph (2) of this Article, by Article 28(1)(b), by 
Article 33(2), and by the Appendix, ratification or accession shall automatically entail acceptance 
of all the provisions and admission to all the advantages of this Convention.

(2)

(a) Any country of the Union ratifying or acceding to this Act may, subject to Article V(2) 
of the Appendix, retain the benefit of the reservations it has previously formulated on condition that it makes a declaration to that effect at the time of the deposit of its 
instrument of ratification or accession.

(b) Any country outside the Union may declare, in acceding to this Convention and 
subject to Article V(2) of the Appendix, that it intends to substitute, temporarily at least, 
for Article 8 of this Act concerning the right of translation, the provisions of Article 5 of 
the Union Convention of 1886 4, as completed at Paris in 1896, on the clear understanding 
that the said provisions are applicable only to translations into a language in general use 
in the said country. Subject to Article I(6)(b) of the Appendix, any country has the right to 
apply, in relation to the right of translation of works whose country of origin is a country 
availing itself of such a reservation, a protection which is equivalent to the protection 
granted by the latter country.

(c) Any country may withdraw such reservations at any time by notification addressed to 
the Director General.

#### Article 31

#### Applicability to Certain Territories:

#### 1. Declaration; 2. Withdrawal of declaration; 3. Effective date; 4. Acceptance of factual situations not implied

(1) Any country may declare in its instrument of ratification or accession, or may inform the 
Director General by written notification at any time thereafter, that this Convention shall be 
applicable to all or part of those territories, designated in the declaration or notification, for the 
external relations of which it is responsible.

(2) Any country which has made such a declaration or given such a notification may, at any 
time, notify the Director General that this Convention shall cease to be applicable to all or part of 
such territories.

(3)

(a) Any declaration made under paragraph (1) shall take effect on the same date as the 
ratification or accession in which it was included, and any notification given under that 
paragraph shall take effect three months after its notification by the Director General.

(b) Any notification given under paragraph (2) shall take effect twelve months after its 
receipt by the Director General.

(4) This Article shall in no way be understood as implying the recognition or tacit acceptance 
by a country of the Union of the factual situation concerning a territory to which this Convention 
is made applicable by another country of the Union by virtue of a declaration under paragraph 
<u>(1).</u>

---

#### Article 32

#### Applicability of this Act and of Earlier Acts:

**_1. As between countries already members of the Union;_**

**_2. As between a country becoming a member of the Union and other countries members of the_** 
**_Union; 3. Applicability of the Appendix in Certain Relations_**

(1) This Act shall, as regards relations between the countries of the Union, and to the extent 
that it applies, replace the Berne Convention of September 9, 1886, and the subsequent Acts of 
revision. The Acts previously in force shall continue to be applicable, in their entirety or to the 
extent that this Act does not replace them by virtue of the preceding sentence, in relations with 
countries of the Union which do not ratify or accede to this Act.

(2) Countries outside the Union which become party to this Act shall, subject to paragraph (3), 
apply it with respect to any country of the Union not bound by this Act or which, although bound 
by this Act, has made a declaration pursuant to Article 28(1)(b). Such countries recognize that the 
said country of the Union, in its relations with them:

(i) may apply the provisions of the most recent Act by which it is bound, and

(ii) subject to Article I(6) of the Appendix, has the right to adapt the protection to the level 
provided for by this Act.

(3) Any country which has availed itself of any of the faculties provided for in the Appendix 
may apply the provisions of the Appendix relating to the faculty or faculties of which it has 
availed itself in its relations with any other country of the Union which is not bound by this Act, 
provided that the latter country has accepted the application of the said provisions.

#### Article 33

#### Disputes:

#### 1. Jurisdiction of the International Court of Justice;

#### 2. Reservation as to such jurisdiction; 3. Withdrawal of reservation

(1) Any dispute between two or more countries of the Union concerning the interpretation or 
application of this Convention, not settled by negotiation, may, by any one of the countries 
concerned, be brought before the International Court of Justice by application in conformity with 
the Statute of the Court, unless the countries concerned agree on some other method of 
settlement. The country bringing the dispute before the Court shall inform the International 
Bureau; the International Bureau shall bring the matter to the attention of the other countries of 
the Union.

(2) Each country may, at the time it signs this Act or deposits its instrument of ratification or 
accession, declare that it does not consider itself bound by the provisions of paragraph (1). With regard to any dispute between such country and any other country of the Union, the provisions 
of paragraph (1) shall not apply.

(3) Any country having made a declaration in accordance with the provisions of paragraph (2) 
may, at any time, withdraw its declaration by notification addressed to the Director General.

#### Article 34

#### Closing of Certain Earlier Provisions: <em>1. Of earlier Acts; 2. Of the Protocol to the Stockholm Act</em>

(1) Subject to Article 29bis, no country may ratify or accede to earlier Acts of this Convention 
once Articles 1 to 21 and the Appendix have entered into force.

(2) Once Articles 1 to 21 and the Appendix have entered into force, no country may make a 
declaration under Article 5 of the Protocol Regarding Developing Countries attached to the 
Stockholm Act.

#### Article 35

**Duration of the Convention; Denunciation: _1. Unlimited duration; 2. Possibility of 
denunciation; 3. Effective date of denunciation; 4. Moratorium on denunciation_**

(1) This Convention shall remain in force without limitation as to time.

(2) Any country may denounce this Act by notification addressed to the Director General. 
Such denunciation shall constitute also denunciation of all earlier Acts and shall affect only the 
country making it, the Convention remaining in full force and effect as regards the other countries 
of the Union.

(3) Denunciation shall take effect one year after the day on which the Director General has 
received the notification.

(4) The right of denunciation provided by this Article shall not be exercised by any country 
before the expiration of five years from the date upon which it becomes a member of the Union.

#### Article 36

#### Application of the Convention:

**_1. Obligation to adopt the necessary measures; 2. Time from which obligation exists_**

(1) Any country party to this Convention undertakes to adopt, in accordance with its 
constitution, the measures necessary to ensure the application of this Convention.

---

(2) It is understood that, at the time a country becomes bound by this Convention, it will be in 
a position under its domestic law to give effect to the provisions of this Convention.

#### Article 37

#### Final Clauses:

#### 1. Languages of the Act; 2. Signature; 3. Certified copies; 4. Registration; 5. Notifications

(1)

(a) This Act shall be signed in a single copy in the French and English languages and, 
subject to paragraph (2), shall be deposited with the Director General.

(b) Official texts shall be established by the Director General, after consultation with the 
interested Governments, in the Arabic, German, Italian, Portuguese and Spanish 
languages, and such other languages as the Assembly may designate.

(c) In case of differences of opinion on the interpretation of the various texts, the French 
text shall prevail.

(2) This Act shall remain open for signature until January 31, 1972. Until that date, the copy 
referred to in paragraph (1)(a) shall be deposited with the Government of the French Republic.

(3) The Director General shall certify and transmit two copies of the signed text of this Act to 
the Governments of all countries of the Union and, on request, to the Government of any other 
country.

(4) The Director General shall register this Act with the Secretariat of the United Nations.

(5) The Director General shall notify the Governments of all countries of the Union of 
signatures, deposits of instruments of ratification or accession and any declarations included in 
such instruments or made pursuant to Articles 28(1)(c), 30(2)(a) and (b), and 33(2), entry into force 
of any provisions of this Act, notifications of denunciation, and notifications pursuant to Articles 
30(2)(c), 31(1) and (2), 33(3), and 38(1), as well as the Appendix.

#### Article 38

#### Transitory Provisions:

**_1. Exercise of the “five-year privilege”; 2. Bureau of the Union, Director of the Bureau; 3._** 
**_Succession of Bureau of the Union_**

(1) Countries of the Union which have not ratified or acceded to this Act and which are not 
bound by Articles 22 to 26 of the Stockholm Act of this Convention may, until April 26, 1975, 
exercise, if they so desire, the rights provided under the said Articles as if they were bound by 
<u>them. Any country desiring to exercise such rights shall give written notification to this effect to</u> the Director General; this notification shall be effective on the date of its receipt. Such countries 
shall be deemed to be members of the Assembly until the said date.

(2) As long as all the countries of the Union have not become Members of the Organization, 
the International Bureau of the Organization shall also function as the Bureau of the Union, and 
the Director General as the Director of the said Bureau.

(3) Once all the countries of the Union have become Members of the Organization, the rights, 
obligations, and property, of the Bureau of the Union shall devolve on the International Bureau 
of the Organization.

#### APPENDIX SPECIAL PROVISIONS REGARDING DEVELOPING COUNTRIES

**Article I** 
**Faculties Open to Developing Countries:** 
**_1. Availability of certain faculties; declaration; 2. Duration of effect of declaration;_** 
**_3. Cessation of developing country status; 4. Existing stocks of copies;_** 
**_5. Declarations concerning certain territories; 6. Limits of reciprocity_**

(1) Any country regarded as a developing country in conformity with the established practice 
of the General Assembly of the United Nations which ratifies or accedes to this Act, of which this 
Appendix forms an integral part, and which, having regard to its economic situation and its social 
or cultural needs, does not consider itself immediately in a position to make provision for the 
protection of all the rights as provided for in this Act, may, by a notification deposited with the 
Director General at the time of depositing its instrument of ratification or accession or, subject to 
Article V(1)(c), at any time thereafter, declare that it will avail itself of the faculty provided for in 
Article II, or of the faculty provided for in Article III, or of both of those faculties. It may, instead 
of availing itself of the faculty provided for in Article II, make a declaration according to Article 
V(1)(a).

(2)

(a) Any declaration under paragraph (1) notified before the expiration of the period of ten 
years from the entry into force of Articles 1 to 21 and this Appendix according to Article 
28(2) shall be effective until the expiration of the said period. Any such declaration may 
be renewed in whole or in part for periods of ten years each by a notification deposited 
with the Director General not more than fifteen months and not less than three months 
before the expiration of the ten-year period then running.

(b) Any declaration under paragraph (1) notified after the expiration of the period of ten 
years from the entry into force of Articles 1 to 21 and this Appendix according to Article

---

28(2) shall be effective until the expiration of the ten-year period then running. Any such 
declaration may be renewed as provided for in the second sentence of subparagraph (a).

(3) Any country of the Union which has ceased to be regarded as a developing country as 
referred to in paragraph (1) shall no longer be entitled to renew its declaration as provided in 
paragraph (2), and, whether or not it formally withdraws its declaration, such country shall be 
precluded from availing itself of the faculties referred to in paragraph (1) from the expiration of 
the ten-year period then running or from the expiration of a period of three years after it has 
ceased to be regarded as a developing country, whichever period expires later.

(4) Where, at the time when the declaration made under paragraph (1) or (2) ceases to  
be effective, there are copies in stock which were made under a license granted by virtue of this 
Appendix, such copies may continue to be distributed until their stock is exhausted.

(5) Any country which is bound by the provisions of this Act and which has deposited a 
declaration or a notification in accordance with Article 31(1) with respect to the application of this 
Act to a particular territory, the situation of which can be regarded as analogous to that of the 
countries referred to in paragraph (1), may, in respect of such territory, make the declaration 
referred to in paragraph (1) and the notification of renewal referred to in paragraph (2). As long 
as such declaration or notification remains in effect, the provisions of this Appendix shall be 
applicable to the territory in respect of which it was made.

(6)

(a) The fact that a country avails itself of any of the faculties referred to in paragraph (1) 
does not permit another country to give less protection to works of which the country of 
origin is the former country than it is obliged to grant under Articles 1 to 20.

(b) The right to apply reciprocal treatment provided for in Article 30(2)(b), second 
sentence, shall not, until the date on which the period applicable under Article I(3) expires, 
be exercised in respect of works the country of origin of which is a country which has 
made a declaration according to Article V(1)(a).

#### Article II

#### Limitations on the Right of Translation:

**_1. Licenses grantable by competent authority; 2. to 4. Conditions allowing the grant of such 
licenses; 5. Purposes for which licenses may be granted; 6. Termination of licenses; 7. Works 
composed mainly of illustrations; 8. Works withdrawn from circulation; 9. Licenses for 
broadcasting organizations_**

(1) Any country which has declared that it will avail itself of the faculty provided for in this 
Article shall be entitled, so far as works published in printed or analogous forms of reproduction 
<u>are concerned, to substitute for the exclusive right of translation provided for in Article 8 a system</u> of non-exclusive and non-transferable licenses, granted by the competent authority under the 
following conditions and subject to Article IV.

(2)

(a) Subject to paragraph (3), if, after the expiration of a period of three years, or of any 
longer period determined by the national legislation of the said country, commencing on 
the date of the first publication of the work, a translation of such work has not been 
published in a language in general use in that country by the owner of the right of 
translation, or with his authorization, any national of such country may obtain a license 
to make a translation of the work in the said language and publish the translation in 
printed or analogous forms of reproduction.

(b) A license under the conditions provided for in this Article may also be granted if all 
the editions of the translation published in the language concerned are out of print.

(3)

(a) In the case of translations into a language which is not in general use in one or more 
developed countries which are members of the Union, a period of one year shall be 
substituted for the period of three years referred to in paragraph (2)(a).

(b) Any country referred to in paragraph (1) may, with the unanimous agreement of the 
developed countries which are members of the Union and in which the same language is 
in general use, substitute, in the case of translations into that language, for the period of 
three years referred to in paragraph (2)(a) a shorter period as determined by such 
agreement but not less than one year. However, the provisions of the foregoing sentence 
shall not apply where the language in question is English, French or Spanish. The Director 
General shall be notified of any such agreement by the Governments which have 
concluded it.

(4)

(a) No license obtainable after three years shall be granted under this Article until a further 
period of six months has elapsed, and no license obtainable after one year shall be granted 
under this Article until a further period of nine months has elapsed

(i) from the date on which the applicant complies with the requirements 
mentioned in Article IV(1), or

(ii) where the identity or the address of the owner of the right of translation is 
unknown, from the date on which the applicant sends, as provided for in Article 
IV(2), copies of his application submitted to the authority competent to grant the 
license.

---

(b) If, during the said period of six or nine months, a translation in the language in respect 
of which the application was made is published by the owner of the right of translation or 
with his authorization, no license under this Article shall be granted.

(5) Any license under this Article shall be granted only for the purpose of teaching, scholarship 
or research.

(6) If a translation of a work is published by the owner of the right of translation or with his 
authorization at a price reasonably related to that normally charged in the country for comparable 
works, any license granted under this Article shall terminate if such translation is in the same 
language and with substantially the same content as the translation published under the license. 
Any copies already made before the license terminates may continue to be distributed until their 
stock is exhausted.

(7) For works which are composed mainly of illustrations, a license to make and publish a 
translation of the text and to reproduce and publish the illustrations may be granted only if the 
conditions of Article III are also ful
…[truncated]