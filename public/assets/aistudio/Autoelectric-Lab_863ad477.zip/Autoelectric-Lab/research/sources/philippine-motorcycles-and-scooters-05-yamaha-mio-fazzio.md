Source: https://www.yamaha-motor.com.ph/personal-commuter/lifestyle/mio-series/mio-fazzio
Title: Mio Fazzio | Yamaha Motor Philippines Inc.
Fetched: 2026-11-11T12:55:18.110Z

# This website uses cookies

![Privacy Stamp](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/DPA_Seal%20(2026).webp)

We use cookies to personalise content and ads, to provide social
media features and to analyse our traffic. We also share information
about your use of our site with our social media, advertising and
analytics partners who may combine it with other information that
you've provided to them or that they've collected from your use of
their services.


Accept AllReject All

Privacy PolicyManage Cookies

![Yamaha logo](https://www.yamaha-motor.com.ph/images/new-yamaha-logo.webp)

![](https://www.yamaha-motor.com.ph/images/new-yamaha-logo.webp)

![](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/ICONS-%20MOTORCYCLES.png)

![Hero Background](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/VIS/news_background_mobile_1.webp)

MENU

![](https://www.yamaha-motor.com.ph/images/new-yamaha-logo.webp)

Home

Motorcycle

Racing

News

Find Dealer

RIDE WITH US

Get the best dealer for You

[Find a Dealer![Hero Background](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/Icon.png)](https://find-dealer.yamaha-motor.com.ph/)

![Hero Background](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/VIS/news_background_main_mobile.webp)

Latest

![](https://www.yamaha-motor.com.ph/images/new-yamaha-logo.webp)

![MIO GEAR S](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Fmio-gear-s%2F202608040226456a714de5e98ac.webp&w=3840&q=75)

MIO GEAR S₱ 81,900.00

![LEXI 155](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Flexi%2F202602200510146997ecb673975.webp&w=3840&q=75)

LEXI 155₱ 99,900.00

![AEROX](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Faerox%2F2025080609244268931f5a7774b.webp&w=3840&q=75)

AEROX₱ 133,900.00

![NMAX TECH MAX](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Fnmax-tech-max%2F2026022010484269983c0a5f4c9.webp&w=3840&q=75)

NMAX TECH MAX₱ 178,400.00

![MIO GRAVIS](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Fmio-gravis%2F20250801010235688c122bdfde0.webp&w=3840&q=75)

MIO GRAVIS₱ 84,900.00

![SNIPER155](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Fsniper155%2F20250801021124688c224c8622f.webp&w=3840&q=75)

SNIPER155₱ 125,900.00

![PG-1](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Fpg-1%2F20260220101401699833e99079a.webp&w=3840&q=75)

PG-1₱ 92,900.00

![MIO FAZZIO](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Fmio-fazzio%2F202607010825036a44cedf5abbf.webp&w=3840&q=75)

MIO FAZZIO₱ 93,900.00

![YZF-R1M](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Fyzf-r1m%2F20250731172841688ba7c90810f.webp&w=3840&q=75)

YZF-R1M₱ 1,799,000.00

![TMAX TECH MAX](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Ftmax-tech-max%2F2025090206540668b6948e95c46.webp&w=3840&q=75)

TMAX TECH MAX₱ 859,000.00

![XSR900](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Fxsr900%2F20250719090900687b60ac917b5.webp&w=3840&q=75)

XSR900₱ 729,000.00

![XSR700](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Fxsr700%2F20250731074532688b1f1c48819.webp&w=3840&q=75)

XSR700₱ 489,000.00

![TÉNÉRÉ 700](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Ftenere-700%2F20250731001552688ab5b8c363a.webp&w=3840&q=75)

TÉNÉRÉ 700₱ 699,000.00

# Mio Fazzio

[See pricing now![Arrow Icon](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/Icon.png)](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#pricing-section)

![Hero background](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicles%2Fmio-fazzio%2F202607010824336a44cec16b7a0.webp&w=3840&q=75)

Mio Fazzio

[See pricing now![Arrow Icon](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/Icon.png)](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#pricing-section)

![Hero background](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicle-banners-mobile%2F202607010822316a44ce4736885.webp&w=3840&q=75)

![Hero Background](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/VIS/product_page_background_1.webp)

## Featured specs

![Side Mirror](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/features/2026041006492969d89d79a6f51.webp)

1 of 9

Side Mirror

USB Power Socket

Double Seat

New Graphics

Underseat Storage

Description

The side mirror has been redesigned for better rearward visibility.

![Hero Background](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/VIS/product_page_background_mobile_1.webp)

Featured specs

![Side Mirror](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/features/2026041006492969d89d79a6f51.webp)

selected featured spec

1 of 9

Side Mirror

USB Power Socket

Double Seat

New Graphics

Underseat Storage

Blue Core Hybrid

Headlight / Taillight

Spacious Footboard

More Power for Less Fuel.

The side mirror has been redesigned for better rearward visibility.

![Hero Background](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/VIS/product_page_background_2.webp)

![Logo](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/vehicles/mio-fazzio/variant-logo/2025102701125268fec71476fdd.webp)

₱93,900

Suggested Retail price

Color : LIGHT GREEN

[find a dealer![Hero Background](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/Icon.png)](https://find-dealer.yamaha-motor.com.ph/)

![](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/vehicles/mio-fazzio/color-variation/2026041006500069d89d9871d47.webp)

![Spec 1](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/vehicles/mio-fazzio/vehicle-features/2024120604104767527947dd5e3.webp)

![](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/production/vehicles/mio-fazzio/gallery/202607010825356a44ceffd1538.webp)

![](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/production/vehicles/mio-fazzio/gallery/202607010825376a44cf01a8b90.webp)

![](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/production/vehicles/mio-fazzio/gallery/202607010825396a44cf0360f65.webp)

![](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/production/vehicles/mio-fazzio/gallery/202607010825416a44cf05f0ada.webp)

![Logo](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/vehicles/mio-fazzio/variant-logo/2025102701125268fec71476fdd.webp)

![LIGHT GREEN - 1](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/vehicles/mio-fazzio/color-variation/2026041006500069d89d9871d47.webp)

![Spec 1](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/vehicles/mio-fazzio/vehicle-features/2024120604104767527947dd5e3.webp)

![Hero Background](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/VIS/product_page_background_mobile_2.webp)

P93,900

Suggested Retail price

Color :LIGHT GREEN

[find a dealer![Hero Background](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/Icon.png)](https://find-dealer.yamaha-motor.com.ph/)

![LIGHT GREEN - 2](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/production/vehicles/mio-fazzio/gallery/202607010825356a44ceffd1538.webp)

![LIGHT GREEN - 3](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/production/vehicles/mio-fazzio/gallery/202607010825376a44cf01a8b90.webp)

![LIGHT GREEN - 4](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/production/vehicles/mio-fazzio/gallery/202607010825396a44cf0360f65.webp)

![LIGHT GREEN - 5](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/production/vehicles/mio-fazzio/gallery/202607010825416a44cf05f0ada.webp)

#### Spec breakdown

ENGINE

ENGINE TYPE

Air cooled, 4-stroke, SOHC, 2 Valve

CYLINDER ARRANGEMENT

Single Cylinder

DISPLACEMENT

125 cm³

BORE & STROKE

52.4×57.9mm

COMPRESSION RATIO

11.0:1

MAXIMUM HORSE POWER

6.2kW(8.4PS)/6500r/min

MAXIMUM TORQUE

9.9N・m(1.0kgf・m)/5000r/min

MAXIMUM HORSE POWER(WHEN ASSIST IS ACTIVATED)

6.2kW(8.4PS)/6500r/min

MAXIMUM TORQUE (WHEN ASSIST IS ACTIVATED)

10.6N・m(1.1kgf・m)/4500r/min

STARTING SYSTEM

Electric Starter

LUBRICATION SYSTEM

Wet sump

ENGINE OIL CAPACITY

0.84L

FUEL SUPPLY SYSTEM

Fuel injection

CLUTCH TYPE

Dry, Centrifugal, Shoe

TRANSMISSION TYPE

V-Belt Automatic

CHASSIS

FRAME TYPE

Underbone

FRONT SUSPENSION

Telescopic Fork

REAR SUSPENSION

Unit Swing

FRONT TIRE

110/70-12 47L Tubeless

REAR TIRE

110/70-12 47L Tubeless

FRONT BRAKE

Hydraulic Single Disc Brake

REAR BRAKE

Mechanical Leading Trailing Drum Brake

ELECTRICAL

IGNITION SYSTEM TYPE

TCI (Transistor Controlled Ignition)

BATTERY

YTZ6V, 12V, 5.0Ah (10HR)

HEADLIGHT

LED

TAIL LIGHT

12V, 18/5W x 1

DIMENSION

OVERALL LENGTH X WIDTH X HEIGHT

1820mm x 685mm x 1125mm

SEAT HEIGHT

750mm

WHEELBASE

1280mm

MINIMUM GROUND CLEARANCE

135mm

CURB WEIGHT (WITH OIL AND FULL FUEL TANK)

95kg

FUEL TANK CAPACITY

5.1L

STANDARD EQUIPMENT

METER PANEL

Digital

![Specification](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fvehicle-banners-mobile%2F202607010822316a44ce4736885.webp&w=3840&q=75)

Spec breakdown

ENGINE

ENGINE TYPE

Air cooled, 4-stroke, SOHC, 2 Valve

CYLINDER ARRANGEMENT

Single Cylinder

DISPLACEMENT

125 cm³

BORE & STROKE

52.4×57.9mm

COMPRESSION RATIO

11.0:1

MAXIMUM HORSE POWER

6.2kW(8.4PS)/6500r/min

MAXIMUM TORQUE

9.9N・m(1.0kgf・m)/5000r/min

MAXIMUM HORSE POWER(WHEN ASSIST IS ACTIVATED)

6.2kW(8.4PS)/6500r/min

MAXIMUM TORQUE (WHEN ASSIST IS ACTIVATED)

10.6N・m(1.1kgf・m)/4500r/min

STARTING SYSTEM

Electric Starter

LUBRICATION SYSTEM

Wet sump

ENGINE OIL CAPACITY

0.84L

FUEL SUPPLY SYSTEM

Fuel injection

CLUTCH TYPE

Dry, Centrifugal, Shoe

TRANSMISSION TYPE

V-Belt Automatic

CHASSIS

FRAME TYPE

Underbone

FRONT SUSPENSION

Telescopic Fork

REAR SUSPENSION

Unit Swing

FRONT TIRE

110/70-12 47L Tubeless

REAR TIRE

110/70-12 47L Tubeless

FRONT BRAKE

Hydraulic Single Disc Brake

REAR BRAKE

Mechanical Leading Trailing Drum Brake

ELECTRICAL

IGNITION SYSTEM TYPE

TCI (Transistor Controlled Ignition)

BATTERY

YTZ6V, 12V, 5.0Ah (10HR)

HEADLIGHT

LED

TAIL LIGHT

12V, 18/5W x 1

DIMENSION

OVERALL LENGTH X WIDTH X HEIGHT

1820mm x 685mm x 1125mm

SEAT HEIGHT

750mm

WHEELBASE

1280mm

MINIMUM GROUND CLEARANCE

135mm

CURB WEIGHT (WITH OIL AND FULL FUEL TANK)

95kg

FUEL TANK CAPACITY

5.1L

STANDARD EQUIPMENT

METER PANEL

Digital

![Hero Background](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/VIS/product_page_background_3.webp)

Explore More Models

![PG-1](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/vehicles/pg-1/20260220101401699833e99079a.webp)

### PG-1

![MIO GRAVIS](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/vehicles/mio-gravis/20250801010235688c122bdfde0.webp)

### MIO GRAVIS

![MIO i125](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/vehicles/mio-i125/2026041008323369d8b5a151f31.webp)

### MIO i125

![Hero Background](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/VIS/product_page_background_mobile_3.webp)

Explore More Models

![PG-1](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/vehicles/pg-1/20260220101401699833e99079a.webp)

PG-1

![MIO GRAVIS](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/vehicles/mio-gravis/20250801010235688c122bdfde0.webp)

MIO GRAVIS

![MIO i125](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/vehicles/mio-i125/2026041008323369d8b5a151f31.webp)

MIO i125

![Hero Background](https://yamaha-storage.s3.ap-southeast-1.amazonaws.com/production/other-images/VIS/footer_homepage.webp)

Stay Connected

Be the first to hear about Yamaha news, rides, and special offers.

email

SUBSCRIBE

Personal Commuter

Mio

- MIO GEAR S
- MIO GRAVIS
- MIO FAZZIO
- MIO i125

LEXI

- LEXI 155

Max

- NMAX TECH MAX
- XMAX

On Road

- AEROX
- SNIPER155
- YZF-R15M
- YZF-R3

STREET

- MT-15
- XSR 155
- MT-03

Outdoor

- PG-1

Off Road

- XTZ125
- WR155R
- SEROW 250

Business

- YTX125

Sport Machines

SUPERSPORT

- YZF-R1M
- YZF-R7
- YZF-R9

HYPERNAKED

- MT-07
- MT-09 SP
- MT-10 SP

SPORT HERITAGE

- XSR900
- XSR700
- BOLT R-SPEC

SPORT SCOOTER

- TMAX TECH MAX

SPORT TOURING

- TRACER 9 GT

ADVENTURE

- TÉNÉRÉ 700
- SUPER TÉNÉRÉ ES

### The Company

- [About Yamaha](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#)
- [Yamaha Handling](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#)
- [Privacy Policy](https://www.yamaha-motor.com.ph/privacy-policy)
- [Cookie Policy](https://www.yamaha-motor.com.ph/cookie-policy)

### Other Platforms

- [Find Dealer](https://find-dealer.yamaha-motor.com.ph/)
- [My Yamaha Motor Rev PH](https://www.yamaha-motor.com.ph/my-yamaha-rev-ph)
- [Spare Parts & Accessories](https://aftersales.yamaha-motor.com.ph/)
- [YClub Philippines](https://yclub.yamaha-motor.com.ph/)
- [Yamaha Racing Philippines](https://www.yamaha-motor.com.ph/yamaha-racing)

### Support

- [Service Shops](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#)
- [Service Warranty](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#)

### Yamaha Service

- [Service & Maintenance](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#)
- [Yamaha Technical Academy](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#)

![Yamaha Racing Logo](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fother-images%2Fracing-logo.PNG&w=3840&q=75)

![Yamaha SPA Logo](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fother-images%2Fspa-logo.png&w=3840&q=75)

![Yamaha Club Logo](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fother-images%2Fyclub-logo.PNG&w=3840&q=75)

![My Yamaha Logo](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fother-images%2Fmy-yamaha-logo.PNG&w=3840&q=75)

![Yamaha Riders Academy Logo](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fother-images%2Fyra-logo.PNG&w=3840&q=75)

2025 yamaha motor philippines inc.

![Yamaha news background](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fother-images%2FVIS%2Ffooter_homepage_mobile.webp&w=3840&q=75)

Stay Connected

Be the first to hear about Yamaha news, rides, and special offers.

email

SUBSCRIBE

Personal Commuter

Mio

- MIO GEAR S
- MIO GRAVIS
- MIO FAZZIO
- MIO i125

LEXI

- LEXI 155

Max

- NMAX TECH MAX
- XMAX

On Road

- AEROX
- SNIPER155
- YZF-R15M
- YZF-R3

STREET

- MT-15
- XSR 155
- MT-03

Outdoor

- PG-1

Off Road

- XTZ125
- WR155R
- SEROW 250

Business

- YTX125

Sport Machines

SUPERSPORT

- YZF-R1M
- YZF-R7
- YZF-R9

HYPERNAKED

- MT-07
- MT-09 SP
- MT-10 SP

SPORT HERITAGE

- XSR900
- XSR700
- BOLT R-SPEC

SPORT SCOOTER

- TMAX TECH MAX

SPORT TOURING

- TRACER 9 GT

ADVENTURE

- TÉNÉRÉ 700
- SUPER TÉNÉRÉ ES

The Company

- [About Yamaha](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#)
- [Yamaha Handling](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#)
- [Privacy Policy](https://www.yamaha-motor.com.ph/privacy-policy)
- [Cookie Policy](https://www.yamaha-motor.com.ph/cookie-policy)

Other Platforms

- [Find Dealer](https://find-dealer.yamaha-motor.com.ph/)
- [My Yamaha Motor Rev PH](https://www.yamaha-motor.com.ph/my-yamaha-rev-ph)
- [Spare Parts & Accessories](https://aftersales.yamaha-motor.com.ph/)
- [YClub Philippines](https://yclub.yamaha-motor.com.ph/)
- [Yamaha Racing Philippines](https://www.yamaha-motor.com.ph/yamaha-racing)

Support

- [Service Shops](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#)
- [Service Warranty](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#)

Yamaha Service

- [Service & Maintenance](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#)
- [Yamaha Technical Academy](https://www.yamaha-motor.com.ph/motorcycles/personal-commuter/mio-series/mio-fazzio#)

![](data:image/svg+xml,%3csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20version=%271.1%27%20width=%27100%27%20height=%27100%27/%3e)![Yamaha Racing Logo](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fother-images%2Fracing-logo.PNG&w=256&q=75)

![](data:image/svg+xml,%3csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20version=%271.1%27%20width=%27100%27%20height=%27100%27/%3e)![Yamaha SPA Logo](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fother-images%2Fspa-logo.png&w=256&q=75)

![](data:image/svg+xml,%3csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20version=%271.1%27%20width=%27100%27%20height=%27100%27/%3e)![Yamaha Club Logo](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fother-images%2Fyclub-logo.PNG&w=256&q=75)

![](data:image/svg+xml,%3csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20version=%271.1%27%20width=%27100%27%20height=%27100%27/%3e)![My Yamaha Logo](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fother-images%2Fmy-yamaha-logo.PNG&w=256&q=75)

![](data:image/svg+xml,%3csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20version=%271.1%27%20width=%27100%27%20height=%27100%27/%3e)![Yamaha Riders Academy Logo](https://www.yamaha-motor.com.ph/_next/image?url=https%3A%2F%2Fyamaha-storage.s3.ap-southeast-1.amazonaws.com%2Fproduction%2Fother-images%2Fyra-logo.PNG&w=256&q=75)

yamaha motor philippines inc

This website uses cookies