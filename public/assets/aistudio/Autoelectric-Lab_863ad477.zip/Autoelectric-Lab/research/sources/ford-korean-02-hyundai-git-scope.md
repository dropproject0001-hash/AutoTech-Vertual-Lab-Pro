Source: https://support.gitauto.com/hc/en-gb/articles/4403345307929--HYUNDAI-GDS-Smart-User-Manual
Title: [HYUNDAI] GDS-Smart User Manual – GIT FAQ | Asia/Pacific, Europe, Africa, Middle East
Fetched: 2026-11-11T10:06:04.062Z

[Skip to main content](https://support.gitauto.com/hc/en-gb/articles/4403345307929--HYUNDAI-GDS-Smart-User-Manual#main-content)

NEW **New Dedicated KIA Support Portal** Are you a KIA customer?

[Go to KIA Support Portal →](https://support-kia.gitauto.com/hc/en-001)

DEDICATED SUPPORT PORTAL

## New Dedicated KIA Support Portal

A dedicated support portal for KIA vehicles and diagnostic solutions is now live. Please use the new portal for all KIA-related support.

KDS 2.0 · VCI 3 · EV

support-kia.gitauto.com

[Go to KIA Support ↗](https://support-kia.gitauto.com/hc/en-001)
Continue with Hyundai/Genesis


Don't show this again today

Download User Manual zip file as your language with the below.

\\* **English** : [HME\_ENG.zip](https://support.gitauto.com/hc/article_attachments/4411462480537)

\\* **Deutsch** : [HME\_DEU.zip](https://support.gitauto.com/hc/article_attachments/4411455858073)

\\* **Français** : [HME\_FRA.zip](https://support.gitauto.com/hc/article_attachments/4411455861913)

\\* **español** : [HME\_SPA.zip](https://support.gitauto.com/hc/article_attachments/4411462466457)

\\* **русский язык** : [HME\_RUS.zip](https://support.gitauto.com/hc/article_attachments/4411449754905)

\\* **Português** : [HME\_POR.zip](https://support.gitauto.com/hc/article_attachments/4411455863065)

\\* **Italiano** : [HME\_ITA.zip](https://support.gitauto.com/hc/article_attachments/4411462464921)

\\* **Čeština** : [HME\_CZE.zip](https://support.gitauto.com/hc/article_attachments/4411449749529)

Here is the English User Manual in detail.

**Please select the feature you want to see.**

\-\-\------------------------------------------------------------------------------------------------------------------

[BasicOperation](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/BasicOperation.pdf) [ModuleConnection](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/ModuleConnection.pdf)[DigitalFieldFix](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/DigitalFieldFix.pdf)[SmartDiagnosis](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/SmartDiagnosis.pdf)

[Tool Box](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/ToolBox.pdf) [Fault Code Searching](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/DTCAnalysis.pdf)[DataAnlysis](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/DataAnlysis.pdf)[MultiDataAnlysis](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/MultiDataAnlysis.pdf)

[ActuationTest](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/ActuationTest.pdf)[SWManagement](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/SWManagement.pdf)[SystemIdentificatio](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/SystemIdentification.pdf) [ECU Upgrade](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/ECUUpgrade.pdf)

[OBD-II](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/OBD-II.pdf) [Hardware](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/Hardware.pdf) [Measurement](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/Measurement.pdf) [RecordedData](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/RecordedData.pdf)

\-\-\------------------------------------------------------------------------------------------------------------------

[BasicOperation](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/BasicOperation.pdf)

: This section provides description on basic operation.

[ModuleConnection](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/ModuleConnection.pdf)

: Explanation of the VCI II, GDS VCI, TPMS module connection (pairing).

[SmartDiagnosis](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/SmartDiagnosis.pdf)

: This function provides comprehensive diagnosis results on the selected vehicle’s system.

You can check various functions such as the presence/non-presence of fault codes, ECU upgrade target status and ECU mapping check, etc. at once.

[Tool Box](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/ToolBox.pdf)

: In Expert’s Diagnosis, the user can use diagnosis function, special function and utility function provided by GDS-Smart.

[Fault Code Searching](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/DTCAnalysis.pdf)

: It searches fault code(s) of one or multiple number of systems mounted on the vehicle. The users can check detailed information related to fault codes that are searched, as well as maintenance information.

[SmartDiagnosis](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/SmartDiagnosis.pdf)

: This function provides comprehensive diagnosis results on the selected vehicle’s system.

You can check various functions such as the presence/non-presence of fault codes, ECU upgrade target status and ECU mapping check, etc. at once.

[DataAnlysis](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/DataAnlysis.pdf)

: This function allows various types of control modules mounted on the vehicle to confirm the parameter values, which control the sensor’s signal input and movement of actuators, through vehicle communication.

[MultiDataAnlysis](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/MultiDataAnlysis.pdf)

: This function is similar to Sensor Data Diagnosis, which supports the analysis of each sensor item of multiple controllers mounted on the vehicle on a single screen at the same time.

\\* It only supports modules that support CAN communication protocol.

[ECU Upgrade](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/ECUUpgrade.pdf)

: The purpose of this function is to upgrade data on the ECU(electronic control unit ) to improve the vehicle performance or correct a known issue.

[ActuationTest](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/ActuationTest.pdf)

: This is a function of performing forced self-driving and stopping various actuators installed on vehicles through a control module, which can inspect the normal driving status of parts.

[SWManagement](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/SWManagement.pdf)

: This supports functions such as additional settings after vehicle repair, test or initialization, etc.

The supported items are varied depending on vehicle type, and caution should be paid for vehicle condition.

[SystemIdentification](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/SystemIdentification.pdf)

: It shows specification information of the controller (part number, H/W, S/W, etc.) mounted on the vehicle.

[OBD-II](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/OBD-II.pdf)

:  OBD-II mode is used to display generic vehicle powertrain diagnostic data. The vehicle communication protocol is automatically determined when OBD-II mode is selected.

[DigitalFieldFix](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/DigitalFieldFix.pdf)

: This provides a function of checking the controller prior to repair of the vehicle or operation status of the vehicle parts. Supported items vary depending on the selected vehicle, and attention shall be paid to the vehicle conditions.

#### [Measurement](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/Measurement.pdf)

: This function uses VMI prediction module to measure the actual

waveform of the sensor and actuator, and uses simulation function to

diagnose the vehicle.

[RecordedData](http://gsup.gitauto.com/GDSN/GDSNif/support/usermanaul/HME-PA/ENG/RecordedData.pdf)

: You can view the data saved in tablet PC, and also copy the driving data

saved in VCI II.

- [HME\_DEU.zip](https://support.gitauto.com/hc/en-gb/article_attachments/4411455858073)
10 MB [Download](https://support.gitauto.com/hc/en-gb/article_attachments/4411455858073)

- [HME\_CZE.zip](https://support.gitauto.com/hc/en-gb/article_attachments/4411449749529)
10 MB [Download](https://support.gitauto.com/hc/en-gb/article_attachments/4411449749529)

- [HME\_FRA.zip](https://support.gitauto.com/hc/en-gb/article_attachments/4411455861913)
9 MB [Download](https://support.gitauto.com/hc/en-gb/article_attachments/4411455861913)

- [HME\_ITA.zip](https://support.gitauto.com/hc/en-gb/article_attachments/4411462464921)
9 MB [Download](https://support.gitauto.com/hc/en-gb/article_attachments/4411462464921)

- [HME\_POR.zip](https://support.gitauto.com/hc/en-gb/article_attachments/4411455863065)
9 MB [Download](https://support.gitauto.com/hc/en-gb/article_attachments/4411455863065)

- [HME\_RUS.zip](https://support.gitauto.com/hc/en-gb/article_attachments/4411449754905)
8 MB [Download](https://support.gitauto.com/hc/en-gb/article_attachments/4411449754905)

- [HME\_SPA.zip](https://support.gitauto.com/hc/en-gb/article_attachments/4411462466457)
8 MB [Download](https://support.gitauto.com/hc/en-gb/article_attachments/4411462466457)

- [HME\_ENG.zip](https://support.gitauto.com/hc/en-gb/article_attachments/4411462480537)
20 MB [Download](https://support.gitauto.com/hc/en-gb/article_attachments/4411462480537)


## Related articles

- [\[Hyundai\] GDS Smart Install Guide](https://support.gitauto.com/hc/en-gb/related/click?data=BAh7CjobZGVzdGluYXRpb25fYXJ0aWNsZV9pZGwrCJVWOdVTADoYcmVmZXJyZXJfYXJ0aWNsZV9pZGwrCBk51TsBBDoLbG9jYWxlSSIKZW4tZ2IGOgZFVDoIdXJsSSJFL2hjL2VuLWdiL2FydGljbGVzLzM2MDA1OTU5MDI5My0tSHl1bmRhaS1HRFMtU21hcnQtSW5zdGFsbC1HdWlkZQY7CFQ6CXJhbmtpBg%3D%3D--7f1e90a858c8d7922def8ebb4d90fd731a983c57)
- [How to install GDS Smart/KDS2.0 on a tablet PC.(2023.Feb.22)](https://support.gitauto.com/hc/en-gb/related/click?data=BAh7CjobZGVzdGluYXRpb25fYXJ0aWNsZV9pZGwrCJnNML9hDjoYcmVmZXJyZXJfYXJ0aWNsZV9pZGwrCBk51TsBBDoLbG9jYWxlSSIKZW4tZ2IGOgZFVDoIdXJsSSJhL2hjL2VuLWdiL2FydGljbGVzLzE1ODEyOTgyMjYzMTkzLUhvdy10by1pbnN0YWxsLUdEUy1TbWFydC1LRFMyLTAtb24tYS10YWJsZXQtUEMtMjAyMy1GZWItMjIGOwhUOglyYW5raQc%3D--59d986551df06fb402d85885c0888cd7ac4264e1)
- [Tablet PC specification for GDS Smart, GENESIS Smart, KDS 2.0 Including Noise Inspection](https://support.gitauto.com/hc/en-gb/related/click?data=BAh7CjobZGVzdGluYXRpb25fYXJ0aWNsZV9pZGwrCK3oa9VTADoYcmVmZXJyZXJfYXJ0aWNsZV9pZGwrCBk51TsBBDoLbG9jYWxlSSIKZW4tZ2IGOgZFVDoIdXJsSSJ7L2hjL2VuLWdiL2FydGljbGVzLzM2MDA2MjkwNDQ5My1UYWJsZXQtUEMtc3BlY2lmaWNhdGlvbi1mb3ItR0RTLVNtYXJ0LUdFTkVTSVMtU21hcnQtS0RTLTItMC1JbmNsdWRpbmctTm9pc2UtSW5zcGVjdGlvbgY7CFQ6CXJhbmtpCA%3D%3D--97e27feb80f14be5a0c99302ce2f864ddc27e929)
- [\[KIA\] KDS 2.0 Install Guide](https://support.gitauto.com/hc/en-gb/related/click?data=BAh7CjobZGVzdGluYXRpb25fYXJ0aWNsZV9pZGwrCM%2FSjozRADoYcmVmZXJyZXJfYXJ0aWNsZV9pZGwrCBk51TsBBDoLbG9jYWxlSSIKZW4tZ2IGOgZFVDoIdXJsSSI%2FL2hjL2VuLWdiL2FydGljbGVzLzkwMDAwNjMzNTE4My0tS0lBLUtEUy0yLTAtSW5zdGFsbC1HdWlkZQY7CFQ6CXJhbmtpCQ%3D%3D--c3d0e40a56d75c3238c17a58c683714db917adb3)
- [How to reinstall GDS Smart/KDS 2.0](https://support.gitauto.com/hc/en-gb/related/click?data=BAh7CjobZGVzdGluYXRpb25fYXJ0aWNsZV9pZGwrCIaoeIzRADoYcmVmZXJyZXJfYXJ0aWNsZV9pZGwrCBk51TsBBDoLbG9jYWxlSSIKZW4tZ2IGOgZFVDoIdXJsSSJHL2hjL2VuLWdiL2FydGljbGVzLzkwMDAwNDg4MjU2Ni1Ib3ctdG8tcmVpbnN0YWxsLUdEUy1TbWFydC1LRFMtMi0wBjsIVDoJcmFua2kK--0475bff5c9b2c221693b9a932afd910de5c6136f)

Article is closed for comments.

Hi there! You can quickly find answers to your questions or submit an inquiry here.

AI Quick Questions

AI Quick Questions

Summarize this articleKey steps & guidelinesCommon FAQs for this

GDPR · ePrivacy · TDDDG · PIPA

## Cookie Preference Center

Under EU GDPR and global privacy standards, all non-essential cookies are disabled (OFF) by default prior to your explicit consent. You can customize your preferences by category below and withdraw consent at any time. [View Full Terms in New Tab](https://support.gitauto.com/hc/en-gb/articles/63471965237913)

**1\. Strictly Necessary Cookies** Always Active (Essential)

Essential for Help Center security (CSRF/bot protection), login sessions, saving your cookie consent state, and operating the bottom-right AI Chatbot for FAQ search. These cannot be disabled.

`_help_center_session, _zendesk_shared_session, git_cookie_consent_v1, zE_oauth, zd-widget-storage (AI Chatbot FAQ Search)`

**2\. Functional & Preference Cookies**

Remembers UI preferences such as dark/light theme mode, dismissed emergency notices, and profile completion prompts.

`kia-illumination-mode, hc_locale_pref, app_variant`

**3\. Analytics & Performance Cookies**

Uses Google Analytics 4 (GA4) to measure visitor traffic and FAQ search effectiveness so we can improve Help Center documentation. Blocked completely prior to consent (Basic Mode).

`_ga, _ga_BZF8WLENGQ, _ga_F0K31RHM56 (Hostname-Isolated, IP Anonymized)`

Reject Non-EssentialSave PreferencesAccept All