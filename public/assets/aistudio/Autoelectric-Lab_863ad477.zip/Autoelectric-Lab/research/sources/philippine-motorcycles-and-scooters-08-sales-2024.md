Source: https://mb.com.ph/2025/3/3/philippine-motorcycle-sales-surge-7-in-2024
Title: Manila Bulletin - Philippine motorcycle sales surge 7% in 2024
Fetched: 2026-11-11T12:56:02.486Z

ADVERTISEMENT

![Logo](https://mb.com.ph/manilabulletin/uploads/global_files/mb-close.svg)

![Logo](https://mb.com.ph/manilabulletin/uploads/global_files/logo-manila-b.jpg)

![Search](https://mb.com.ph/manilabulletin/uploads/global_files/mb-search.svg)

Press Escape to quit searching

### [Drive](https://mb.com.ph/category/drive)

# Philippine motorcycle sales surge 7% in 2024

Highest growth in ASEAN region

##### By [Ian D. Magbanua](https://mb.com.ph/author/ian-d-magbanua)

Published Mar 3, 2025 02:09 am

![Copy Link](https://mb.com.ph/manilabulletin/uploads/global_files/share-arrow.svg)[![X](https://mb.com.ph/manilabulletin/uploads/global_files/share-x.svg)](https://x.com/intent/tweet?url=https://mb.com.ph/2025/3/3/philippine-motorcycle-sales-surge-7-in-2024)[![Facebook](https://mb.com.ph/manilabulletin/uploads/global_files/share-facebook.svg)](https://www.facebook.com/sharer/sharer.php?u=https://mb.com.ph/2025/3/3/philippine-motorcycle-sales-surge-7-in-2024)[![Whatsapp](https://mb.com.ph/manilabulletin/uploads/global_files/share-whatsapp.svg)](viber://forward?text=https://mb.com.ph/2025/3/3/philippine-motorcycle-sales-surge-7-in-2024)

![020525SuzukiMotorcycles1.jpg](https://mb.com.ph/uploads/imported_images/020525_Suzuki_Motorcycles1_ef6e44f7ee.jpg)

The Motorcycle Development Program Participants Association, Inc. (MDPPA), which represents major motorcycle manufacturers including Honda, Kawasaki, Suzuki, Yamaha, and its newest member, TVS Philippines, has reported a 7% increase in motorcycle sales for 2024. This growth represents the highest rate in the ASEAN region for the year.

**Record-breaking sales figures**

![012825HondaGiorno1.jpg](https://mb.com.ph/uploads/imported_images/012825_Honda_Giorno1_e43102b471.jpg)Automatic motorcycles, like the Honda Giorno+ continue to be the leading segment.

MDPPA members achieved a total of 1,682,482 wholesale sales in 2024, marking the highest figure in the past five years. This is a significant rise from the 1,577,597 units sold in 2023. In comparison, sales in 2022 and 2021 were 1,564,827 and 1,435,677 units, respectively. Prior to the pandemic in 2020, total sales were around 1.2 million units, while the highest recorded sales occurred in 2019, with 1.7 million units sold. MDPPA President, Alex Cumpas, emphasized the importance of the 7% growth, especially in light of the modest 2% increases seen in Indonesia and Malaysia. “Despite ongoing challenges in the industry, MDPPA is pleased to share that the 7% growth achieved in 2024 is the highest among our ASEAN neighbors. We are hopeful that the golden years of 2019, when we recorded sales of 1.7 million units, could be surpassed this year in 2025,” Cumpas said.

**Factors driving growth**

![030325MDPPA1.jpg](https://mb.com.ph/uploads/imported_images/030325_MDPPA_1_2607964fda.jpg)

MDPPA's optimistic outlook for 2025 is fueled by several key factors, including the upcoming national election, favorable economic conditions, and legislative support for the motorcycle industry. As a result, the association forecasts an additional 5% growth for 2025. In terms of market segments, automatic motorcycles continue to dominate sales, accounting for 64% of total units sold. Business Unit (BU) motorcycles represent 17%, while mopeds make up 16.3%. The remaining 2.7% is shared between street bikes and big bikes.

**Focus on safety and responsibility**

![030325MDPPA2.jpg](https://mb.com.ph/uploads/imported_images/030325_MDPPA_2_184a4b3427.jpg)

Beyond sales growth, MDPPA is committed to its “Tropang MAALAM” campaign, which promotes responsible riding, road safety, and proper motorcycle maintenance. Through educational initiatives and awareness campaigns, this program seeks to equip riders with the skills and knowledge necessary for safer road use. “The motorcycle industry has shown remarkable resilience, and as we move into 2025, we are focused on ensuring that safety, innovation, and sustainability remain at the forefront of our efforts,” Cumpas stated. “We believe that with continued support from both the industry and the government, we can surpass our 2019 sales figures and create a safer, smarter future for all riders.”

With the industry well-positioned for continued expansion, MDPPA is dedicated to promoting growth while prioritizing the safety and well-being of the increasing number of motorcycle riders in the Philippines.

### Related Tags

[motorcycles](https://mb.com.ph/tag/motorcycles "motorcycles")

ADVERTISEMENT

## Latest Stories

[![Manila Bulletin](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145877.webp)](https://mb.com.ph/2026/11/11/sms-tessie-sy-coson-uses-tiktok-to-spot-trends-heres-her-top-tip-for-small-businesses "SM's Tessie Sy-Coson uses TikTok to spot trends — Here's her top tip for small businesses")

[**SM's Tessie Sy-Coson uses TikTok to spot trends — Here's her top tip for small businesses**](https://mb.com.ph/2026/11/11/sms-tessie-sy-coson-uses-tiktok-to-spot-trends-heres-her-top-tip-for-small-businesses "SM's Tessie Sy-Coson uses TikTok to spot trends — Here's her top tip for small businesses")

[![Manila Bulletin](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145871.webp)](https://mb.com.ph/2026/11/11/pnp-press-corps-holds-inaugural-medical-mission-for-media-practitioners "PNP Press Corps holds inaugural medical mission for media practitioners")

[**PNP Press Corps holds inaugural medical mission for media practitioners**](https://mb.com.ph/2026/11/11/pnp-press-corps-holds-inaugural-medical-mission-for-media-practitioners "PNP Press Corps holds inaugural medical mission for media practitioners")

[![no-image](https://mb.com.ph/manilabulletin/uploads/global_files/no-image.jpg)](https://mb.com.ph/2026/11/11/adamson-stays-in-final-four-hunt-with-big-win-over-ateneo "Adamson stays in Final Four hunt with big win over Ateneo")

[**Adamson stays in Final Four hunt with big win over Ateneo**](https://mb.com.ph/2026/11/11/adamson-stays-in-final-four-hunt-with-big-win-over-ateneo "Adamson stays in Final Four hunt with big win over Ateneo")

[![Manila Bulletin](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145870.webp)](https://mb.com.ph/2026/11/11/us-rate-hike-fears-push-psei-down-as-losses-erase-recent-gains "US rate hike fears push PSEi down as losses erase recent gains")

[**US rate hike fears push PSEi down as losses erase recent gains**](https://mb.com.ph/2026/11/11/us-rate-hike-fears-push-psei-down-as-losses-erase-recent-gains "US rate hike fears push PSEi down as losses erase recent gains")

[![Manila Bulletin](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145869.webp)](https://mb.com.ph/2026/11/11/quimbo-bill-seeks-p3000-monthly-pay-p1000-hazard-allowance-for-barangay-health-workers "Quimbo bill seeks P3,000 monthly pay, P1,000 hazard allowance for barangay health workers")

[**Quimbo bill seeks P3,000 monthly pay, P1,000 hazard allowance for barangay health workers**](https://mb.com.ph/2026/11/11/quimbo-bill-seeks-p3000-monthly-pay-p1000-hazard-allowance-for-barangay-health-workers "Quimbo bill seeks P3,000 monthly pay, P1,000 hazard allowance for barangay health workers")

## Recommended For You

[![Manila Bulletin](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145877.webp)](https://mb.com.ph/2026/11/11/sms-tessie-sy-coson-uses-tiktok-to-spot-trends-heres-her-top-tip-for-small-businesses "SM's Tessie Sy-Coson uses TikTok to spot trends — Here's her top tip for small businesses")

[**SM's Tessie Sy-Coson uses TikTok to spot trends — Here's her top tip for small businesses**](https://mb.com.ph/2026/11/11/sms-tessie-sy-coson-uses-tiktok-to-spot-trends-heres-her-top-tip-for-small-businesses "SM's Tessie Sy-Coson uses TikTok to spot trends — Here's her top tip for small businesses")

[![Manila Bulletin](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145871.webp)](https://mb.com.ph/2026/11/11/pnp-press-corps-holds-inaugural-medical-mission-for-media-practitioners "PNP Press Corps holds inaugural medical mission for media practitioners")

[**PNP Press Corps holds inaugural medical mission for media practitioners**](https://mb.com.ph/2026/11/11/pnp-press-corps-holds-inaugural-medical-mission-for-media-practitioners "PNP Press Corps holds inaugural medical mission for media practitioners")

[![no-image](https://mb.com.ph/manilabulletin/uploads/global_files/no-image.jpg)](https://mb.com.ph/2026/11/11/adamson-stays-in-final-four-hunt-with-big-win-over-ateneo "Adamson stays in Final Four hunt with big win over Ateneo")

[**Adamson stays in Final Four hunt with big win over Ateneo**](https://mb.com.ph/2026/11/11/adamson-stays-in-final-four-hunt-with-big-win-over-ateneo "Adamson stays in Final Four hunt with big win over Ateneo")

[![Manila Bulletin](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145870.webp)](https://mb.com.ph/2026/11/11/us-rate-hike-fears-push-psei-down-as-losses-erase-recent-gains "US rate hike fears push PSEi down as losses erase recent gains")

[**US rate hike fears push PSEi down as losses erase recent gains**](https://mb.com.ph/2026/11/11/us-rate-hike-fears-push-psei-down-as-losses-erase-recent-gains "US rate hike fears push PSEi down as losses erase recent gains")

[![Manila Bulletin](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145869.webp)](https://mb.com.ph/2026/11/11/quimbo-bill-seeks-p3000-monthly-pay-p1000-hazard-allowance-for-barangay-health-workers "Quimbo bill seeks P3,000 monthly pay, P1,000 hazard allowance for barangay health workers")

[**Quimbo bill seeks P3,000 monthly pay, P1,000 hazard allowance for barangay health workers**](https://mb.com.ph/2026/11/11/quimbo-bill-seeks-p3000-monthly-pay-p1000-hazard-allowance-for-barangay-health-workers "Quimbo bill seeks P3,000 monthly pay, P1,000 hazard allowance for barangay health workers")

# More Stories

[![Manila Bulletin](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145877.webp)](https://mb.com.ph/2026/11/11/sms-tessie-sy-coson-uses-tiktok-to-spot-trends-heres-her-top-tip-for-small-businesses "SM's Tessie Sy-Coson uses TikTok to spot trends — Here's her top tip for small businesses")[**SM's Tessie Sy-Coson uses TikTok to spot trends — Here's her top tip for small businesses**](https://mb.com.ph/2026/11/11/sms-tessie-sy-coson-uses-tiktok-to-spot-trends-heres-her-top-tip-for-small-businesses "SM's Tessie Sy-Coson uses TikTok to spot trends — Here's her top tip for small businesses")

[![Manila Bulletin](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145871.webp)](https://mb.com.ph/2026/11/11/pnp-press-corps-holds-inaugural-medical-mission-for-media-practitioners "PNP Press Corps holds inaugural medical mission for media practitioners")[**PNP Press Corps holds inaugural medical mission for media practitioners**](https://mb.com.ph/2026/11/11/pnp-press-corps-holds-inaugural-medical-mission-for-media-practitioners "PNP Press Corps holds inaugural medical mission for media practitioners")

[![no-image](https://mb.com.ph/manilabulletin/uploads/global_files/no-image.jpg)](https://mb.com.ph/2026/11/11/adamson-stays-in-final-four-hunt-with-big-win-over-ateneo "Adamson stays in Final Four hunt with big win over Ateneo")[**Adamson stays in Final Four hunt with big win over Ateneo**](https://mb.com.ph/2026/11/11/adamson-stays-in-final-four-hunt-with-big-win-over-ateneo "Adamson stays in Final Four hunt with big win over Ateneo")

[![Manila Bulletin](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145870.webp)](https://mb.com.ph/2026/11/11/us-rate-hike-fears-push-psei-down-as-losses-erase-recent-gains "US rate hike fears push PSEi down as losses erase recent gains")[**US rate hike fears push PSEi down as losses erase recent gains**](https://mb.com.ph/2026/11/11/us-rate-hike-fears-push-psei-down-as-losses-erase-recent-gains "US rate hike fears push PSEi down as losses erase recent gains")

[![Manila Bulletin](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145869.webp)](https://mb.com.ph/2026/11/11/quimbo-bill-seeks-p3000-monthly-pay-p1000-hazard-allowance-for-barangay-health-workers "Quimbo bill seeks P3,000 monthly pay, P1,000 hazard allowance for barangay health workers")[**Quimbo bill seeks P3,000 monthly pay, P1,000 hazard allowance for barangay health workers**](https://mb.com.ph/2026/11/11/quimbo-bill-seeks-p3000-monthly-pay-p1000-hazard-allowance-for-barangay-health-workers "Quimbo bill seeks P3,000 monthly pay, P1,000 hazard allowance for barangay health workers")

* * *

### [Drive](https://mb.com.ph/category/drive)

# Try out your top new car choices at the Auto Focus Test Drive Festival

Browse and test drive for free

##### By [Inigo Roces](https://mb.com.ph/author/inigo-roces)

Published Nov 11, 2026 11:04 am \| Updated Nov 11, 2026 11:14 am

![Copy Link](https://mb.com.ph/manilabulletin/uploads/global_files/share-arrow.svg)[![X](https://mb.com.ph/manilabulletin/uploads/global_files/share-x.svg)](https://x.com/intent/tweet?url=https://mb.com.ph/2026/11/11/try-out-your-top-new-car-choices-at-the-auto-focus-test-drive-festival)[![Facebook](https://mb.com.ph/manilabulletin/uploads/global_files/share-facebook.svg)](https://www.facebook.com/sharer/sharer.php?u=https://mb.com.ph/2026/11/11/try-out-your-top-new-car-choices-at-the-auto-focus-test-drive-festival)[![Whatsapp](https://mb.com.ph/manilabulletin/uploads/global_files/share-whatsapp.svg)](viber://forward?text=https://mb.com.ph/2026/11/11/try-out-your-top-new-car-choices-at-the-auto-focus-test-drive-festival)

Those in the market for a new car will have an easier time comparing their choices with this unique event happening at the SM Mall of Asia Complex this week. That event is the Auto Focus Multi-Brand Test Drive Festival that gathers multiple automobile brands together in one venue to make the car buying experience much easier and more enjoyable.

![](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145635.webp)

The 2026 Auto Focus Multi-Brand Test Drive Festival gathers the country’s top automotive brands in one venue, with their booths, and top models side by side. This makes it easier for car shoppers to compare and even test drive their top new car choices back to back. It helps buyers sample all the vehicles in their list within the same day instead of visiting dealerships across the metropolis during the holiday rush.

![](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145637.webp)

Those in the market for a new car will have an easier time comparing their choices with this unique event happening at the SM Mall of Asia Complex this week. That event is the Auto Focus Multi-Brand Test Drive Festival that gathers multiple automobile brands together in one venue to make the car buying experience much easier and more enjoyable.

![](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145635.webp)

The 2026 Auto Focus Multi-Brand Test Drive Festival gathers the country’s top automotive brands in one venue, with their booths, and top models side by side. This makes it easier for car shoppers to compare and even test drive their top new car choices back to back. It helps buyers sample all the vehicles in their list within the same day instead of visiting dealerships across the metropolis during the holiday rush.

![](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145637.webp)

This event will be particularly vital for those looking into a hybrid or full electric vehicle. Under the theme, “Drive What’s Next,” the event features many of the latest hybrid, plug-in hybrid, and even fully-electric models on display and available for test drive. Buyers can ask staff on hand anything about these vehicles, with some brands even bringing samples of their chargers, battery and hybrid system mock-ups, as well as visual aids to better understand how these new systems work.

![](https://mb.com.ph/manilabulletin/uploads/images/2026/11/11/145636.webp)

If you’re already decided, you can also finalize the deal on the spot. Exhibitors will have special deals as well as freebies for those that choose to buy during the event. Get freebies, refreshments, or tokens just by going for a test drive or participating in the activities.

Joining this year’s event are 21 automotive marques. These are BAIC, BYD, Chery, Dongfeng, Ford, GAC, Geely, GWM, Hyundai, iCAUR, Jetour, Lexus, Lynk & Co, Kia, Morris Garages (MG), Nissan, Omoda and Jaecoo, Radar, Subaru, Toyota, and Xpeng.

The Auto Focus Multi-Brand Test Drive Festival happens from November 12–15, 2026, from 11 a.m.-9 p.m. at the SM Mall of Asia Concert Grounds. Admission is free.

Read More

* * *

[![Logo](https://mb.com.ph/manilabulletin/uploads/global_files/logo-manila-b.jpg)](https://mb.com.ph/)

###### Join Our Newsletters

Sign up by email to receive news.

SUBSCRIBE