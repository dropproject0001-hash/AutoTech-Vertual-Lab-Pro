Source: https://www.alientech-tools.com/en/accessories/kess3-adapter-for-denso-ecu-nec-76f00xx-board-type-b/
Title: Adapter for Denso ECU (NEC 76F00xx Board Type B) - Alientech
Fetched: 2026-11-11T10:09:11.885Z

![](https://cdn-cookieyes.com/assets/images/close.svg)

We value your privacy

We use cookies to enhance your browsing experience, serve personalised ads or content, and analyse our traffic. By clicking "Accept All", you consent to our use of cookies. [Cookie Policy](https://www.alientech-tools.com/cookie-policy/)

CustomiseReject AllAccept All

Customise Consent Preferences![](https://cdn-cookieyes.com/assets/images/close.svg)

We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.

The cookies that are categorised as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. ... Show more

For more information on how Google's third-party cookies operate and handle your data, see: [Google Privacy Policy](https://business.safety.google/privacy)

NecessaryAlways Active

Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.

- Cookie

\_\_cf\_bm

- Duration

1 hour

- Description

This cookie, set by Cloudflare, is used to support Cloudflare Bot Management.


- Cookie

elementor

- Duration

Never Expires

- Description

The website's WordPress theme uses this cookie. It allows the website owner to implement or change the website's content in real-time.


- Cookie

wp\_consent\_preferences

- Duration

1 month

- Description

WP Consent API sets this cookie to save users' consent choices for different types of cookies on the website. This ensures a tailored browsing experience by applying users preferences consistently across the visits.


- Cookie

wp\_consent\_statistics

- Duration

1 month

- Description

WP Consent API sets this cookie to collect anonymous data on website usage and help to analyze and enhance the sites' performance.


- Cookie

wp\_consent\_statistics-anonymous

- Duration

1 month

- Description

WP Consent API sets this cookie to understand how the website is used, which enables enhanced user content and services and respects privacy.


- Cookie

wp\_consent\_functional

- Duration

1 month

- Description

WP Consent API sets this cookie to remember user preferences for essential website functionalities, ensuring a seamless and personalized experience.


- Cookie

wp\_consent\_marketing

- Duration

1 month

- Description

WP Consent API sets this cookie to record user consent choices for marketing cookies. This ensures that users only receive advertisements tailored to their interests.


- Cookie

VISITOR\_PRIVACY\_METADATA

- Duration

6 months

- Description

YouTube sets this cookie to store the user's cookie consent state for the current domain.


- Cookie

rc::a

- Duration

Never Expires

- Description

This cookie is set by the Google recaptcha service to identify bots to protect the website against malicious spam attacks.


- Cookie

rc::c

- Duration

session

- Description

This cookie is set by the Google recaptcha service to identify bots to protect the website against malicious spam attacks.


- Cookie

cookieyes-\*

- Duration

1 year

- Description

CookieYes sets this cookie for consent solution management.


Functional

Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.

- Cookie

wp-wpml\_current\_language

- Duration

session

- Description

WordPress multilingual plugin sets this cookie to store the current language/language settings.


- Cookie

VISITOR\_INFO1\_LIVE

- Duration

6 months

- Description

A cookie set by YouTube to measure bandwidth that determines whether the user gets the new or old player interface.


- Cookie

ytidb::LAST\_RESULT\_ENTRY\_KEY

- Duration

Never Expires

- Description

The cookie ytidb::LAST\_RESULT\_ENTRY\_KEY is used by YouTube to store the last search result entry that was clicked by the user. This information is used to improve the user experience by providing more relevant search results in the future.


Analytics

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.

- Cookie

\_ga\_\*

- Duration

1 year 1 month 4 days

- Description

Google Analytics sets this cookie to store and count page views.


- Cookie

\_ga

- Duration

1 year 1 month 4 days

- Description

Google Analytics sets this cookie to calculate visitor, session and campaign data and track site usage for the site's analytics report. The cookie stores information anonymously and assigns a randomly generated number to recognise unique visitors.


- Cookie

\_fbp

- Duration

3 months

- Description

Facebook sets this cookie to display advertisements when either on Facebook or on a digital platform powered by Facebook advertising after visiting the website.


- Cookie

YSC

- Duration

session

- Description

YSC cookie is set by Youtube and is used to track the views of embedded videos on Youtube pages.


Performance

Performance cookies are used to understand and analyse the key performance indexes of the website which helps in delivering a better user experience for the visitors.

No cookies to display.

Advertisement

Advertisement cookies are used to provide visitors with customised advertisements based on the pages you visited previously and to analyse the effectiveness of the ad campaigns.

- Cookie

\_gcl\_au

- Duration

3 months

- Description

Google Tag Manager sets this cookie to experiment advertisement efficiency of websites using their services.


- Cookie

test\_cookie

- Duration

15 minutes

- Description

doubleclick.net sets this cookie to determine if the user's browser supports cookies.


- Cookie

IDE

- Duration

1 year 24 days 1 minute

- Description

Google DoubleClick IDE cookies store information about how the user uses the website to present them with relevant ads according to the user profile.


- Cookie

ttwid

- Duration

1 year

- Description

Tiktok sets this cookie to keep track of user authentication and session information.


Uncategorised

Other uncategorised cookies are those that are being analysed and have not been classified into a category as yet.

- Cookie

\_\_Secure-YNID

- Duration

6 months

- Description

Description is currently not available.


- Cookie

\_\_Secure-ROLLOUT\_TOKEN

- Duration

6 months

- Description

Description is currently not available.


- Cookie

\_\_Secure-YEC

- Duration

past

- Description

Description is currently not available.


- Cookie

msToken

- Duration

10 days

- Description

Description is currently not available.


Accept AllSave My PreferencesReject All

Powered by [![](https://cdn-cookieyes.com/assets/images/poweredbtcky.svg)](https://www.cookieyes.com/product/cookie-consent/?ref=cypbcyb&utm_source=cookie-banner&utm_medium=powered-by-cookieyes)

[Skip to content](https://www.alientech-tools.com/en/accessories/kess3-adapter-for-denso-ecu-nec-76f00xx-board-type-b/#content)

# Adapter for Denso ECU (NEC 76F00xx Board Type B)

![14AM00T16M_2](https://www.alientech-tools.com/wp-content/uploads/2026/06/14AM00T16M_2-1.webp)

![14AM00T16M](https://www.alientech-tools.com/wp-content/uploads/2026/06/14AM00T16M.webp)

![14AM00T16M_2](https://www.alientech-tools.com/wp-content/uploads/2026/06/14AM00T16M_2-1.webp)

![14AM00T16M](https://www.alientech-tools.com/wp-content/uploads/2026/06/14AM00T16M.webp)

Adapter board for use with the positioning frame for connection in Boot mode to Denso control units installed on Toyota vehicles and equipped with NEC76F00xx microcontrollers. It enables interfacing through direct contact with the control unit’s programming pads, allowing the programming operations supported by the KESS3 tool to be performed. To be used in combination with the positioning frame 14P800DIMA and the 16-way ribbon cable 144300T102. Equipped with a dedicated ENA signal connection, where required, and LEDs for illuminating the programming pads.

## Details

- SKU: 14AM00T16M
- Tools: KESS3

## Submit your application

## Download Alientech Suite