# Philippine ECU Reference Coverage and Verification Limits

**Research date:** 11 November 2026  
**Depth:** Deep, focused on technical-source eligibility and applicability  
**Sources consulted:** {{SOURCE_COUNT}} cited, fetched sources; additional rejected leads and failed fetches are preserved in the evidence registry

## Executive Summary

**No Philippine-specific ECU pin assignment passed the complete source and applicability checks in this research. The requested automotive-data coverage is therefore not complete.** Public searches located official service-information systems, Philippine owner/service channels, and tool-vendor documentation. They did not establish a publishable exact-match terminal table for the target Philippine vehicle configurations. This is a finding about the reviewed evidence, not a claim that authorized manuals do not exist.

The strongest finding is that an official source can still be the wrong source for the vehicle. Toyota Europe explicitly limits its service information to its European-market vehicles and directs other-market users to the relevant distributor. Isuzu's RMI FAQ similarly restricts its published information to European vehicles. Mitsubishi's North American portal explicitly covers US/Canadian vehicles. These independent manufacturer statements support a strict rule against transferring an overseas pinout to a Philippine vehicle merely because the model or engine name looks similar. [@toyota-eu-faq] [@mitsubishi-isuzu-03-isuzu-global-rmi-faq] [@mitsubishi-us-scope]

The app can responsibly provide a source directory, clearly labeled user transcripts, manual image observations, user-entered measurement records, and an explicitly idealized circuit calculator. None of these constitutes an independently verified Philippine ECU database, a physical test instrument, or a calibration certificate. Imported reviewer declarations must remain user declarations. The remaining data milestone requires an authenticated, applicable technical document, exact vehicle/ECU identity, connector-view interpretation, and permission appropriate to the proposed use.

## Background and Method

The research question was not simply whether a pinout image could be found. It was whether the evidence could establish who issued it, which exact vehicle and ECU it applies to, how the connector is viewed, what its symbols and test conditions mean, and whether the intended use of the document is permitted.

Five research scopes covered Toyota/Denso; Mitsubishi/Isuzu; Nissan/Honda/Suzuki; Ford/Hyundai/Kia; and Philippine market evidence plus MG/BYD/Geely. Two targeted follow-up scopes addressed Denso/ASEAN manuals and current access/tool-manufacturer sources. English and Filipino search variants were used. A final brand-by-brand news sweep was saved separately; it did not establish a replacement exact-match technical source.

Manufacturer-authored scope statements were treated as primary evidence about that manufacturer's own portal, not as independent confirmation of a pin table. Industry/media evidence was suitable for defining a research queue, not for validating wiring. Search snippets were retained as leads only for technical assignments. Unauthenticated reposts, inaccessible pages, and a Toyota terms page on a nonproduction subdomain were excluded from the report's controlling technical evidence. The registry records these exclusions rather than disguising them as successful validation.

## Key Findings

### 1. Market evidence helps prioritize research, not identify an ECU

GMA's reporting of 2025 Philippine vehicle sales distinguishes a wider industry estimate from the CAMPI–TMA member total. Those measures should not be silently mixed when calculating shares or selecting priorities. The article reports new sales; it does not provide an installed-fleet census or a fleet/private-use split. This report therefore does not turn recent sales into a definitive ranking of the vehicles a repair shop will encounter. [@market-chinese-01-ph-2025-sales]

The proposed research queue includes Toyota Vios/Hilux/Innova/Fortuner/Hiace; Mitsubishi Mirage/G4/Xpander/Montero Sport/Strada/Triton/L300; Ford Ranger/Everest; Nissan Navara/Terra/Almera; Isuzu D-Max/mu-X; and relevant Suzuki, Honda, Hyundai, Kia, MG, BYD, and Geely configurations. This is an implementation priority list, not a verified assignment of ECU manufacturers, part numbers, production years, or connector layouts.

### 2. Official technical portals have material regional limits

| Brand/source | What the reviewed source establishes | What remains unproved for this project |
|---|---|---|
| Toyota Europe | EWD/repair information for Toyota Europe's vehicles; directs other markets to their distributor. [@toyota-eu-faq] | Exact Philippine fitment, part/hardware match, connector view, and each terminal. |
| Toyota North America | TIS describes North American vehicle coverage; Toyota's support article describes repair publications with generally US-market scope. [@toyota-02-tis-market-coverage] [@toyota-01-official-repair-information] | Philippine Vios, Hilux, Innova, Fortuner, or Hiace applicability cannot be inferred from this portal description. |
| Mitsubishi North America | The portal expressly limits its service information to US/Canadian vehicles. [@mitsubishi-us-scope] | Philippine model/engine/transmission-specific terminal maps. |
| Isuzu RMI | Offers workshop manuals and electrical information, but its FAQ limits published coverage to Europe and directs other-market owners to a local dealer. [@mitsubishi-isuzu-03-isuzu-global-rmi-faq] | Philippine D-Max/mu-X applicability and exact ECU identity. |
| Nissan TechInfo | The fetched publication site identifies US/North American technical-information scope. [@japanese-02-nissan-techinfo-publications] | Philippine Navara, Terra, and Almera terminal maps. |
| Suzuki | Suzuki Switzerland identifies the fee-based European Service Portal for independent workshops. [@gapfill-access-suzuki-rmi] | A global or Philippine RMI entitlement and exact local-model applicability. |
| Ford | Ford directs users to Motorcraft Service with location selection; Ford Canada's page describes service-publication subscriptions. [@ford-us-access] [@ford-korean-04-ford-canada-scope] | Whether the selected service supports the exact Philippine Ranger/Everest configuration and the intended reuse. |
| Hyundai/GIT | The GDS-Smart support page identifies tool-user documentation in a regional support context. [@ford-korean-02-hyundai-git-scope] | Its regional heading does not establish H100/Accent/Starex Philippine wiring or ECU-document coverage. |
| Kia KGIS | The reviewed KGIS page expressly scopes its service information to US-sold vehicles. [@ford-korean-03-kia-kgis-us-scope] | Philippine K2500/Soluto coverage despite the system's “Global” name. |

These are attributed portal-scope findings, not populated pinouts. An exact controlled document could potentially establish a cross-market match, but that match must be evidenced, not assumed. Three different manufacturers' regional restrictions corroborate the general regional-risk finding; they do not corroborate one another's individual terminal assignments.

### 3. Philippine owner and service pages are useful access routes, not workshop diagrams

The reviewed local pages are useful for reaching the right organization, but their public-facing service content is not a substitute for an electrical troubleshooting manual.

| Brand | Reviewed local evidence | Narrow conclusion |
|---|---|---|
| Mitsubishi | Service guide and service-booking channel. [@mitsubishi-isuzu-01-mitsubishi-ph-service-guide] [@mitsubishi-isuzu-02-mitsubishi-book-service] | Maintenance and appointment routes were established; no terminal table was authenticated. |
| Isuzu | Owners information and dealer directory. [@mitsubishi-isuzu-04-isuzu-ph-owners] [@mitsubishi-isuzu-05-isuzu-ph-dealers] | A local escalation route exists; these pages did not supply an applicable ECU diagram. |
| Nissan | Philippine service overview. [@japanese-01-nissan-ph-service-overview] | Local aftersales information, not proof of public workshop-document access. |
| Honda | Local announcement describing digital service/inspection records. [@japanese-06-honda-ph-aftersales] | Does not establish a Philippine wiring library. American Honda SIS search leads were not accepted as Philippine applicability evidence. |
| Suzuki | Philippine Carry product page. [@japanese-05-suzuki-carry-ph] | Product presence is not a service-manual or ECU cross-reference. |
| Kia | Philippine manual/resources page. [@ford-korean-05-kia-philippines-resources] | Owner information and service support do not establish a K2500/Soluto terminal map. |
| MG | Philippine aftersales page. [@market-chinese-02-mg-aftersales] | A service/contact route, not an authenticated ECU repair-information catalogue. |
| BYD | Philippine warranty and service guidance. [@market-chinese-03-byd-warranty] | Consumer guidance is not a workshop procedure. Its qualified-personnel warning cannot be converted into an inferred HV repair procedure. |
| Geely | Philippine Care+ service page. [@market-chinese-04-geely-care] | Service/contact information, not ECU/wiring evidence. |

The precise negative finding is that no qualifying pinout was established from the reviewed pages and searches. It would be inaccurate to conclude that these manufacturers have no dealer-only, licensed, or otherwise authorized technical information.

### 4. Tool connection instructions and full harness maps are different evidence

Alientech's connection-method documentation describes application-specific Bench/Boot instructions, pinouts, diagrams, and operating steps in its suite. This establishes the existence of protocol-specific guidance, not a public universal Denso or Bosch pin map. Its Toyota/Denso adapter page identifies a microcontroller/board-family application, but does not establish an exact Philippine vehicle/ECU connector drawing. [@alientech-methods] [@gapfill-access-alientech-denso]

Abrites' manufacturer-hosted ECU Programming Tool manual includes connection documentation and stated copying conditions. It must be interpreted within the exact tool, ECU, cable, and procedure described. No Toyota Denso diagram meeting the complete identity, orientation, Philippine-fitment, and permitted-use checks was established by the follow-up search. A vendor's supported-brand list is not proof that every ECU in that brand has the same connections. [@gapfill-access-abrites-manual]

### 5. Availability and permission are separate checks

Toyota Europe's FAQ and Isuzu's RMI FAQ describe publication access while also restricting reproduction/publication of their materials. Access to a document must not be treated as automatic permission to redistribute its diagrams inside an app. A subscription also does not establish a match to the target vehicle. [@toyota-eu-faq] [@mitsubishi-isuzu-03-isuzu-global-rmi-faq]

No subscription was purchased, restricted account accessed, publisher contacted, or permission obtained in this work. Public reposts carrying manufacturer-like titles were not promoted into authoritative app data. This is particularly important when a search result has a convincing model name but lacks a controlled edition, revision, applicable market, or connector-view legend.

## Analysis

The appropriate unit of support is an exact, documented configuration, not a brand button. A brand can have an official service channel without the project possessing even one verified terminal assignment for it. Likewise, an engine family can be identified without proving the fitted ECU hardware, connector shell, pin numbering, harness variant, or test conditions.

A useful data record should therefore join the actual evidence to the identity of the configuration: model/chassis code, engine, production range/date, transmission and other relevant build distinctions, market, ECU part/hardware identifiers, document edition, diagram locator, connector identifier, connector-side view, and source terms. A physical label photo can help identify the ECU, but cannot by itself prove what a cavity does.

Coverage must be measured by documented assignments. If a source gives only selected power and communication connections, the result is a partial connection reference. Other cavities remain unknown. They cannot be rendered as “NC,” marked unpopulated, assigned zero volts, or colored as grounds merely to fill a complete-looking grid. A bench connection reference also cannot be silently expanded into injector, sensor, DTC, or internal PCB claims.

The same boundary applies to software behavior. A successful API call, a valid JSON schema, or a passing arithmetic test proves only that the software behaved as checked. It does not authenticate the source or independently verify the transcript. A user-supplied source declaration must not become an OEM certification. A value derived from an ideal resistor formula is a calculation; a number typed by a technician is an entered observation. Neither is a voltage acquired by this browser from an ECU.

The responsible near-term product is consequently a working manual/reference workstation with explicit coverage limits. That is useful functionality, but it is not completion of the requested Philippine ECU database. The absent vehicle-specific milestone should remain open until matching evidence is available.

## Limitations

No exact Philippine ECU pin table was accepted. No source document established a complete connector-side orientation and exact target variant suitable for a published profile. The reviewed web pages are a point-in-time source-access assessment, not an exhaustive catalogue of every OEM or authorized provider.

Honda technical-page fetches returned maintenance content; historical ServiceExpress snippets were not used to assert a documented transition date or Philippine SIS applicability. Denso-labelled documents found on third-party hosts remained unauthenticated reposts. A Toyota terms page on a QA subdomain was not treated as the controlling production contract. These attempts are preserved in the registry with their limitations.

Recent sales do not resolve older service-fleet prevalence. No physical ECU, meter, cable, or vehicle was tested. No warranty, repair, high-voltage, or calibration approval follows from this report. Publisher-specific access/reuse questions remain unresolved where an exact document has not been acquired.

## Recommendations

Start with one exact ECU that the shop actually services. Obtain a clear label/hardware photo and the vehicle's build/model code, engine, year/production date, transmission, and market specification. Full personal VIN or registration information is not necessary for a public app record; share sensitive identifiers only through an appropriate private channel when the OEM requires them.

Supply the applicable OEM EWD/repair-manual pages, including the title/edition, applicability section, connector-view legend, terminal table, and test conditions. Alternatively, approve investigation of an authorized licensed source after its vehicle coverage, account eligibility, price, and permitted use have been clarified. Account credentials must not be sent in chat.

Review each transcription against the actual page and connector orientation. Preserve source locators on each published pin, and document any incomplete or conflicting sections. Do not use a second website repeating the same unattributed image as independent verification. Leave unresolved values unknown and keep high-voltage/programming procedures outside the ordinary manual-review workflow.

Continue testing software workflows separately from technical-data acceptance. Report which create/edit/delete, save/reload, import/export, calculation, and API behaviors passed, but keep the Philippine-source milestone incomplete until a qualifying real profile can exercise the applicable vehicle-specific flows.

## Sources
{{SOURCES}}
