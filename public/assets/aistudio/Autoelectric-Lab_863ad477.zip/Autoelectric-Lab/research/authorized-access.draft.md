# Authorized technical-data access: Philippine ECU coverage

**Assessed:** 11 November 2026  
**Cited fetched sources:** {{SOURCE_COUNT}}  
**Status:** Feasible commercial integration routes identified; no licence obtained, no technical data imported, and no exact Philippine pinout accepted.

## Recommendation

Seek a written **coverage demonstration and application-licensing quote from Autodata and HaynesPro before buying anything**. Both publish integration routes appropriate to a software product. That is a stronger starting point than buying an ordinary workshop login and assuming it permits republishing technical information. Neither reviewed public route proves exact Philippine fitment or grants this app a licence. [@licensed-autodata-corporate-api] [@licensed-haynespro-canonical]

MotorData is a potentially relevant diagnostic-reference source, but its ordinary public EULA is not a suitable basis for copying data into this app. Its terms restrict copying/distribution and require written consent for redistribution. It also expressly disclaims a guarantee that all data is correct. A paid subscription is therefore neither an app-redistribution grant nor a promise of “100% truth.” [@licensed-motordata-agreement]

## Comparison

| Provider | What is actually documented | Remaining Philippine/app requirement | Suggested use now |
|---|---|---|---|
| **Autodata API** | The provider advertises a technical-data API, lists wiring diagrams among its API products, and states that its data is manufacturer-licensed. Its technical overview describes web-application integration, REST/JSON, and authentication; interactive evaluation requires an API key from its integration team. These are provider statements, not an independent certification of every datum. [@licensed-autodata-api] [@licensed-autodata-docs] [@licensed-autodata-interactive] | Written confirmation of Philippine/ASEAN model variants, ECU terminal-level coverage, source/revision/connector-view metadata, entitlement rules, permitted display/export/cache behaviour, and a commercial quote. Public brand/model totals do not prove any exact ECU match. | **First integration/licensing enquiry.** Do not request credentials or implement a public data proxy before scope and rights are agreed. |
| **HaynesPro / Infopro Digital Automotive** | The official product page describes Web Services, portal-to-portal integration and standalone licences as different delivery options. An official Australia/New Zealand partnership announcement describes selected interactive wiring diagrams and pin connections inside another workshop platform. [@licensed-haynespro-canonical] [@licensed-haynespro-tat-partnership] | Its European coverage marketing and ANZ example do not establish Philippine-specific coverage. Ask for an exact Philippine support matrix, an approved integration method, source metadata, end-user licensing and a quote. | **Parallel integration enquiry.** Portal-to-portal access may be an option if direct data redistribution is not licensed. Do not assume a retail licence covers Web Services. |
| **MotorData Automotive Electrics** | Official access options, a public model catalogue, and scanner-integration examples exist. The public EULA permits some viewing/local-file/printed use but places separate copying, redistribution and confidentiality restrictions on the software/data. Its commercial-use language also needs clarification for the intended application. [@licensed-motordata-access] [@licensed-motordata-models] [@licensed-motordata-integration] [@licensed-motordata-agreement] | Exact Philippine fitment and a separate written app-use agreement have not been established. Scanner integration examples do not grant this app the same agreement. | **Not approved for importing subscription data into the app.** Ask the publisher about a separate commercial agreement if its exact coverage proves useful. |
| **Bosch ESI[tronic]** | Bosch publishes an interactive vehicle-coverage checker. [@licensed-bosch-coverage] | The fetched checker did not establish a Philippine subscription offer, an exact ECU pin-table result, or app-redistribution/API rights. A global diagnostic-product claim is not enough. | Keep as a verification/access lead, not an approved embedded-data source. |

## What was deliberately not done

No provider was contacted; no enquiry was sent; no account or trial was created; no payment was made; no subscription content was accessed; and no API credential was requested.

No Philippines-specific application-licence price was established. Retail workshop offers, foreign-market trial prices and third-party reseller prices are not interchangeable with an API or redistribution agreement. A quote must identify territory, product/data modules, usage model, tax/currency, minimum term, renewal conditions and any setup fee.

The `haynespro.com/terms-of-use` URL resolved to Infopro's **product page**, not a controlling terms document. It was not accepted as licence permission. The canonical product page was fetched separately. The contact form's country list includes the Philippines, but that is only a contact option—not technical-coverage proof. [@licensed-haynespro-canonical] [@licensed-haynespro-contact]

## Acceptance criteria before any licensed record is enabled

1. **Fitment:** Obtain an exact Philippine/ASEAN applicability matrix, including production range, model/chassis, engine/transmission and ECU part/hardware identifiers where relevant. A shared model name or engine family is insufficient.
2. **Evidence:** Obtain a permitted sample showing connector-side orientation, cavity numbering, terminal function, test conditions and source/revision/diagram locator. Record incompleteness and conflicts rather than filling missing pins.
3. **Rights:** Confirm whether the agreement permits API retrieval, deep linking, authenticated/public display, local caching, printed/PDF and JSON exports, offline retention, and any AI processing. None of these permissions should be inferred from access to a workshop viewer.
4. **Access control:** Agree end-user and licence-count enforcement before exposing any licensed backend data. The current browser-local app does not authenticate users; a commercial integration cannot simply make protected data public.
5. **Quality process:** Independently compare a real pilot configuration against the licensed document, then test the app mapping. Licensing establishes permitted access, not universal factual correctness or a physical-hardware test result.
6. **Commercial approval:** Review the written quote and terms before authorizing a paid account, purchase or automatic renewal.

## Verified contact routes

- **Autodata:** Its official interactive API documentation directs enquiries to **customer-integration@autodata-group.com**. [@licensed-autodata-interactive]
- **HaynesPro/Infopro:** The official contact page lists an **Asia Pacific Contact** for company projects and quotations. Use that page to confirm the current regional contact or request forwarding to HaynesPro Web Services licensing. [@licensed-haynespro-contact]

Prepared enquiries are in **provider-inquiry-drafts.md**. They have **not been sent**. They request coverage and rights clarification, not an order or API credentials.

## Sources
{{SOURCES}}
