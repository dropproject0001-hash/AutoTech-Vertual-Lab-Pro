# Autoelectric Lab: software checks and coverage limits

Date: 11 November 2026

## What this release does

- Maintains a directory of source-access routes with regional and applicability caveats.
- Imports, validates, edits, exports, selects, and deletes browser-local user transcripts. These remain **USER_TRANSCRIPT**, not independently OEM verified.
- Displays only the connector pins actually transcribed, with source locators and a declared connector view. Omitted cavities are unknown, not automatically “NC.”
- Calculates current and power for an **ideal DC resistor**. It is not a vehicle-specific ECU simulation or a connected instrument.
- Creates manual image-review projects with observed component boxes, paths, notes, audit entries, and document-scoped editing.
- Records technician-entered values. Optional PASS/FAIL compares the entered value with the user's cited limits; it does not certify hardware.
- Keeps simulated values visibly separate from technician entries. Unassessed values are not counted as diagnosed faults.
- Produces unsigned observation PDFs and JSON exports. Unsupported PDF font characters are disclosed; JSON retains exact text.
- Preserves browser-local records across reloads, with explicit storage-error messages. PCB backups can be restored after validation. A raw recovery snapshot can preserve unreadable local data for manual recovery.
- Performs literal searches over the selected transcript without generating unsupported technical answers.

## Confirmed automated checks

| Check | Result | Scope |
|---|---|---|
| Regression suite | **39 passed, 0 failed** | Arithmetic, invalid inputs, reference validation, trust-status boundaries, variant identity, manual comparisons, unknown/fault counts, persistence failures, backup relationships, layer preferences, raw recovery, isolated record-deletion rules, and empty unsupported datasets. |
| Frontend TypeScript | Passed | Application source types. |
| API TypeScript | Passed | API routes and generated contract types. |
| Frontend production build | Passed | Vite compiled the application. A large-chunk advisory remains; it is not a build failure or a performance certification. |
| API health | Passed | Returns SOURCE_REVIEW_ONLY and technicalAnswersEnabled=false. |
| Chat validation/refusal | Passed | Missing/blank messages return 400; valid requests receive a source-required refusal, not invented technical answers. |
| Schematic validation/manual-only response | Passed | Missing/blank document names return 400; valid requests contain zero inferred components/nets and MANUAL_ONLY mode. |
| Desktop/mobile overview screenshots | Passed | 1440×1000 and 402×874; no visible crash or browser exception. This does not verify every interactive mobile screen. |

Repeat the regression suite with:

`pnpm --filter @workspace/autoelectric-lab test`

The suite's synthetic fixtures are clearly marked **software tests only**. They are not vehicle reference records and are never imported into the shipped catalogue.

## Browser journey results

The first browser pass confirmed image upload, actual 640×360 dimensions, no automatic inference, manual component creation, and an explicit statement that no voltage was measured or simulated.

It found a real obstruction: the component details panel covered the toolbar Edit control, and closing the panel originally cleared selection. This was repaired by adding an Edit action inside the details panel and separating panel visibility from selection.

**Continuation result:** passed. The browser confirmed component editing with a named reviewer and rationale; path/note creation and editing; reload persistence; JSON export and restore; actual decoded image dimensions after restore; manual project comparison; and project-level deletion/cleanup. The exported JSON was parsed, and the generated PDF was checked for a PDF header/trailer and its non-certification disclaimer.

Individual component/path/note deletion controls were inspected but not individually clicked in that browser journey. Their removal and relationship-preservation rules are covered directly by three regression tests using the same functions called by the UI. No new browser pass was claimed for those actions.

**Transcript-to-reading browser journey:** passed with an explicitly synthetic software fixture. It confirmed:

- Transcript validation, reviewer acknowledgment, saving as USER_TRANSCRIPT, editing/replacing, and deletion.
- Connector A and B pin 1 remained distinct; an omitted cavity stayed unknown, not NC.
- Exact reference lookup returned only literal fixture text and its locator; an unrelated query supplied no technical answer.
- The calculator displayed 0.1 A and 1.2 W for 12 V/120 ohm and logged a SIMULATED/UNVERIFIED value.
- A manual 0 V record with no limits stayed UNVERIFIED. Editing it to 0.5 V with a fixture-only 0–1 V range produced a comparison-only PASS.
- Both records survived reload and reselecting the same transcript.
- Actual JSON/PDF Blobs contained both record types, the correct context and non-certification wording; the PDF had a valid header/trailer.
- Changing only the ECU part number created a different active context without mixing earlier readings. All-context history retained the earlier records.
- Only the two test readings and unique test transcript were deleted, through their confirmations; no clear-all-storage action was used.

The 402×874 mobile navigation drawer and calculator layout were also inspected; the calculator was not recalculated at mobile size. No runtime crash was observed. The browser harness dismissed one replacement confirmation automatically; explicitly accepting it on retry succeeded. No application bug remained in this journey.

## Storage and format limits

- Data is browser-local, not synchronized to an account or cloud. Clearing site data can remove its only stored copy.
- Image review accepts PNG, JPEG, or WebP, up to 2 MB per image, maximum 12,000 pixels per edge and 40 megapixels.
- The reference importer is limited to 256 KB JSON; PCB backup restore is limited to 12 MB JSON.
- Restore validates relationships and embedded image URLs, then decodes images to obtain actual dimensions. Remote image URLs are not accepted in backups.
- Storage-quota and malformed-data failures do not count as successful durable saves. Preserve a JSON backup or raw recovery snapshot before repairing stored data.
- A raw recovery snapshot is a raw export for manual recovery, not an importable PCB project backup.
- After reloading, choose the saved transcript again to see its active-context readings. “Show history from all contexts” also exposes records whose transcript was removed. PDF exports remain active-context only.

## What is not complete or verified

**No exact Philippine ECU pinout has passed the full source/applicability review.** Vehicle-specific wiring diagrams and DTC procedures remain deliberately unavailable rather than fabricated.

No physical ECU, vehicle, meter, programming cable, CAN network, high-voltage system, or calibration procedure was tested. There is no instrument connection. Software tests, JSON validity, imported reviewer declarations, and successful PDF downloads cannot establish automotive truth.

The requested fully accurate vehicle-data coverage therefore remains incomplete. See **Philippine ECU Reference Coverage and Verification Limits** for the 26-source research, excluded evidence, regional restrictions, and the exact documentation needed next.
