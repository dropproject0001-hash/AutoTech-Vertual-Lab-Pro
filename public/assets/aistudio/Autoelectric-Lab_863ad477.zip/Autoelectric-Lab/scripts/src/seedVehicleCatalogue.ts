import { readFile } from "node:fs/promises";
import { db, ecuPinoutEvidenceTable, pool } from "@workspace/db";
import {
  vehicleCatalogueModelsTable,
  vehicleCatalogueSourcesTable,
} from "@workspace/db";

interface VehicleCatalogueSnapshot {
  snapshotDate: string;
  scope: string;
  sources: Array<{
    key: string;
    title: string;
    url: string;
    publisher: string;
    kind:
      | "OEM_PRODUCT_PAGE"
      | "OEM_OWNER_MANUAL_INDEX"
      | "OEM_CAMPAIGN_NOTICE";
    tier: 1 | 2 | 3;
    publicationDate: string | null;
    evidencePath: string;
    note: string;
  }>;
  models: Array<{
    modelKey: string;
    sourceKey: string;
    make: string;
    model: string;
    vehicleClass:
      | "CAR"
      | "VAN"
      | "PICKUP"
      | "MOTORCYCLE"
      | "MOTORCYCLE_OR_SCOOTER"
      | "TRUCK"
      | "BUS"
      | "PUBLIC_UTILITY_VEHICLE";
    recordKind:
      | "OEM_PRODUCT_PAGE"
      | "OEM_OWNER_MANUAL"
      | "OEM_CAMPAIGN_NOTICE";
    modelYearEvidence: string | null;
    observedOn: string;
    observationNote: string;
  }>;
}

const vehicleClasses = new Set([
  "CAR",
  "VAN",
  "PICKUP",
  "MOTORCYCLE",
  "MOTORCYCLE_OR_SCOOTER",
  "TRUCK",
  "BUS",
  "PUBLIC_UTILITY_VEHICLE",
]);

const sourceKinds = new Set([
  "OEM_PRODUCT_PAGE",
  "OEM_OWNER_MANUAL_INDEX",
  "OEM_CAMPAIGN_NOTICE",
]);

const recordKinds = new Set([
  "OEM_PRODUCT_PAGE",
  "OEM_OWNER_MANUAL",
  "OEM_CAMPAIGN_NOTICE",
]);

function isDateOnly(value: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(value);
}

async function seedVehicleCatalogue(): Promise<void> {
  const snapshotUrl = new URL(
    "../../research/vehicle-catalogue-snapshot.json",
    import.meta.url,
  );
  const snapshot = JSON.parse(
    await readFile(snapshotUrl, "utf8"),
  ) as VehicleCatalogueSnapshot;

  if (
    snapshot.scope !== "PARTIAL_PHILIPPINE_OEM_PAGE_OBSERVATIONS" ||
    !isDateOnly(snapshot.snapshotDate) ||
    snapshot.sources.length === 0 ||
    snapshot.models.length === 0
  ) {
    throw new Error("The vehicle-catalogue snapshot metadata is invalid.");
  }

  const sourceKeys = new Set(snapshot.sources.map((source) => source.key));
  const modelKeys = new Set<string>();

  for (const source of snapshot.sources) {
    if (
      !source.url.startsWith("https://") ||
      !source.title.trim() ||
      !source.publisher.trim() ||
      !source.note.trim() ||
      !source.evidencePath.startsWith("research/sources/") ||
      !sourceKinds.has(source.kind) ||
      ![1, 2, 3].includes(source.tier)
    ) {
      throw new Error(`Invalid source metadata for ${source.key}.`);
    }
    if (source.publicationDate && !isDateOnly(source.publicationDate)) {
      throw new Error(`Invalid publication date for ${source.key}.`);
    }
  }

  for (const model of snapshot.models) {
    if (
      !sourceKeys.has(model.sourceKey) ||
      !model.make.trim() ||
      !model.model.trim() ||
      !model.observationNote.trim() ||
      !isDateOnly(model.observedOn) ||
      !vehicleClasses.has(model.vehicleClass) ||
      !recordKinds.has(model.recordKind) ||
      modelKeys.has(model.modelKey)
    ) {
      throw new Error(`Invalid or duplicated model observation: ${model.modelKey}.`);
    }
    modelKeys.add(model.modelKey);
  }

  await db.transaction(async (tx) => {
    for (const source of snapshot.sources) {
      await tx
        .insert(vehicleCatalogueSourcesTable)
        .values({
          sourceKey: source.key,
          title: source.title,
          url: source.url,
          publisher: source.publisher,
          sourceKind: source.kind,
          tier: source.tier,
          publicationDate: source.publicationDate,
          evidencePath: source.evidencePath,
          observedOn: snapshot.snapshotDate,
          sourceScopeNote: source.note,
        })
        .onConflictDoNothing({
          target: vehicleCatalogueSourcesTable.sourceKey,
        });
    }

    for (const model of snapshot.models) {
      await tx
        .insert(vehicleCatalogueModelsTable)
        .values(model)
        .onConflictDoNothing({
          target: vehicleCatalogueModelsTable.modelKey,
        });
    }
  });

  const databaseModels = await db
    .select({ modelKey: vehicleCatalogueModelsTable.modelKey })
    .from(vehicleCatalogueModelsTable);
  const databaseModelKeys = new Set(databaseModels.map((row) => row.modelKey));
  const missingModels = snapshot.models
    .filter((model) => !databaseModelKeys.has(model.modelKey))
    .map((model) => model.modelKey);
  const anyAuthorizedPinouts = await db
    .select({ id: ecuPinoutEvidenceTable.id })
    .from(ecuPinoutEvidenceTable)
    .limit(1);

  console.log(
    JSON.stringify(
      {
        snapshotDate: snapshot.snapshotDate,
        sourcesSeeded: snapshot.sources.length,
        modelObservationsSeeded: snapshot.models.length,
        matchedModelRows: snapshot.models.length - missingModels.length,
        missingModelRows: missingModels.length,
        hasAnyAuthorizedEcuPinoutRow: anyAuthorizedPinouts.length > 0,
      },
      null,
      2,
    ),
  );

  if (missingModels.length > 0) {
    throw new Error("Some vehicle catalogue observations were not saved.");
  }
}

try {
  await seedVehicleCatalogue();
} catch (error) {
  console.error(
    "Vehicle catalogue seeding failed:",
    error instanceof Error ? error.message : "Unknown error",
  );
  process.exitCode = 1;
} finally {
  await pool.end();
}
