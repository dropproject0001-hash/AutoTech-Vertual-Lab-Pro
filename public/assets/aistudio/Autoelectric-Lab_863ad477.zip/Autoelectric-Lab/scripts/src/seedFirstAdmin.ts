import { createClerkClient } from "@clerk/backend";
import { appUsersTable, db, pool } from "@workspace/db";
import { eq } from "drizzle-orm";

async function seedFirstAdmin(): Promise<void> {
  if (process.env.NODE_ENV !== "development") {
    throw new Error("First-admin bootstrap is allowed only in development.");
  }

  const email = process.env.CLERK_FIRST_ADMIN_EMAIL?.trim().toLowerCase();
  const secretKey = process.env.CLERK_SECRET_KEY;
  if (!email || !secretKey) {
    throw new Error("First-admin bootstrap configuration is incomplete.");
  }

  const clerk = createClerkClient({ secretKey });
  const existingUsers = await clerk.users.getUserList({
    emailAddress: [email],
    limit: 10,
  });
  if (existingUsers.data.length > 1) {
    throw new Error("More than one matching sign-in account requires manual review.");
  }

  const user =
    existingUsers.data[0] ??
    (await clerk.users.createUser({
      emailAddress: [email],
      skipPasswordRequirement: true,
    }));

  if (
    !user.emailAddresses.some(
      (address) => address.emailAddress.toLowerCase() === email,
    )
  ) {
    throw new Error("The sign-in provider did not resolve the requested account.");
  }

  const [existingMembership] = await db
    .select()
    .from(appUsersTable)
    .where(eq(appUsersTable.clerkUserId, user.id))
    .limit(1);

  if (existingMembership) {
    if (
      existingMembership.role !== "ADMIN" ||
      !existingMembership.isActive
    ) {
      throw new Error("An existing role grant was changed; it was not restored.");
    }
    console.log("First administrator already has an active development grant.");
    return;
  }

  await db
    .insert(appUsersTable)
    .values({ clerkUserId: user.id, role: "ADMIN", isActive: true })
    .onConflictDoNothing();

  const [savedMembership] = await db
    .select({
      role: appUsersTable.role,
      isActive: appUsersTable.isActive,
    })
    .from(appUsersTable)
    .where(eq(appUsersTable.clerkUserId, user.id))
    .limit(1);

  if (savedMembership?.role !== "ADMIN" || !savedMembership.isActive) {
    throw new Error("The first administrator role could not be verified.");
  }

  console.log("First administrator provisioned in the development environment.");
}

try {
  await seedFirstAdmin();
} catch (error) {
  console.error(
    "First-admin provisioning failed:",
    error instanceof Error ? error.message : "Unknown error",
  );
  process.exitCode = 1;
} finally {
  await pool.end();
}
