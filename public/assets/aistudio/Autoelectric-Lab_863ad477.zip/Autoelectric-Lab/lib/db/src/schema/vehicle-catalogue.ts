import { createInsertSchema } from "drizzle-zod";
import {
  check,
  date,
  index,
  integer,
  pgEnum,
  pgTable,
  serial,
  text,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { z } from "zod/v4";

export const roadVehicleClassEnum = pgEnum("road_vehicle_class", [
  "CAR",
  "VAN",
  "PICKUP",
  "MOTORCYCLE",
  "MOTORCYCLE_OR_SCOOTER",
  "TRUCK",
  "BUS",
  "PUBLIC_UTILITY_VEHICLE",
]);

export const vehicleSourceKindEnum = pgEnum("vehicle_source_kind", [
  "OEM_PRODUCT_PAGE",
  "OEM_OWNER_MANUAL_INDEX",
  "OEM_CAMPAIGN_NOTICE",
]);

export const vehicleRecordKindEnum = pgEnum("vehicle_record_kind", [
  "OEM_PRODUCT_PAGE",
  "OEM_OWNER_MANUAL",
  "OEM_CAMPAIGN_NOTICE",
]);

export const vehicleCatalogueSourcesTable = pgTable(
  "vehicle_catalogue_sources",
  {
    sourceKey: text("source_key").primaryKey(),
    title: text("title").notNull(),
    url: text("url").notNull(),
    publisher: text("publisher").notNull(),
    sourceKind: vehicleSourceKindEnum("source_kind").notNull(),
    tier: integer("source_tier").notNull(),
    publicationDate: date("publication_date", { mode: "string" }),
    evidencePath: text("evidence_path").notNull(),
    observedOn: date("observed_on", { mode: "string" }).notNull(),
    sourceScopeNote: text("source_scope_note").notNull(),
    reuseStatus: text("reuse_status")
      .notNull()
      .default("SOURCE_LINK_ONLY_NO_REPRODUCTION_PERMISSION"),
  },
  (table) => [
    check(
      "vehicle_source_url_https",
      sql`${table.url} LIKE 'https://%'`,
    ),
    check(
      "vehicle_source_tier_range",
      sql`${table.tier} >= 1 AND ${table.tier} <= 3`,
    ),
    check(
      "vehicle_source_link_only",
      sql`${table.reuseStatus} = 'SOURCE_LINK_ONLY_NO_REPRODUCTION_PERMISSION'`,
    ),
  ],
);

export const vehicleCatalogueModelsTable = pgTable(
  "vehicle_catalogue_models",
  {
    modelKey: text("model_key").primaryKey(),
    sourceKey: text("source_key")
      .notNull()
      .references(() => vehicleCatalogueSourcesTable.sourceKey),
    make: text("make").notNull(),
    model: text("model").notNull(),
    vehicleClass: roadVehicleClassEnum("vehicle_class").notNull(),
    recordKind: vehicleRecordKindEnum("record_kind").notNull(),
    modelYearEvidence: text("model_year_evidence"),
    observedOn: date("observed_on", { mode: "string" }).notNull(),
    observationNote: text("observation_note").notNull(),
  },
  (table) => [
    index("vehicle_catalogue_models_make_idx").on(table.make),
    index("vehicle_catalogue_models_class_idx").on(table.vehicleClass),
    index("vehicle_catalogue_models_source_idx").on(table.sourceKey),
    uniqueIndex("vehicle_catalogue_models_source_name_uidx").on(
      table.sourceKey,
      table.make,
      table.model,
      table.vehicleClass,
    ),
    check("vehicle_catalogue_model_make_nonempty", sql`${table.make} <> ''`),
    check("vehicle_catalogue_model_name_nonempty", sql`${table.model} <> ''`),
  ],
);

export const ecuPinoutEvidenceTable = pgTable(
  "ecu_pinout_evidence",
  {
    id: serial("id").primaryKey(),
    modelKey: text("model_key")
      .notNull()
      .references(() => vehicleCatalogueModelsTable.modelKey),
    exactVariant: text("exact_variant").notNull(),
    modelYearRange: text("model_year_range").notNull(),
    ecuPartNumber: text("ecu_part_number").notNull(),
    connectorIdentifier: text("connector_identifier").notNull(),
    connectorOrientation: text("connector_orientation").notNull(),
    pinNumber: text("pin_number").notNull(),
    circuitFunction: text("circuit_function").notNull(),
    testConditions: text("test_conditions").notNull(),
    expectedValue: text("expected_value").notNull(),
    sourceKey: text("source_key")
      .notNull()
      .references(() => vehicleCatalogueSourcesTable.sourceKey),
    sourceEdition: text("source_edition").notNull(),
    sourceLocator: text("source_locator").notNull(),
    reuseStatus: text("reuse_status").notNull(),
    reviewedOn: date("reviewed_on", { mode: "string" }).notNull(),
  },
  (table) => [
    index("ecu_pinout_evidence_model_idx").on(table.modelKey),
    check(
      "ecu_pinout_reuse_must_be_authorized",
      sql`${table.reuseStatus} = 'APPLICATION_REUSE_AUTHORIZED'`,
    ),
    check(
      "ecu_pinout_exact_variant_required",
      sql`${table.exactVariant} <> '' AND ${table.modelYearRange} <> '' AND ${table.ecuPartNumber} <> '' AND ${table.connectorIdentifier} <> '' AND ${table.connectorOrientation} <> '' AND ${table.pinNumber} <> '' AND ${table.circuitFunction} <> '' AND ${table.testConditions} <> '' AND ${table.expectedValue} <> '' AND ${table.sourceEdition} <> '' AND ${table.sourceLocator} <> ''`,
    ),
  ],
);

export const insertVehicleCatalogueSourceSchema = createInsertSchema(
  vehicleCatalogueSourcesTable,
).omit({ publicationDate: true });
export const insertVehicleCatalogueModelSchema = createInsertSchema(
  vehicleCatalogueModelsTable,
);
export const insertEcuPinoutEvidenceSchema = createInsertSchema(
  ecuPinoutEvidenceTable,
);

export type InsertVehicleCatalogueSource = z.infer<
  typeof insertVehicleCatalogueSourceSchema
>;
export type InsertVehicleCatalogueModel = z.infer<
  typeof insertVehicleCatalogueModelSchema
>;
export type InsertEcuPinoutEvidence = z.infer<
  typeof insertEcuPinoutEvidenceSchema
>;

export type VehicleCatalogueSource =
  typeof vehicleCatalogueSourcesTable.$inferSelect;
export type VehicleCatalogueModel =
  typeof vehicleCatalogueModelsTable.$inferSelect;
export type EcuPinoutEvidence = typeof ecuPinoutEvidenceTable.$inferSelect;
