import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  check,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { z } from "zod/v4";

export const appUserRoleEnum = pgEnum("app_user_role", [
  "ADMIN",
  "EDITOR",
  "TECHNICIAN",
  "VIEWER",
]);

export const verificationStatusEnum = pgEnum("ecu_verification_status", [
  "OEM_VERIFIED",
  "HIGH_CONFIDENCE",
  "PARTIALLY_VERIFIED",
  "UNVERIFIED",
  "PENDING_REVIEW",
  "CONFLICTING_INFORMATION",
]);

export const reuseRightsStatusEnum = pgEnum("technical_reuse_rights_status", [
  "PENDING_RIGHTS",
  "LINK_ONLY",
  "APPLICATION_REUSE_AUTHORIZED",
  "NOT_AUTHORIZED",
]);

export const electricalClassificationEnum = pgEnum(
  "electrical_classification",
  ["POWER", "GROUND", "COMMUNICATION", "SENSOR", "ACTUATOR", "OTHER", "UNKNOWN"],
);

export const benchProcedureKindEnum = pgEnum("bench_procedure_kind", [
  "POWER_SUPPLY",
  "IGNITION_SUPPLY",
  "MAIN_GROUND",
  "SENSOR_GROUND",
  "CAN_H",
  "CAN_L",
  "K_LINE",
  "WAKE_UP",
  "COMMUNICATION",
  "OTHER",
]);

export const benchSafetyStatusEnum = pgEnum("bench_safety_status", [
  "NOT_REVIEWED",
  "BENCH_ONLY",
  "SAFETY_REVIEWED",
]);

export const technicalSourceKindEnum = pgEnum("technical_source_kind", [
  "OEM_SERVICE_MANUAL",
  "OEM_WIRING_DIAGRAM",
  "OEM_TECHNICAL_DOCUMENT",
  "LICENSED_REPAIR_DATABASE",
  "PUBLIC_TECHNICAL_ARTICLE",
  "TECHNICIAN_CONTRIBUTION",
  "OTHER",
]);

export const appUsersTable = pgTable("app_users", {
  clerkUserId: text("clerk_user_id").primaryKey(),
  role: appUserRoleEnum("role").notNull().default("VIEWER"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const technicalKnowledgeSourcesTable = pgTable(
  "technical_knowledge_sources",
  {
    id: text("id").primaryKey(),
    sourceName: text("source_name").notNull(),
    sourcePublisher: text("source_publisher").notNull(),
    documentTitle: text("document_title").notNull(),
    url: text("url").notNull(),
    kind: technicalSourceKindEnum("kind").notNull(),
    edition: text("edition"),
    pageOrSection: text("page_or_section"),
    localEvidencePath: text("local_evidence_path"),
    collectedOn: timestamp("collected_on", { withTimezone: true })
      .notNull()
      .defaultNow(),
    verificationStatus: verificationStatusEnum("verification_status")
      .notNull()
      .default("PENDING_REVIEW"),
    reuseRightsStatus: reuseRightsStatusEnum("reuse_rights_status")
      .notNull()
      .default("LINK_ONLY"),
    createdBy: text("created_by")
      .notNull()
      .references(() => appUsersTable.clerkUserId),
  },
  (table) => [
    uniqueIndex("technical_knowledge_sources_url_edition_uidx").on(
      table.url,
      table.edition,
    ),
    index("technical_knowledge_sources_kind_idx").on(table.kind),
    check(
      "technical_knowledge_sources_https",
      sql`${table.url} LIKE 'https://%'`,
    ),
    check(
      "technical_knowledge_sources_required_fields",
      sql`${table.sourceName} <> '' AND ${table.sourcePublisher} <> '' AND ${table.documentTitle} <> ''`,
    ),
  ],
);

export const ecuTechnicalRecordsTable = pgTable(
  "ecu_technical_records",
  {
    id: text("id").primaryKey(),
    identityKey: text("identity_key").notNull(),
    vehicleMake: text("vehicle_make").notNull(),
    vehicleModel: text("vehicle_model").notNull(),
    vehicleGeneration: text("vehicle_generation"),
    market: text("market").notNull().default("PH"),
    productionYearStart: integer("production_year_start"),
    productionYearEnd: integer("production_year_end"),
    engineCode: text("engine_code"),
    ecuManufacturer: text("ecu_manufacturer"),
    ecuModel: text("ecu_model"),
    ecuHardwareNumber: text("ecu_hardware_number"),
    ecuPartNumber: text("ecu_part_number"),
    connectorType: text("connector_type"),
    communicationProtocol: text("communication_protocol"),
    verificationStatus: verificationStatusEnum("verification_status")
      .notNull()
      .default("PENDING_REVIEW"),
    reuseRightsStatus: reuseRightsStatusEnum("reuse_rights_status")
      .notNull()
      .default("PENDING_RIGHTS"),
    sourceId: text("source_id")
      .notNull()
      .references(() => technicalKnowledgeSourcesTable.id),
    createdBy: text("created_by")
      .notNull()
      .references(() => appUsersTable.clerkUserId),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("ecu_technical_records_identity_uidx").on(table.identityKey),
    index("ecu_technical_records_vehicle_search_idx").on(
      table.vehicleMake,
      table.vehicleModel,
    ),
    index("ecu_technical_records_engine_code_idx").on(table.engineCode),
    index("ecu_technical_records_ecu_part_idx").on(table.ecuPartNumber),
    index("ecu_technical_records_ecu_hardware_idx").on(
      table.ecuHardwareNumber,
    ),
    check(
      "ecu_technical_records_vehicle_nonempty",
      sql`${table.vehicleMake} <> '' AND ${table.vehicleModel} <> '' AND ${table.market} <> ''`,
    ),
    check(
      "ecu_technical_records_identity_nonempty",
      sql`${table.identityKey} <> ''`,
    ),
    check(
      "ecu_technical_records_year_range",
      sql`${table.productionYearStart} IS NULL OR ${table.productionYearEnd} IS NULL OR ${table.productionYearStart} <= ${table.productionYearEnd}`,
    ),
  ],
);

export const ecuConnectorsTable = pgTable(
  "ecu_connectors",
  {
    id: text("id").primaryKey(),
    ecuRecordId: text("ecu_record_id")
      .notNull()
      .references(() => ecuTechnicalRecordsTable.id),
    connectorIdentifier: text("connector_identifier").notNull(),
    connectorType: text("connector_type"),
    connectorView: text("connector_view"),
    pinCount: integer("pin_count"),
    technicalNotes: text("technical_notes"),
    verificationStatus: verificationStatusEnum("verification_status")
      .notNull()
      .default("PENDING_REVIEW"),
    reuseRightsStatus: reuseRightsStatusEnum("reuse_rights_status")
      .notNull()
      .default("PENDING_RIGHTS"),
    sourceId: text("source_id")
      .notNull()
      .references(() => technicalKnowledgeSourcesTable.id),
    createdBy: text("created_by")
      .notNull()
      .references(() => appUsersTable.clerkUserId),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("ecu_connectors_record_identifier_uidx").on(
      table.ecuRecordId,
      table.connectorIdentifier,
    ),
    index("ecu_connectors_source_idx").on(table.sourceId),
    check(
      "ecu_connectors_identifier_nonempty",
      sql`${table.connectorIdentifier} <> ''`,
    ),
    check(
      "ecu_connectors_pin_count_positive",
      sql`${table.pinCount} IS NULL OR ${table.pinCount} > 0`,
    ),
  ],
);

export const ecuPinAssignmentsTable = pgTable(
  "ecu_pin_assignments",
  {
    id: text("id").primaryKey(),
    ecuRecordId: text("ecu_record_id")
      .notNull()
      .references(() => ecuTechnicalRecordsTable.id),
    connectorId: text("connector_id")
      .notNull()
      .references(() => ecuConnectorsTable.id),
    pinNumber: text("pin_number").notNull(),
    pinLocation: text("pin_location"),
    terminalDesignation: text("terminal_designation"),
    wireColor: text("wire_color"),
    wireStripeColor: text("wire_stripe_color"),
    electricalFunction: text("electrical_function"),
    voltageSpecification: text("voltage_specification"),
    signalType: text("signal_type"),
    classification: electricalClassificationEnum("classification")
      .notNull()
      .default("UNKNOWN"),
    communicationLine: text("communication_line"),
    sensorOrActuator: text("sensor_or_actuator"),
    technicalNotes: text("technical_notes"),
    verificationStatus: verificationStatusEnum("verification_status")
      .notNull()
      .default("PENDING_REVIEW"),
    reuseRightsStatus: reuseRightsStatusEnum("reuse_rights_status")
      .notNull()
      .default("PENDING_RIGHTS"),
    sourceId: text("source_id")
      .notNull()
      .references(() => technicalKnowledgeSourcesTable.id),
    createdBy: text("created_by")
      .notNull()
      .references(() => appUsersTable.clerkUserId),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("ecu_pin_assignments_connector_pin_uidx").on(
      table.connectorId,
      table.pinNumber,
    ),
    index("ecu_pin_assignments_record_idx").on(table.ecuRecordId),
    index("ecu_pin_assignments_source_idx").on(table.sourceId),
    check(
      "ecu_pin_assignments_pin_nonempty",
      sql`${table.pinNumber} <> ''`,
    ),
    check(
      "ecu_pin_assignments_reuse_authorized",
      sql`${table.reuseRightsStatus} = 'APPLICATION_REUSE_AUTHORIZED'`,
    ),
  ],
);

export const benchTestingProceduresTable = pgTable(
  "bench_testing_procedures",
  {
    id: text("id").primaryKey(),
    ecuRecordId: text("ecu_record_id")
      .notNull()
      .references(() => ecuTechnicalRecordsTable.id),
    procedureKind: benchProcedureKindEnum("procedure_kind").notNull(),
    procedureTitle: text("procedure_title").notNull(),
    equipment: jsonb("equipment").$type<string[]>().notNull().default([]),
    steps: jsonb("steps").$type<string[]>().notNull().default([]),
    expectedReadings: jsonb("expected_readings")
      .$type<Array<{ name: string; value: string; condition: string }>>()
      .notNull()
      .default([]),
    safetyNotes: text("safety_notes").notNull(),
    safetyStatus: benchSafetyStatusEnum("safety_status")
      .notNull()
      .default("NOT_REVIEWED"),
    verificationStatus: verificationStatusEnum("verification_status")
      .notNull()
      .default("PENDING_REVIEW"),
    reuseRightsStatus: reuseRightsStatusEnum("reuse_rights_status")
      .notNull()
      .default("PENDING_RIGHTS"),
    sourceId: text("source_id")
      .notNull()
      .references(() => technicalKnowledgeSourcesTable.id),
    createdBy: text("created_by")
      .notNull()
      .references(() => appUsersTable.clerkUserId),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("bench_testing_procedures_record_idx").on(table.ecuRecordId),
    check(
      "bench_testing_procedures_safety_evidence_required",
      sql`${table.safetyNotes} <> ''`,
    ),
    check(
      "bench_testing_procedures_reuse_authorized",
      sql`${table.reuseRightsStatus} = 'APPLICATION_REUSE_AUTHORIZED'`,
    ),
    check("bench_testing_procedures_title_nonempty", sql`${table.procedureTitle} <> ''`),
  ],
);

export const knowledgeRevisionEntityEnum = pgEnum("knowledge_revision_entity", [
  "ECU_RECORD",
  "CONNECTOR",
  "PIN_ASSIGNMENT",
  "BENCH_PROCEDURE",
]);

export const knowledgeRecordRevisionsTable = pgTable(
  "knowledge_record_revisions",
  {
    id: serial("id").primaryKey(),
    entityType: knowledgeRevisionEntityEnum("entity_type").notNull(),
    entityId: text("entity_id").notNull(),
    revisionNumber: integer("revision_number").notNull(),
    action: text("action").notNull(),
    snapshot: jsonb("snapshot").$type<Record<string, unknown>>().notNull(),
    changedBy: text("changed_by")
      .notNull()
      .references(() => appUsersTable.clerkUserId),
    changedAt: timestamp("changed_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("knowledge_record_revisions_entity_number_uidx").on(
      table.entityType,
      table.entityId,
      table.revisionNumber,
    ),
    index("knowledge_record_revisions_entity_idx").on(
      table.entityType,
      table.entityId,
    ),
  ],
);

export const knowledgeAuditLogTable = pgTable(
  "knowledge_audit_log",
  {
    id: serial("id").primaryKey(),
    actorClerkUserId: text("actor_clerk_user_id")
      .notNull()
      .references(() => appUsersTable.clerkUserId),
    action: text("action").notNull(),
    entityType: text("entity_type").notNull(),
    entityId: text("entity_id").notNull(),
    metadata: jsonb("metadata").$type<Record<string, string>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("knowledge_audit_log_entity_idx").on(
      table.entityType,
      table.entityId,
      table.createdAt,
    ),
    index("knowledge_audit_log_actor_idx").on(
      table.actorClerkUserId,
      table.createdAt,
    ),
  ],
);

export const insertEcuTechnicalRecordSchema = createInsertSchema(
  ecuTechnicalRecordsTable,
);
export const insertEcuConnectorSchema = createInsertSchema(ecuConnectorsTable);
export const insertEcuPinAssignmentSchema = createInsertSchema(
  ecuPinAssignmentsTable,
);
export const insertBenchTestingProcedureSchema = createInsertSchema(
  benchTestingProceduresTable,
);

export type AppUser = typeof appUsersTable.$inferSelect;
export type TechnicalKnowledgeSource =
  typeof technicalKnowledgeSourcesTable.$inferSelect;
export type EcuTechnicalRecord = typeof ecuTechnicalRecordsTable.$inferSelect;
export type EcuConnector = typeof ecuConnectorsTable.$inferSelect;
export type EcuPinAssignment = typeof ecuPinAssignmentsTable.$inferSelect;
export type BenchTestingProcedure =
  typeof benchTestingProceduresTable.$inferSelect;
